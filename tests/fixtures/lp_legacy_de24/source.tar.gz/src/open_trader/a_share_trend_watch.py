from __future__ import annotations

import hashlib
import json
import time as time_module
from collections.abc import Callable, Collection, Mapping
from contextlib import nullcontext
from dataclasses import dataclass
from datetime import datetime, time
from decimal import Decimal, InvalidOperation
from pathlib import Path
from uuid import uuid4
from zoneinfo import ZoneInfo

from .a_share_trend import AccountSnapshot, load_watch_events
from .daily_premarket import RunLock, send_notification_with_results
from .futu_quote import FutuQuoteClient, FutuQuoteError
from .futu_symbols import to_futu_symbol
from .notification_policy import (
    BROKER_LABELS,
    _numeric_detail,
    brief_zh_detail,
    group_order_alerts,
    render_attention,
    render_order_alert,
    render_protection_alert,
)
from .notifications import (
    CompositeNotifier,
    Notifier,
    XiaoaiSSHNotifier,
)


SHANGHAI = ZoneInfo("Asia/Shanghai")


@dataclass(frozen=True)
class AShareWatchResult:
    status: str
    watched_symbol_count: int
    trigger_count: int
    exception_count: int
    unknown_quote_count: int
    events_path: Path


def cn_session(now: datetime) -> str:
    local = now.astimezone(SHANGHAI).time()
    if local < time(9, 30):
        return "before"
    if local <= time(11, 30):
        return "morning"
    if local < time(13, 0):
        return "lunch"
    if local <= time(15, 0):
        return "afternoon"
    return "closed"


def append_watch_event(
    path: Path,
    *,
    symbol: str,
    trading_date: str,
    event_type: str,
    occurred_at: str,
    last_price: Decimal | None,
    active_line: Decimal | None,
    market: str = "",
    reason: str = "",
    channel: str = "",
    group_id: str = "",
    notification_title: str = "",
    notification_message: str = "",
    group_symbols: list[str] | None = None,
) -> dict[str, object]:
    path.parent.mkdir(parents=True, exist_ok=True)
    event = {
        "event_id": uuid4().hex,
        "symbol": symbol,
        "trading_date": trading_date,
        "event_type": event_type,
        "occurred_at": occurred_at,
        "last_price": None if last_price is None else str(last_price),
        "active_line": None if active_line is None else str(active_line),
    }
    if market:
        event["market"] = market
    if reason:
        event["reason"] = reason
    if channel:
        event["channel"] = channel
    if group_id:
        event["group_id"] = group_id
    if notification_title:
        event["notification_title"] = notification_title
    if notification_message:
        event["notification_message"] = notification_message
    if group_symbols is not None:
        event["group_symbols"] = group_symbols
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
    return event


def watch_a_share_protection(
    *,
    portfolio_path: Path,
    state_path: Path,
    events_path: Path,
    quote_client: object | None,
    close_quote_client: bool = True,
    notifier: Notifier,
    poll_seconds: float,
    reconnect_seconds: float,
    once: bool = False,
    quote_client_factory: Callable[[], object] | None = None,
    report_lock_path: Path | None = None,
    now_fn: Callable[[], datetime] = lambda: datetime.now(SHANGHAI),
    sleep_fn: Callable[[float], None] = time_module.sleep,
    market: str = "CN",
    market_label: str = "A股",
    broker_label: str = "东方财富",
    session_timezone: ZoneInfo = SHANGHAI,
    session_fn: Callable[[datetime], str] = cn_session,
    account_loader: Callable[..., AccountSnapshot],
    on_session_open: Callable[[str], None] | None = None,
    on_protection_trigger: Callable[[Mapping[str, object]], None] | None = None,
    send_trigger_feishu: bool = True,
    excluded_symbols: Collection[str] = (),
) -> AShareWatchResult:
    excluded = {symbol.strip().upper() for symbol in excluded_symbols}
    client = quote_client
    if quote_client_factory is None and client is not None:
        host = getattr(client, "host", None)
        port = getattr(client, "port", None)
        if isinstance(host, str) and isinstance(port, int):
            quote_client_factory = lambda: FutuQuoteClient(host=host, port=port)

    first_now = now_fn()
    trading_date = first_now.astimezone(session_timezone).date().isoformat()
    positions: dict[str, object] = {}
    active_lines: dict[str, Decimal | None] = {}
    trigger_events: dict[str, Mapping[str, object]] = {}
    alerted: set[str] = set()
    delivered_alerts_feishu: set[str] = set()
    delivered_alerts_macos: set[str] = set()
    reported_lines: set[str] = set()
    delivered_lines: set[str] = set()
    reported_quotes: set[str] = set()
    delivered_quotes: set[str] = set()

    trigger_count = exception_count = unknown_quote_count = 0
    calendar_checked = False
    interrupted = _monitor_interrupted(events_path)
    now = first_now

    def outcome(status: str, *, failed: bool = False) -> AShareWatchResult:
        nonlocal client
        result = _result(
            status,
            positions,
            trigger_count,
            exception_count + int(failed),
            unknown_quote_count,
            events_path,
        )
        if client is None or not close_quote_client:
            return result
        closing_client = client
        client = None
        try:
            _close(closing_client)
        except Exception:
            if not once:
                raise
            if status != "abnormal":
                result = _result(
                    "abnormal",
                    positions,
                    trigger_count,
                    exception_count + 1,
                    unknown_quote_count,
                    events_path,
                )
        return result

    def recover_monitor() -> None:
        nonlocal interrupted
        if interrupted:
            _record_recovery(
                events_path, notifier, trading_date, now,
                market_label=market_label,
            )
            interrupted = False

    try:
        while True:
            session = session_fn(now)
            if client is None:
                if quote_client_factory is None:
                    raise RuntimeError("quote client factory is required after interruption")
                try:
                    client = quote_client_factory()
                except FutuQuoteError as exc:
                    if not interrupted:
                        _record_interruption(
                            events_path, notifier, trading_date, now, str(exc),
                            market_label=market_label, broker_label=broker_label,
                        )
                        interrupted = True
                    if once and not close_quote_client:
                        raise
                    if once:
                        return outcome("abnormal", failed=True)
                    sleep_fn(reconnect_seconds)
                    now = now_fn()
                    continue

            if not calendar_checked:
                try:
                    trading_days = (
                        client.get_cn_trading_days(start=trading_date, end=trading_date)
                        if market == "CN"
                        else client.get_trading_days(
                            market=market, start=trading_date, end=trading_date
                        )
                    )
                except FutuQuoteError as exc:
                    if not interrupted:
                        _record_interruption(
                            events_path, notifier, trading_date, now, str(exc),
                            market_label=market_label, broker_label=broker_label,
                        )
                        interrupted = True
                    if once and not close_quote_client:
                        raise
                    failed_client = client
                    client = None
                    try:
                        _close(failed_client)
                    except Exception:
                        if not once:
                            raise
                    if once:
                        return outcome("abnormal", failed=True)
                    sleep_fn(reconnect_seconds)
                    now = now_fn()
                    continue
                calendar_checked = True
                if trading_date not in trading_days:
                    recover_monitor()
                    return outcome("holiday")

            _retry_pending_callback_feishu_groups(
                events_path=events_path,
                notifier=notifier,
                trading_date=trading_date,
                now=now,
                market=market,
            )
            if on_session_open is not None:
                exception_count += _run_review_callback(
                    on_session_open,
                    trading_date,
                    events_path=events_path,
                    trading_date=trading_date,
                    now=now,
                    notifier=notifier,
                    market=market,
                    market_label=market_label,
                    broker_label=broker_label,
                )
                _notify_trend_review_deadline(
                    data_dir=events_path.parents[1],
                    market=market,
                    trading_date=trading_date,
                    now=now,
                    events_path=events_path,
                    notifier=notifier,
                )

            if session == "closed":
                recover_monitor()
                return outcome("closed")
            if session == "before":
                opening = now.astimezone(session_timezone).replace(
                    hour=9, minute=30, second=0, microsecond=0
                )
                sleep_fn((opening - now.astimezone(session_timezone)).total_seconds())
                now = now_fn()
                continue
            if session == "lunch":
                afternoon = now.astimezone(session_timezone).replace(
                    hour=13, minute=0, second=0, microsecond=0
                )
                sleep_fn((afternoon - now.astimezone(session_timezone)).total_seconds())
                now = now_fn()
                continue

            try:
                with (
                    RunLock(report_lock_path)
                    if report_lock_path is not None
                    else nullcontext()
                ):
                    account = account_loader(
                        portfolio_path,
                        expected_date=trading_date,
                        timezone=session_timezone,
                    )
                    positions = {
                        item.symbol: item
                        for item in account.positions
                    }
                    active_lines = _load_active_lines(state_path)
                    prior_events = load_watch_events(events_path)
                    trigger_events = {
                        str(event.get("symbol", "")): event
                        for event in prior_events
                        if event.get("trading_date") == trading_date
                        and event.get("event_type") == "protection_triggered"
                    }
                    alerted = set(trigger_events)
                    delivered_alerts_feishu = {
                        str(event.get("symbol", ""))
                        for event in prior_events
                        if event.get("trading_date") == trading_date
                        and event.get("event_type")
                        == "protection_triggered_notification_delivered_feishu"
                    }
                    delivered_alerts_macos = {
                        str(event.get("symbol", ""))
                        for event in prior_events
                        if event.get("trading_date") == trading_date
                        and event.get("event_type")
                        == "protection_triggered_notification_delivered_macos"
                    }
                    reported_lines = {
                        str(event.get("symbol", ""))
                        for event in prior_events
                        if event.get("trading_date") == trading_date
                        and event.get("event_type") == "protection_line_missing"
                    }
                    reported_quotes = {
                        str(event.get("symbol", ""))
                        for event in prior_events
                        if event.get("trading_date") == trading_date
                        and event.get("event_type") == "quote_unknown"
                    }
            except Exception as exc:
                if once:
                    return outcome("abnormal", failed=True)
                if not isinstance(exc, RuntimeError) or str(exc) != (
                    "daily premarket run already active"
                ):
                    raise
                sleep_fn(poll_seconds)
                now = now_fn()
                continue

            callback_failures: list[Mapping[str, object]] = []
            for symbol, event in sorted(trigger_events.items()):
                if symbol not in positions:
                    continue
                if on_protection_trigger is not None:
                    exception_count += _run_review_callback(
                        on_protection_trigger,
                        event,
                        events_path=events_path,
                        trading_date=trading_date,
                        now=now,
                        notifier=notifier,
                        market=market,
                        market_label=market_label,
                        broker_label=broker_label,
                        failures=callback_failures,
                    )
                _deliver_trigger_notification(
                    events_path=events_path,
                    notifier=notifier,
                    trading_date=trading_date,
                    now=now,
                    symbol=symbol,
                    position_name=str(getattr(positions[symbol], "name", "")),
                    last_price=_optional_decimal(event.get("last_price")),
                    active_line=_optional_decimal(event.get("active_line")),
                    delivered_feishu=delivered_alerts_feishu,
                    delivered_macos=delivered_alerts_macos,
                    replay=True,
                    send_feishu=send_trigger_feishu,
                    market_label=market_label,
                    broker_label=broker_label,
                )

            comparable: dict[str, tuple[str, Decimal]] = {}
            for symbol in sorted(positions):
                if symbol in excluded:
                    continue
                active_line = active_lines.get(symbol)
                if active_line is None:
                    if symbol not in reported_lines:
                        append_watch_event(
                            events_path,
                            symbol=symbol,
                            trading_date=trading_date,
                            event_type="protection_line_missing",
                            occurred_at=now.isoformat(timespec="seconds"),
                            last_price=None,
                            active_line=None,
                        )
                        reported_lines.add(symbol)
                        exception_count += 1
                    continue
                comparable[to_futu_symbol(market, symbol)] = (symbol, active_line)

            if not comparable:
                _notify_review_callback_failure_groups(
                    events_path=events_path,
                    notifier=notifier,
                    trading_date=trading_date,
                    now=now,
                    market=market,
                    broker_label=broker_label,
                    failures=callback_failures,
                )
                recover_monitor()
                if once:
                    return outcome("completed")
                sleep_fn(poll_seconds)
                now = now_fn()
                continue

            try:
                snapshots = client.get_snapshots(sorted(comparable))
            except FutuQuoteError as exc:
                _notify_review_callback_failure_groups(
                    events_path=events_path,
                    notifier=notifier,
                    trading_date=trading_date,
                    now=now,
                    market=market,
                    broker_label=broker_label,
                    failures=callback_failures,
                )
                if not interrupted:
                    _record_interruption(
                        events_path, notifier, trading_date, now, str(exc),
                        market_label=market_label, broker_label=broker_label,
                    )
                    interrupted = True
                if once and not close_quote_client:
                    raise
                failed_client = client
                client = None
                try:
                    _close(failed_client)
                except Exception:
                    if not once:
                        raise
                if once:
                    return outcome("abnormal", failed=True)
                sleep_fn(reconnect_seconds)
                now = now_fn()
                continue
            snapshots_complete = comparable.keys() <= snapshots.keys()
            if snapshots_complete:
                recover_monitor()

            for futu_symbol, (symbol, active_line) in comparable.items():
                snapshot = snapshots.get(futu_symbol)
                if snapshot is None:
                    if symbol not in reported_quotes:
                        append_watch_event(
                            events_path,
                            symbol=symbol,
                            trading_date=trading_date,
                            event_type="quote_unknown",
                            occurred_at=now.isoformat(timespec="seconds"),
                            last_price=None,
                            active_line=active_line,
                        )
                        reported_quotes.add(symbol)
                        unknown_quote_count += 1
                    continue
                if snapshot.last_price > active_line:
                    continue
                if symbol not in alerted:
                    event = append_watch_event(
                        events_path,
                        symbol=symbol,
                        trading_date=trading_date,
                        event_type="protection_triggered",
                        occurred_at=now.isoformat(timespec="seconds"),
                        last_price=snapshot.last_price,
                        active_line=active_line,
                    )
                    alerted.add(symbol)
                    trigger_count += 1
                    if on_protection_trigger is not None:
                        exception_count += _run_review_callback(
                            on_protection_trigger,
                            event,
                            events_path=events_path,
                            trading_date=trading_date,
                            now=now,
                            notifier=notifier,
                            market=market,
                            market_label=market_label,
                            broker_label=broker_label,
                            failures=callback_failures,
                        )
                    _deliver_trigger_notification(
                        events_path=events_path,
                        notifier=notifier,
                        trading_date=trading_date,
                        now=now,
                        symbol=symbol,
                        position_name=str(getattr(positions[symbol], "name", "")),
                        last_price=snapshot.last_price,
                        active_line=active_line,
                        delivered_feishu=delivered_alerts_feishu,
                        delivered_macos=delivered_alerts_macos,
                        replay=False,
                        send_feishu=send_trigger_feishu,
                        market_label=market_label,
                        broker_label=broker_label,
                    )

            _notify_review_callback_failure_groups(
                events_path=events_path,
                notifier=notifier,
                trading_date=trading_date,
                now=now,
                market=market,
                broker_label=broker_label,
                failures=callback_failures,
            )

            if once:
                return outcome("completed" if snapshots_complete else "abnormal")
            sleep_fn(poll_seconds)
            now = now_fn()
    finally:
        if client is not None and close_quote_client:
            _close(client)


def _notify_trend_review_deadline(
    *,
    data_dir: Path,
    market: str,
    trading_date: str,
    now: datetime,
    events_path: Path,
    notifier: Notifier,
) -> None:
    deadline = time(15, 30) if market == "US" else time(10)
    timezone = ZoneInfo("America/New_York") if market == "US" else SHANGHAI
    if now.astimezone(timezone).time().replace(tzinfo=None) < deadline:
        return
    prior = load_watch_events(events_path)
    legacy_notified = {
        str(event.get("symbol") or "")
        for event in prior
        if event.get("event_type") == "trend_review_deadline_notified"
        and event.get("trading_date") == trading_date
    }
    labels = {
        "pending": "待执行",
        "submitted": "已提交",
        "partially_filled": "部分成交",
        "failed": "失败",
        "blocked": "受阻",
        "missed": "错过",
        "incomplete": "未完成",
    }
    root = (
        data_dir
        / "trend_review"
        / "ledgers"
        / market
        / "actions"
        / trading_date
    )
    events: list[Mapping[str, object]] = []
    for action_dir in sorted(root.glob("*")):
        event = _latest_valid_action(action_dir)
        if event is None:
            continue
        symbol = str(event.get("symbol") or "")
        status = str(event.get("status") or "")
        if not symbol or symbol in legacy_notified or status == "filled":
            continue
        events.append(event)

    delivered_non_feishu = legacy_notified | {
        str(event.get("symbol") or "")
        for event in prior
        if event.get("event_type")
        == "trend_review_deadline_notification_delivered_non_feishu"
        and event.get("trading_date") == trading_date
    }
    for event in events:
        symbol = str(event.get("symbol") or "")
        status = str(event.get("status") or "")
        if symbol in delivered_non_feishu:
            continue
        attempts = send_notification_with_results(
            notifier,
            f"趋势模拟执行未完成 · {trading_date}",
            f"{symbol} · {labels.get(status, '状态未知')}",
            channels={"macos", "xiaoai"},
        )
        if any(attempt.success for attempt in attempts):
            append_watch_event(
                events_path,
                symbol=symbol,
                trading_date=trading_date,
                event_type=(
                    "trend_review_deadline_notification_delivered_non_feishu"
                ),
                occurred_at=now.isoformat(timespec="seconds"),
                last_price=None,
                active_line=None,
                market=market,
                reason=status,
                channel="non_feishu",
            )

    for group in group_order_alerts(market, events):
        symbols = [item.symbol for item in group.items]
        group_id = _order_group_id(
            trading_date, market, group.side, group.status, symbols
        )
        title, message = render_order_alert(
            group,
            broker_label=BROKER_LABELS[market],
            trading_date=trading_date,
        )
        _send_persisted_feishu_group(
            events_path=events_path,
            notifier=notifier,
            trading_date=trading_date,
            now=now,
            market=market,
            status=group.status,
            event_prefix="trend_review_deadline_notification",
            group_id=group_id,
            symbols=symbols,
            title=title,
            message=message,
        )


def _latest_valid_action(action_dir: Path) -> Mapping[str, object] | None:
    for path in reversed(sorted(action_dir.glob("*.json"))):
        try:
            event = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            continue
        if isinstance(event, Mapping):
            return event
    return None


def _order_group_id(
    trading_date: str,
    market: str,
    side: str,
    status: str,
    symbols: list[str],
) -> str:
    identity = "|".join((
        trading_date,
        market,
        side,
        status,
        ",".join(sorted(symbols)),
    ))
    return hashlib.sha256(identity.encode("utf-8")).hexdigest()


def _run_review_callback(
    callback: Callable[[object], None],
    value: object,
    *,
    events_path: Path,
    trading_date: str,
    now: datetime,
    notifier: Notifier,
    market: str = "CN",
    market_label: str = "A股",
    broker_label: str = "东方财富",
    failures: list[Mapping[str, object]] | None = None,
) -> int:
    try:
        callback(value)
        return 0
    except Exception as exc:
        event = value if isinstance(value, Mapping) else {}
        append_watch_event(
            events_path,
            symbol=str(event.get("symbol") or ""),
            trading_date=trading_date,
            event_type="trend_review_callback_failed",
            occurred_at=now.isoformat(timespec="seconds"),
            last_price=_optional_decimal(event.get("last_price")),
            active_line=_optional_decimal(event.get("active_line")),
            market=market,
            reason=str(exc),
        )
        prior_events = load_watch_events(events_path)
        already_notified = any(
            event.get("event_type") == "trend_review_callback_failure_notified"
            and event.get("trading_date") == trading_date
            and event.get("reason") == str(exc)
            for event in prior_events
        )
        if not already_notified:
            attempts = send_notification_with_results(
                notifier,
                f"趋势模拟执行失败 · {trading_date}",
                str(exc),
                channels={"macos", "xiaoai"},
            )
            if any(attempt.success for attempt in attempts):
                append_watch_event(
                    events_path,
                    symbol=str(event.get("symbol") or ""),
                    trading_date=trading_date,
                    event_type="trend_review_callback_failure_notified",
                    occurred_at=now.isoformat(timespec="seconds"),
                    last_price=_optional_decimal(event.get("last_price")),
                    active_line=_optional_decimal(event.get("active_line")),
                    market=market,
                    reason=str(exc),
                )
        if failures is not None:
            failures.append({
                **event,
                "side": "sell",
                "status": "failed",
                "reason": str(exc),
            })
        else:
            _notify_review_callback_batch_failure(
                events_path=events_path,
                notifier=notifier,
                trading_date=trading_date,
                now=now,
                market=market,
                market_label=market_label,
                broker_label=broker_label,
                reason=str(exc),
            )
        return 1


def _notify_review_callback_batch_failure(
    *,
    events_path: Path,
    notifier: Notifier,
    trading_date: str,
    now: datetime,
    market: str,
    market_label: str,
    broker_label: str,
    reason: str,
) -> None:
    group_id = hashlib.sha256(
        f"{trading_date}|{market}|failed".encode("utf-8")
    ).hexdigest()
    title, message = render_attention(
        broker_label,
        f"{market_label}批次执行失败",
        trading_date,
        happened="趋势模拟批次执行失败",
        impact="相关订单状态需要人工核对",
        action="查看不可变动作账本与控制器日志",
        detail=brief_zh_detail(reason),
    )
    _send_persisted_feishu_group(
        events_path=events_path,
        notifier=notifier,
        trading_date=trading_date,
        now=now,
        market=market,
        status="failed",
        event_prefix="trend_review_callback_failure_notification",
        group_id=group_id,
        symbols=[],
        title=title,
        message=message,
    )


def _notify_review_callback_failure_groups(
    *,
    events_path: Path,
    notifier: Notifier,
    trading_date: str,
    now: datetime,
    market: str,
    broker_label: str,
    failures: list[Mapping[str, object]],
) -> None:
    for group in group_order_alerts(market, failures):
        symbols = [item.symbol for item in group.items]
        group_id = _order_group_id(
            trading_date, market, group.side, group.status, symbols
        )
        title, message = render_order_alert(
            group,
            broker_label=broker_label,
            trading_date=trading_date,
        )
        _send_persisted_feishu_group(
            events_path=events_path,
            notifier=notifier,
            trading_date=trading_date,
            now=now,
            market=market,
            status=group.status,
            event_prefix="trend_review_callback_failure_notification",
            group_id=group_id,
            symbols=symbols,
            title=title,
            message=message,
        )


def _send_persisted_feishu_group(
    *,
    events_path: Path,
    notifier: Notifier,
    trading_date: str,
    now: datetime,
    market: str,
    status: str,
    event_prefix: str,
    group_id: str,
    symbols: list[str],
    title: str,
    message: str,
) -> None:
    prior = [
        event
        for event in load_watch_events(events_path)
        if event.get("group_id") == group_id
        and str(event.get("event_type") or "").startswith(event_prefix)
    ]
    if any(
        event.get("event_type") in {
            f"{event_prefix}_delivered_feishu",
            f"{event_prefix}_exhausted_feishu",
        }
        for event in prior
    ):
        return
    attempt_count = sum(
        event.get("event_type") == f"{event_prefix}_attempted_feishu"
        for event in prior
    )
    if attempt_count >= 2:
        return
    first_attempt = next(
        (
            event
            for event in prior
            if event.get("event_type")
            == f"{event_prefix}_attempted_feishu"
        ),
        None,
    )
    if first_attempt is not None:
        title = str(first_attempt.get("notification_title") or title)
        message = str(first_attempt.get("notification_message") or message)
        stored_symbols = first_attempt.get("group_symbols")
        if isinstance(stored_symbols, list) and all(
            isinstance(symbol, str) for symbol in stored_symbols
        ):
            symbols = stored_symbols
    attempts = send_notification_with_results(
        notifier,
        title,
        message,
        channels={"feishu", "feishu_app"},
    )
    append_watch_event(
        events_path,
        symbol="",
        trading_date=trading_date,
        event_type=f"{event_prefix}_attempted_feishu",
        occurred_at=now.isoformat(timespec="seconds"),
        last_price=None,
        active_line=None,
        market=market,
        reason=status,
        channel="feishu",
        group_id=group_id,
        notification_title=title,
        notification_message=message,
        group_symbols=symbols,
    )
    if any(attempt.success for attempt in attempts):
        for symbol in symbols or [""]:
            append_watch_event(
                events_path,
                symbol=symbol,
                trading_date=trading_date,
                event_type=f"{event_prefix}_delivered_feishu",
                occurred_at=now.isoformat(timespec="seconds"),
                last_price=None,
                active_line=None,
                market=market,
                reason=status,
                channel="feishu",
                group_id=group_id,
            )
    elif attempt_count == 1:
        append_watch_event(
            events_path,
            symbol="",
            trading_date=trading_date,
            event_type=f"{event_prefix}_exhausted_feishu",
            occurred_at=now.isoformat(timespec="seconds"),
            last_price=None,
            active_line=None,
            market=market,
            reason=status,
            channel="feishu",
            group_id=group_id,
        )


def _retry_pending_callback_feishu_groups(
    *,
    events_path: Path,
    notifier: Notifier,
    trading_date: str,
    now: datetime,
    market: str,
) -> None:
    for prefix in (
        "trend_review_callback_failure_notification",
        "trend_review_deadline_notification",
    ):
        events = [
            event
            for event in load_watch_events(events_path)
            if event.get("trading_date") == trading_date
            and event.get("market") == market
            and str(event.get("event_type") or "").startswith(prefix)
        ]
        group_ids = {
            str(event.get("group_id") or "") for event in events
        } - {""}
        for group_id in sorted(group_ids):
            group_events = [
                event for event in events if event.get("group_id") == group_id
            ]
            attempts = [
                event
                for event in group_events
                if event.get("event_type") == f"{prefix}_attempted_feishu"
            ]
            if len(attempts) != 1 or any(
                event.get("event_type") in {
                    f"{prefix}_delivered_feishu",
                    f"{prefix}_exhausted_feishu",
                }
                for event in group_events
            ):
                continue
            attempt = attempts[0]
            title = attempt.get("notification_title")
            message = attempt.get("notification_message")
            symbols = attempt.get("group_symbols")
            if (
                not isinstance(title, str)
                or not isinstance(message, str)
                or not isinstance(symbols, list)
                or not all(isinstance(symbol, str) for symbol in symbols)
            ):
                continue
            _send_persisted_feishu_group(
                events_path=events_path,
                notifier=notifier,
                trading_date=trading_date,
                now=now,
                market=market,
                status=str(attempt.get("reason") or "failed"),
                event_prefix=prefix,
                group_id=group_id,
                symbols=symbols,
                title=title,
                message=message,
            )


def _deliver_trigger_notification(
    *,
    events_path: Path,
    notifier: Notifier,
    trading_date: str,
    now: datetime,
    symbol: str,
    position_name: str,
    last_price: Decimal | None,
    active_line: Decimal | None,
    delivered_feishu: set[str],
    delivered_macos: set[str],
    replay: bool,
    send_feishu: bool = True,
    market_label: str = "A股",
    broker_label: str = "东方财富",
) -> None:
    alert_title, alert_body = render_protection_alert(
        broker_label,
        market_label,
        symbol,
        last_price=last_price,
        active_line=active_line,
    )
    if replay:
        line_text = (
            _numeric_detail(active_line) if active_line is not None else "未知"
        )
        message = (
            f"今日已触发活动保护线 {line_text}；"
            "此前提醒未完整送达，建议动作：全部卖出（人工执行）"
        )
    else:
        message = alert_body
    trigger_notifications = (
        (
            {"feishu", "feishu_app"},
            "protection_triggered_notification_delivered_feishu",
            delivered_feishu,
            alert_title,
            alert_body,
        ),
    ) if send_feishu else ()
    for channels, event_type, delivered, title, body in (
        *trigger_notifications,
        (
            {"macos"},
            "protection_triggered_notification_delivered_macos",
            delivered_macos,
            f"{market_label}保护线触发 · {symbol}",
            message,
        ),
    ):
        if symbol in delivered:
            continue
        attempts = send_notification_with_results(
            notifier,
            title,
            body,
            channels=channels,
        )
        if any(attempt.success for attempt in attempts):
            append_watch_event(
                events_path,
                symbol=symbol,
                trading_date=trading_date,
                event_type=event_type,
                occurred_at=now.isoformat(timespec="seconds"),
                last_price=last_price,
                active_line=active_line,
            )
            delivered.add(symbol)

    if replay or not _has_xiaoai_notifier(notifier):
        return

    voice_body = (
        f"名称：{position_name}\n{alert_body}" if position_name else alert_body
    )
    attempts = send_notification_with_results(
        notifier,
        f"{market_label}保护线触发 · {symbol}",
        voice_body,
        channels={"xiaoai"},
    )
    if not attempts:
        return
    attempt = attempts[0]
    if attempt.suppressed:
        append_watch_event(
            events_path,
            symbol=symbol,
            trading_date=trading_date,
            event_type=(
                "protection_triggered_notification_suppressed_quiet_hours_xiaoai"
            ),
            occurred_at=now.isoformat(timespec="seconds"),
            last_price=last_price,
            active_line=active_line,
            market=market_label,
        )
        return
    reason = "" if attempt.success else "音箱连接或播放失败"
    append_watch_event(
        events_path,
        symbol=symbol,
        trading_date=trading_date,
        event_type=(
            "protection_triggered_notification_queued_xiaoai"
            if attempt.success
            else "protection_triggered_notification_failed_xiaoai"
        ),
        occurred_at=now.isoformat(timespec="seconds"),
        last_price=last_price,
        active_line=active_line,
        market=market_label,
        reason=reason,
    )


def _has_xiaoai_notifier(notifier: Notifier) -> bool:
    targets = (
        notifier._notifiers
        if isinstance(notifier, CompositeNotifier)
        else [notifier]
    )
    return any(isinstance(target, XiaoaiSSHNotifier) for target in targets)


def _load_active_lines(path: Path) -> dict[str, Decimal | None]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise ValueError("protection state is unreadable or malformed") from None
    if not isinstance(payload, Mapping) or payload.get("schema_version") != 1:
        raise ValueError("protection state has an invalid schema")
    positions = payload.get("positions")
    if not isinstance(positions, Mapping):
        raise ValueError("protection state positions must be an object")
    return {
        str(symbol): _optional_decimal(
            state.get("active_line") if isinstance(state, Mapping) else None
        )
        for symbol, state in positions.items()
    }


def _optional_decimal(value: object) -> Decimal | None:
    try:
        result = Decimal(str(value).strip())
    except (InvalidOperation, ValueError, AttributeError):
        return None
    return result if result.is_finite() else None


def _monitor_interrupted(events_path: Path) -> bool:
    for event in reversed(load_watch_events(events_path)):
        event_type = event.get("event_type")
        if event_type in {"monitor_interrupted", "monitor_recovered"}:
            return event_type == "monitor_interrupted"
    return False


def _record_interruption(
    events_path: Path,
    notifier: Notifier,
    trading_date: str,
    now: datetime,
    error: str,
    *,
    market_label: str = "A股",
    broker_label: str = "东方财富",
) -> None:
    append_watch_event(
        events_path,
        symbol="",
        trading_date=trading_date,
        event_type="monitor_interrupted",
        occurred_at=now.isoformat(timespec="seconds"),
        last_price=None,
        active_line=None,
    )
    send_notification_with_results(
        notifier,
        f"{market_label}价格监控中断",
        f"Futu OpenD 实时价格不可用：{error}\n请立即在{broker_label}人工核价。",
        channels={"macos", "xiaoai"},
    )


def _record_recovery(
    events_path: Path,
    notifier: Notifier,
    trading_date: str,
    now: datetime,
    *,
    market_label: str = "A股",
) -> None:
    append_watch_event(
        events_path,
        symbol="",
        trading_date=trading_date,
        event_type="monitor_recovered",
        occurred_at=now.isoformat(timespec="seconds"),
        last_price=None,
        active_line=None,
    )
    send_notification_with_results(
        notifier,
        f"{market_label}价格监控恢复",
        "Futu OpenD 实时价格已恢复，活动保护线监控继续运行。",
        channels={"macos", "xiaoai"},
    )


def _result(
    status: str,
    positions: Mapping[str, object],
    trigger_count: int,
    exception_count: int,
    unknown_quote_count: int,
    events_path: Path,
) -> AShareWatchResult:
    return AShareWatchResult(
        status=status,
        watched_symbol_count=len(positions),
        trigger_count=trigger_count,
        exception_count=exception_count,
        unknown_quote_count=unknown_quote_count,
        events_path=events_path,
    )


def _close(client: object) -> None:
    close = getattr(client, "close", None)
    if callable(close):
        close()
