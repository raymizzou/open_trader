from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, datetime, time
from decimal import Decimal
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Literal
from zoneinfo import ZoneInfo

from .notifications import Notifier
from .strategy_drawdown import (
    automatic_bootstrap_strategy_drawdown,
    recover_strategy_drawdown_state,
    strategy_drawdown_keys,
    strategy_drawdown_state_status,
)


REPORT_DIRECTORIES = {
    "CN": "trend_a_share",
    "HK": "trend_hk_phillips",
    "US": "trend_us_futu",
}
MARKET_TIMEZONES = {
    "CN": ZoneInfo("Asia/Shanghai"),
    "HK": ZoneInfo("Asia/Hong_Kong"),
    "US": ZoneInfo("America/New_York"),
}
_DRAWDOWN_FAILURE_LABELS = {
    "baseline_unavailable": "历史基线不可用",
    "parameter_mismatch": "策略参数与已登记版本不一致",
    "parameter_identity_missing": "策略参数身份缺失",
    "state_missing_recovery_failed": "回撤状态丢失且恢复失败",
    "state_corrupt_recovery_failed": "回撤状态损坏且恢复失败",
}


@dataclass(frozen=True)
class DrawdownMarketInput:
    market: str
    strategy_snapshot: Mapping[str, object]
    baseline_equity: Decimal | None
    source_date: str | None
    entry_eligible_from: str | None
    error: str = ""


@dataclass(frozen=True)
class FrozenBaselineLookup:
    status: Literal["available", "missing", "invalid"]
    equity: Decimal | None = None
    error: str = ""


def market_preflight_dates(
    market: str, *, now: datetime, trading_days: list[str]
) -> tuple[str, str]:
    settings = {
        "CN": (MARKET_TIMEZONES["CN"], time(9, 30), time(15)),
        "HK": (MARKET_TIMEZONES["HK"], time(9, 30), time(16)),
        "US": (MARKET_TIMEZONES["US"], time(9, 30), time(16)),
    }
    try:
        timezone, opened_at, closed_at = settings[market.strip().upper()]
    except KeyError:
        raise ValueError(f"unsupported drawdown preflight market: {market}") from None
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("drawdown preflight clock must be timezone-aware")
    local_now = now.astimezone(timezone)
    days = sorted({date.fromisoformat(value) for value in trading_days})
    completed = [
        day
        for day in days
        if datetime.combine(day, closed_at, timezone) <= local_now
    ]
    eligible = [
        day
        for day in days
        if datetime.combine(day, opened_at, timezone) > local_now
    ]
    if not completed or not eligible:
        raise ValueError(f"{market} trading calendar has no preflight boundary")
    return completed[-1].isoformat(), eligible[0].isoformat()


def load_frozen_baseline(
    reports_dir: Path,
    *,
    market: str,
    strategy_id: str,
    strategy_version: str,
    source_date: str,
) -> FrozenBaselineLookup:
    directory = reports_dir / REPORT_DIRECTORIES[market]
    candidates = [
        path
        for path in (
            directory / f"{source_date}.json",
            *directory.glob(f"{source_date}-r*.json"),
        )
        if path.is_file()
    ]
    if not candidates:
        return FrozenBaselineLookup(status="missing")
    for path in sorted(candidates, reverse=True):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            return FrozenBaselineLookup(
                status="invalid",
                error=f"unreadable frozen drawdown baseline: {path}",
            )
        if not isinstance(payload, dict):
            return FrozenBaselineLookup(
                status="invalid",
                error=f"invalid frozen drawdown baseline: {path}",
            )
        metadata = payload.get("metadata")
        strategy = payload.get("strategy_snapshot")
        if not (
            isinstance(metadata, dict)
            and str(metadata.get("market") or "").upper() == market
            and isinstance(strategy, dict)
        ):
            return FrozenBaselineLookup(
                status="invalid",
                error=f"invalid frozen drawdown baseline: {path}",
            )
        if (
            strategy.get("strategy_id") != strategy_id
            or strategy.get("strategy_version") != strategy_version
        ):
            continue
        account = payload.get("account")
        drawdown = payload.get("drawdown_summary")
        if not (
            isinstance(account, dict)
            and account.get("source_date") == source_date
            and isinstance(drawdown, dict)
            and drawdown.get("state_status") == "missing"
        ):
            return FrozenBaselineLookup(
                status="invalid",
                error=f"invalid frozen drawdown baseline: {path}",
            )
        try:
            equity = Decimal(str(account.get("net_value")))
        except Exception:
            return FrozenBaselineLookup(
                status="invalid",
                error=f"invalid frozen drawdown baseline: {path}",
            )
        if equity.is_finite() and equity > 0:
            return FrozenBaselineLookup(status="available", equity=equity)
        return FrozenBaselineLookup(
            status="invalid",
            error=f"invalid frozen drawdown baseline: {path}",
        )
    return FrozenBaselineLookup(status="missing")


def _latest_market_predecessor(
    data_dir: Path, market: str,
) -> tuple[str, str] | None:
    path = data_dir / "trend_drawdown" / "state.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, OSError, UnicodeError, json.JSONDecodeError):
        return None
    records = payload.get("records") if isinstance(payload, Mapping) else None
    candidates = [
        record
        for record in records or ()
        if isinstance(record, Mapping)
        and str(record.get("market") or "").upper() == market
    ]
    if not candidates:
        return None
    latest = max(
        candidates,
        key=lambda record: (
            str(record.get("updated_at") or ""),
            str(record.get("strategy_version") or ""),
        ),
    )
    strategy_id = str(latest.get("strategy_id") or "")
    strategy_version = str(latest.get("strategy_version") or "")
    if not strategy_id or not strategy_version:
        return None
    return strategy_id, strategy_version


def run_drawdown_preflight(
    *,
    data_dir: Path,
    reports_dir: Path,
    market_inputs: Mapping[str, DrawdownMarketInput],
    accepted_git_sha: str,
    actor: str,
    occurred_at: str,
    notifier: Notifier,
) -> dict[str, object]:
    initial_status = strategy_drawdown_state_status(data_dir)
    historical_ok = _any_frozen_report_has_healthy_drawdown(reports_dir)
    recovered = False
    recovery_details: dict[str, object] | None = None
    if initial_status == "corrupt" or initial_status == "missing" and historical_ok:
        try:
            recovery_details = recover_strategy_drawdown_state(
                data_dir, actor=actor, occurred_at=occurred_at
            )
            recovered = True
        except ValueError as exc:
            error = str(exc)
            failure_status = f"state_{initial_status}_recovery_failed"
            results = [
                {
                    "market": market,
                    "status": "failed",
                    "failure_status": failure_status,
                    "error": error,
                }
                for market in _ordered_markets(market_inputs)
            ]
            result = {"status": "failed", "markets": results}
            _sync_failure_alerts(data_dir, market_inputs, results, notifier)
            return result

    first_activation = initial_status == "missing" and not historical_ok
    existing_keys = strategy_drawdown_keys(data_dir)
    results: list[dict[str, object]] = []
    for market in _ordered_markets(market_inputs):
        item = market_inputs[market]
        if item.error:
            results.append(
                {"market": market, "status": "unavailable", "error": item.error}
            )
            continue
        strategy_id = str(item.strategy_snapshot.get("strategy_id") or "")
        strategy_version = str(
            item.strategy_snapshot.get("strategy_version") or ""
        )
        parameters = item.strategy_snapshot.get("parameters")
        if not isinstance(parameters, Mapping):
            results.append(
                {
                    "market": market,
                    "status": "failed",
                    "error": "strategy parameters are unavailable",
                }
            )
            continue
        key = (market, strategy_id, strategy_version)
        was_present = key in existing_keys
        reason = (
            "first_activation"
            if first_activation or not any(row[0] == market for row in existing_keys)
            else "new_strategy_version"
        )
        predecessor = (
            _latest_market_predecessor(data_dir, market)
            if reason == "new_strategy_version"
            else None
        )
        approved_predecessor = predecessor is not None
        if not was_present and (
            item.source_date is None or item.entry_eligible_from is None
        ) and not (item.baseline_equity is None and predecessor is None):
            results.append({
                "market": market,
                "status": "failed",
                "failure_status": "baseline_unavailable",
                "error": "completed-date frozen Futu baseline date is unavailable",
            })
            continue
        baseline_equity = item.baseline_equity
        if (
            not was_present
            and baseline_equity is None
            and not approved_predecessor
        ):
            if item.source_date is None or item.entry_eligible_from is None:
                results.append({
                    "market": market,
                    "status": "skipped",
                    "reason": "baseline_missing",
                    "source_date": item.source_date,
                })
                continue
            assert item.source_date is not None
            baseline = load_frozen_baseline(
                reports_dir,
                market=market,
                strategy_id=strategy_id,
                strategy_version=strategy_version,
                source_date=item.source_date,
            )
            if baseline.status == "missing":
                results.append({
                    "market": market,
                    "status": "skipped",
                    "reason": "baseline_missing",
                    "source_date": item.source_date,
                })
                continue
            if baseline.status == "invalid":
                results.append({
                    "market": market,
                    "status": "failed",
                    "failure_status": "baseline_invalid",
                    "error": baseline.error,
                })
                continue
            baseline_equity = baseline.equity
        try:
            decision = automatic_bootstrap_strategy_drawdown(
                data_dir,
                market=market,
                strategy_id=strategy_id,
                strategy_version=strategy_version,
                parameters=parameters,
                baseline_equity=baseline_equity,
                source_date=item.source_date,
                accepted_git_sha=accepted_git_sha,
                actor=actor,
                occurred_at=occurred_at,
                reason=reason,
                entry_eligible_from=item.entry_eligible_from,
                entry_date=_market_date(market, occurred_at),
                inherit_from=predecessor,
            )
        except (OSError, ValueError) as exc:
            error = str(exc)
            results.append(
                {
                    "market": market,
                    "status": "failed",
                    "failure_status": (
                        "parameter_mismatch"
                        if "parameters changed" in error
                        else "parameter_identity_missing"
                        if "parameter identity" in error
                        else "preflight_failed"
                    ),
                    "error": error,
                }
            )
            continue
        existing_keys.add(key)
        result_status = (
            "recovered" if recovered and was_present
            else "ready" if was_present
            else "bootstrapped"
        )
        result = {
            "market": market,
            "status": result_status,
            "state_status": decision["state_status"],
            "entry_allowed": decision["entry_allowed"],
            "high_water_mark": decision["high_water_mark"],
            "bootstrap_event": decision["bootstrap_event"],
            "recovery_event": decision["recovery_event"],
        }
        if result_status == "recovered" and recovery_details is not None:
            result["recovery"] = recovery_details
        results.append(result)
    statuses = {str(item["status"]) for item in results}
    overall = "failed" if "failed" in statuses else "unavailable" if "unavailable" in statuses else "ready"
    _sync_failure_alerts(data_dir, market_inputs, results, notifier)
    return {"status": overall, "markets": results}


def _sync_failure_alerts(
    data_dir: Path,
    market_inputs: Mapping[str, DrawdownMarketInput],
    results: list[dict[str, object]],
    notifier: Notifier,
) -> None:
    if getattr(notifier, "records_delivery", True) is False:
        return
    path = data_dir / "trend_drawdown/alerts.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        active = set(payload["active"])
        if not all(isinstance(item, str) for item in active):
            raise ValueError
    except (FileNotFoundError, OSError, UnicodeError, json.JSONDecodeError, KeyError, TypeError, ValueError):
        active = set()
    original = set(active)
    pending: list[tuple[str, str, str]] = []
    for result in results:
        market = str(result["market"])
        strategy = market_inputs[market].strategy_snapshot
        version = str(strategy.get("strategy_version") or "")
        prefix = f"{market}|{version}|"
        if result["status"] in {"ready", "bootstrapped", "recovered"}:
            active = {key for key in active if not key.startswith(prefix)}
            continue
        failure_status = result.get("failure_status")
        if result["status"] != "failed" or not failure_status:
            continue
        failure_status = str(failure_status)
        key = prefix + failure_status
        if key in active:
            continue
        pending.append((
            key,
            f"{market} {version}",
            _DRAWDOWN_FAILURE_LABELS.get(failure_status, "回撤预检失败"),
        ))
    if pending:
        affected = "、".join(label for _, label, _ in pending)
        details = "\n".join(
            f"- {label}：{reason}" for _, label, reason in pending
        )
        try:
            notifier.notify(
                "【需处理｜系统｜累计回撤状态阻断】",
                "\n".join([
                    "发生：累计回撤状态未通过部署预检",
                    (
                        f"影响：{affected} 暂停新开仓；"
                        "卖出和保护线继续运行"
                    ),
                    (
                        "现在做：让 Codex 检查回撤预检并重新部署；"
                        "不要手动解除限制"
                    ),
                    "",
                    "明细：",
                    details,
                ]),
            )
        except Exception:
            pass
        else:
            active.update(key for key, _, _ in pending)
    if active == original:
        return
    content = (
        json.dumps(
            {"active": sorted(active)},
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    try:
        with NamedTemporaryFile(
            "w", encoding="utf-8", delete=False, dir=path.parent
        ) as handle:
            handle.write(content)
            temp_path = Path(handle.name)
        temp_path.replace(path)
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def _ordered_markets(
    market_inputs: Mapping[str, DrawdownMarketInput],
) -> list[str]:
    return [market for market in ("CN", "HK", "US") if market in market_inputs]


def _market_date(market: str, occurred_at: str) -> str:
    return datetime.fromisoformat(occurred_at).astimezone(
        MARKET_TIMEZONES[market]
    ).date().isoformat()


def _any_frozen_report_has_healthy_drawdown(reports_dir: Path) -> bool:
    for market, directory in REPORT_DIRECTORIES.items():
        for path in (reports_dir / directory).glob("*.json"):
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, UnicodeError, json.JSONDecodeError):
                continue
            if not isinstance(payload, dict):
                continue
            metadata = payload.get("metadata")
            drawdown = payload.get("drawdown_summary")
            if (
                isinstance(metadata, dict)
                and str(metadata.get("market") or "").upper() == market
                and isinstance(drawdown, dict)
                and drawdown.get("state_status") == "ok"
            ):
                return True
    return False
