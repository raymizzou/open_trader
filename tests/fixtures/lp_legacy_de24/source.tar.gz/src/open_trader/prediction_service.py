from __future__ import annotations

import argparse
from concurrent.futures import Future
from http.cookies import SimpleCookie
from datetime import UTC, date, datetime
import ipaddress
import json
import logging
import os
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import secrets
import signal
import sqlite3
import subprocess
import threading
import time
from typing import Any, Callable, Mapping
from urllib.parse import parse_qs, urlparse

from .daily_premarket import build_notifier, load_env_config
from .llm_providers import PROVIDER_IDS, provider_credentials_configured, resolve_provider
from .prediction_read_model import (
    PREDICTION_HISTORY_KINDS,
    _prediction_safe_value,
    prediction_history_payload,
    prediction_state_payload,
    prediction_venues_payload,
)
from .prediction_n_leg_canary_report import build_canary_report
from .prediction_n_leg_confirm import NLegConfirmRejected, confirm_enqueue
from .prediction_n_leg_mode import NLegVersionConflict
from .prediction_release import load_prediction_release_manifest
from .prediction_runtime import PredictionRuntime
from .relation_catalog import RelationConflictError


_HISTORY_DEFAULT_LIMIT = 100
_HISTORY_MAX_LIMIT = 500
_RELATIONS_DEFAULT_LIMIT = 500
_MAX_JSON_BODY_BYTES = 1024 * 1024
_MAX_CONCURRENT_HTTP_REQUESTS = 8
_HISTORY_CACHE_SECONDS = 1.0
_HISTORY_WAIT_SECONDS = 5.0
_BUSY_BODY = b'{"error":"prediction service busy"}'
_READ_ONLY_ERROR = {
    "code": "shadow_read_only",
    "message": "Shadow Prediction Service is read-only",
}
#: Issue #60: machine-checkable code carried by the 410 body once the runtime
#: reports ``legacy_retired`` (reader fence >= ``N_LEG_READER_GENERATION``).
LEGACY_STRATEGY_REMOVED = "legacy_strategy_removed"
_LEGACY_STRATEGY_ENDPOINTS = frozenset(
    {
        "/api/prediction-arbitrage/preview",
        "/api/prediction-arbitrage/executions",
        "/api/prediction-arbitrage/mode",
        "/api/prediction-arbitrage/circuit-breaker/reset",
        "/api/prediction-arbitrage/cross-auto/pause",
    }
)
_N_LEG_PAUSE_PATHS = frozenset(
    {
        "/api/prediction-arbitrage/state",
        "/api/prediction-arbitrage/history",
        "/api/prediction-arbitrage/llm-provider",
        "/api/prediction-arbitrage/preview",
        "/api/prediction-arbitrage/executions",
        "/api/prediction-arbitrage/mode",
        "/api/prediction-arbitrage/circuit-breaker/reset",
        "/api/prediction-arbitrage/predict-allowance/cleanup",
        "/api/prediction-arbitrage/cross-auto/pause",
    }
)


def _is_n_leg_pause_path(path: str) -> bool:
    return path in _N_LEG_PAUSE_PATHS or path == "/api/prediction-arbitrage/relations" or path.startswith(
        "/api/prediction-arbitrage/relations/"
    ) or path.startswith("/api/prediction-arbitrage/n-leg/")


def _n_leg_paused(runtime: object) -> bool:
    return getattr(runtime, "n_leg_paused", False) is True


def _lp_projection_safe_value(value: object, *, key: str = "") -> object:
    """Sanitize LP projections while retaining explicit UNKNOWN nulls."""

    if isinstance(value, Mapping):
        result: dict[str, object] = {}
        for name, item in value.items():
            field = str(name)
            if _prediction_safe_value("safe-field", key=field) is None:
                continue
            result[field] = _lp_projection_safe_value(item, key=field)
        return result
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_lp_projection_safe_value(item, key=key) for item in value]
    return _prediction_safe_value(value, key=key)


class _PredictionHTTPServer(ThreadingHTTPServer):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._request_slots = threading.BoundedSemaphore(_MAX_CONCURRENT_HTTP_REQUESTS)
        self._http_load_lock = threading.Lock()
        self._http_active = 0
        self._overload_rejections = 0
        self._history_cache_hits = 0
        self._history_cache_misses = 0
        self._history_cache: dict[
            tuple[str, int, int], tuple[float, dict[str, object]]
        ] = {}
        self._history_flights: dict[
            tuple[str, int, int], Future[dict[str, object]]
        ] = {}
        self._busy_response = (
            b"HTTP/1.1 503 Service Unavailable\r\n"
            b"Content-Type: application/json; charset=utf-8\r\n"
            b"Content-Length: "
            + str(len(_BUSY_BODY)).encode("ascii")
            + b"\r\nRetry-After: 1\r\nConnection: close\r\n\r\n"
            + _BUSY_BODY
        )

    def process_request(self, request: object, client_address: object) -> None:
        if not self._request_slots.acquire(blocking=False):
            self._record_overload()
            try:
                request.sendall(self._busy_response)  # type: ignore[attr-defined]
            except OSError:
                pass
            finally:
                self.shutdown_request(request)  # type: ignore[arg-type]
            return
        self._record_admitted()
        try:
            super().process_request(request, client_address)  # type: ignore[arg-type]
        except BaseException:
            self._release_admitted()
            raise

    def process_request_thread(self, request: object, client_address: object) -> None:
        try:
            super().process_request_thread(request, client_address)  # type: ignore[arg-type]
        finally:
            self._release_admitted()

    def http_load_snapshot(self) -> dict[str, int]:
        with self._http_load_lock:
            return {
                "limit": _MAX_CONCURRENT_HTTP_REQUESTS,
                "active": self._http_active,
                "overload_rejections": self._overload_rejections,
                "history_cache_hits": self._history_cache_hits,
                "history_cache_misses": self._history_cache_misses,
            }

    def history_payload(
        self,
        key: tuple[str, int, int],
        compute: Callable[[], dict[str, object]],
    ) -> dict[str, object]:
        with self._http_load_lock:
            now = time.monotonic()
            for cache_key, (expires_at, _) in tuple(self._history_cache.items()):
                if expires_at <= now:
                    del self._history_cache[cache_key]
            cached = self._history_cache.get(key)
            if cached is not None:
                self._history_cache_hits += 1
                return cached[1]
            flight = self._history_flights.get(key)
            if flight is None:
                flight = Future()
                self._history_flights[key] = flight
                self._history_cache_misses += 1
                leader = True
            else:
                self._history_cache_hits += 1
                leader = False

        if not leader:
            return flight.result(timeout=_HISTORY_WAIT_SECONDS)
        try:
            payload = compute()
        except BaseException as exc:
            with self._http_load_lock:
                if self._history_flights.get(key) is flight:
                    del self._history_flights[key]
                    flight.set_exception(exc)
            raise
        with self._http_load_lock:
            self._history_cache[key] = (time.monotonic() + _HISTORY_CACHE_SECONDS, payload)
            if self._history_flights.get(key) is flight:
                del self._history_flights[key]
                flight.set_result(payload)
        return payload

    def _record_admitted(self) -> None:
        with self._http_load_lock:
            self._http_active += 1

    def _release_admitted(self) -> None:
        with self._http_load_lock:
            self._http_active -= 1
        self._request_slots.release()

    def _record_overload(self) -> None:
        with self._http_load_lock:
            self._overload_rejections += 1


def _require_loopback_host(host: str) -> None:
    if host == "localhost":
        return
    try:
        if ipaddress.ip_address(host).is_loopback:
            return
    except ValueError:
        pass
    raise ValueError("prediction service requires a loopback host")


def _runtime_metadata() -> dict[str, object]:
    cwd = Path.cwd().resolve()
    try:
        git_sha = subprocess.check_output(
            ["git", "-C", str(cwd), "rev-parse", "HEAD"], text=True
        ).strip()
        source_status = subprocess.check_output(
            [
                "git",
                "-C",
                str(cwd),
                "status",
                "--porcelain",
                "--untracked-files=all",
                "--",
                "src/open_trader",
            ],
            text=True,
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        git_sha = ""
        source_status = "unavailable"
    return {
        "pid": os.getpid(),
        "cwd": str(cwd),
        "git_sha": git_sha,
        "source_state": "clean" if not source_status else "dirty",
        "started_at": datetime.now().astimezone().isoformat(),
    }


def _shadow_evidence(runtime: PredictionRuntime) -> Mapping[str, object]:
    evidence = getattr(runtime, "shadow_evidence", {})
    return evidence if isinstance(evidence, Mapping) else {}


def _llm_provider_payload(runtime: PredictionRuntime) -> dict[str, object]:
    store = getattr(runtime, "store", None)
    monitor = getattr(runtime, "monitor", None)
    validator = getattr(monitor, "_relation_validator", None)
    snapshot = getattr(validator, "provider_snapshot", None)
    info: dict[str, object] = {}
    if callable(snapshot):
        try:
            candidate = snapshot()
            if isinstance(candidate, Mapping):
                info = dict(candidate)
        except Exception:
            info = {}
    credentials = provider_credentials_configured()
    usage: dict[str, dict[str, int]] = {}
    try:
        if store is not None:
            usage = store.llm_usage_24h_by_provider()
    except Exception:
        usage = {}
    models = info.get("models") if isinstance(info.get("models"), Mapping) else {}
    providers = [
        {
            "provider": provider,
            "model": str(models.get(provider, "")),
            "credentials_configured": bool(credentials.get(provider, False)),
            "usage_24h": usage.get(provider, {}),
        }
        for provider in PROVIDER_IDS
    ]
    return {
        "schema_version": "open_trader.prediction_service.llm_provider.v1",
        "selected": str(info.get("selected", "")),
        "default": str(info.get("default", "")),
        "fallback": str(info.get("fallback", "")),
        "providers": providers,
    }


def _is_available(runtime: PredictionRuntime) -> bool:
    evidence = _shadow_evidence(runtime)
    return (
        getattr(runtime, "state", None) == "RUNNING"
        and evidence.get("mode") == "shadow"
        and evidence.get("first_violation") is None
    )


def _is_production_available(runtime: PredictionRuntime) -> bool:
    return (
        getattr(runtime, "state", None) == "RUNNING"
        and getattr(runtime, "production_owner", False) is True
    )


def _query_int(query: Mapping[str, list[str]], key: str, default: int) -> int:
    raw = str(query.get(key, [str(default)])[0] or str(default))
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{key} must be a non-negative integer") from exc
    if value < 0 or (key == "limit" and value > _HISTORY_MAX_LIMIT):
        raise ValueError(f"{key} is outside the allowed range")
    if key == "limit" and value == 0:
        raise ValueError("limit must be positive")
    return value


def _object_value(payload: Mapping[str, object], key: str) -> Mapping[str, object]:
    value = payload.get(key)
    if not isinstance(value, Mapping):
        raise ValueError(f"{key} must be an object")
    return value


def create_prediction_server(
    *,
    runtime: PredictionRuntime,
    host: str = "127.0.0.1",
    port: int = 8769,
    session_token: str | None = None,
    csrf_token: str | None = None,
    runtime_metadata: Mapping[str, object] | None = None,
) -> ThreadingHTTPServer:
    _require_loopback_host(host)
    mode = str(getattr(runtime, "mode", _shadow_evidence(runtime).get("mode", "")))
    if mode not in {"shadow", "production"}:
        raise ValueError("prediction service mode is invalid")
    if mode == "production" and not _is_production_available(runtime):
        raise RuntimeError("production runtime is not ready")
    prediction_session = session_token or secrets.token_urlsafe(32)
    prediction_csrf = csrf_token or secrets.token_urlsafe(32)
    metadata = dict(runtime_metadata if runtime_metadata is not None else _runtime_metadata())

    class PredictionRequestHandler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def _send_json(
            self,
            status: HTTPStatus,
            payload: Mapping[str, object],
            *,
            set_session: bool = False,
        ) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            if set_session:
                self.send_header(
                    "Set-Cookie",
                    f"ot_prediction_session={prediction_session}; SameSite=Strict; HttpOnly; Path=/",
                )
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                return

        def _send_unavailable(self) -> None:
            self._send_json(
                HTTPStatus.SERVICE_UNAVAILABLE,
                {"error": f"{mode} runtime is unavailable"},
            )

        def _send_n_leg_paused(self) -> None:
            self._send_json(
                HTTPStatus.CONFLICT,
                {"error": "N_LEG_PAUSED", "error_code": "N_LEG_PAUSED"},
            )

        def _send_error(self, status: HTTPStatus, error: Exception) -> None:
            self._send_json(
                status,
                {
                    "status": "error",
                    "error_type": type(error).__name__,
                    "message": str(error),
                },
            )

        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            if parsed.path == "/healthz":
                evidence = _shadow_evidence(runtime)
                available = (
                    _is_available(runtime)
                    if mode == "shadow"
                    else _is_production_available(runtime)
                )
                self._send_json(
                    HTTPStatus.OK if available else HTTPStatus.SERVICE_UNAVAILABLE,
                    {
                        "schema_version": "open_trader.prediction_service.health.v1",
                        "module": "prediction_service",
                        "status": "running" if available else "unavailable",
                        "mode": mode,
                        "production_owner": (
                            getattr(runtime, "production_owner", False) is True
                        ),
                        "mutations": "prohibited" if mode == "shadow" else "enabled",
                        "runtime_state": str(getattr(runtime, "state", "")),
                        **metadata,
                        "code_root": str(Path(__file__).resolve().parent.parent),
                        "codex": evidence.get("codex", {}),
                        "first_violation": evidence.get("first_violation"),
                        "guard_attempts": evidence.get("guard_attempts", []),
                        "http_load": self.server.http_load_snapshot(),  # type: ignore[attr-defined]
                        "n_leg": (
                            {"status": "paused", "code": "N_LEG_PAUSED"}
                            if _n_leg_paused(runtime)
                            else {"status": "running", "code": "N_LEG_RUNNING"}
                        ),
                    },
                )
                return
            if _n_leg_paused(runtime) and _is_n_leg_pause_path(parsed.path):
                self._send_n_leg_paused()
                return
            relation_prefix = "/api/prediction-arbitrage/relations"
            if parsed.path == relation_prefix or parsed.path.startswith(relation_prefix + "/"):
                if (
                    mode == "shadow"
                    and not _is_available(runtime)
                    or mode == "production"
                    and not _is_production_available(runtime)
                ):
                    self._send_unavailable()
                    return
                catalog = getattr(runtime, "relation_catalog", None)
                if catalog is None:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": "relation catalog is unavailable"})
                    return
                try:
                    if parsed.path == relation_prefix:
                        query = parse_qs(parsed.query, keep_blank_values=True)
                        if set(query) - {"view", "limit", "offset"}:
                            raise ValueError("relation catalog query is invalid")
                        view = str(query.get("view", ["pending"])[0] or "pending")
                        limit = _query_int(query, "limit", _RELATIONS_DEFAULT_LIMIT)
                        offset = _query_int(query, "offset", 0)
                        rows = catalog.list(view)
                        self._send_json(
                            HTTPStatus.OK,
                            {
                                "view": view,
                                "pending_count": catalog.pending_count(),
                                "total": len(rows),
                                "items": rows[offset : offset + limit],
                            },
                        )
                    else:
                        version_id = parsed.path.removeprefix(relation_prefix + "/")
                        if not version_id or "/" in version_id:
                            raise ValueError("relation version path is invalid")
                        self._send_json(HTTPStatus.OK, catalog.detail(version_id))
                except ValueError as exc:
                    self._send_error(HTTPStatus.BAD_REQUEST, exc)
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            if parsed.path == "/api/prediction-arbitrage/llm-provider":
                if (
                    mode == "shadow"
                    and not _is_available(runtime)
                    or mode == "production"
                    and not _is_production_available(runtime)
                ):
                    self._send_unavailable()
                    return
                try:
                    self._send_json(HTTPStatus.OK, _llm_provider_payload(runtime))
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            auto_report_path = "/api/prediction-arbitrage/lp/auto/reports"
            if parsed.path == auto_report_path or parsed.path.startswith(auto_report_path + "/"):
                report_date = parsed.path[len(auto_report_path):].removeprefix("/") or None
                try:
                    if parsed.query or (report_date is not None and date.fromisoformat(report_date).isoformat() != report_date):
                        raise ValueError("LP report date is invalid")
                except ValueError as exc:
                    self._send_error(HTTPStatus.BAD_REQUEST, exc)
                    return
                if (mode == "shadow" and not _is_available(runtime)
                        or mode == "production" and not _is_production_available(runtime)):
                    self._send_unavailable()
                    return
                # Stale clients receive an explicit pause without DB/venue reads.
                self._send_json(HTTPStatus.OK, {
                    "state": "paused", "reason": "lp_auto_reporting_paused",
                })
                return
            lp_report_prefix = "/api/prediction-arbitrage/lp/reports/"
            if parsed.path.startswith(lp_report_prefix):
                report_date = parsed.path.removeprefix(lp_report_prefix)
                try:
                    parsed_date = date.fromisoformat(report_date)
                    if parsed_date.isoformat() != report_date or parsed.query:
                        raise ValueError("LP report date is invalid")
                except ValueError as exc:
                    self._send_error(HTTPStatus.BAD_REQUEST, exc)
                    return
                if (
                    mode == "shadow"
                    and not _is_available(runtime)
                    or mode == "production"
                    and not _is_production_available(runtime)
                ):
                    self._send_unavailable()
                    return
                execution = getattr(runtime, "execution", None)
                if execution is None or not callable(getattr(execution, "lp_report", None)):
                    self._send_json(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        {"error": "LP reports are unavailable"},
                    )
                    return
                try:
                    result = execution.lp_report(report_date)
                    if result is None:
                        self._send_json(HTTPStatus.NOT_FOUND, {"error": "LP report not found"})
                        return
                    safe_result = _lp_projection_safe_value(result)
                    if not isinstance(safe_result, Mapping):
                        raise RuntimeError("LP report result is invalid")
                    self._send_json(HTTPStatus.OK, safe_result)
                except ValueError as exc:
                    self._send_error(HTTPStatus.BAD_REQUEST, exc)
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            if parsed.path not in {
                "/api/prediction-arbitrage/venues",
                "/api/prediction-arbitrage/lp/account/trades",
                "/api/prediction-arbitrage/state",
                "/api/prediction-arbitrage/history",
                "/api/prediction-arbitrage/n-leg/mode",
                "/api/prediction-arbitrage/n-leg/report",
                "/api/prediction-arbitrage/lp/dashboard",
                "/api/prediction-arbitrage/lp/auto/state",
                "/api/prediction-arbitrage/lp/auto/reservations",
                "/api/prediction-arbitrage/lp/sessions/current",
            }:
                self._send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
                return
            if (
                mode == "shadow"
                and not _is_available(runtime)
                or mode == "production"
                and not _is_production_available(runtime)
            ):
                self._send_unavailable()
                return
            if parsed.path == "/api/prediction-arbitrage/venues":
                venues = prediction_venues_payload(
                    store=getattr(runtime, "store", None),
                    monitor=getattr(runtime, "monitor", None),
                    execution=getattr(runtime, "execution", None),
                    csrf_token="" if mode == "shadow" else prediction_csrf,
                    cross_venue_monitor=getattr(
                        runtime, "cross_venue_monitor", None
                    ),
                    n_leg_paused=_n_leg_paused(runtime),
                )
                venues["mode"] = mode
                venues["mutations"] = (
                    "prohibited" if mode == "shadow" else "enabled"
                )
                self._send_json(
                    HTTPStatus.OK,
                    venues,
                    set_session=mode == "production",
                )
                return
            if parsed.path == "/api/prediction-arbitrage/state":
                monitor = getattr(runtime, "monitor", None)
                refresh_metrics = getattr(monitor, "refresh_snapshot_metrics", None)
                if callable(refresh_metrics):
                    try:
                        refresh_metrics()
                    except Exception:
                        pass
                state_payload = prediction_state_payload(
                    store=getattr(runtime, "store", None),
                    monitor=getattr(runtime, "monitor", None),
                    execution=getattr(runtime, "execution", None),
                    csrf_token="" if mode == "shadow" else prediction_csrf,
                    cross_venue_monitor=getattr(runtime, "cross_venue_monitor", None),
                    relation_catalog=getattr(runtime, "relation_catalog", None),
                    n_leg_solutions=getattr(
                        runtime, "n_leg_solutions", lambda: []
                    )(),
                    n_leg_episodes=getattr(
                        runtime, "n_leg_episodes", lambda: {}
                    )(),
                    n_leg_metrics=getattr(
                        runtime, "n_leg_metrics", lambda: {}
                    )(),
                    observation_snapshot=getattr(
                        runtime, "observation_snapshot", lambda: None
                    )(),
                    legacy_retired=getattr(runtime, "legacy_retired", False) is True,
                )
                execution = getattr(runtime, "execution", None)
                lp_status = getattr(execution, "lp_status", None)
                if callable(lp_status):
                    try:
                        status_payload = lp_status()
                    except Exception as exc:
                        status_payload = {
                            "state": "error",
                            "error": type(exc).__name__,
                        }
                    if isinstance(status_payload, Mapping):
                        safe_status_payload = _prediction_safe_value(status_payload)
                        if not isinstance(safe_status_payload, Mapping):
                            safe_status_payload = {"state": "error"}
                        state_payload = {
                            **state_payload,
                            "lp_session": dict(safe_status_payload),
                        }
                self._send_json(
                    HTTPStatus.OK,
                    state_payload,
                    set_session=mode == "production",
                )
                return
            if parsed.path == "/api/prediction-arbitrage/lp/account/trades":
                try:
                    query = parse_qs(parsed.query)
                    result = runtime.execution.lp_account_trades_page(
                        offset=_query_int(query, "offset", 0),
                        limit=_query_int(query, "limit", 100))
                    self._send_json(HTTPStatus.OK, _lp_projection_safe_value(result))
                except ValueError as exc:
                    self._send_error(HTTPStatus.BAD_REQUEST, exc)
                except (AttributeError, sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            if parsed.path == "/api/prediction-arbitrage/lp/auto/reservations":
                try:
                    reader = getattr(getattr(runtime, "execution", None), "lp_auto_reservations", None)
                    if not callable(reader):
                        raise RuntimeError("LP reservation API is unavailable")
                    result = reader()
                    self._send_json(HTTPStatus.OK, _lp_projection_safe_value(result))
                except ValueError as exc:
                    self._send_error(HTTPStatus.BAD_REQUEST, exc)
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            if parsed.path == "/api/prediction-arbitrage/lp/auto/state":
                try:
                    self._send_json(HTTPStatus.OK, _lp_projection_safe_value(runtime.lp_auto_state()))
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            if parsed.path == "/api/prediction-arbitrage/lp/sessions/current":
                execution = getattr(runtime, "execution", None)
                if execution is None or not callable(getattr(execution, "lp_status", None)):
                    self._send_json(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        {"error": "LP execution service is unavailable"},
                    )
                    return
                try:
                    result = execution.lp_status()
                    safe_result = _prediction_safe_value(result)
                    if not isinstance(safe_result, Mapping):
                        raise RuntimeError("LP status result is invalid")
                    self._send_json(HTTPStatus.OK, safe_result)
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            if parsed.path == "/api/prediction-arbitrage/lp/dashboard":
                execution = getattr(runtime, "execution", None)
                if execution is None or not callable(getattr(execution, "lp_dashboard", None)):
                    self._send_json(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        {"error": "LP dashboard is unavailable"},
                    )
                    return
                try:
                    result = execution.lp_dashboard()
                    auto_state = getattr(runtime, "lp_auto_state", None)
                    if callable(auto_state) and mode != "shadow":
                        # The automatic order/intent list is paused on the dashboard.
                        result = {**result, "auto": auto_state(include_intents=False)}
                    safe_result = _lp_projection_safe_value(result)
                    if not isinstance(safe_result, Mapping):
                        raise RuntimeError("LP dashboard result is invalid")
                    self._send_json(HTTPStatus.OK, safe_result)
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            if parsed.path == "/api/prediction-arbitrage/n-leg/mode":
                try:
                    execution = getattr(runtime, "execution", None)
                    if execution is None or getattr(execution, "n_leg_mode_contract", None) is None:
                        raise RuntimeError("n-leg mode contract is unavailable")
                    self._send_json(HTTPStatus.OK, execution.n_leg_mode_contract())
                except ValueError as exc:
                    self._send_error(HTTPStatus.BAD_REQUEST, exc)
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            if parsed.path == "/api/prediction-arbitrage/n-leg/report":
                # Issue #65: read-only canary fact report over the EXISTING
                # N-leg tables. The builder opens the store file mode=ro and
                # injects no clock, so generated_at is the real request time.
                store = getattr(runtime, "store", None)
                if store is None:
                    self._send_json(
                        HTTPStatus.SERVICE_UNAVAILABLE,
                        {"error": "prediction store is unavailable"},
                    )
                    return
                try:
                    self._send_json(HTTPStatus.OK, build_canary_report(store))
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            try:
                query = parse_qs(parsed.query, keep_blank_values=True)
                kind = str(query.get("kind", [""])[0]).strip()
                limit = _query_int(query, "limit", _HISTORY_DEFAULT_LIMIT)
                offset = _query_int(query, "offset", 0)
                if kind not in PREDICTION_HISTORY_KINDS:
                    raise ValueError("kind must be signals, executions, or incidents")
            except ValueError as exc:
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return
            try:
                self._send_json(
                    HTTPStatus.OK,
                    self.server.history_payload(  # type: ignore[attr-defined]
                        (kind, limit, offset),
                        lambda: prediction_history_payload(
                            getattr(runtime, "store", None),
                            kind=kind,
                            limit=limit,
                            offset=offset,
                            monitor=getattr(runtime, "monitor", None),
                            execution=getattr(runtime, "execution", None),
                            cross_venue_monitor=getattr(runtime, "cross_venue_monitor", None),
                        ),
                    ),
                )
            except Exception:
                self._send_json(
                    HTTPStatus.SERVICE_UNAVAILABLE,
                    {"error": "prediction history unavailable"},
                )

        def do_POST(self) -> None:
            self.close_connection = True
            path = urlparse(self.path).path
            if _n_leg_paused(runtime) and _is_n_leg_pause_path(path):
                self._send_n_leg_paused()
                return
            if mode == "shadow" and path.startswith("/api/prediction-arbitrage/"):
                self._send_json(HTTPStatus.FORBIDDEN, _READ_ONLY_ERROR)
                return
            # Issue #60 final-review P1-1: the retired-mode legacy POSTs
            # answer 410 uniformly — including the cutover orchestrator's
            # unauthenticated live probe — so this refusal runs BEFORE
            # production auth. 410 is a refusal; endpoint existence is not
            # sensitive. Every gated path is also in the POST whitelist
            # below, so no unknown path can 410 instead of 404, and at
            # fence 1 (legacy_retired falsy) the gate is inert.
            if path in _LEGACY_STRATEGY_ENDPOINTS and (
                getattr(runtime, "legacy_retired", False) is True
            ):
                self._send_json(
                    HTTPStatus.GONE,
                    {
                        "error": "legacy strategy endpoints are retired",
                        "error_code": LEGACY_STRATEGY_REMOVED,
                    },
                )
                return
            if mode == "production" and path.startswith(
                "/api/prediction-arbitrage/"
            ):
                try:
                    self._require_production_auth()
                except PermissionError as exc:
                    self._send_error(HTTPStatus.FORBIDDEN, exc)
                    return
                if not _is_production_available(runtime):
                    self._send_unavailable()
                    return
            relation_prefix = "/api/prediction-arbitrage/relations"
            relation_mutation = path.startswith(relation_prefix + "/") or path == relation_prefix + "/change-set"
            if relation_mutation:
                try:
                    payload = self._read_json_body()
                    catalog = getattr(runtime, "relation_catalog", None)
                    if catalog is None:
                        raise RuntimeError("relation catalog is unavailable")
                    audit = self._audit_context()
                    actor = str(audit["actor"])
                    git_sha = str(audit["git_sha"])
                    if path == relation_prefix + "/change-set":
                        self._require_schema(payload, {"active", "candidate", "reason", "note", "confirm"})
                        if payload.get("confirm") is not True:
                            raise ValueError("confirm must be true")
                        active = self._relation_expected(_object_value(payload, "active"))
                        candidate = self._relation_expected(_object_value(payload, "candidate"))
                        result = catalog.replace(active, candidate, reason=self._required_string(payload, "reason"), note=self._optional_string(payload, "note"), actor=actor, git_sha=git_sha)
                    elif path == relation_prefix + "/approve-batch":
                        self._require_schema(payload, {"items", "confirm"})
                        if payload.get("confirm") is not True:
                            raise ValueError("confirm must be true")
                        items = payload.get("items")
                        if not isinstance(items, list) or not items:
                            raise ValueError("items must be a non-empty list")
                        for item in items:
                            if not isinstance(item, dict) or set(item) != {"version_id"}:
                                raise ValueError("each item must contain exactly version_id")
                            version_id = item.get("version_id")
                            if not isinstance(version_id, str) or not version_id.strip():
                                raise ValueError("version_id is required")
                        result = catalog.approve_many(items, actor=actor, git_sha=git_sha)
                    elif path == relation_prefix + "/revoke-batch":
                        if set(payload) - {"items", "reason", "note", "confirm"} or not {"items", "reason", "confirm"} <= set(payload):
                            raise ValueError("prediction request fields are invalid")
                        if payload.get("confirm") is not True:
                            raise ValueError("confirm must be true")
                        items = payload.get("items")
                        if not isinstance(items, list) or not items:
                            raise ValueError("items must be a non-empty list")
                        for item in items:
                            if not isinstance(item, dict) or set(item) != {"version_id"}:
                                raise ValueError("each item must contain exactly version_id")
                            version_id = item.get("version_id")
                            if not isinstance(version_id, str) or not version_id.strip():
                                raise ValueError("version_id is required")
                        result = catalog.revoke_many(
                            items,
                            reason=self._required_string(payload, "reason"),
                            note=self._optional_string(payload, "note"),
                            actor=actor,
                            git_sha=git_sha,
                        )
                    elif path == relation_prefix + "/auto-confirm-round":
                        self._require_confirm(payload)
                        runner = getattr(runtime, "relation_auto_confirm_runner", None)
                        if runner is None:
                            raise RuntimeError("relation auto-confirm is unavailable")
                        result = runner.run_round(git_sha=git_sha)
                    elif path == relation_prefix + "/stale-reject":
                        self._require_confirm(payload)
                        result = catalog.reject_stale_pending(actor=actor, git_sha=git_sha)
                    else:
                        suffixes = {"/approve", "/reject", "/revoke"}
                        suffix = next((item for item in suffixes if path.endswith(item)), "")
                        version_id = path[len(relation_prefix) + 1 : -len(suffix)] if suffix else ""
                        if not suffix or not version_id or "/" in version_id:
                            self._send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
                            return
                        expected = self._relation_expected(payload)
                        if expected["version_id"] != version_id:
                            raise ValueError("relation version path and body differ")
                        if suffix == "/approve":
                            self._require_schema(payload, set(expected) | {"confirm"})
                            if payload.get("confirm") is not True:
                                raise ValueError("confirm must be true")
                            result = catalog.approve(version_id, expected, actor=actor, git_sha=git_sha)
                        else:
                            self._require_schema(payload, set(expected) | {"reason", "note", "confirm"})
                            if payload.get("confirm") is not True:
                                raise ValueError("confirm must be true")
                            operation = catalog.reject if suffix == "/reject" else catalog.revoke
                            result = operation(version_id, expected, reason=self._required_string(payload, "reason"), note=self._optional_string(payload, "note"), actor=actor, git_sha=git_sha)
                    self._send_json(HTTPStatus.OK, result)
                except RelationConflictError as exc:
                    self._send_error(HTTPStatus.CONFLICT, exc)
                except OverflowError as exc:
                    self._send_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, {"error": str(exc)})
                except ValueError as exc:
                    self._send_error(HTTPStatus.BAD_REQUEST, exc)
                except (sqlite3.Error, OSError, RuntimeError) as exc:
                    self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})
                return
            lp_preview_path = "/api/prediction-arbitrage/lp/preview"
            lp_augment_preview_path = "/api/prediction-arbitrage/lp/augment/preview"
            lp_candidate_preview_path = (
                "/api/prediction-arbitrage/lp/candidates/preview"
            )
            lp_candidate_refresh_path = (
                "/api/prediction-arbitrage/lp/candidates/refresh"
            )
            lp_cancel_orders_path = "/api/prediction-arbitrage/lp/orders/cancel"
            # Issue 163: single-shot submit endpoints (UI no longer calls the
            # preview-then-confirm pair, which stays available unchanged).
            lp_submit_entry_path = "/api/prediction-arbitrage/lp/orders"
            lp_submit_augment_path = "/api/prediction-arbitrage/lp/augment"
            lp_sessions_prefix = "/api/prediction-arbitrage/lp/sessions/"
            lp_start_path = "/api/prediction-arbitrage/lp/sessions"
            lp_auto_prefix = "/api/prediction-arbitrage/lp/auto/"
            lp_auto_paths = {lp_auto_prefix + action for action in ("config", "enable", "pause", "resume", "reservations/release")}
            lp_stop_session: str | None = None
            if path.startswith(lp_sessions_prefix) and path.endswith("/stop"):
                candidate = path[len(lp_sessions_prefix) : -len("/stop")]
                if candidate and "/" not in candidate:
                    lp_stop_session = candidate
            lp_augment_session: str | None = None
            if path.startswith(lp_sessions_prefix) and path.endswith("/augment"):
                candidate = path[len(lp_sessions_prefix) : -len("/augment")]
                if candidate and "/" not in candidate:
                    lp_augment_session = candidate
            execution_mutation = path in {
                "/api/prediction-arbitrage/preview",
                "/api/prediction-arbitrage/executions",
            }
            if path not in {
                "/api/prediction-arbitrage/preview",
                "/api/prediction-arbitrage/executions",
                "/api/prediction-arbitrage/mode",
                "/api/prediction-arbitrage/circuit-breaker/reset",
                "/api/prediction-arbitrage/predict-allowance/cleanup",
                "/api/prediction-arbitrage/cross-auto/pause",
                "/api/prediction-arbitrage/n-leg/mode",
                "/api/prediction-arbitrage/n-leg/config",
                "/api/prediction-arbitrage/n-leg/scope",
                "/api/prediction-arbitrage/n-leg/orders/confirm",
                "/api/prediction-arbitrage/n-leg/incidents/acknowledge",
                "/api/prediction-arbitrage/n-leg/circuit-breaker/reset",
                "/api/prediction-arbitrage/llm-provider",
                lp_preview_path,
                lp_augment_preview_path,
                lp_candidate_preview_path,
                lp_candidate_refresh_path,
                lp_cancel_orders_path,
                lp_submit_entry_path,
                lp_submit_augment_path,
                lp_start_path,
            } and path not in lp_auto_paths and lp_stop_session is None and lp_augment_session is None:
                self._send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
                return
            try:
                payload = self._read_json_body()
                execution = getattr(runtime, "execution", None)
                if execution is None:
                    raise RuntimeError("prediction execution service is unavailable")
                audit = (
                    {}
                    if execution_mutation
                    else self._audit_context()
                )
                if path in lp_auto_paths:
                    if path == lp_auto_prefix + "reservations/release":
                        result = execution.lp_auto_release_reservations(payload, audit=audit)
                    elif path == lp_auto_prefix + "config":
                        timing_fields = {'round_interval_seconds', 'api_retry_interval_seconds', 'order_check_interval_seconds'}
                        trading = bool(set(payload) & {'budget_usd', 'target_buy_count', 'buy_price_level'})
                        expected = {"budget_usd", "target_buy_count"} if trading else set()
                        expected.update(set(payload) & timing_fields)
                        if not trading and not expected:
                            raise ValueError('auto_config_invalid')
                        if "buy_price_level" in payload:
                            expected.add("buy_price_level")
                        if "expected_config_version" in payload:
                            expected.add("expected_config_version")
                        self._require_schema(payload, expected)
                        result = execution.lp_auto_configure(payload, audit=audit)
                    else:
                        self._require_confirm(payload)
                        result = runtime.lp_auto_set_desired_running(
                            path != lp_auto_prefix + "pause", audit=audit
                        )
                elif path == "/api/prediction-arbitrage/llm-provider":
                    self._require_schema(payload, {"provider"})
                    provider = self._required_string(payload, "provider").strip().lower()
                    if provider not in PROVIDER_IDS:
                        raise ValueError(
                            "provider must be one of: " + ", ".join(PROVIDER_IDS)
                        )
                    store = getattr(runtime, "store", None)
                    if store is None:
                        raise RuntimeError("prediction store is unavailable")
                    store.set_llm_provider(
                        provider,
                        default=resolve_provider(
                            os.environ.get("OPEN_TRADER_PREDICTION_LLM_PROVIDER")
                        ),
                        audit=audit,
                    )
                    self._send_json(HTTPStatus.OK, _llm_provider_payload(runtime))
                    return
                elif path == lp_candidate_preview_path:
                    self._require_schema(
                        payload,
                        {"market_id", "condition_id", "token_id", "outcome"},
                    )
                    candidate_preview = getattr(execution, "lp_candidate_preview", None)
                    if not callable(candidate_preview):
                        raise RuntimeError("LP execution service is unavailable")
                    result = candidate_preview(payload)
                elif path == lp_cancel_orders_path:
                    selectors = [
                        name
                        for name in ("order_ids", "condition_id", "scope")
                        if name in payload
                    ]
                    if len(selectors) != 1:
                        raise ValueError(
                            "exactly one of order_ids, condition_id, scope is required"
                        )
                    self._require_schema(
                        payload, set(selectors) | {"confirm"}
                    )
                    if payload.get("confirm") is not True:
                        raise ValueError("confirm must be true")
                    order_ids_value = payload.get("order_ids")
                    if order_ids_value is not None and (
                        not isinstance(order_ids_value, list)
                        or not order_ids_value
                        or not all(
                            isinstance(item, str) and item.strip()
                            for item in order_ids_value
                        )
                    ):
                        raise ValueError(
                            "order_ids must be a non-empty list of strings"
                        )
                    scope_value = payload.get("scope")
                    if scope_value is not None and scope_value != "all":
                        raise ValueError("scope must be \"all\"")
                    lp_cancel = getattr(execution, "lp_cancel_orders", None)
                    if not callable(lp_cancel):
                        raise RuntimeError("LP execution service is unavailable")
                    result = lp_cancel(payload)
                elif path == lp_candidate_refresh_path:
                    if set(payload) - {"manual_recovery", "recovery_scope", "expected_generation"}:
                        raise ValueError("prediction request fields are invalid")
                    if "manual_recovery" in payload and type(payload["manual_recovery"]) is not bool:
                        raise ValueError("manual_recovery must be a boolean")
                    recovery_scope = payload.get("recovery_scope", "all")
                    expected_generation = payload.get("expected_generation")
                    if not isinstance(recovery_scope, str) or recovery_scope not in {"all", "global"}:
                        raise ValueError("recovery_scope must be all or global")
                    if {"recovery_scope", "expected_generation"} & set(payload) and payload.get("manual_recovery") is not True:
                        raise ValueError("recovery scope requires manual_recovery")
                    if recovery_scope == "global" and (
                        type(expected_generation) is not int or expected_generation < 1
                    ):
                        raise ValueError("positive expected preparation generation required")
                    if recovery_scope == "all" and "expected_generation" in payload:
                        raise ValueError("expected generation requires global recovery scope")
                    if payload.get("manual_recovery") is True:
                        recover = getattr(runtime, "recover_lp_preparation", None)
                        if not callable(recover):
                            self._send_json(
                                HTTPStatus.SERVICE_UNAVAILABLE,
                                {"error": "LP preparation recovery is unavailable"},
                            )
                            return
                        result = (
                            recover() if recovery_scope == "all"
                            else recover(scope="global", expected_generation=expected_generation)
                        )
                        safe_result = _lp_projection_safe_value(result)
                        if not isinstance(safe_result, Mapping):
                            raise RuntimeError("LP preparation recovery result is invalid")
                        self._send_json(HTTPStatus.OK, safe_result)
                        return
                    queue_refresh = getattr(
                        runtime, "queue_lp_candidate_refresh", None
                    )
                    if not callable(queue_refresh) or queue_refresh() is not True:
                        self._send_json(
                            HTTPStatus.SERVICE_UNAVAILABLE,
                            {"error": "LP candidate refresh is unavailable"},
                        )
                        return
                    self._send_json(
                        HTTPStatus.ACCEPTED, {"state": "queued"}
                    )
                    return
                elif path == lp_preview_path:
                    request_payload: Mapping[str, object]
                    if set(payload) == {"request"} and isinstance(payload.get("request"), Mapping):
                        request_payload = payload["request"]  # type: ignore[assignment]
                    else:
                        request_payload = payload
                    lp_preview = getattr(execution, "lp_preview", None)
                    if not callable(lp_preview):
                        raise RuntimeError("LP execution service is unavailable")
                    result = lp_preview(request_payload)
                elif path == lp_augment_preview_path:
                    # Issue 158: augment preflight locks quantity and the
                    # session entry price; the session id comes from the body.
                    self._require_schema(payload, {"session_id", "quantity"})
                    lp_augment_preview = getattr(execution, "lp_augment_preview", None)
                    if not callable(lp_augment_preview):
                        raise RuntimeError("LP execution service is unavailable")
                    result = lp_augment_preview(payload)
                elif path == lp_submit_entry_path:
                    # Issue 163: strict schema — eight required fields plus
                    # explicit optional fields; anything missing or extra is a
                    # 400 before the facade runs.  A non-decimal price or
                    # quantity raises through _normalize_request and lands
                    # here as a 400 with the reason.
                    lp_entry_required = {
                        "market_id",
                        "condition_id",
                        "token_id",
                        "outcome",
                        "price",
                        "quantity",
                        "review_at",
                        "idempotency_key",
                    }
                    lp_entry_optional = {
                        "candidate_policy",
                        "candidate_bid_level",
                        "estimated_target_quantity",
                    }
                    if not lp_entry_required <= set(payload) or set(payload) - lp_entry_required - lp_entry_optional:
                        raise ValueError("prediction request fields are invalid")
                    lp_submit_entry = getattr(execution, "lp_submit_entry", None)
                    if not callable(lp_submit_entry):
                        raise RuntimeError("LP execution service is unavailable")
                    result = lp_submit_entry(payload)
                elif path == lp_submit_augment_path:
                    # Issue 163: strict augment submit bound to the named
                    # session.  Issue 167: the optional ``price`` unlocks the
                    # level (default = the group price).
                    lp_augment_required = {"session_id", "quantity", "idempotency_key"}
                    if (
                        not lp_augment_required <= set(payload)
                        or set(payload) - lp_augment_required - {"price"}
                    ):
                        raise ValueError("prediction request fields are invalid")
                    lp_submit_augment = getattr(execution, "lp_submit_augment", None)
                    if not callable(lp_submit_augment):
                        raise RuntimeError("LP execution service is unavailable")
                    result = lp_submit_augment(payload)
                elif path == lp_start_path:
                    self._require_schema(payload, {"preview_id", "idempotency_key"})
                    lp_start = getattr(execution, "lp_start", None)
                    if not callable(lp_start):
                        raise RuntimeError("LP execution service is unavailable")
                    result = lp_start(
                        self._required_string(payload, "preview_id"),
                        self._required_string(payload, "idempotency_key"),
                    )
                elif lp_augment_session is not None:
                    # Issue 158: augment submit keeps the strict two-field
                    # confirm shape of lp/sessions.
                    self._require_schema(payload, {"preview_id", "idempotency_key"})
                    lp_augment = getattr(execution, "lp_augment", None)
                    if not callable(lp_augment):
                        raise RuntimeError("LP execution service is unavailable")
                    result = lp_augment(
                        lp_augment_session,
                        self._required_string(payload, "preview_id"),
                        self._required_string(payload, "idempotency_key"),
                    )
                elif lp_stop_session is not None:
                    self._require_schema(payload, set())
                    lp_stop = getattr(execution, "lp_stop", None)
                    if not callable(lp_stop):
                        raise RuntimeError("LP execution service is unavailable")
                    result = lp_stop(lp_stop_session)
                elif path.endswith("/preview"):
                    self._require_schema(payload, {"opportunity_id"})
                    result = execution.preview(
                        self._required_string(payload, "opportunity_id")
                    )
                elif path.endswith("/executions"):
                    self._require_schema(payload, {"preview_id", "idempotency_key"})
                    result = execution.confirm(
                        self._required_string(payload, "preview_id"),
                        self._required_string(payload, "idempotency_key"),
                    )
                elif path == "/api/prediction-arbitrage/n-leg/mode":
                    self._require_schema(payload, {"mode", "base_contract_generation", "incident_id"})
                    incident_id = payload.get("incident_id")
                    if incident_id is not None and not isinstance(incident_id, str):
                        raise ValueError("incident_id must be a string or null")
                    result = execution.n_leg_set_mode(
                        self._required_string(payload, "mode"),
                        base_contract_generation=self._required_int(
                            payload, "base_contract_generation"
                        ),
                        incident_id=incident_id,
                        audit=audit,
                    )
                elif path == "/api/prediction-arbitrage/n-leg/config":
                    has_policy = "qualification_policy" in payload
                    has_safety = "safety_config" in payload
                    if has_policy == has_safety:
                        raise ValueError(
                            "config requires exactly one of qualification_policy or safety_config"
                        )
                    if has_policy:
                        self._require_schema(
                            payload,
                            {"qualification_policy", "base_qualification_policy_version"},
                        )
                        result = execution.n_leg_update_qualification_policy(
                            payload["qualification_policy"],
                            base_version=self._required_int(
                                payload, "base_qualification_policy_version"
                            ),
                            audit=audit,
                        )
                    else:
                        self._require_schema(
                            payload, {"safety_config", "base_safety_config_version"}
                        )
                        result = execution.n_leg_update_safety_config(
                            payload["safety_config"],
                            base_version=self._required_int(
                                payload, "base_safety_config_version"
                            ),
                            audit=audit,
                        )
                elif path == "/api/prediction-arbitrage/n-leg/orders/confirm":
                    # Issue #64: manual confirmation enqueues one re-verified
                    # ExecutionSolution. The server fetches the component's
                    # CURRENT solution here; a rotation that stays qualified
                    # binds the current solution, a drop-out rejects.
                    self._require_schema(
                        payload,
                        {"component_id", "displayed_fingerprint", "idempotency_key"},
                    )
                    store = getattr(runtime, "store", None)
                    if store is None:
                        raise RuntimeError("prediction store is unavailable")
                    solutions = getattr(runtime, "n_leg_solutions", lambda: [])()
                    # Issue #64: prefer the resolver's retained admission-
                    # grade material (heavy #51 payloads + the #74 proof bound
                    # to exactly that execution solution) for the freeze; the
                    # pointer proof is the fallback when none is retained.
                    material = None
                    source_provider = getattr(
                        runtime, "n_leg_execution_source", None
                    )
                    if callable(source_provider):
                        try:
                            material = source_provider(
                                payload["component_id"]
                            )
                        except Exception:
                            material = None
                    proof = self._partial_fill_proof_for(
                        runtime, payload["component_id"]
                    )
                    if isinstance(material, Mapping) and isinstance(
                        material.get("partial_fill_proof"), Mapping
                    ):
                        proof = dict(material["partial_fill_proof"])
                    execution_source = None
                    if isinstance(material, Mapping):
                        execution_source = {
                            "market": material.get("market"),
                            "execution": material.get("execution"),
                        }
                    result = confirm_enqueue(
                        store,
                        solutions,
                        component_id=self._required_string(
                            payload, "component_id"
                        ),
                        displayed_fingerprint=self._required_string(
                            payload, "displayed_fingerprint"
                        ),
                        idempotency_key=self._required_string(
                            payload, "idempotency_key"
                        ),
                        now=datetime.now(UTC),
                        partial_fill_proof=proof,
                        execution_source=execution_source,
                    )
                elif path == "/api/prediction-arbitrage/n-leg/incidents/acknowledge":
                    # Issue #64 Slice 6: incident-gate unlock. The store
                    # re-checks batch receipts + ledger atomically before it
                    # releases; any inconsistency keeps the incident state.
                    self._require_schema(
                        payload,
                        {"execution_batch_id", "actor", "reconciliation"},
                    )
                    store = getattr(runtime, "store", None)
                    if store is None:
                        raise RuntimeError("prediction store is unavailable")
                    result = store.n_leg_acknowledge_incident(
                        self._required_string(payload, "execution_batch_id"),
                        acknowledgement={
                            "actor": self._required_string(payload, "actor"),
                            "reconciliation": self._required_string(
                                payload, "reconciliation"
                            ),
                            "reason": str(payload.get("reason") or ""),
                            "git_sha": str(audit.get("git_sha") or ""),
                        },
                    )
                elif path == "/api/prediction-arbitrage/n-leg/circuit-breaker/reset":
                    self._require_schema(payload, {})
                    store = getattr(runtime, "store", None)
                    if store is None:
                        raise RuntimeError("prediction store is unavailable")
                    result = store.n_leg_breaker_reset(audit=audit)
                elif path == "/api/prediction-arbitrage/n-leg/scope":
                    scope_id = self._required_string(payload, "scope_id")
                    if "enable" in payload:
                        self._require_schema(
                            payload, {"scope_id", "enable", "base_contract_generation"}
                        )
                        enable = payload.get("enable")
                        if type(enable) is not bool:
                            raise ValueError("enable must be a boolean")
                        result = execution.n_leg_set_enabled_scope(
                            scope_id,
                            enable=enable,
                            base_contract_generation=self._required_int(
                                payload, "base_contract_generation"
                            ),
                            audit=audit,
                        )
                    else:
                        self._require_schema(
                            payload, {"scope_id", "capability", "members", "base_scope_version"}
                        )
                        base_scope_version = payload.get("base_scope_version")
                        if base_scope_version is not None and (
                            type(base_scope_version) is not int or base_scope_version < 1
                        ):
                            raise ValueError(
                                "base_scope_version must be a positive integer or null"
                            )
                        result = execution.n_leg_upsert_scope(
                            scope_id,
                            capability=self._required_string(payload, "capability"),
                            members=payload["members"],
                            base_scope_version=base_scope_version,
                            audit=audit,
                        )
                elif path.endswith("/mode"):
                    self._require_schema(payload, {"mode"})
                    result = execution.set_validation_mode(
                        self._required_string(payload, "mode"), audit=audit
                    )
                elif path.endswith("/circuit-breaker/reset"):
                    self._require_schema(payload, {"incident_id"})
                    result = execution.reset_breaker(
                        self._required_string(payload, "incident_id"), audit=audit
                    )
                elif path.endswith("/cross-auto/pause"):
                    self._require_confirm(payload)
                    result = execution.pause_cross_auto(audit=audit)
                else:
                    self._require_confirm(payload)
                    result = execution.cleanup_predict_allowance(
                        confirm=True, audit=audit
                    )
                status = HTTPStatus.OK
                # Issue 158: the LP entry/augment submit responses render
                # their state branch in the dashboard modal from the body
                # (busy/locked/rejected text), so they stay HTTP 200.
                # Issue 163: the single-shot endpoints join that rule — the
                # dashboard toasts branch on body.state, never on status.
                lp_submit_state_body = (
                    path == lp_start_path
                    or lp_augment_session is not None
                    or path in {lp_submit_entry_path, lp_submit_augment_path}
                )
                if (
                    not execution_mutation
                    and not lp_submit_state_body
                    and isinstance(result, Mapping)
                    and result.get("state") == "busy"
                ):
                    status = HTTPStatus.CONFLICT
                safe_result = (
                    _lp_projection_safe_value(result)
                    if path == lp_auto_prefix + "reservations/release"
                    else _prediction_safe_value(result)
                )
                if not isinstance(safe_result, Mapping):
                    raise RuntimeError("prediction mutation result is invalid")
                self._send_json(status, safe_result)
            except PermissionError as exc:
                self._send_error(HTTPStatus.FORBIDDEN, exc)
            except NLegVersionConflict as exc:
                self._send_json(HTTPStatus.CONFLICT, {"error": str(exc)})
            except NLegConfirmRejected as exc:
                self._send_json(
                    exc.http_status, {"error": str(exc), "reason": exc.reason}
                )
            except OverflowError as exc:
                self._send_json(
                    HTTPStatus.REQUEST_ENTITY_TOO_LARGE, {"error": str(exc)}
                )
            except ValueError as exc:
                self._send_error(HTTPStatus.BAD_REQUEST, exc)
            except (sqlite3.Error, OSError, RuntimeError) as exc:
                self._send_json(HTTPStatus.SERVICE_UNAVAILABLE, {"error": str(exc)})

        def _partial_fill_proof_for(self, runtime: object, component_id: object):
            """The bound #74 proof record cached on the live resolver."""
            provider = getattr(runtime, "latest_partial_fill_proof", None)
            if not callable(provider):
                return None
            try:
                proof = provider(component_id)
            except Exception:
                return None
            return dict(proof) if isinstance(proof, Mapping) else None

        def _listener_host_header(self) -> str:
            bound_host = str(host)
            if ":" in bound_host and not bound_host.startswith("["):
                bound_host = f"[{bound_host}]"
            return f"{bound_host}:{int(self.server.server_address[1])}"

        def _require_production_auth(self) -> None:
            try:
                if not ipaddress.ip_address(str(self.client_address[0])).is_loopback:
                    raise PermissionError("prediction mutations require loopback")
            except ValueError as exc:
                raise PermissionError("prediction mutations require loopback") from exc
            expected_host = self._listener_host_header()
            if self.headers.get("Host", "") != expected_host:
                raise PermissionError("prediction mutation Host is invalid")
            if self.headers.get("Origin", "") != f"http://{expected_host}":
                raise PermissionError("prediction mutation Origin is invalid")
            cookie = SimpleCookie()
            try:
                cookie.load(self.headers.get("Cookie", ""))
            except Exception as exc:
                raise PermissionError("prediction session is invalid") from exc
            provided_session = cookie.get("ot_prediction_session")
            if provided_session is None or not secrets.compare_digest(
                provided_session.value, prediction_session
            ):
                raise PermissionError("prediction session is invalid")
            if not secrets.compare_digest(
                self.headers.get("X-CSRF-Token", ""), prediction_csrf
            ):
                raise PermissionError("prediction CSRF token is invalid")

        def _read_json_body(self) -> dict[str, object]:
            raw_length = self.headers.get("Content-Length") or "0"
            try:
                content_length = int(raw_length)
            except ValueError as exc:
                raise ValueError("Content-Length must be a non-negative integer") from exc
            if content_length < 0:
                raise ValueError("Content-Length must be a non-negative integer")
            if content_length > _MAX_JSON_BODY_BYTES:
                raise OverflowError("request body cannot exceed 1 MiB")
            body = self.rfile.read(content_length) if content_length else b"{}"
            try:
                payload = json.loads(body.decode("utf-8") or "{}")
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                raise ValueError("request body must be a JSON object") from exc
            if not isinstance(payload, dict):
                raise ValueError("request body must be a JSON object")
            return payload

        @staticmethod
        def _require_schema(payload: Mapping[str, object], expected: set[str]) -> None:
            if set(payload) != expected:
                raise ValueError("prediction request fields are invalid")

        @staticmethod
        def _required_string(payload: Mapping[str, object], key: str) -> str:
            value = payload.get(key)
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{key} is required")
            return value.strip()

        @staticmethod
        def _required_int(payload: Mapping[str, object], key: str) -> int:
            value = payload.get(key)
            if type(value) is not int or value < 1:
                raise ValueError(f"{key} must be a positive integer")
            return value

        @classmethod
        def _optional_string(cls, payload: Mapping[str, object], key: str) -> str:
            value = payload.get(key, "")
            if not isinstance(value, str):
                raise ValueError(f"{key} must be a string")
            return value.strip()

        @classmethod
        def _relation_expected(cls, payload: Mapping[str, object]) -> dict[str, object]:
            version_id = payload.get("version_id")
            if not isinstance(version_id, str) or not version_id.strip():
                raise ValueError("version_id is required")
            return {"version_id": version_id}

        @classmethod
        def _require_confirm(cls, payload: Mapping[str, object]) -> None:
            cls._require_schema(payload, {"confirm"})
            if payload.get("confirm") is not True:
                raise ValueError("confirm must be true")

        def _audit_context(self) -> dict[str, object]:
            audit = {
                "actor": "local_operator",
                "git_sha": str(metadata.get("git_sha", "")),
            }
            store = getattr(runtime, "store", None)
            policy = getattr(store, "safety_policy", None)
            if callable(policy):
                current = policy()
                if isinstance(current, Mapping):
                    audit["safety_fingerprint"] = str(current.get("fingerprint", ""))
            return audit

        def _unsupported_method(self) -> None:
            self._send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})

        do_HEAD = _unsupported_method
        do_PUT = _unsupported_method
        do_DELETE = _unsupported_method
        do_OPTIONS = _unsupported_method
        do_PATCH = _unsupported_method
        do_CONNECT = _unsupported_method
        do_TRACE = _unsupported_method

    server = _PredictionHTTPServer((host, port), PredictionRequestHandler)
    server.timeout = 0.2
    return server


create_prediction_service = create_prediction_server


def serve_prediction_service(
    *,
    data_dir: Path,
    prediction_config_path: Path,
    host: str = "127.0.0.1",
    port: int = 8769,
    mode: str = "shadow",
    release_manifest_path: Path | None = None,
    notifier_config_path: Path | None = None,
) -> int:
    _require_loopback_host(host)
    if mode not in {"shadow", "production"}:
        raise ValueError("prediction service mode is invalid")
    release = None
    notifier = None
    if release_manifest_path is not None:
        release = load_prediction_release_manifest(release_manifest_path)
    if mode == "production":
        if release_manifest_path is None:
            raise ValueError("production release manifest is required")
        notifier = (
            None
            if notifier_config_path is None
            else build_notifier(load_env_config(notifier_config_path, dry_run=False))
        )
    metadata = _runtime_metadata()
    if release is not None:
        metadata.update(
            {
                "release_schema_version": release.schema_version,
                "reader_generation": release.reader_generation,
                "contract_generation": release.contract_generation,
            }
        )
    runtime = PredictionRuntime(
        data_dir=Path(data_dir),
        prediction_config_path=Path(prediction_config_path),
        dashboard_url=f"http://{host}:{port}",
        mode=mode,
        notifier=notifier,
        git_sha=str(metadata.get("git_sha", "")),
        reader_generation=None if release is None else release.reader_generation,
        enable_n_leg_background=(
            os.environ.get("OPEN_TRADER_DISABLE_NLEG_BACKGROUND") != "1"
        ),
    )
    server: ThreadingHTTPServer | None = None
    previous_handlers: dict[int, Any] = {}
    stopping = False

    def stop_handler(_signum: int, _frame: Any) -> None:
        nonlocal stopping
        stopping = True

    try:
        for signum in (signal.SIGINT, signal.SIGTERM):
            previous_handlers[signum] = signal.getsignal(signum)
            signal.signal(signum, stop_handler)
        runtime.start()
        if mode == "production" and not (
            runtime.state == "RUNNING" and runtime.production_owner is True
        ):
            raise RuntimeError("production runtime is not ready")
        server = create_prediction_server(
            runtime=runtime,
            host=host,
            port=port,
            runtime_metadata=metadata,
        )
        while not stopping:
            server.handle_request()
            if mode == "shadow":
                runtime.poll_shadow_failure()
        return 0
    finally:
        try:
            try:
                runtime.stop()
            finally:
                if server is not None:
                    server.server_close()
        finally:
            for signum, handler in previous_handlers.items():
                signal.signal(signum, handler)


def _configure_entry_logging() -> None:
    """Give the prediction-service launchd logs ISO-8601 timestamps.

    The launchd StandardOut/Err logs previously carried no timestamp prefix
    at all, so operators could not correlate structured diagnostics lines
    with incidents.  Scoped to the CLI entry only: library-level logging
    defaults stay untouched.
    """

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="open_trader prediction-service")
    parser.add_argument("--mode", default="shadow")
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8769)
    parser.add_argument("--release-manifest", type=Path)
    parser.add_argument("--notifier-config", type=Path)
    args = parser.parse_args(argv)
    _configure_entry_logging()
    from .prediction_shadow_resources import shadow_resource_guard
    with shadow_resource_guard(args.mode):
        return serve_prediction_service(
            data_dir=args.data_dir,
            prediction_config_path=args.config,
            host=args.host,
            port=args.port,
            mode=args.mode,
            release_manifest_path=args.release_manifest,
            notifier_config_path=args.notifier_config,
        )
