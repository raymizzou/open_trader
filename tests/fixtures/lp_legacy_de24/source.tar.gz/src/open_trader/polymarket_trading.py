"""The one authenticated boundary for protected Polymarket orders.

The rest of the application should pass :class:`PairIntent` values here and
never handle private keys, builder credentials, or signed order payloads.
"""

from __future__ import annotations

import json
import importlib.metadata
import logging
import math
import os
import sqlite3
import pty
import queue
import re
import stat
import sys
import uuid
import subprocess
import threading
import time
from copy import deepcopy
from contextlib import contextmanager
from collections import deque
from collections.abc import Mapping, MutableMapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import Future
from concurrent.futures import TimeoutError as FuturesTimeoutError
from dataclasses import dataclass
from datetime import UTC, date as Date, datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Callable, Literal, cast
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import ProxyHandler, Request, build_opener, urlopen

from polymarket import BuilderApiKey, PRODUCTION, PublicClient, SecureClient
from polymarket._internal.wallet import signature_type_for

from .polymarket_lp_errors import LpObservationWait
from .polymarket_lp_scratch import LPReadRows, LPReadScratch
from .prediction_arbitrage import (
    MAX_NORMAL_COST,
    MAX_WALLET_BALANCE,
    MIN_ESTIMATED_PROFIT,
    MIN_NET_EDGE,
    PairIntent,
    ThresholdHedgeIntent,
    ThresholdHedgeLeg,
    protected_buy_quantity,
)


SECURITY = "/usr/bin/security"
logger = logging.getLogger(__name__)
KEYCHAIN_SERVICE = "com.open-trader.polymarket"
PREDICT_KEYCHAIN_SERVICE = "com.open-trader.predict"
PREDICT_API_KEY_ACCOUNT = "api-key"
PREDICT_PRIVATE_KEY_ACCOUNT = "privy-private-key"
KEYCHAIN_ACCOUNTS = (
    "signing-private-key",
    "builder-key",
    "builder-secret",
    "builder-passphrase",
)
GEOBLOCK_URL = "https://polymarket.com/api/geoblock"
GEOBLOCK_TIMEOUT_SECONDS = 5.0
MERGE_WAIT_TIMEOUT_SECONDS = 60.0
REMEDIATION_BOOK_FRESHNESS_SECONDS = 10.0
LP_PRICE_HISTORY_ENDPOINT = "https://clob.polymarket.com/batch-prices-history"
LP_PRICE_HISTORY_BATCH_SIZE = 20
LP_PRICE_HISTORY_MAX_CONCURRENCY = 4
LP_PRICE_HISTORY_TIMEOUT_SECONDS = 20.0
# Issue #177: the official competition catalog is a public, unauthenticated
# read; it uses the raw urllib channel (the SDK's default 10s read timeout
# kept scrapping whole pagination rounds) with a per-page retry budget and
# an in-memory resume bookmark.
LP_COMPETITIVENESS_ENDPOINT = "https://clob.polymarket.com/rewards/markets/multi"
LP_COMPETITIVENESS_TIMEOUT_SECONDS = 15.0
LP_COMPETITIVENESS_PAGE_ATTEMPTS = 3
LP_COMPETITIVENESS_RETRY_PAUSE_SECONDS = 1.0


def _lp_competition_direct_opener():
    """Issue #177 R2: stdlib urlopen honors the macOS system proxy and
    the local proxy stalls the long pagination with trickle reads under
    the per-recv timeout; pin the direct route the SDK httpx channel
    (env-var proxies only) always used."""
    return build_opener(ProxyHandler({})).open


LP_REWARD_SELECTED_MAX_CONCURRENCY = 4
# Issue #137: the ~17k-market reward catalog must not be re-read and fully
# re-validated from gamma on every lp_market_metadata call.  Results live in
# an in-process TTL cache (positive and confirmed-missing entries) with a
# per-call refresh budget, optionally warm-started from a SQLite backing
# store.
LP_METADATA_CACHE_TTL_SECONDS = 43200.0
LP_METADATA_CACHE_JITTER_SECONDS = 0.0
LP_METADATA_NEGATIVE_TTL_SECONDS = 3600.0
LP_METADATA_MAX_REFRESH_IDS_PER_CALL = 1500
# Keep Gamma condition-ID query URLs near 4 KiB under shared HTTP/2 reads.
LP_METADATA_MARKET_BATCH_SIZE = 50
# Each Gamma event can contain hundreds of full child markets. Bound SDK
# parsing separately from the lightweight market metadata reads.
LP_METADATA_EVENT_BATCH_SIZE = 10
LP_REWARD_ASSET_USD_ADDRESSES = frozenset(
    {
        # Both contracts are identified by the official Polymarket contracts
        # and pUSD migration docs; arbitrary reward assets remain UNKNOWN.
        "0xc011a7e12a19f7b1f670d46f03b03f3342e82dfb",
        "0x2791bca1f2de4661ed88a30c99a7a9449aa84174",
    }
)
LP_REWARD_ASSET_LABELS = {
    "0xc011a7e12a19f7b1f670d46f03b03f3342e82dfb": "pUSD",
    "0x2791bca1f2de4661ed88a30c99a7a9449aa84174": "USDC.e",
}
COLLATERAL_BASE_UNITS = Decimal("1000000")
DEFAULT_TICK_SIZE = Decimal("0.01")
CENT = Decimal("0.01")
_ADDRESS_RE = re.compile(r"0x[0-9a-fA-F]{40}\Z")
_LP_DIAGNOSTIC_SUMMARY_MAX_CHARS = 512
_LP_DIAGNOSTIC_LOG_MAX_CHARS = 2048
_LP_DIAGNOSTIC_FIELD_MAX_CHARS = 96
_SAFE_ERROR_CODES = {
    "ambiguous",
    "auth",
    "geoblock_blocked",
    "geoblock_error",
    "invalid",
    "keychain_empty",
    "keychain_unavailable",
    "network",
    "order_amount_mismatch",
    "order_shape_mismatch",
    "preflight_required",
    "market_probe_unavailable",
    "account_insufficient",
    "rejected",
    "sdk_error",
    "signing",
    "timeout",
    "unavailable",
}


class PolymarketTradingError(RuntimeError):
    """An intentionally redacted adapter error."""

    def __init__(self, error_code: str, *, response_facts: Mapping[str, object] | None = None) -> None:
        self.response_facts = dict(response_facts or {})
        safe_code = error_code if error_code in _SAFE_ERROR_CODES else "sdk_error"
        self.error_code = safe_code
        super().__init__(f"polymarket trading error: {safe_code}")


class _RewardReadCancelled(RuntimeError):
    """Cooperative stop requested between bounded reward reads."""


#: Issue #64: the N-leg unit scale (units per $1.00) shared with the #117
#: economics pipeline; FOK bounds and prices convert through this divisor.
_NLEG_UNITS_PER_DOLLAR = 1_000_000


def _interpret_fok_response(response: object) -> dict[str, object]:
    """Map one FOK BUY response to a conservative terminal outcome.

    Only an explicit positive acknowledgement (``success``/``status``
    indicating the FOK matched) books a FILLED leg, at the conservative
    ``max_cost_units`` bound the caller supplied. An explicit failure books a
    clean REJECTED (FOK either fills fully or not at all, nothing rests).
    Everything else — model shapes this adapter does not recognize — is
    UNKNOWN so the driver opens an incident instead of guessing.
    """
    success = _field(response, "success", None)
    status = _field(response, "status", None)
    if success is None and isinstance(response, Mapping):
        success = response.get("success")
    if status is None and isinstance(response, Mapping):
        status = response.get("status")
    status_text = str(status or "").strip().upper()
    if success is True or status_text in {"MATCHED", "FILLED", "MATCHED_CONFIRMED"}:
        return {"state": "FILLED", "error_code": None}
    if success is False or status_text in {
        "REJECTED",
        "CANCELLED",
        "EXPIRED",
        "UNFILLED",
        "NOT_PLACED",
        "FAILED",
    }:
        return {"state": "REJECTED", "error_code": None}
    return {"state": "UNKNOWN", "error_code": "unrecognized_receipt"}


class KeychainError(RuntimeError):
    """A redacted Keychain operation failure."""

    def __init__(self, error_code: str = "keychain_unavailable") -> None:
        safe_code = (
            error_code
            if error_code in {"keychain_empty", "keychain_unavailable"}
            else "keychain_unavailable"
        )
        self.error_code = safe_code
        super().__init__(f"keychain error: {safe_code}")


@dataclass(frozen=True, slots=True)
class PredictConfig:
    wallet_address: str
    environment: Literal["mainnet"] = "mainnet"


@dataclass(frozen=True, slots=True)
class TradingConfig:
    signer_address: str
    wallet_address: str
    predict: PredictConfig | None = None


@dataclass(frozen=True, slots=True)
class AccountSnapshot:
    wallet_address: str
    p_usd_balance: Decimal
    p_usd_allowance: Decimal
    open_order_ids: tuple[str, ...]
    positions: tuple[dict[str, str], ...]
    checked_at: datetime


@dataclass(frozen=True, slots=True)
class LegResult:
    leg: Literal["YES", "NO"]
    accepted: bool
    status: str
    order_id: str
    filled_quantity: Decimal
    trade_ids: tuple[str, ...]
    error_code: str


@dataclass(frozen=True, slots=True)
class PairSubmission:
    yes: LegResult
    no: LegResult


@dataclass(frozen=True, slots=True)
class ThresholdLegResult:
    label: Literal["A", "B"]
    outcome: Literal["YES", "NO"]
    condition_id: str
    token_id: str
    accepted: bool
    status: str
    order_id: str
    filled_quantity: Decimal
    trade_ids: tuple[str, ...]
    error_code: str


@dataclass(frozen=True, slots=True)
class ThresholdHedgeSubmission:
    leg_a: ThresholdLegResult
    leg_b: ThresholdLegResult


def _run_security(
    args: list[str], **kwargs: object
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, **kwargs)  # type: ignore[arg-type]


def _validate_keychain_account(account: str) -> None:
    if account not in KEYCHAIN_ACCOUNTS:
        raise ValueError("unsupported polymarket keychain account")


def _store_keychain_password(
    account: str,
    service: str,
    secret: str,
    run: Callable[..., subprocess.CompletedProcess[str]] | None,
) -> None:
    if os.environ.get("OPEN_TRADER_CREDENTIAL_BACKEND", "keychain") != "keychain":
        raise KeychainError()
    args = [
        SECURITY,
        "add-generic-password",
        "-U",
        "-a",
        account,
        "-s",
        service,
        "-w",
    ]
    master_fd = slave_fd = -1
    process: subprocess.Popen[bytes] | None = None
    try:
        if run is not None:
            run(args, input=f"{secret}\n", text=True, capture_output=True, check=True)
            return

        master_fd, slave_fd = pty.openpty()
        process = subprocess.Popen(
            args,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            close_fds=True,
            start_new_session=True,
        )
        os.close(slave_fd)
        slave_fd = -1
        password_lines = (f"{secret}\n{secret}\n").encode()
        if os.write(master_fd, password_lines) != len(password_lines):
            raise OSError
        if process.wait(timeout=5) != 0:
            raise KeychainError()
    except Exception:
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        raise KeychainError() from None
    finally:
        if master_fd >= 0:
            os.close(master_fd)
        if slave_fd >= 0:
            os.close(slave_fd)


def store_keychain_secret(
    account: str,
    secret: str,
    *,
    run: Callable[..., subprocess.CompletedProcess[str]] | None = None,
) -> None:
    """Store one secret without placing it in process arguments."""

    _validate_keychain_account(account)
    if not isinstance(secret, str) or not secret:
        raise ValueError("keychain secret must not be empty")
    _store_keychain_password(account, KEYCHAIN_SERVICE, secret, run)


def load_keychain_secret(
    account: str,
    *,
    run: Callable[..., subprocess.CompletedProcess[str]] | None = None,
) -> str:
    """Read one secret from Keychain without including it in diagnostics."""

    _validate_keychain_account(account)
    return _load_keychain_password(account, KEYCHAIN_SERVICE, run)


def _load_file_secret(service: str, account: str) -> str:
    path = Path(os.environ["OPEN_TRADER_CREDENTIAL_FILE"])
    if not path.is_absolute():
        raise ValueError
    if any(stat.S_ISLNK(part.lstat().st_mode) for part in path.parents):
        raise ValueError
    directory = path.parent.lstat()
    file = path.lstat()
    owner = os.geteuid()
    if (not stat.S_ISDIR(directory.st_mode) or directory.st_uid != owner
        or stat.S_IMODE(directory.st_mode) != 0o700
        or not stat.S_ISREG(file.st_mode) or file.st_uid != owner
        or stat.S_IMODE(file.st_mode) != 0o600):
        raise ValueError
    dirfd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        opened_dir = os.fstat(dirfd)
        if (opened_dir.st_dev, opened_dir.st_ino) != (directory.st_dev, directory.st_ino):
            raise ValueError
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=dirfd)
        with os.fdopen(fd, "rb") as stream:
            opened_file = os.fstat(stream.fileno())
            if (opened_file.st_dev, opened_file.st_ino) != (file.st_dev, file.st_ino):
                raise ValueError
            raw = stream.read(16385)
    finally:
        os.close(dirfd)
    if len(raw) > 16384:
        raise ValueError
    bundle = json.loads(raw)
    allowed = {
        KEYCHAIN_SERVICE: set(KEYCHAIN_ACCOUNTS),
        PREDICT_KEYCHAIN_SERVICE: {PREDICT_API_KEY_ACCOUNT, PREDICT_PRIVATE_KEY_ACCOUNT},
    }
    if (not isinstance(bundle, dict) or not set(bundle) <= set(allowed)
        or KEYCHAIN_SERVICE not in bundle):
        raise ValueError
    for name, values in bundle.items():
        if (not isinstance(values, dict) or not set(values) <= allowed[name]
            or (name == KEYCHAIN_SERVICE and set(values) != allowed[name])
            or any(not isinstance(value, str) or not value.strip() for value in values.values())):
            raise ValueError
    return bundle[service][account]


def _load_keychain_password(
    account: str,
    service: str,
    run: Callable[..., subprocess.CompletedProcess[str]] | None,
) -> str:
    backend = os.environ.get("OPEN_TRADER_CREDENTIAL_BACKEND", "keychain")
    if backend == "disabled":
        raise KeychainError()
    if backend == "file":
        try:
            return _load_file_secret(service, account)
        except Exception:
            raise KeychainError() from None
    if backend == "tencent-ssm":
        from .prediction_ssm import load_ssm_secret
        try:
            return load_ssm_secret(service, account)
        except Exception:
            raise KeychainError() from None
    if backend != "keychain":
        raise KeychainError()
    runner = run or _run_security
    args = [
        SECURITY,
        "find-generic-password",
        "-a",
        account,
        "-s",
        service,
        "-w",
    ]
    try:
        completed = runner(args, text=True, capture_output=True, check=True)
        value = getattr(completed, "stdout", "")
    except Exception as exc:
        del exc
        raise KeychainError() from None
    if not isinstance(value, str):
        raise KeychainError("keychain_empty")
    value = value.rstrip("\r\n")
    if not value:
        raise KeychainError("keychain_empty")
    return value


def store_predict_api_key(
    secret: str,
    *,
    run: Callable[..., subprocess.CompletedProcess[str]] | None = None,
) -> None:
    """Store the Predict API key without exposing it in process arguments."""

    if not isinstance(secret, str) or not secret:
        raise ValueError("keychain secret must not be empty")
    _store_keychain_password(
        PREDICT_API_KEY_ACCOUNT, PREDICT_KEYCHAIN_SERVICE, secret, run
    )


def load_predict_api_key(
    *,
    run: Callable[..., subprocess.CompletedProcess[str]] | None = None,
) -> str:
    """Load the Predict API key without exposing it in failures."""

    return _load_keychain_password(PREDICT_API_KEY_ACCOUNT, PREDICT_KEYCHAIN_SERVICE, run)


def load_predict_private_key(
    *,
    run: Callable[..., subprocess.CompletedProcess[str]] | None = None,
) -> str:
    """Load the Predict signer key without exposing it in failures."""

    return _load_keychain_password(PREDICT_PRIVATE_KEY_ACCOUNT, PREDICT_KEYCHAIN_SERVICE, run)


def _canonical_address(value: object, field: str) -> str:
    if not isinstance(value, str) or value != value.strip() or not _ADDRESS_RE.fullmatch(value):
        raise ValueError(f"{field} must be a canonical 20-byte hex address")
    return value


def load_trading_config(path: Path) -> TradingConfig:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        del exc
        raise ValueError("invalid prediction arbitrage config") from None
    if not isinstance(payload, dict):
        raise ValueError("prediction arbitrage config must be an object")
    expected = {"signer_address", "wallet_address"}
    if set(payload) not in (expected, expected | {"predict"}):
        raise ValueError("prediction arbitrage config must contain signer_address and wallet_address")
    predict: PredictConfig | None = None
    if "predict" in payload:
        predict_payload = payload["predict"]
        if not isinstance(predict_payload, dict) or set(predict_payload) != {
            "wallet_address",
            "environment",
        }:
            raise ValueError("predict config must contain wallet_address and environment")
        if predict_payload.get("environment") != "mainnet":
            raise ValueError("predict environment must be mainnet")
        predict = PredictConfig(
            wallet_address=_canonical_address(
                predict_payload.get("wallet_address"), "predict.wallet_address"
            )
        )
    return TradingConfig(
        signer_address=_canonical_address(payload.get("signer_address"), "signer_address"),
        wallet_address=_canonical_address(payload.get("wallet_address"), "wallet_address"),
        predict=predict,
    )


def _safe_error_code(exc: BaseException) -> str:
    name = type(exc).__name__.lower()
    if isinstance(exc, KeychainError):
        return exc.error_code
    if isinstance(exc, PolymarketTradingError):
        return exc.error_code
    status = getattr(exc, "code", None)
    if isinstance(status, int):
        if status in {401, 403}:
            return "rejected"
        if status == 429 or status >= 500:
            return "network"
    if "timeout" in name:
        return "timeout"
    if "sign" in name:
        return "signing"
    if "reject" in name or "unauthor" in name or "forbidden" in name:
        return "rejected"
    if isinstance(exc, (ConnectionError, URLError)) or "network" in name:
        return "network"
    if isinstance(exc, (ValueError, TypeError)):
        return "invalid"
    if isinstance(exc, OSError):
        return "unavailable"
    return "sdk_error"


def _safe_read_failure(stage: str, exc: BaseException) -> str:
    """Identify a failed read without retaining exception details."""

    error_types: list[str] = []
    seen: set[int] = set()
    current: BaseException | None = exc
    status: int | None = None
    for _ in range(8):
        if current is None or id(current) in seen:
            break
        seen.add(id(current))
        error_types.append(type(current).__name__)
        if status is None and type(getattr(current, "status", None)) is int:
            status = cast(int, getattr(current, "status"))
        cause = current.__cause__
        if cause is None and not current.__suppress_context__:
            cause = current.__context__
        current = cause if isinstance(cause, BaseException) else None
    status_detail = f" status={status}" if status is not None else ""
    logger.warning(
        "lp_metadata_read_failed stage=%s error_types=%s%s",
        stage,
        ">".join(error_types) or "unknown",
        status_detail,
    )
    return f"{stage}_read_{type(exc).__name__}"


def _safe_metadata_failure(
    stage: str,
    exc: BaseException,
    response_facts: Mapping[str, object] | None = None,
) -> dict[str, object]:
    """Return redacted structured facts for one Gamma metadata failure."""

    facts: dict[str, object] = {
        "error_type": _safe_read_failure(stage, exc),
        "error_chain": _safe_read_error_chain(exc),
        **_safe_sqlite_error_facts(exc),
    }
    if response_facts:
        facts.update(
            {
                key: value
                for key, value in response_facts.items()
                if key in {"status", "retry_after_seconds", "retry_after_at"}
            }
        )
    status = facts.get("status")
    if type(status) is not int:
        status = getattr(exc, "status", None)
    if type(status) is not int:
        status = getattr(exc, "code", None)
    if type(status) is not int:
        response = getattr(exc, "response", None)
        status = getattr(response, "status_code", None)
    if type(status) is int and 100 <= status <= 599:
        facts["status"] = status
    return facts


def _read_exception_chain(exc: BaseException) -> tuple[BaseException, ...]:
    """Bound explicit causes and unsuppressed contexts; stop at cycles."""
    chain: list[BaseException] = []
    seen: set[int] = set()
    current: BaseException | None = exc
    for _ in range(8):
        if current is None or id(current) in seen:
            break
        seen.add(id(current))
        chain.append(current)
        cause = current.__cause__
        if cause is None and not current.__suppress_context__:
            cause = current.__context__
        current = cause if isinstance(cause, BaseException) else None
    return tuple(chain)


def _safe_read_error_chain(exc: BaseException) -> tuple[str, ...]:
    """Return exception class names without retaining exception messages."""
    return tuple(dict.fromkeys(
        name for error in _read_exception_chain(exc)
        if (name := type(error).__name__).replace("_", "").isalnum()
    ))


def _safe_sqlite_error_facts(value: object) -> dict[str, object]:
    """Keep SQLite result codes, never SQL, parameters, or exception text."""
    if isinstance(value, BaseException):
        value = next((error for error in _read_exception_chain(value)
                      if isinstance(error, sqlite3.Error)), None)
        code = getattr(value, "sqlite_errorcode", None)
        name = getattr(value, "sqlite_errorname", None)
    elif isinstance(value, Mapping):
        code, name = value.get("sqlite_errorcode"), value.get("sqlite_errorname")
    else:
        return {}
    facts: dict[str, object] = {}
    if type(code) is int and 0 < code <= 65535:
        facts["sqlite_errorcode"] = code
    if isinstance(name, str) and name.startswith("SQLITE_") and type(code) is int and getattr(sqlite3, name, None) == code:
        facts["sqlite_errorname"] = name
    return facts


def _null_order_response(exc: BaseException) -> bool:
    from pydantic import ValidationError

    cause = exc.__cause__
    return isinstance(cause, ValidationError) and any(
        row.get("loc") == () and row.get("type") == "model_type"
        and "input" in row and row["input"] is None
        for row in cause.errors(include_url=False)
    )


_lp_read_local = threading.local()
# ponytail: one process-local daemon and 32 records; overflow is counted, never queued.
# The consumer has no business state, I/O slots, or business locks. Business
# shutdown does not join it; buffered output is not guaranteed before process exit.
_lp_read_log_lock = threading.Lock()
_lp_read_log_queue = queue.Queue(maxsize=32)
_lp_read_log_dropped = 0
_lp_read_log_failed = 0


def _lp_run_read_logs():
    global _lp_read_log_dropped, _lp_read_log_failed
    while True:
        record = _lp_read_log_queue.get()
        try:
            try:
                record()
            except Exception:
                with _lp_read_log_lock:
                    _lp_read_log_failed = min(sys.maxsize, _lp_read_log_failed + 1)
            with _lp_read_log_lock:
                dropped, failed = _lp_read_log_dropped, _lp_read_log_failed
                _lp_read_log_dropped = _lp_read_log_failed = 0
            if dropped or failed:
                try:
                    logger.info('lp_read_log_limited scope=best_effort pending_limit=32 consumer_limit=1 dropped=%s output_errors=%s count_scope=since_last_report count_saturation=%s', dropped, failed, sys.maxsize)
                except Exception:
                    with _lp_read_log_lock:
                        _lp_read_log_dropped = min(sys.maxsize, _lp_read_log_dropped + dropped)
                        _lp_read_log_failed = min(sys.maxsize, _lp_read_log_failed + failed + 1)
        finally:
            _lp_read_log_queue.task_done()


# Start outside all business operations/locks, exactly once on module import.
_lp_read_log_thread = threading.Thread(target=_lp_run_read_logs, daemon=True, name='lp-read-diagnostics')
try:
    _lp_read_log_thread.start()
except Exception:
    pass  # Failed diagnostic startup must not prevent the trading module loading.


def _lp_capture_read_log(emit, deferred=None):
    global _lp_read_log_dropped
    try:
        if deferred is None:
            _lp_read_log_queue.put_nowait(emit)
        elif len(deferred) < 32:
            deferred.append(emit)
        else:
            raise queue.Full
    except queue.Full:
        with _lp_read_log_lock:
            _lp_read_log_dropped = min(sys.maxsize, _lp_read_log_dropped + 1)
    except Exception:
        pass


def _lp_causal_event(event, *, account=None, owner=None, outcome=None, used_at=None, **counts):
    """Snapshot causal facts into Queue32; never format or call a sink here.

    Timestamps join the same API read across caches/publication/automatic use.
    Owner evidence is process-local; an external flock holder stays unknown.
    """
    try:
        task = getattr(_lp_read_local, "task", None) or {}
        facts = dict(at=datetime.now(UTC).isoformat(), monotonic=time.monotonic(),
                     thread=threading.get_ident(), task_id=task.get("task_id"),
                     entry=task.get("entry"), stage=task.get("stage"))
        for key in ("read_started_at", "read_ended_at", "checked_at"):
            stamp = (account or {}).get(key)
            if isinstance(stamp, str):
                try:
                    stamp = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
                except ValueError:
                    stamp = None
            if isinstance(stamp, datetime) and stamp.tzinfo is not None:
                facts[key] = stamp.astimezone(UTC).isoformat()
        generation = (account or {}).get("trade_generation")
        if type(generation) is int:
            facts["trade_generation"] = generation
        if isinstance(used_at, datetime) and used_at.tzinfo is not None:
            facts["used_at"] = used_at.astimezone(UTC).isoformat()
        if outcome in {"complete", "failed", "registered", "skipped", "process_busy", "file_busy"}:
            facts["outcome"] = outcome
        if owner:
            owner_task = owner.get("task") or {}
            facts.update(owner_scope="process_local", owner_id=owner["id"],
                         owner_thread=owner["thread"], owner_started=owner["started"],
                         owner_entry=owner["entry"], owner_task_id=owner_task.get("task_id"),
                         owner_stage=owner_task.get("stage"))
        else:
            facts["owner_scope"] = "unknown"
        facts.update({key: value for key, value in counts.items()
                      if key in {"prepare_seconds", "begin_wait_seconds", "body_seconds", "commit_seconds"}
                      and type(value) in {int, float} and math.isfinite(value) and value >= 0})
        _lp_capture_read_log(lambda: logger.info("lp_causal_event event=%s facts=%s", event, facts))
    except Exception:
        pass


def _lp_read_count(**counts):
    """Only numeric aggregates; never retain business identifiers."""
    try:
        task = getattr(_lp_read_local, "task", None)
        if task is not None:
            stage_counts = task["counts"].setdefault(task["stage"], {})
            for key, value in counts.items():
                stage_counts[key] = stage_counts.get(key, 0) + value
    except Exception:
        pass


@contextmanager
def _lp_read_task(entry, *, task=None, deferred_logs=None):
    previous = getattr(_lp_read_local, "task", None)
    previous_logs = getattr(_lp_read_local, "deferred_logs", None)
    if previous is not None:
        if previous_logs is None:
            _lp_read_local.deferred_logs = deferred_logs
        try:
            yield previous
        finally:
            _lp_read_local.deferred_logs = previous_logs
        return
    owns_logs = deferred_logs is None and previous_logs is None
    deferred_logs = previous_logs if previous_logs is not None else deferred_logs
    if owns_logs:
        deferred_logs = []
    try:
        task = task if task is not None else dict(task_id=uuid.uuid4().hex, entry=entry)
        task.update(thread=threading.get_ident(), started_at=datetime.now(UTC).isoformat(),
                    started=time.monotonic(), stage="start", timings={}, counts={})
        _lp_read_local.task = task
    except Exception:
        task = None
    _lp_read_local.deferred_logs = deferred_logs
    failed = False
    try:
        yield task
    except BaseException:
        failed = True
        raise
    finally:
        _lp_read_local.task = previous
        _lp_read_local.deferred_logs = previous_logs
        try:
            if task is not None:
                task.update(ended_at=datetime.now(UTC).isoformat(), ended=time.monotonic(), stage="ended")
                elapsed = task["ended"] - task["started"]
                if failed or task.get("diagnose") or elapsed >= task.get("budget", 60):
                    def emit():
                        logger.info(
                            "lp_read_task_end task_id=%s entry=%s parent_task_id=%s thread=%s started_at=%s ended_at=%s elapsed_seconds=%.3f caller_timed_out=%s failed=%s timings=%s http_count_scope=installed_thread_hooks records_scope=completed_lists unobserved_counts=unknown counts=%s",
                            task["task_id"], task["entry"], task.get("parent_task_id"), task["thread"], task["started_at"], task["ended_at"],
                            elapsed, bool(task.get("caller_timed_out")), failed, task["timings"], task["counts"],
                        )
                    _lp_capture_read_log(emit, deferred_logs)
        except Exception:
            pass
        if owns_logs:
            _lp_flush_read_logs(deferred_logs)


def _lp_flush_read_logs(logs):
    """Transfer to the outermost scope or non-blocking diagnostic queue."""
    deferred = getattr(_lp_read_local, 'deferred_logs', None)
    for record in logs:
        _lp_capture_read_log(record, deferred)
    logs.clear()


@contextmanager
def _lp_read_lock(lock, stage):
    pending = []
    previous_logs = getattr(_lp_read_local, 'deferred_logs', None)
    _lp_read_local.deferred_logs = previous_logs if previous_logs is not None else pending
    acquired = False
    try:
        with _lp_read_stage(stage, deferred_logs=pending):
            lock.__enter__()
            acquired = True
        yield
    finally:
        try:
            if acquired:
                lock.__exit__(*sys.exc_info())
        finally:
            _lp_read_local.deferred_logs = previous_logs
            _lp_flush_read_logs(pending)


def _lp_market_read_diagnostic(reason, jobs, *, stack=False):
    """Snapshot only the related workers; format/log outside the scheduler lock."""
    try:
        tasks = []
        for job in jobs:
            task = getattr(job, "lp_diagnostic", None)
            if task is not None:
                task["diagnose"] = True
                tasks.append(task)
        now = time.monotonic()
        rows = [dict(task_id=t["task_id"], entry=t["entry"], parent_task_id=t.get("parent_task_id"), thread=t.get("thread"),
                     started_at=t.get("started_at"), ended_at=t.get("ended_at"),
                     age_seconds=round(now-t["started"], 3) if "started" in t else None,
                     stage=t.get("stage", "queued"), ended=job.done())
                for job in jobs if (t := getattr(job, "lp_diagnostic", None)) is not None]
        emit = logger.warning if reason == "market_read_timeout" else logger.info
        inflight = sum(not job.done() for job in jobs)
        _lp_capture_read_log(lambda: emit("lp_market_read_diagnostic reason=%s inflight=%s tasks=%s", reason, inflight, rows))
        if stack:
            frames = sys._current_frames()
            try:
                for task in tasks:
                    if task.get("stack_captured"):
                        continue
                    task["stack_captured"] = True
                    frame = frames.get(task.get("thread")) if not task.get("ended_at") else None
                    locations = []
                    for _ in range(12):
                        if frame is None:
                            break
                        locations.append((Path(frame.f_code.co_filename).name, frame.f_code.co_name, frame.f_lineno))
                        frame = frame.f_back
                    task_id, thread = task["task_id"], task.get("thread")
                    _lp_capture_read_log(lambda task_id=task_id, thread=thread, locations=locations:
                        logger.info("lp_market_read_stack task_id=%s thread=%s locations=%s", task_id, thread, locations))
                    del frame
            finally:
                del frames
    except Exception:
        pass


@contextmanager
def _lp_read_stage(stage: str, timings: dict[str, float] | None = None, *, deferred_logs=None):
    """Log failed or minute-long reads without messages, payloads or identities.

    SDK pagination includes transport and decoding; its exception class chain
    distinguishes those failures. Thread identity links nested stage timings.
    """
    started = time.monotonic()
    causal = stage in {"account_shared_lock_wait", "account_lock_wait", "account_future_wait", "facts_apply_wait", "facts_mutex_wait", "facts_publish", "facts_report_publish", "facts_failure_publish"}
    task = getattr(_lp_read_local, "task", None)
    previous_stage = task.get("stage") if task is not None else None
    if task is not None:
        task["stage"] = stage
    if causal:
        _lp_causal_event(stage + "_begin")
    if stage in {"account_balance", "account_orders", "account_trades", "account_positions", "market", "book", "market_rewards", "required_order"}:
        _lp_read_count(logical_reads=1)
    error_types = ()
    wait_reason = None
    details = ""
    try:
        yield
    except Exception as exc:
        try:
            error_types = _safe_read_error_chain(exc)
            if any(isinstance(error, (LpAccountRoundInvalid, LpNewerAccountFacts)) for error in _read_exception_chain(exc)):
                wait_reason = "account_round_invalid"
            elif typed_wait := next((
                str(error) for error in _read_exception_chain(exc)
                if isinstance(error, LpObservationWait) and str(error) in {
                    "session_changed", "account_round_invalid", "market_read_in_progress",
                    "market_read_cooling_down", "market_read_capacity", "market_closed",
                }
            ), None):
                wait_reason = typed_wait
            elif stage == "required_order" and _null_order_response(exc):
                wait_reason = "order_lookup_unavailable"
            else:
                try:
                    facts = _safe_history_response_facts(exc)
                    response_facts = getattr(exc, "response_facts", None)
                    if isinstance(response_facts, Mapping):
                        facts.update({key: response_facts[key] for key in (
                            "status", "retry_after_seconds", "retry_after_at",
                        ) if key in response_facts})
                    status = facts.get("status")
                    if type(status) is int and 100 <= status <= 599:
                        details += f" status={status}"
                    retry = facts.get("retry_after_seconds")
                    if type(retry) in {int, float} and math.isfinite(retry) and retry >= 0:
                        details += f" retry_after_seconds={retry}"
                    retry_at = facts.get("retry_after_at")
                    if isinstance(retry_at, datetime) and retry_at.tzinfo is not None:
                        details += f" retry_after_at={retry_at.isoformat()}"
                except Exception:
                    details = ""
        except Exception:
            pass
        raise
    finally:
        if causal:
            _lp_causal_event(stage + "_end", outcome="failed" if error_types else "complete")
        try:
            elapsed = time.monotonic() - started
            if task is not None:
                task["stage"] = previous_stage
                task["timings"][stage] = round(task["timings"].get(stage, 0) + elapsed, 3)
                details += f' task_id={task["task_id"]}'
            if timings is not None:
                timings[stage] = round(elapsed, 3)
            thread = threading.get_ident()
            def emit():
                if wait_reason is not None:
                    logger.info(
                        "lp_read_wait stage=%s elapsed_seconds=%.3f reason=%s thread=%s%s",
                        stage, elapsed, wait_reason, thread, details,
                    )
                elif error_types:
                    logger.warning(
                        "lp_snapshot_stage stage=%s elapsed_seconds=%.3f error_types=%s thread=%s%s",
                        stage, elapsed, ">".join(error_types), thread, details,
                    )
                elif elapsed >= 60:
                    logger.warning(
                        "lp_read_slow stage=%s elapsed_seconds=%.3f thread=%s%s",
                        stage, elapsed, thread, details,
                    )
            if error_types or wait_reason is not None:
                # Preserve the original real error/wait logging path and level.
                emit()
            elif elapsed >= 60:
                deferred = deferred_logs if deferred_logs is not None else getattr(_lp_read_local, 'deferred_logs', None)
                if deferred is None and task is None:
                    emit()  # Preserve existing standalone stage logging.
                else:
                    _lp_capture_read_log(emit, deferred)
        except Exception:
            pass


def _safe_history_response_facts(exc: BaseException) -> dict[str, object]:
    """Keep status, pacing, and exception-chain facts from urllib reads."""

    facts: dict[str, object] = {
        "error_chain": _safe_read_error_chain(exc),
        "error_type": type(exc).__name__,
        **_safe_sqlite_error_facts(exc),
    }
    status = getattr(exc, "code", None)
    if type(status) is not int:
        status = getattr(exc, "status", None)
    if type(status) is int and 100 <= status <= 599:
        facts["status"] = status
        if status == 429 or 500 <= status <= 599:
            facts["error_type"] = f"status{status}"

    headers = getattr(exc, "headers", None)
    if headers is None:
        headers = getattr(exc, "hdrs", None)
    try:
        retry_after = headers.get("Retry-After") if headers is not None else None
    except Exception:
        retry_after = None
    if retry_after is None:
        return facts
    try:
        retry_seconds = float(str(retry_after).strip())
    except (TypeError, ValueError):
        retry_seconds = math.nan
    if math.isfinite(retry_seconds) and retry_seconds >= 0:
        facts["retry_after_seconds"] = (
            int(retry_seconds)
            if retry_seconds.is_integer()
            else retry_seconds
        )
        return facts
    try:
        retry_at = parsedate_to_datetime(str(retry_after).strip())
        if retry_at.tzinfo is None:
            retry_at = retry_at.replace(tzinfo=UTC)
        facts["retry_after_at"] = retry_at
        response_date = headers.get("Date") if headers is not None else None
        if response_date is None:
            response_date = headers.get("date") if headers is not None else None
        if response_date is None:
            return facts
        response_at = parsedate_to_datetime(str(response_date).strip())
        if response_at.tzinfo is None:
            response_at = response_at.replace(tzinfo=UTC)
        retry_delta = (retry_at - response_at).total_seconds()
    except (TypeError, ValueError, OverflowError):
        return facts
    if math.isfinite(retry_delta) and retry_delta >= 0:
        facts["retry_after_seconds"] = (
            int(retry_delta) if retry_delta.is_integer() else retry_delta
        )
    return facts


def _redact_lp_diagnostic(value: object, *, limit: int) -> str:
    text = str(value)
    text = re.sub(
        r"(?im)\b(?:authorization|proxy-authorization)\s*[:=]\s*[^\r\n]*",
        "[redacted-header]",
        text,
    )
    text = re.sub(
        r"(?im)\b(?:cookie|set-cookie)\s*[:=]\s*[^\r\n]*",
        "[redacted-header]",
        text,
    )
    text = " ".join(text.split())
    text = re.sub(r"(?i)https?://[^\s<>\"']+", "[redacted-url]", text)
    text = re.sub(
        r"(?i)\b(?:authorization|proxy-authorization|cookie|set-cookie)\s*[:=]\s*[^\s,;]+",
        "[redacted-header]",
        text,
    )
    text = re.sub(
        r"(?i)(?:[?&](?:token|access_token|api[_-]?key|secret|auth|cookie)=[^&\s]+)",
        "[redacted-query]",
        text,
    )
    text = re.sub(
        r"(?i)\b(?:wallet|token|condition|market|asset|address)(?:[_-]?id)?\s*[:=]\s*[^\s,;]+",
        "[redacted-id]",
        text,
    )
    text = re.sub(r"\b0x[0-9a-fA-F]{40,64}\b", "[redacted-id]", text)
    text = re.sub(r"\b\d{40,}\b", "[redacted-id]", text)
    text = re.sub(
        r"(?i)\b(?:[a-z0-9]+[-_])*(?:token|secret|cookie|password|credential)[-_][a-z0-9._~-]+",
        "[redacted-secret]",
        text,
    )
    return text[:limit]


def _lp_response_error_summary(response: object) -> str:
    try:
        payload = response.json()
    except Exception:
        payload = None
    if isinstance(payload, Mapping):
        field_names = ("error", "message", "detail", "code")

        def public_values(value: object, depth: int = 0) -> tuple[str, ...]:
            if depth > 3:
                return ()
            if isinstance(value, Mapping):
                return tuple(
                    fragment
                    for name in field_names
                    if name in value
                    for fragment in public_values(value[name], depth + 1)
                )
            if isinstance(value, (str, int, float, bool)):
                return (str(value),)
            return ()

        raw = " ".join(public_values(payload))
    elif isinstance(payload, str):
        raw = payload
    else:
        try:
            raw = response.text
        except Exception:
            return "[unavailable]"
    return _redact_lp_diagnostic(raw, limit=_LP_DIAGNOSTIC_SUMMARY_MAX_CHARS)


def _install_lp_metadata_response_hook(
    public: object,
    requested_count: int,
    *,
    facts: dict[str, object] | None = None,
    facts_by_condition_ids: Mapping[frozenset[str], dict[str, object]] | None = None,
) -> Callable[[], None] | None:
    try:
        gamma = getattr(getattr(public, "_ctx"), "gamma")
        http_client = getattr(gamma, "_client")
        response_hooks = getattr(http_client, "event_hooks").get("response")
    except Exception:
        return None
    if not isinstance(response_hooks, list):
        return None

    def on_response(response: object) -> None:
        status = getattr(response, "status_code", None)
        if not isinstance(status, int) or 200 <= status < 300:
            return
        request = getattr(response, "request", None)
        url = getattr(request, "url", None)
        if getattr(url, "path", None) != "/markets/keyset":
            return
        params = getattr(url, "params", None)
        condition_ids = (
            tuple(str(value) for value in params.get_list("condition_ids"))
            if callable(getattr(params, "get_list", None))
            else ()
        )
        response_facts = facts
        if facts_by_condition_ids is not None:
            response_facts = facts_by_condition_ids.get(frozenset(condition_ids))
        if response_facts is not None:
            if type(status) is int:
                response_facts["status"] = status
            headers = getattr(response, "headers", None)
            retry_after = headers.get("retry-after") if headers is not None else None
            if retry_after is not None:
                try:
                    retry_seconds = float(str(retry_after).strip())
                except (TypeError, ValueError):
                    retry_seconds = math.nan
                if math.isfinite(retry_seconds) and retry_seconds >= 0:
                    response_facts["retry_after_seconds"] = (
                        int(retry_seconds)
                        if retry_seconds.is_integer()
                        else retry_seconds
                    )
                else:
                    try:
                        retry_at = parsedate_to_datetime(str(retry_after).strip())
                        if retry_at.tzinfo is None:
                            retry_at = retry_at.replace(tzinfo=UTC)
                        response_facts["retry_after_at"] = retry_at
                    except (TypeError, ValueError, OverflowError):
                        pass
        # httpx runs response hooks before Client.send reads the body.  Keep
        # this read outside the best-effort diagnostic block so a real stream
        # error remains the original request error.
        response.read()
        try:
            page = (
                "continuation"
                if params is not None and params.get("after_cursor") is not None
                else "first"
            )
            url_bytes = len(str(url).encode("utf-8"))
            headers = getattr(response, "headers")
            fields = {
                "content_type": headers.get("content-type", "-"),
                "server": headers.get("server", "-"),
                "cf_ray": headers.get("cf-ray", "-"),
                "retry_after": headers.get("retry-after", "-"),
            }
            safe_fields = {
                name: _redact_lp_diagnostic(
                    value, limit=_LP_DIAGNOSTIC_FIELD_MAX_CHARS
                )
                for name, value in fields.items()
            }
            requested = len(condition_ids) or requested_count
            message = (
                "lp_metadata_http_failure "
                f"status={status} page={page} requested_ids={requested} "
                f"url_bytes={url_bytes} "
                f"content_type={safe_fields['content_type']} "
                f"server={safe_fields['server']} "
                f"cf_ray={safe_fields['cf_ray']} "
                f"retry_after={safe_fields['retry_after']} "
                f"summary={_lp_response_error_summary(response)}"
            )
            logger.warning("%s", message[:_LP_DIAGNOSTIC_LOG_MAX_CHARS])
        except Exception:
            return

    response_hooks.append(on_response)

    def remove() -> None:
        try:
            for index, hook in enumerate(response_hooks):
                if hook is on_response:
                    del response_hooks[index]
                    break
        except Exception:
            return

    return remove


def _install_lp_response_fact_hook(
    public: object,
    *,
    path: str,
    facts: dict[str, object],
    transport_name: str | None = None,
) -> Callable[[], None] | None:
    """Capture safe response facts before the SDK turns them into exceptions."""

    try:
        context = getattr(public, "_ctx")
        preferred = "gamma" if path == "/markets/keyset" else "clob"
        transport_names = (transport_name,) if transport_name is not None else (
            (preferred,) + tuple(
                name for name in ("clob", "gamma", "data") if name != preferred
            )
        )
        transport = next(
            getattr(context, name)
            for name in transport_names
            if getattr(context, name, None) is not None
        )
        http_client = getattr(transport, "_client")
        response_hooks = getattr(http_client, "event_hooks").get("response")
        request_hooks = getattr(http_client, "event_hooks").get("request")
    except Exception:
        return None
    if not isinstance(response_hooks, list):
        return None

    owner_thread = threading.get_ident()

    def on_request(request: object) -> None:
        try:
            if threading.get_ident() == owner_thread and getattr(getattr(request, "url", None), "path", None) == path:
                _lp_read_count(http_requests=1)
        except Exception:
            pass

    def on_response(response: object) -> None:
        try:
            if threading.get_ident() != owner_thread:
                return
            url = getattr(getattr(response, "request", None), "url", None)
            if getattr(url, "path", None) != path:
                return
            _lp_read_count(http_responses=1)
            for field in ("status", "retry_after_seconds", "retry_after_at"):
                facts.pop(field, None)
            status = getattr(response, "status_code", None)
            if type(status) is int:
                facts["status"] = status
                if 200 <= status < 300 and path in {"/data/orders", "/data/trades", "/positions"}:
                    _lp_read_count(http_pages=1)
            headers = getattr(response, "headers", None)
            retry_after = headers.get("retry-after") if headers is not None else None
            if retry_after is None:
                return
            try:
                retry_seconds = float(str(retry_after).strip())
            except (TypeError, ValueError):
                retry_seconds = math.nan
            if math.isfinite(retry_seconds) and retry_seconds >= 0:
                facts["retry_after_seconds"] = (
                    int(retry_seconds)
                    if retry_seconds.is_integer()
                    else retry_seconds
                )
                return
            try:
                retry_at = parsedate_to_datetime(str(retry_after).strip())
                if retry_at.tzinfo is None:
                    retry_at = retry_at.replace(tzinfo=UTC)
                facts["retry_after_at"] = retry_at
                response_date = (
                    headers.get("date") if headers is not None else None
                )
                if response_date is None:
                    return
                response_at = parsedate_to_datetime(str(response_date).strip())
                if response_at.tzinfo is None:
                    response_at = response_at.replace(tzinfo=UTC)
                retry_delta = (retry_at - response_at).total_seconds()
            except (TypeError, ValueError, OverflowError):
                return
            if math.isfinite(retry_delta) and retry_delta >= 0:
                facts["retry_after_seconds"] = (
                    int(retry_delta)
                    if retry_delta.is_integer()
                    else retry_delta
                )
        except Exception:
            return

    def remove() -> None:
        for hooks, callback in ((response_hooks, on_response), (request_hooks, on_request)):
            try:
                if isinstance(hooks, list):
                    for index, hook in enumerate(hooks):
                        if hook is callback:
                            del hooks[index]
                            break
            except Exception:
                continue

    try:
        response_hooks.append(on_response)
        if isinstance(request_hooks, list):
            request_hooks.append(on_request)
    except Exception:
        remove()
        return None
    return remove


def _submit_error_detail(exc: BaseException) -> dict[str, str]:
    """Redacted observable facts about a submit exception; never credentials."""

    message = " ".join(str(exc).split())
    if len(message) > 500:
        message = message[:500] + "…"
    return {
        "error_code": _safe_error_code(exc),
        "error_type": type(exc).__name__,
        "message": message,
    }


def _collect(
    value: object, *, stop_event: threading.Event | None = None
) -> tuple[object, ...]:
    def cancellable(items):
        iterator = iter(items)
        while True:
            if stop_event.is_set():
                raise _RewardReadCancelled
            try:
                item = next(iterator)
            except StopIteration:
                return
            if stop_event.is_set():
                raise _RewardReadCancelled
            yield item

    if stop_event is not None and stop_event.is_set():
        raise _RewardReadCancelled
    if value is None:
        return ()
    if isinstance(value, (str, bytes, Mapping)):
        return (value,)
    # SDK iter_items() hides empty pages. Walk pages so cancellation is
    # checked before each request, including an empty continuation page.
    if (stop_event is not None and callable(getattr(value, "first_page", None))
        and callable(getattr(value, "iter_items", None))):
        try:
            pages = iter(value)
        except TypeError:
            pass  # Older read adapters expose iter_items() without page iteration.
        else:
            return tuple(item for page in cancellable(pages)
                         for item in cancellable(_field(page, "items", ())))
    for method_name in ("iter_items", "all"):
        method = getattr(value, method_name, None)
        if callable(method):
            try:
                return tuple(cancellable(method()) if stop_event is not None else method())
            except TypeError:
                continue
    try:
        return tuple(cancellable(value) if stop_event is not None else cast(Sequence[object], value))
    except TypeError:
        return (value,)


def _iter_reward_items(value: object, stop_event: threading.Event | None):
    """Stream SDK reward/event pages with cancellation and no raw-result cache."""
    def checked(items):
        iterator = iter(items)
        while True:
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            try:
                item = next(iterator)
            except StopIteration:
                return
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            yield item

    read_items = getattr(value, "iter_items", None)
    if callable(read_items):
        if callable(getattr(value, "first_page", None)):
            try:
                pages = iter(value)
            except TypeError:
                pass
            else:
                for page in checked(pages):
                    yield from checked(_field(page, "items", ()))
                return
        yield from checked(read_items())
    else:
        yield from checked(_collect(value, stop_event=stop_event))


def _collect_lp_market_pages(
    value: object, requested: set[str]
) -> tuple[Mapping[str, object], ...]:
    def project(items: object) -> tuple[Mapping[str, object], ...]:
        return tuple(
            facts for item in _collect(items)
            if (facts := _lp_market_facts(item)) is not None
        )

    first_page = getattr(value, "first_page", None)
    from_cursor = getattr(value, "from_cursor", None)
    if not callable(first_page) or not callable(from_cursor):
        page_items = _field(value, "items", None)
        if page_items is not None:
            return project(page_items)
        return project(value)

    rows: list[Mapping[str, object]] = []
    observed: set[str] = set()
    page = first_page()
    while True:
        page_rows = project(_field(page, "items", ()))
        rows.extend(page_rows)
        observed.update(
            condition_id
            for row in page_rows
            for condition_id in (row.get("condition_id", row.get("conditionId")),)
            if isinstance(condition_id, str) and condition_id in requested
        )
        if observed >= requested or not _field(page, "has_more", False):
            return tuple(rows)
        cursor = _field(page, "next_cursor")
        if not isinstance(cursor, str) or not cursor:
            raise RuntimeError("market pagination cursor missing")
        page = from_cursor(cursor).first_page()


def _field(value: object, name: str, default: object = None) -> object:
    if isinstance(value, Mapping):
        return value.get(name, default)
    return getattr(value, name, default)


def _safe_string(value: object) -> str:
    return value if isinstance(value, str) else str(value)


def _decimal(value: object, *, base_units: bool = False) -> Decimal:
    if isinstance(value, bool):
        raise ValueError("invalid decimal")
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        del exc
        raise ValueError("invalid decimal") from None
    if not parsed.is_finite():
        raise ValueError("invalid decimal")
    return parsed / COLLATERAL_BASE_UNITS if base_units else parsed


def _address_from_client(client: object, name: str) -> str | None:
    try:
        value = getattr(client, name)
    except Exception:
        return None
    if not isinstance(value, str) or not _ADDRESS_RE.fullmatch(value):
        return None
    return value


def _lp_event_facts(value: object) -> Mapping[str, object] | None:
    """Keep LP event evidence without serializing the unused child markets."""
    fields = {"id", "slug", "state", "schedule"}
    if isinstance(value, Mapping):
        return {key: value[key] for key in fields if key in value}
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        facts = model_dump(include=fields)
        return facts if isinstance(facts, Mapping) else None
    return None


def _lp_market_facts(value: object) -> Mapping[str, object] | None:
    """Project LP inputs before a completed worker can retain the SDK tree."""
    fields = {
        "id", "market_id", "condition_id", "conditionId", "slug", "question",
        "title", "market_url", "url", "state", "trading", "rewards", "sports",
        "prices", "outcomes", "events", "rewards_max_spread", "rewards_min_size",
        "taker_fee_rate",
    }
    if isinstance(value, Mapping):
        return {key: value[key] for key in fields if key in value}
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            facts = model_dump(include=fields, exclude={"rewards": {"clob_rewards"}})
        except Exception:
            return None
        return dict(facts) if isinstance(facts, Mapping) else None
    return None


def _model_dict(value: object) -> Mapping[str, object] | None:
    if isinstance(value, Mapping):
        return value
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            dumped = model_dump()
        except Exception:
            return None
        return dumped if isinstance(dumped, Mapping) else None
    return None


def _lp_decimal(value: object) -> Decimal | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None
    return parsed if parsed.is_finite() else None


def _reward_date(value: object) -> Date | None:
    if isinstance(value, datetime):
        return value.astimezone(UTC).date()
    if not isinstance(value, str):
        return None
    text = value.strip()
    if "T" in text:
        text = text.split("T", 1)[0]
    try:
        return Date.fromisoformat(text)
    except ValueError:
        return None


def _normalize_lp_reward_config(
    value: object,
    *,
    sponsored: bool,
    source: str | None = None,
    require_id: bool = True,
) -> tuple[dict[str, object], tuple[str | None, str, Date, Date]] | None:
    """Normalize one SDK reward config for both catalog read paths."""

    config = _model_dict(value)
    if config is None:
        return None
    config_id = config.get("id")
    asset_address = config.get("asset_address")
    start_date = _reward_date(config.get("start_date"))
    end_date = _reward_date(config.get("end_date"))
    rate = _lp_decimal(config.get("rate_per_day"))
    if (
        (require_id and config_id is None)
        or not isinstance(asset_address, str)
        or start_date is None
        or end_date is None
        or rate is None
        or rate < 0
    ):
        return None
    normalized = dict(config)
    normalized["rate_per_day"] = rate
    normalized["sponsored"] = sponsored
    if source is not None:
        normalized["source"] = source
    return normalized, (
        None if config_id is None else str(config_id),
        asset_address.casefold(),
        start_date,
        end_date,
    )


def _reward_usd_value(row: Mapping[str, object]) -> Decimal | None:
    asset = row.get("asset_address")
    if not isinstance(asset, str) or asset.strip().lower() not in LP_REWARD_ASSET_USD_ADDRESSES:
        return None
    earnings = _lp_decimal(row.get("earnings"))
    asset_rate = _lp_decimal(row.get("asset_rate"))
    # The official reward docs identify the supported pUSD/USDC.e assets, but
    # do not define asset_rate as a general USD FX rate.  Only a unit rate is
    # safe to treat as nominal USD; every other valuation remains UNKNOWN.
    if (
        earnings is None
        or asset_rate is None
        or earnings < 0
        or asset_rate != Decimal("1")
    ):
        return None
    return earnings


def _reward_raw_amounts(
    rows: Sequence[Mapping[str, object]],
    *,
    parsed_date: Date,
    maker: str,
    condition_id: str | None = None,
) -> dict[str, Decimal] | None:
    amounts: dict[str, Decimal] = {}
    maker_folded = maker.casefold()
    for row in rows:
        if _reward_date(row.get("date")) != parsed_date:
            return None
        row_maker = row.get("maker_address")
        if not isinstance(row_maker, str) or row_maker.casefold() != maker_folded:
            return None
        if condition_id is not None:
            row_condition = row.get("condition_id")
            if not isinstance(row_condition, str):
                return None
            if row_condition != condition_id:
                continue
        asset = row.get("asset_address")
        amount = _lp_decimal(row.get("earnings"))
        if not isinstance(asset, str) or not asset.strip() or amount is None or amount < 0:
            return None
        identity = asset.strip().casefold()
        amounts[identity] = amounts.get(identity, Decimal("0")) + amount
    return amounts


def _reward_accruals(amounts: Mapping[str, Decimal]) -> tuple[dict[str, object], ...]:
    return tuple(
        {
            "amount": amount,
            "asset": LP_REWARD_ASSET_LABELS.get(address, address),
            "asset_address": address,
        }
        for address, amount in sorted(amounts.items())
    )


def _lp_level(value: object) -> dict[str, object] | None:
    row = _model_dict(value)
    if row is None:
        return None
    price = _lp_decimal(row.get("price"))
    size = _lp_decimal(row.get("size"))
    if price is None or size is None:
        return None
    return {"price": price, "size": size}


def _lp_book(value: object) -> dict[str, object] | None:
    row = _model_dict(value)
    if row is None:
        return None
    bids: dict[Decimal, Decimal] = {}
    asks: dict[Decimal, Decimal] = {}
    for field, target in (("bids", bids), ("asks", asks)):
        raw_levels = row.get(field)
        if not isinstance(raw_levels, Sequence) or isinstance(raw_levels, (str, bytes)):
            return None
        for raw_level in raw_levels:
            level = _lp_level(raw_level)
            if level is None:
                continue
            price = cast(Decimal, level["price"])
            size = cast(Decimal, level["size"])
            if price <= 0 or size <= 0:
                continue
            target[price] = target.get(price, Decimal("0")) + size
    timestamp = _venue_timestamp(row.get("timestamp"))
    return {
        "market": row.get("condition_id", row.get("market")),
        "condition_id": row.get("condition_id", row.get("market")),
        "token_id": row.get("token_id", row.get("asset_id")),
        "timestamp": timestamp,
        "source_timestamp": timestamp if isinstance(row.get("timestamp"), datetime) else row.get("timestamp"),
        "bids": [
            {"price": price, "size": size}
            for price, size in sorted(bids.items())
        ],
        "asks": [
            {"price": price, "size": size}
            for price, size in sorted(asks.items())
        ],
        "min_order_size": _lp_decimal(row.get("min_order_size")),
        "tick_size": _lp_decimal(row.get("tick_size")),
        "neg_risk": row.get("neg_risk"),
        "last_trade_price": _lp_decimal(row.get("last_trade_price")),
        "hash": row.get("hash"),
    }


def _lp_order(value: object) -> dict[str, object] | None:
    row = _model_dict(value)
    if row is None:
        return None
    order_id = row.get("id", row.get("order_id"))
    token_id = row.get("token_id", row.get("asset_id"))
    if order_id in (None, "") or token_id in (None, ""):
        return None
    original_size = _lp_decimal(row.get("original_size", row.get("size")))
    matched = _lp_decimal(row.get("size_matched", row.get("matched_amount")))
    if original_size is None:
        original_size = Decimal("0")
    if matched is None:
        matched = Decimal("0")
    return {
        "id": str(order_id),
        "order_id": str(order_id),
        "market": row.get("condition_id", row.get("market")),
        "condition_id": row.get("condition_id", row.get("market")),
        "market_id": row.get("market_id"),
        "market_title": row.get("market_title", row.get("title")),
        "market_url": row.get("market_url"),
        "token_id": str(token_id),
        "asset_id": str(token_id),
        "side": str(row.get("side", "")).upper(),
        "price": _lp_decimal(row.get("price")),
        "original_size": original_size,
        "size_matched": matched,
        "fill_quantity_known": _lp_decimal(row.get("size_matched", row.get("matched_amount"))) is not None,
        "average_price": _lp_decimal(row.get("average_price", row.get("average_fill_price"))),
        "fee": _lp_decimal(row.get("fee", row.get("fees"))),
        "matched_at": _venue_timestamp(row.get("matched_at", row.get("match_time"))),
        "updated_at": _venue_timestamp(row.get("updated_at")),
        "remaining_size": max(Decimal("0"), original_size - matched),
        "size": max(Decimal("0"), original_size - matched),
        "outcome": row.get("outcome"),
        "order_type": row.get("order_type"),
        "status": str(row.get("status", "")).upper(),
        "expiration": (
            _venue_timestamp(row.get("expiration", row.get("expires_at")))
            if isinstance(row.get("expiration", row.get("expires_at")), datetime)
            else row.get("expiration", row.get("expires_at"))
        ),
        "created_at": _venue_timestamp(row.get("created_at")),
    }


def _lp_position(value: object) -> dict[str, object] | None:
    row = _model_dict(value)
    if row is None:
        return None
    token_id = row.get("token_id", row.get("asset_id", row.get("asset")))
    if token_id in (None, ""):
        return None
    market_url = row.get("market_url")
    slug = row.get("slug")
    if not market_url and isinstance(slug, str) and slug.strip():
        market_url = f"https://polymarket.com/event/{slug.strip()}"
    return {
        "condition_id": row.get("condition_id", row.get("conditionId", row.get("market"))),
        "market_id": row.get("market_id"),
        "market_title": row.get("market_title", row.get("title")),
        "market_url": market_url,
        "token_id": str(token_id),
        "outcome": row.get("outcome"),
        "size": _lp_decimal(row.get("size", row.get("quantity"))),
        "average_price": _lp_decimal(row.get("average_price", row.get("avg_price"))),
        "initial_value": _lp_decimal(row.get("initial_value")),
        "current_value": _lp_decimal(row.get("current_value")),
        "current_price": _lp_decimal(row.get("cur_price")),
        "redeemable": row.get("redeemable"),
    }


def _lp_maker_order(value: object) -> dict[str, object] | None:
    row = _model_dict(value)
    if row is None:
        return None
    order_id = row.get("order_id", row.get("id"))
    token_id = row.get("token_id", row.get("asset_id"))
    if order_id in (None, "") or token_id in (None, ""):
        return None
    return {
        "order_id": str(order_id),
        "token_id": str(token_id),
        "asset_id": str(token_id),
        "maker_address": row.get("maker_address"),
        "owner": row.get("owner"),
        "side": str(row.get("side", "")).upper(),
        "price": _lp_decimal(row.get("price")),
        "matched_amount": _lp_decimal(row.get("matched_amount", row.get("size"))),
        "fee_rate_bps": _lp_decimal(row.get("fee_rate_bps")),
    }


def _lp_maker_order_is_self(row: object, wallet_address: object) -> bool:
    """True only when a maker row provably belongs to our wallet.

    Rows without a usable maker address/owner cannot be attributed and are
    treated as foreign: missing volume is safer than misattributed volume.
    """

    target = str(wallet_address or "").strip().lower()
    if not target:
        return False
    if not isinstance(row, Mapping):
        return False
    for key in ("maker_address", "owner"):
        value = str(row.get(key) or "").strip().lower()
        if value and value == target:
            return True
    return False


def _lp_trade(value: object) -> dict[str, object] | None:
    row = _model_dict(value)
    if row is None:
        return None
    trade_id = row.get("id", row.get("trade_id"))
    token_id = row.get("token_id", row.get("asset_id"))
    raw_makers = row.get("maker_orders", ())
    if trade_id in (None, "") or token_id in (None, ""):
        return None
    makers: list[dict[str, object]] = []
    if not isinstance(raw_makers, Sequence) or isinstance(raw_makers, (str, bytes)):
        return None
    for maker in raw_makers:
        normalized = _lp_maker_order(maker)
        if normalized is None:
            # Dropping a malformed maker can erase an owned order's fill.
            return None
        makers.append(normalized)
    status = str(row.get("status") or "").strip().upper()
    if status.startswith("TRADE_STATUS_"):
        status = status[len("TRADE_STATUS_") :]
    taker_order_id = str(row.get("taker_order_id") or "").strip()
    if not status or (not taker_order_id and not makers):
        return None
    return {
        "id": str(trade_id),
        "trade_id": str(trade_id),
        "market": row.get("condition_id", row.get("market")),
        "condition_id": row.get("condition_id", row.get("market")),
        "token_id": str(token_id),
        "asset_id": str(token_id),
        "taker_order_id": taker_order_id,
        "side": str(row.get("side", "")).upper(),
        "trader_side": str(row.get("trader_side", "")).upper(),
        "price": _lp_decimal(row.get("price")),
        "size": _lp_decimal(row.get("size")),
        "status": status,
        "fee_rate_bps": _lp_decimal(row.get("fee_rate_bps")),
        "maker_orders": makers,
        "matched_at": _trade_timestamp(row),
        "updated_at": _venue_timestamp(row.get("updated_at", row.get("last_update"))),
    }


def _venue_timestamp(value: object) -> datetime | None:
    if isinstance(value, datetime):
        # Guarded SDK datetimes are capability proxies; reconstruct a scalar
        # before caching facts, without accessing any protected raw internals.
        moment = datetime.fromisoformat(value.isoformat())
    elif isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        try:
            number = Decimal(str(value))
            if not number.is_finite():
                return None
            # CLOB order-book timestamps are epoch milliseconds; trade
            # collaborators have historically supplied epoch seconds.
            divisor = Decimal("1000") if abs(number) > Decimal("10000000000") else Decimal("1")
            moment = datetime.fromtimestamp(float(number / divisor), UTC)
        except (OverflowError, OSError, ValueError):
            return None
    elif isinstance(value, str):
        text = value.strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            moment = datetime.fromisoformat(text)
        except ValueError:
            try:
                number = Decimal(text)
            except (InvalidOperation, ValueError):
                return None
            if not number.is_finite():
                return None
            divisor = Decimal("1000") if abs(number) > Decimal("10000000000") else Decimal("1")
            try:
                moment = datetime.fromtimestamp(float(number / divisor), UTC)
            except (OverflowError, OSError, ValueError):
                return None
    else:
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=UTC)
    return moment.astimezone(UTC)


def _trade_timestamp(value: object) -> datetime | None:
    for name in ("matched_at", "match_time", "updated_at", "last_update", "timestamp"):
        timestamp = _venue_timestamp(_field(value, name))
        if timestamp is not None:
            return timestamp
    return None


def _lp_full_trade_is_relevant(
    value: object,
    *,
    condition_id: str,
    token_id: str,
    exact_order_ids: set[str],
) -> bool:
    """Decide relevance before parsing, without trusting only top-level IDs."""

    row = _model_dict(value)
    if row is None:
        # An unnormalizable row has no proof it is unrelated. Preserve the
        # original fail-closed behavior instead of silently discarding it.
        return True
    top_condition = str(
        _field(row, "condition_id", _field(row, "market", "")) or ""
    )
    top_token = str(
        _field(row, "token_id", _field(row, "asset_id", "")) or ""
    )
    exact_ids = {str(_field(row, "taker_order_id", "") or "")}
    ambiguous_maker = False
    matching_maker_token = False
    for maker in _collect(row.get("maker_orders")):
        maker_row = _model_dict(maker)
        if maker_row is not None:
            exact_ids.add(
                str(_field(maker_row, "order_id", _field(maker_row, "id", "")) or "")
            )
            maker_token = str(
                _field(maker_row, "token_id", _field(maker_row, "asset_id", "")) or ""
            )
            if maker_token in ("", token_id):
                matching_maker_token = True
        else:
            ambiguous_maker = True
    if exact_order_ids & exact_ids:
        return True
    if top_condition not in ("", condition_id):
        return False
    if matching_maker_token or ambiguous_maker:
        return True
    # A missing top-level token is ambiguous only when the condition itself
    # matches; maker legs still determine attribution after normalization.
    return top_token in ("", token_id)


_LP_BUNDLE_FILL_STATUSES = frozenset({"CONFIRMED", "MATCHED", "FILLED"})


def _lp_bundle_receipt_facts(
    raw_trades: object,
) -> dict[str, tuple[Decimal | None, set[str]]]:
    """Aggregate exact-order fills from one complete trade bundle."""

    observed: dict[tuple[str, str], list[Decimal]] = {}
    trade_ids_by_order: dict[str, set[str]] = {}
    ambiguous_orders: set[str] = set()
    all_order_ids: set[str] = set()
    for raw in _collect(raw_trades):
        row = _model_dict(raw)
        if row is None:
            continue
        status = str(_field(row, "status", "") or "").upper()
        if status.startswith("TRADE_STATUS_"):
            status = status[len("TRADE_STATUS_") :]
        trade_id = str(_field(row, "id", _field(row, "trade_id", "")) or "")
        taker_id = str(_field(row, "taker_order_id", "") or "")
        row_order_ids: set[str] = set()
        if taker_id:
            row_order_ids.add(taker_id)
        for maker in _collect(row.get("maker_orders")):
            maker_row = _model_dict(maker)
            if maker_row is None:
                continue
            maker_id = str(
                _field(maker_row, "order_id", _field(maker_row, "id", "")) or ""
            )
            if maker_id:
                row_order_ids.add(maker_id)
        # Failed and pending identities are not fill quantity, but the venue
        # may still reference them from an exact order receipt. Record their
        # presence so a known FAILED trade cannot masquerade as newly observed.
        if trade_id:
            for order_id in row_order_ids:
                trade_ids_by_order.setdefault(order_id, set()).add(trade_id)
                all_order_ids.add(order_id)
        if status not in _LP_BUNDLE_FILL_STATUSES:
            # FAILED and unknown states are not evidence of a successful fill.
            continue
        if not trade_id:
            # Without a venue identity, repeated pages cannot be distinguished
            # from additional fills.
            # Scope ambiguity to the exact orders carried by this malformed
            # row; earlier unrelated rows must not become UNKNOWN.
            ambiguous_orders.update(row_order_ids)
            continue
        amounts: list[tuple[str, Decimal]] = []
        taker_quantity = _lp_decimal(row.get("size"))
        if taker_id and taker_quantity is not None:
            amounts.append((taker_id, taker_quantity))
        for maker in _collect(row.get("maker_orders")):
            maker_row = _model_dict(maker)
            if maker_row is None:
                continue
            maker_id = str(
                _field(maker_row, "order_id", _field(maker_row, "id", "")) or ""
            )
            amount = _lp_decimal(
                maker_row.get("matched_amount", maker_row.get("size"))
            )
            if not maker_id or amount is None:
                continue
            amounts.append((maker_id, amount))
        for order_id, amount in amounts:
            observed.setdefault((order_id, trade_id), []).append(amount)
            trade_ids_by_order.setdefault(order_id, set()).add(trade_id)
            all_order_ids.add(order_id)

    quantities: dict[str, Decimal] = {}
    for (order_id, _trade_id), amounts in observed.items():
        if any(amount is None for amount in amounts):
            ambiguous_orders.add(order_id)
            continue
        unique = set(amounts)
        if len(unique) != 1:
            ambiguous_orders.add(order_id)
            continue
        quantities[order_id] = quantities.get(order_id, Decimal("0")) + unique.pop()

    fills: dict[str, tuple[Decimal | None, set[str]]] = {}
    for order_id in all_order_ids:
        fills[order_id] = (
            None if order_id in ambiguous_orders else quantities.get(order_id, Decimal("0")),
            trade_ids_by_order.get(order_id, set()),
        )
    return fills


def _string_refs(value: object) -> set[str]:
    if isinstance(value, str):
        return {value} if value.strip() else set()
    if isinstance(value, (list, tuple, set, frozenset)):
        return {item for item in value if isinstance(item, str) and item.strip()}
    return set()


def _reward_total_rows(payload: object) -> tuple[Mapping[str, object], ...]:
    if not isinstance(payload, Sequence) or isinstance(payload, (str, bytes, Mapping)):
        raise ValueError("reward_total_shape_unknown")
    rows: list[Mapping[str, object]] = []
    for row in payload:
        if not isinstance(row, Mapping):
            raise ValueError("reward_row_unknown")
        rows.append(row)
    return tuple(rows)


def _reward_amount(
    rows: Sequence[Mapping[str, object]],
    *,
    parsed_date: Date,
    maker: str,
    condition_id: str | None = None,
) -> Decimal | None:
    total = Decimal("0")
    maker_folded = maker.casefold()
    for row in rows:
        if _reward_date(row.get("date")) != parsed_date:
            return None
        row_maker = row.get("maker_address")
        if not isinstance(row_maker, str) or row_maker.casefold() != maker_folded:
            return None
        if condition_id is not None:
            row_condition = row.get("condition_id")
            if not isinstance(row_condition, str):
                return None
            if row_condition != condition_id:
                continue
        value = _reward_usd_value(row)
        if value is None:
            return None
        total += value
    return total


@dataclass(eq=False)
class _LpAccountRound:
    """One explicitly ended, read-only reconciliation scope."""

    client: "PolymarketTradingClient"
    lock: threading.Lock
    active: bool = True
    generation: int = 0
    trade_generation_provider: Callable[[], int] | None = None
    trade_generation: int | None = None
    future: "Future[Mapping[str, object]] | None" = None


class LpNewerAccountFacts(ValueError):
    """Exact account evidence that the observed DB trade generation is old."""

    def __init__(self, *, observed_trade_generation: int) -> None:
        super().__init__("external_snapshot_unknown")
        self.observed_trade_generation = observed_trade_generation


class LpAccountRoundInvalid(ValueError):
    """The reconciliation scope ended or advanced; facts are only stale."""


class LpAccountReadError(ValueError):
    """Safe LP account failure with the provider's fixed retry deadline."""

    def __init__(self, reason: str, retry_at: datetime | None = None) -> None:
        super().__init__(reason)
        self.retry_at = retry_at


def _derive_existing_clob_credentials(private_key: str) -> object:
    """GET-only L2 derivation; never use the SDK's create-first bootstrap."""
    from eth_account import Account
    from polymarket._internal.actions.auth import derive_api_key_sync
    from polymarket._internal.l1_auth import sign_api_key_auth
    from polymarket.clients._transport import SyncTransport

    signer = Account.from_key(private_key)
    transport = SyncTransport(base_url=PRODUCTION.clob_url)
    try:
        signature = sign_api_key_auth(
            signer, chain_id=PRODUCTION.chain_id, timestamp=int(time.time()), nonce=0
        )
        return derive_api_key_sync(transport, signature)
    finally:
        transport.close()


class PolymarketTradingClient:
    """A narrow, redacted wrapper around the official synchronous SDK."""

    def __init__(
        self,
        config: TradingConfig,
        client: object,
        *,
        urlopen_fn: Callable[..., object] | None = None,
        public_client_factory: Callable[[], object] | None = None,
        metadata_cache: object | None = None,
    ) -> None:
        self.config = config
        self._client = client
        self._urlopen_fn = urlopen_fn
        self._public_client_factory = public_client_factory or PublicClient
        self._lp_public_client: object | None = None
        self._lp_public_client_lock = threading.Lock()
        self._lp_public_closed = False
        self._lp_public_readers = 0
        self._lp_account_read_lock = threading.Lock()
        self._lp_account_read_retry = None
        self._lp_public_read_timeout = 1.0
        self._lp_public_reads_lock = threading.Lock()
        self._lp_public_reads: dict[str, Future] = {}
        self._lp_public_read_retry: dict[str, tuple[float, dict[str, object]]] = {}
        self._metadata_cache = metadata_cache
        self._candidate_exclusions_enabled = False
        self._metadata_entries: MutableMapping[
            str, tuple[float, dict[str, object] | None]
        ] = LPReadScratch()
        self._metadata_lock = threading.Lock()
        self._lp_order_read_lock = threading.Lock()
        self._lp_order_read_failures = {}
        self._lp_account_shared_lock = threading.Lock()
        self._lp_account_shared_cache: dict[str, object] | None = None
        self._metadata_warm_loaded = False
        self._metadata_last_prune_epoch = float("-inf")
        self._readiness_key: tuple[PairIntent, Decimal] | None = None
        self._threshold_readiness_key: ThresholdHedgeIntent | None = None
        self._cross_leg_readiness_key: object | None = None
        self._last_submit_error: dict[str, str] | None = None

    @contextmanager
    def _lp_snapshot_public_client(self):
        with _lp_read_stage("public_client"), self._lp_public_client_lock:
            if self._lp_public_closed:
                raise RuntimeError("LP snapshot client is closed")
            if self._lp_public_client is None:
                self._lp_public_client = self._public_client_factory()
            public = self._lp_public_client
            self._lp_public_readers += 1
        try:
            yield public
        finally:
            with self._lp_public_client_lock:
                self._lp_public_readers -= 1
                closing = self._lp_public_closed
            if closing:
                self.close()

    def _lp_public_retry_after(self, error: Mapping[str, object]) -> float | None:
        seconds = error.get("retry_after_seconds")
        if isinstance(seconds, (int, float)) and not isinstance(seconds, bool):
            if math.isfinite(float(seconds)) and seconds >= 0:
                return time.monotonic() + float(seconds)
        retry_at = error.get("retry_after_at")
        if isinstance(retry_at, datetime):
            moment = retry_at if retry_at.tzinfo else retry_at.replace(tzinfo=UTC)
            return max(0.0, (moment - datetime.now(UTC)).total_seconds() + time.monotonic())
        return None

    def _lp_public_error_at_deadline_locked(
        self, key: str, error: Mapping[str, object], *, create: bool
    ) -> tuple[float, dict[str, object]] | None:
        """Read/create the provider or local retry fence; caller holds its lock."""
        existing = self._lp_public_read_retry.get(key)
        if existing is not None:
            return existing[0], self._lp_public_retry_projection(existing)
        deadline = self._lp_public_retry_after(error)
        if deadline is None or not create:
            return None
        self._lp_public_read_retry[key] = (deadline, dict(error))
        return deadline, dict(error)

    @staticmethod
    def _lp_public_retry_projection(
        entry: tuple[float, dict[str, object]],
    ) -> dict[str, object]:
        deadline, error = entry
        remaining = max(0.0, deadline - time.monotonic())
        projected = dict(error)
        projected["retry_after_seconds"] = (
            int(remaining) if remaining.is_integer() else remaining
        )
        projected["retry_after_at"] = datetime.fromtimestamp(
            time.time() + remaining, UTC
        )
        return projected

    @staticmethod
    def _lp_public_error_facts(exc: BaseException) -> dict[str, object]:
        if isinstance(exc, LpObservationWait) and str(exc) == "market_closed":
            return {
                "error_type": "market_closed",
                "stage": "market_book",
                "retry_after_seconds": 60,
                "retry_source": "local_closed_market_recheck",
            }
        return _safe_history_response_facts(exc)

    def _read_lp_public_snapshot(
        self, key: str, market_id: str, token_id: str, *, wait: bool = True,
        condition_id: str | None = None,
    ) -> tuple[object | None, object | None, datetime | None, dict[str, object] | None]:
        """Bounded single-flight public read with a fixed in-memory retry fence."""
        with self._lp_public_reads_lock:
            retry = self._lp_public_read_retry.get(key)
            if retry is not None and time.monotonic() < retry[0]:
                return None, None, None, self._lp_public_retry_projection(retry)
            if retry is not None:
                self._lp_public_read_retry.pop(key, None)
                expired = self._lp_public_reads.get(key)
                if expired is not None and expired.done():
                    self._lp_public_reads.pop(key, None)
            existing = self._lp_public_reads.get(key)
            if existing is not None:
                if not existing.done():
                    return None, None, None, {
                        "error_type": "market_read_in_progress",
                        "stage": "market_book",
                    }
                try:
                    cached_market, cached_token, market_model, book_model, received_at = existing.result()
                except Exception as exc:
                    self._lp_public_reads.pop(key, None)
                    recorded = self._lp_public_error_at_deadline_locked(
                        key, self._lp_public_error_facts(exc), create=False
                    )
                    error = recorded[1] if recorded is not None else self._lp_public_error_facts(exc)
                    return None, None, None, error
                fresh = (
                    cached_market == market_id
                    and cached_token == token_id
                    and received_at is not None
                    and 0 <= (datetime.now(UTC) - received_at).total_seconds() <= 60
                )
                if self._lp_public_reads.get(key) is existing:
                    self._lp_public_reads.pop(key)
                if fresh:
                    return market_model, book_model, received_at, None
            if len([job for job in self._lp_public_reads.values() if not job.done()]) >= 2:
                future = None
                now = time.monotonic()
                report_capacity = now >= getattr(self, '_lp_public_diagnostic_at', float('-inf'))
                if report_capacity:
                    self._lp_public_diagnostic_at = now + 60
                jobs = tuple(job for job in self._lp_public_reads.values() if not job.done())
            else:
                future = Future()
                try:
                    parent = getattr(_lp_read_local, 'task', None)
                    future.lp_diagnostic = dict(task_id=uuid.uuid4().hex, entry='public_snapshot',
                        parent_task_id=parent['task_id'] if parent is not None else None,
                        budget=self._lp_public_read_timeout)
                except Exception:
                    pass
                self._lp_public_reads[key] = future
        if future is None:
            if report_capacity:
                _lp_market_read_diagnostic('market_read_capacity', jobs)
            return None, None, None, {'error_type': 'market_read_capacity', 'stage': 'market_book'}

        def run():
            pending_logs = []
            try:
                with _lp_read_task("public_snapshot", task=getattr(future, "lp_diagnostic", None), deferred_logs=pending_logs), self._lp_snapshot_public_client() as public:
                    with _lp_read_stage("market"):
                        market_model = public.get_market(id=market_id)
                        market = _model_dict(market_model) or {}
                        state = _model_dict(market.get("state")) or {}
                        outcomes = _model_dict(market.get("outcomes")) or {}
                        if (
                            state.get("closed") is True
                            and market.get("id") == market_id
                            and condition_id is not None
                            and market.get("condition_id") == condition_id
                            and any(
                                (_model_dict(outcomes.get(side)) or {}).get("token_id") == token_id
                                for side in ("yes", "no")
                            )
                        ):
                            raise LpObservationWait("market_closed")
                    with _lp_read_stage("book"):
                        book_model = public.get_order_book(token_id=token_id)
                        received_at = datetime.now(UTC)
                future.set_result((market_id, token_id, market_model, book_model, received_at))
            except BaseException as exc:
                error = self._lp_public_error_facts(exc)
                with self._lp_public_reads_lock:
                    self._lp_public_error_at_deadline_locked(key, error, create=True)
                future.set_exception(exc)
            finally:
                _lp_flush_read_logs(pending_logs)

        threading.Thread(target=run, daemon=True, name=f"lp-public-read:{key}").start()
        if not wait:
            return None, None, None, {
                "error_type": "market_read_in_progress",
                "stage": "market_book",
            }
        try:
            with _lp_read_stage("public_future_wait"):
                _, _, market_model, book_model, received_at = future.result(
                    timeout=self._lp_public_read_timeout
                )
        except FuturesTimeoutError:
            task = getattr(future, 'lp_diagnostic', None)
            if task is not None:
                task['caller_timed_out'] = True
            with self._lp_public_reads_lock:
                jobs = tuple(job for job in self._lp_public_reads.values() if not job.done())
            if future not in jobs:
                jobs += (future,)
            _lp_market_read_diagnostic('market_read_timeout', jobs, stack=True)
            return None, None, None, {
                "error_type": "TimeoutError",
                "stage": "market_book",
            }
        except Exception as exc:
            with self._lp_public_reads_lock:
                if self._lp_public_reads.get(key) is future:
                    self._lp_public_reads.pop(key)
                recorded = self._lp_public_error_at_deadline_locked(
                    key, self._lp_public_error_facts(exc), create=False
                )
            error = recorded[1] if recorded is not None else self._lp_public_error_facts(exc)
            return None, None, None, error
        with self._lp_public_reads_lock:
            if self._lp_public_reads.get(key) is future:
                self._lp_public_reads.pop(key)
        return market_model, book_model, received_at, None

    def close(self) -> None:
        """Release the public connections owned by LP snapshots."""
        with self._lp_public_client_lock:
            self._lp_public_closed = True
            # Timed-out market workers can still be reading. The final reader
            # releases the connections; shutdown prevents any new borrowers.
            if self._lp_public_readers:
                return
            public, self._lp_public_client = self._lp_public_client, None
        close = getattr(public, "close", None)
        if callable(close):
            with _lp_read_stage("public_close"):
                close()

    def attach_metadata_cache(self, cache: object | None) -> None:
        """Attach a duck-typed persistent backing store before first use."""

        with self._metadata_lock:
            self._metadata_cache = cache

    def configure_lp_candidate_exclusions(self, enabled: bool) -> None:
        self._candidate_exclusions_enabled = enabled
        if enabled:
            self.evict_lp_candidate_metadata(now=datetime.now(UTC))

    def evict_lp_candidate_metadata(self, *, condition_ids=None, now: datetime) -> None:
        if not self._candidate_exclusions_enabled or self._metadata_cache is None:
            return
        with self._metadata_lock:
            ids = tuple(self._metadata_entries) if condition_ids is None else tuple(condition_ids)
            allowed = set(self._metadata_cache.lp_candidate_conditions(ids, now=now))
            for cid in ids:
                if cid not in allowed:
                    self._metadata_entries.pop(cid, None)

    def expire_lp_metadata_cache(self) -> None:
        """Drop all cached LP market metadata so the next read re-fetches."""

        with self._metadata_lock:
            self._metadata_entries.clear()

    def last_submit_error(self) -> dict[str, str] | None:
        """Redacted detail of the most recent submit exception, if any."""

        return self._last_submit_error

    @classmethod
    def from_keychain(
        cls,
        config: TradingConfig,
        *,
        client_factory: Callable[..., object] | None = None,
        run: Callable[..., subprocess.CompletedProcess[str]] | None = None,
        public_client_factory: Callable[[], object] | None = None,
        metadata_cache: object | None = None,
        read_only: bool = False,
    ) -> "PolymarketTradingClient":
        private_key = load_keychain_secret("signing-private-key", run=run)
        builder_key = load_keychain_secret("builder-key", run=run)
        builder_secret = load_keychain_secret("builder-secret", run=run)
        builder_passphrase = load_keychain_secret("builder-passphrase", run=run)
        try:
            # SDK create(credentials=None) POSTs /auth/api-key first, and
            # create() may deploy a missing wallet. Read-only startup derives
            # an existing key with GET and skips the wallet deployment step.
            credentials = _derive_existing_clob_credentials(private_key) if read_only else None
            factory = client_factory or (SecureClient._create if read_only else SecureClient.create)
            kwargs = dict(
                private_key=private_key,
                wallet=config.wallet_address,
                api_key=BuilderApiKey(
                    key=builder_key,
                    secret=builder_secret,
                    passphrase=builder_passphrase,
                ),
            )
            if read_only:
                kwargs["credentials"] = credentials
                if client_factory is None:
                    kwargs["validate_credentials"] = False
            client = factory(**kwargs)
        except Exception as exc:
            code = _safe_error_code(exc)
            del exc
            raise PolymarketTradingError(code) from None
        signer = _address_from_client(client, "signer")
        wallet = _address_from_client(client, "wallet")
        if signer is None or signer.lower() != config.signer_address.lower():
            raise PolymarketTradingError("auth")
        if wallet is None or wallet.lower() != config.wallet_address.lower():
            raise PolymarketTradingError("auth")
        return cls(
            config,
            client,
            public_client_factory=public_client_factory,
            metadata_cache=metadata_cache,
        )

    def geoblock_allowed(self) -> bool:
        """Return true only for an explicit ``{"blocked": false}`` response."""

        opener = self._urlopen_fn or urlopen
        try:
            request = Request(GEOBLOCK_URL, headers={"User-Agent": "OpenTrader/1.0"})
            with opener(request, timeout=GEOBLOCK_TIMEOUT_SECONDS) as response:
                raw = response.read()
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8")
            payload = json.loads(raw)
            return isinstance(payload, dict) and payload.get("blocked") is False
        except Exception:
            return False

    def _account_read_facts(self, *, _planning: bool = False):
        with _lp_read_task("account_read_facts"), _lp_read_lock(self._lp_account_read_lock, "account_lock_wait"):
            retry = self._lp_account_read_retry
            if retry is not None and time.monotonic() < retry[0]:
                raise PolymarketTradingError("network", response_facts=self._lp_public_retry_projection(retry))
            self._lp_account_read_retry = None
            try:
                return (self._account_read_facts_once(_planning=True) if _planning
                        else self._account_read_facts_once())
            except PolymarketTradingError as exc:
                deadline = self._lp_public_retry_after(exc.response_facts)
                if deadline is not None:
                    self._lp_account_read_retry = (deadline, exc.response_facts)
                    exc.response_facts = self._lp_public_retry_projection(self._lp_account_read_retry)
                raise

    def _account_read_facts_once(
        self, *, _planning: bool = False,
    ) -> tuple[
        Decimal,
        Decimal,
        tuple[object, ...],
        tuple[object, ...],
        datetime,
        tuple[object, ...],
        bool,
        datetime,
        datetime,
    ]:
        response_facts: dict[str, object] = {}
        remove_hooks = []
        read_started_at = datetime.now(UTC)
        read_ended_at = None
        _lp_causal_event("account_read_begin", account={"read_started_at": read_started_at})
        try:
            for transport_name, path in (
                ("secure_clob", "/balance-allowance"),
                ("secure_clob", "/data/orders"),
                ("secure_clob", "/data/trades"),
                ("data", "/positions"),
            ):
                try:
                    remove = _install_lp_response_fact_hook(
                        self._client, path=path, facts=response_facts,
                        transport_name=transport_name,
                    )
                except Exception:
                    remove = None
                if remove is not None:
                    remove_hooks.append(remove)
            with _lp_read_stage("account_balance"):
                p_usd_balance, p_usd_allowance = self._collateral_balance_allowance()
            checked_at = datetime.now(UTC)
            with _lp_read_stage("account_orders"):
                raw_orders = self._client.list_open_orders()
                if raw_orders is None:
                    raise ValueError("open_orders_unknown")
                orders = tuple(_collect(raw_orders))
                _lp_read_count(records=len(orders))
            # This read is intentionally performed even though the snapshot only
            # formerly discarded it; the round now preserves the complete list.
            trades_complete = True
            try:
                with _lp_read_stage("account_trades"):
                    raw_trades = self._client.list_account_trades()
                    if raw_trades is None:
                        raise ValueError("account_trades_unknown")
                    trades = tuple(_collect(raw_trades))
                    _lp_read_count(records=len(trades))
            except Exception as exc:
                # Only the private planning read can proceed without a
                # historical transport. Authentication and invalid carriers
                # still fail; None means unavailable, never a complete empty list.
                if (not _planning or _safe_error_code(exc) not in {"timeout", "network", "unavailable"}
                        or _safe_history_response_facts(exc).get("status") in {401, 403}):
                    raise
                trades, trades_complete = None, False
            with _lp_read_stage("account_positions"):
                raw_positions = self._client.list_positions()
                if raw_positions is None:
                    raise ValueError("positions_unknown")
                positions = tuple(_collect(raw_positions))
                _lp_read_count(records=len(positions))
            read_ended_at = datetime.now(UTC)
            return (
                p_usd_balance,
                p_usd_allowance,
                orders,
                positions,
                checked_at,
                trades,
                trades_complete,
                read_started_at,
                read_ended_at,
            )
        except Exception as exc:
            code = _safe_error_code(exc)
            raise PolymarketTradingError(
                code, response_facts={**_safe_history_response_facts(exc), **response_facts}
            ) from None
        finally:
            _lp_causal_event("account_read_end", account={"read_started_at": read_started_at,
                "read_ended_at": read_ended_at or datetime.now(UTC)},
                outcome="complete" if read_ended_at is not None else "failed")
            for remove in reversed(remove_hooks):
                try:
                    remove()
                except Exception:
                    pass

    def account_snapshot(self) -> AccountSnapshot:
        (
            p_usd_balance,
            p_usd_allowance,
            orders,
            positions,
            checked_at,
            _raw_trades,
            _trades_complete,
            _read_started_at,
            _read_ended_at,
        ) = self._account_read_facts()
        open_order_ids = tuple(
            _safe_string(order_id)
            for order in orders
            if (order_id := _field(order, "id")) is not None
        )
        safe_positions: list[dict[str, str]] = []
        for position in positions:
            payload = _model_dict(position)
            if payload is None:
                continue
            safe_positions.append(
                {str(key): _safe_string(value) for key, value in payload.items()}
            )
        return AccountSnapshot(
            wallet_address=self.config.wallet_address,
            p_usd_balance=p_usd_balance,
            p_usd_allowance=p_usd_allowance,
            open_order_ids=open_order_ids,
            positions=tuple(safe_positions),
            checked_at=checked_at,
        )

    def lp_account_snapshot_shared(
        self,
        max_age_seconds: float = 10.0,
        *,
        trade_generation_provider: Callable[[], int] | None = None,
    ) -> dict[str, object]:
        """Return a shared LP account snapshot within the TTL window.

        Issue #146: the full scan, the head maintenance, and the dashboard
        snapshot all read the same account facts. Callers block on one
        instance-level lock so concurrent refreshes coalesce into a single
        external read, and the snapshot is reused until ``max_age_seconds``
        have passed. An underlying read failure is not cached.
        """

        with _lp_read_task("account_snapshot_shared"), _lp_read_lock(self._lp_account_shared_lock, "account_shared_lock_wait"):
            cached = self._lp_account_shared_cache
            if isinstance(cached, Mapping):
                fetched_at = cached.get("fetched_at")
                snapshot = cached.get("snapshot")
                age = (
                    time.monotonic() - float(fetched_at)
                    if isinstance(fetched_at, (int, float))
                    else None
                )
                if (
                    isinstance(snapshot, Mapping)
                    and age is not None
                    and age <= max_age_seconds
                    and (
                        trade_generation_provider is None
                        or (
                            isinstance(snapshot.get("trade_generation"), int)
                            and snapshot["trade_generation"] == trade_generation_provider()
                        )
                    )
                ):
                    return deepcopy(dict(snapshot))
            if trade_generation_provider is None:
                snapshot = self.lp_account_snapshot()
            else:
                token = self.lp_account_round_begin(trade_generation_provider)
                try:
                    snapshot = self.lp_account_snapshot(account_round=token)
                finally:
                    self.lp_account_round_end(token)
            self._lp_account_shared_cache = {
                "snapshot": deepcopy(snapshot),
                "fetched_at": time.monotonic(),
            }
            return deepcopy(snapshot)

    def lp_account_snapshot(
        self, account_round: object | None = None
    ) -> dict[str, object]:
        """Return current account orders and holdings for the read-only LP panel."""
        with _lp_read_task("account_snapshot"):
            if account_round is None:
                account = self._lp_account_facts(include_raw_trades=True)
            else:
                account = dict(self._lp_account_snapshot_for_round(account_round)[0])
            return self._enrich_lp_account_snapshot(account, keep_raw=account_round is not None)

    def _lp_planning_account_snapshot(self, *, trade_generation_provider) -> dict[str, object]:
        """Read one current planning observation without sharing partial cache data."""
        with _lp_read_task("planning_account_snapshot"):
            before = trade_generation_provider()
            account = self._lp_account_facts(include_raw_trades=True, _planning=True)
            after = trade_generation_provider()
            if before != after:
                raise LpAccountRoundInvalid("lp_account_round_invalid")
            account['trade_generation'] = after
            return self._enrich_lp_account_snapshot(account, keep_raw=True)

    def _enrich_lp_account_snapshot(self, account, *, keep_raw):
        """Display enrichment never upgrades the completeness of a source read."""
        with _lp_read_stage("account_enrichment"):
            raw_trades = account.get("raw_trades", ())
            normalized_trades = []
            complete = account.get("trades_complete") is True
            for raw in raw_trades or ():
                row = _lp_trade(raw)
                if row is None:
                    complete = False
                    continue
                row["maker_orders"] = [maker for maker in row["maker_orders"]
                    if _lp_maker_order_is_self(maker, self.config.wallet_address)]
                if not row["taker_order_id"] and not row["maker_orders"]:
                    complete = False
                    continue
                normalized_trades.append(row)
            account.update(account_trades=tuple(normalized_trades) if raw_trades is not None else None,
                display_trades_complete=complete, account_trades_total=len(raw_trades) if raw_trades is not None else None)
            if not keep_raw:
                # Raw own-fill evidence is internal to a fenced registration round.
                account.pop("raw_trades", None)
            order_rows, position_rows = account['open_orders'], account['positions']
            condition_ids = tuple(
                dict.fromkeys(
                    str(row.get("condition_id") or "")
                    for row in (*order_rows, *position_rows)
                    if row.get("condition_id")
                )
            )
            metadata = self.lp_market_metadata(condition_ids)
            for row in (*order_rows, *position_rows):
                market = metadata.get(str(row.get("condition_id") or ""))
                if market is not None:
                    row.update(market)
                    row["condition_id"] = market.get("condition_id")
            return account

    def lp_account_round_begin(
        self, trade_generation_provider: Callable[[], int] | None = None
    ) -> _LpAccountRound:
        """Start an empty account scope; no network work occurs until a read."""

        return _LpAccountRound(
            client=self,
            lock=threading.Lock(),
            trade_generation_provider=trade_generation_provider,
        )

    def lp_account_round_end(self, token: object) -> None:
        """Discard the scope so a late reader can never refill or serve it."""

        if not isinstance(token, _LpAccountRound) or token.client is not self:
            raise LpAccountRoundInvalid("lp_account_round_invalid")
        with token.lock:
            token.active = False
            token.generation += 1
            token.future = None

    def lp_account_round_invalidate(self, token: object) -> None:
        """Begin a new generation without waiting for an in-flight read."""

        if not isinstance(token, _LpAccountRound) or token.client is not self:
            raise LpAccountRoundInvalid("lp_account_round_invalid")
        with token.lock:
            if not token.active:
                return
            token.generation += 1
            # Clear only the slot owned at this invalidation instant. A later
            # generation owns a different Future and is never erased here.
            token.future = None

    def _lp_account_snapshot_for_round(
        self, token: _LpAccountRound
    ) -> tuple[Mapping[str, object], int, int | None]:
        """Return one shared account bundle, scope generation, and DB fence."""

        future: Future[tuple[Mapping[str, object], int | None]] | None
        generation: int
        owner = False
        with token.lock:
            if not token.active:
                raise LpAccountRoundInvalid("lp_account_round_invalid")
            generation = token.generation
            future = token.future
            if future is None:
                future = Future()
                token.future = future
                owner = True
        if owner:
            pending_logs = []
            try:
                with _lp_read_task('account_round', deferred_logs=pending_logs):
                    provider = token.trade_generation_provider
                    try:
                        before_generation = provider() if callable(provider) else None
                        snapshot: Mapping[str, object] = deepcopy(
                            self._lp_account_facts(include_raw_trades=True)
                        )
                        after_generation = provider() if callable(provider) else before_generation
                    except BaseException as exc:
                        with token.lock:
                            if token.future is future:
                                token.future = None
                        future.set_exception(exc)
                        raise
                    if before_generation != after_generation:
                        with token.lock:
                            if token.future is future:
                                token.future = None
                        future.set_exception(LpAccountRoundInvalid("lp_account_round_invalid"))
                        raise LpAccountRoundInvalid("lp_account_round_invalid")
                    snapshot = {
                        **snapshot,
                        "trade_generation": after_generation,
                    }
                    with token.lock:
                        future.set_result((snapshot, after_generation))
                        if token.future is future:
                            token.trade_generation = after_generation
                        if (
                            token.future is future
                            and (not token.active or token.generation != generation)
                        ):
                            token.future = None
                    if not token.active or token.generation != generation:
                        raise LpAccountRoundInvalid("lp_account_round_invalid")
                    return snapshot, generation, after_generation
            finally:
                _lp_flush_read_logs(pending_logs)
        with _lp_read_stage("account_future_wait"):
            snapshot, trade_generation = future.result()
        with token.lock:
            if not token.active or token.generation != generation:
                raise LpAccountRoundInvalid("lp_account_round_invalid")
        return deepcopy(snapshot), generation, trade_generation

    def _lp_account_round_matches(
        self, token: _LpAccountRound, generation: int
    ) -> None:
        with token.lock:
            if not token.active or token.generation != generation:
                raise LpAccountRoundInvalid("lp_account_round_invalid")

    def lp_open_orders_for_round(self, token: object) -> list[dict[str, object]]:
        """Return the shared bundle's complete normalized open-order facts."""

        if (
            not isinstance(token, _LpAccountRound)
            or token.client is not self
        ):
            raise LpAccountRoundInvalid("lp_account_round_invalid")
        account, generation, _trade_generation = self._lp_account_snapshot_for_round(token)
        self._lp_account_round_matches(token, generation)
        if account.get("open_orders_complete") is not True:
            # A dropped malformed row is not an empty list. Reuse the
            # authenticated list's existing unknown read semantics so the
            # caller treats it as an outage instead of proving anchors gone.
            raise ValueError("open_orders_unknown")
        return deepcopy(list(account.get("open_orders", ())))

    def _lp_account_facts(self, *, include_raw_trades: bool = False, _planning: bool = False) -> dict[str, object]:
        """Normalize complete authenticated lists before any display enrichment."""

        lp_checked_at = datetime.now(UTC)
        try:
            facts = tuple(self._account_read_facts(_planning=True) if _planning else self._account_read_facts())
            balance, allowance, orders, positions, account_checked_at, raw_trades, trades_complete = facts[:7]
            read_started_at = facts[7] if len(facts) > 7 else account_checked_at
            read_ended_at = facts[8] if len(facts) > 8 else datetime.now(UTC)
        except PolymarketTradingError as exc:
            facts = exc.response_facts
            if facts.get("status") == 401:
                raise LpAccountReadError("credential_invalid") from None
            retry_at = facts.get("retry_after_at")
            if isinstance(retry_at, datetime):
                raise LpAccountReadError("account_read_cooling_down", retry_at) from None
            raise
        checked_at = (
            account_checked_at
            if isinstance(account_checked_at, datetime)
            and account_checked_at.tzinfo is not None
            else lp_checked_at
        )
        order_rows: list[dict[str, object]] = []
        open_orders_complete = True
        for order in orders:
            raw = _model_dict(order)
            row = _lp_order(order)
            if raw is None or row is None:
                open_orders_complete = False
                continue
            original_size = _lp_decimal(raw.get("original_size", raw.get("size")))
            matched_size = _lp_decimal(raw.get("size_matched", raw.get("matched_amount")))
            if (
                not row.get("condition_id")
                or not row.get("token_id")
                or row.get("side") not in {"BUY", "SELL"}
                or not row.get("status")
                or _lp_decimal(raw.get("price")) is None
                or original_size is None
                or matched_size is None
                or original_size < 0
                or matched_size < 0
            ):
                open_orders_complete = False
            order_rows.append(row)

        position_rows: list[dict[str, object]] = []
        positions_complete = True
        for position in positions:
            raw = _model_dict(position)
            row = _lp_position(position)
            if raw is None or row is None:
                positions_complete = False
                continue
            size = _lp_decimal(raw.get("size", raw.get("quantity")))
            if (
                not row.get("condition_id")
                or not row.get("token_id")
                or size is None
                or size < 0
            ):
                positions_complete = False
            position_rows.append(row)
        return {
            "authenticated": True,
            "wallet_address": self.config.wallet_address,
            "account_id": (
                self.config.wallet_address.strip().casefold()
                if isinstance(self.config.wallet_address, str)
                else ""
            ),
            "read_started_at": read_started_at,
            "balance": balance,
            "allowance": allowance,
            "balance_complete": True,
            "open_orders": tuple(order_rows),
            "positions": tuple(position_rows),
            "checked_at": checked_at,
            "read_ended_at": read_ended_at,
            "pagination_complete": (
                open_orders_complete and positions_complete and trades_complete
            ),
            "open_orders_complete": open_orders_complete,
            "positions_complete": positions_complete,
            # Normalize only session-relevant raw rows in lp_snapshot.  A bad
            # unrelated historical row must not poison every active market.
            "trades": (),
            "trades_complete": trades_complete,
            "raw_trades": raw_trades,
            **({"current_pagination_complete": open_orders_complete and positions_complete} if _planning else {}),
        }

    def lp_open_orders_snapshot(self) -> dict[str, object]:
        """Read only authenticated open-order facts for the LP share watcher."""

        checked_at = datetime.now(UTC)
        try:
            raw_orders = self._client.list_open_orders()
            if raw_orders is None:
                raise ValueError("open_orders_unknown")
            orders = tuple(_collect(raw_orders))
        except Exception:
            return {
                "authenticated": False,
                "open_orders": (),
                "open_orders_complete": False,
                "checked_at": checked_at,
            }
        order_rows: list[dict[str, object]] = []
        complete = True
        for order in orders:
            raw = _model_dict(order)
            row = _lp_order(order)
            if raw is None or row is None:
                complete = False
                continue
            original_size = _lp_decimal(raw.get("original_size", raw.get("size")))
            matched_size = _lp_decimal(raw.get("size_matched", raw.get("matched_amount")))
            if (
                not row.get("condition_id")
                or not row.get("token_id")
                or row.get("side") not in {"BUY", "SELL"}
                or not row.get("status")
                or _lp_decimal(raw.get("price")) is None
                or original_size is None
                or matched_size is None
                or original_size < 0
                or matched_size < 0
            ):
                complete = False
            order_rows.append(row)
        return {
            "authenticated": True,
            "wallet_address": self.config.wallet_address,
            "open_orders": tuple(order_rows),
            "open_orders_complete": complete,
            "checked_at": checked_at,
        }

    def lp_account_trades(
        self,
        condition_ids: Sequence[str],
        *,
        stop_event: threading.Event | None = None,
    ) -> dict[str, object]:
        """Read per-market account trades with conservative completeness.

        One authenticated call per requested market; markets whose read fails
        are absent from ``trades`` and flip ``complete`` to False so callers
        can fail open instead of trusting a partial day.
        """

        requested = tuple(
            dict.fromkeys(
                value.strip()
                for value in condition_ids
                if isinstance(value, str) and value.strip()
            )
        )
        checked_at = datetime.now(UTC)
        if not requested or (stop_event is not None and stop_event.is_set()):
            return {
                "state": "unknown",
                "complete": False,
                "checked_at": checked_at,
                "trades": {},
            }
        trades: dict[str, tuple[dict[str, object], ...]] = {}
        complete = True
        wallet = str(getattr(self.config, "wallet_address", "") or "")

        def read_market(condition_id: str) -> tuple[object, ...]:
            if stop_event is not None and stop_event.is_set():
                return ()
            return _collect(self._client.list_account_trades(market=condition_id))

        with ThreadPoolExecutor(max_workers=min(8, len(requested))) as pool:
            futures = [
                (condition_id, pool.submit(read_market, condition_id))
                for condition_id in requested
            ]
            for condition_id, future in futures:
                try:
                    rows = future.result()
                except Exception:
                    complete = False
                    continue
                normalized: list[dict[str, object]] = []
                for row in rows:
                    trade = _lp_trade(row)
                    if trade is None:
                        complete = False
                        continue
                    # One trade row lists every maker it filled; keep only
                    # maker orders provably ours so aggregation cannot count
                    # foreign or unattributable fills as our volume.
                    makers = trade.get("maker_orders")
                    if isinstance(makers, list):
                        trade["maker_orders"] = [
                            maker
                            for maker in makers
                            if _lp_maker_order_is_self(maker, wallet)
                        ]
                    normalized.append(trade)
                trades[condition_id] = tuple(normalized)
        if stop_event is not None and stop_event.is_set():
            return {
                "state": "unknown",
                "complete": False,
                "checked_at": checked_at,
                "trades": {},
            }
        return {
            "state": "known" if complete else "unknown",
            "complete": complete,
            "checked_at": checked_at,
            "trades": trades,
        }

    def lp_market_metadata(
        self,
        condition_ids: Sequence[str],
        *,
        stop_event: threading.Event | None = None,
    ) -> dict[str, dict[str, object]]:
        """Read LP market facts while retaining the mapping-only API."""

        requested = self._normalise_condition_ids(condition_ids)
        if not requested or (stop_event is not None and stop_event.is_set()):
            return {}
        result = self.lp_market_metadata_batch(requested, stop_event=stop_event)
        markets = cast(dict[str, dict[str, object]], result["markets"])
        failed_ids = cast(dict[str, object], result["failed_ids"])
        market_failures = {
            condition_id
            for condition_id, reason in failed_ids.items()
            if (
                isinstance(reason, Mapping)
                and str(reason.get("error_type") or "").startswith("market_read_")
            )
            or (
                isinstance(reason, str) and reason.startswith("market_read_")
            )
        }
        if market_failures:
            confirmed_absent = set(result["confirmed_absent_ids"])
            if not markets and not confirmed_absent:
                raise RuntimeError("market read failed")
        return {
            condition_id: dict(markets[condition_id])
            for condition_id in requested
            if condition_id in markets
        }

    def lp_market_metadata_batch(
        self,
        condition_ids: Sequence[str],
        *,
        stop_event: threading.Event | None = None,
    ) -> dict[str, object]:
        """Read metadata with explicit success, absence, failure, and deferral."""

        requested = self._normalise_condition_ids(condition_ids)
        checked_at = datetime.now(UTC)
        if not requested:
            return {
                "markets": {},
                "confirmed_absent_ids": (),
                "failed_ids": {},
                "failure_facts": {},
                "deferred_ids": (),
                "state": "known",
                "checked_at": checked_at,
            }
        if stop_event is not None and stop_event.is_set():
            return {
                "markets": {},
                "confirmed_absent_ids": (),
                "failed_ids": {},
                "failure_facts": {},
                "deferred_ids": requested,
                "state": "cancelled",
                "checked_at": checked_at,
            }
        return self._lp_market_metadata_batch_result(
            requested, checked_at=checked_at, force_refresh=False, stop_event=stop_event
        )

    def lp_market_metadata_fresh(
        self,
        condition_ids: Sequence[str],
        *,
        stop_event: threading.Event | None = None,
        include_diagnostics: bool = False,
    ) -> dict[str, object]:
        """Read metadata directly, without serving a stale cached payload."""

        requested = self._normalise_condition_ids(condition_ids)
        if not requested or (stop_event is not None and stop_event.is_set()):
            return {}
        checked_at = datetime.now(UTC)
        result = self._lp_market_metadata_batch_result(
            requested, checked_at=checked_at, force_refresh=True, stop_event=stop_event
        )
        markets = cast(dict[str, dict[str, object]], result["markets"])
        failed_ids = cast(dict[str, object], result["failed_ids"])
        filtered = {
            condition_id: dict(value)
            for condition_id, value in markets.items()
            if condition_id not in failed_ids
        }
        return {**result, "markets": filtered} if include_diagnostics else filtered

    @staticmethod
    def _normalise_condition_ids(condition_ids: Sequence[str]) -> tuple[str, ...]:
        return tuple(
            dict.fromkeys(
                value.strip()
                for value in condition_ids
                if isinstance(value, str) and value.strip()
            )
        )

    def _lp_market_metadata_batch_result(
        self,
        requested: tuple[str, ...],
        *,
        checked_at: datetime,
        force_refresh: bool,
        stop_event: threading.Event | None,
    ) -> dict[str, object]:
        if force_refresh:
            fresh: dict[str, dict[str, object] | None] = {}
            stale: dict[str, dict[str, object] | None] = {}
            refresh_ids = list(requested[:LP_METADATA_MAX_REFRESH_IDS_PER_CALL])
            deferred_ids = list(requested[LP_METADATA_MAX_REFRESH_IDS_PER_CALL:])
            self._prune_metadata_cache(checked_at)
        else:
            fresh, stale, refresh_ids = self._partition_metadata_cache(
                requested, checked_at
            )
            deferred_ids = [
                condition_id
                for condition_id in requested
                if condition_id not in fresh
                and condition_id not in refresh_ids
            ]
            self._prune_metadata_cache(checked_at)

        markets = {
            condition_id: dict(value)
            for condition_id, value in fresh.items()
            if value is not None
        }
        markets.update(
            {
                condition_id: dict(value)
                for condition_id, value in stale.items()
                if value is not None
            }
        )
        confirmed_absent = {
            condition_id
            for condition_id, value in fresh.items()
            if value is None
        }
        failed_ids: dict[str, object] = {}
        fetched: dict[str, dict[str, object]] = {}
        fetched_absent: frozenset[str] = frozenset()
        if refresh_ids:
            public: object | None = None
            try:
                public = self._public_client_factory()
                fetched, failed_ids, fetched_absent = self._fetch_lp_market_metadata(
                    tuple(refresh_ids), public=public, stop_event=stop_event
                )
            except Exception as exc:
                reason = _safe_metadata_failure("market", exc)
                failed_ids.update(
                    (condition_id, reason) for condition_id in refresh_ids
                )
            finally:
                close = getattr(public, "close", None)
                if callable(close):
                    close()
            markets.update(fetched)
            confirmed_absent.update(fetched_absent)
            self._record_metadata_entries(
                tuple(refresh_ids),
                fetched,
                metadata_checked_at=checked_at,
                confirmed_absent_ids=fetched_absent,
                failed_ids=failed_ids,
            )

        accounted = set(markets) | confirmed_absent | set(failed_ids) | set(deferred_ids)
        unclassified = set(requested).difference(accounted)
        deferred_ids.extend(
            condition_id
            for condition_id in requested
            if condition_id in unclassified
        )
        deferred = tuple(dict.fromkeys(deferred_ids))
        confirmed = tuple(
            condition_id for condition_id in requested if condition_id in confirmed_absent
        )
        ordered_failed: dict[str, str] = {}
        failure_facts: dict[str, dict[str, object]] = {}
        for condition_id in requested:
            if condition_id not in failed_ids:
                continue
            failure = failed_ids[condition_id]
            if isinstance(failure, Mapping):
                facts = dict(failure)
                failure_facts[condition_id] = facts
                ordered_failed[condition_id] = str(
                    facts.get("error_type") or "market_read_unknown"
                )
            else:
                ordered_failed[condition_id] = str(failure)
        known_ids = (
            set(fresh).difference({condition_id for condition_id, value in fresh.items() if value is None})
            | set(fetched).difference(ordered_failed)
            | set(confirmed)
        )
        cancelled = stop_event is not None and stop_event.is_set()
        if cancelled:
            state = "cancelled"
        elif not ordered_failed and not deferred and len(known_ids) == len(requested):
            state = "known"
        elif known_ids:
            state = "partial"
        else:
            state = "unknown"
        return {
            "markets": {
                condition_id: markets[condition_id]
                for condition_id in requested
                if condition_id in markets
            },
            "confirmed_absent_ids": confirmed,
            "failed_ids": ordered_failed,
            "failure_facts": failure_facts,
            "deferred_ids": deferred,
            "state": state,
            "checked_at": checked_at,
        }

    def _partition_metadata_cache(
        self,
        requested: tuple[str, ...],
        now: datetime,
    ) -> tuple[
        dict[str, dict[str, object] | None],
        dict[str, dict[str, object] | None],
        list[str],
    ]:
        """Split requested ids into fresh, stale, and refresh candidates.

        Refresh candidates are ordered oldest-expiry first (never-read ids
        first) and capped at ``LP_METADATA_MAX_REFRESH_IDS_PER_CALL``.  Ids
        over the refresh budget are served from their (expired) cached
        value when one exists; never-read ids and expired confirmed-missing
        entries stay absent.
        """

        now_epoch = now.timestamp()
        fresh: dict[str, dict[str, object] | None] = {}
        stale: dict[str, dict[str, object] | None] = {}
        refresh: list[tuple[float, int, str]] = []
        with self._metadata_lock:
            self._warm_load_metadata_cache(now)
            for index, condition_id in enumerate(requested):
                entry = self._metadata_entries.get(condition_id)
                if entry is None:
                    refresh.append((float("-inf"), index, condition_id))
                elif entry[0] > now_epoch:
                    fresh[condition_id] = entry[1]
                else:
                    refresh.append((entry[0], index, condition_id))
        refresh.sort(key=lambda item: (item[0], item[1]))
        refresh_ids = [
            condition_id for _expires_at, _index, condition_id in refresh
        ]
        for condition_id in refresh_ids:
            entry = self._metadata_entries.get(condition_id)
            if entry is not None and entry[1] is not None:
                stale[condition_id] = entry[1]
        capped = refresh_ids[:LP_METADATA_MAX_REFRESH_IDS_PER_CALL]
        return fresh, stale, capped

    def _warm_load_metadata_cache(self, now: datetime) -> None:
        """Bulk-load non-expired persisted entries once per process.

        Warm-started entries keep the persisted `expires_at` stamp as their
        in-memory expiry, so a restart never extends freshness past the
        originally persisted window (which is bounded by the risk-gate
        horizon by construction).  Backing-store failures degrade to a
        memory-only cache.
        """

        cache_store = self._metadata_cache
        if cache_store is None or self._metadata_warm_loaded:
            return
        self._metadata_warm_loaded = True
        try:
            reader = getattr(cache_store, "lp_metadata_cache_items", None)
            if callable(reader):
                items = reader(now=now, exclude_candidates=True) if self._candidate_exclusions_enabled else reader(now=now)
            else:
                warm = cache_store.lp_metadata_cache_entries(now=now)
                if not isinstance(warm, Mapping):
                    return
                items = warm.items()

            def valid_entries():
                for key, value in items:
                    if not (isinstance(key, str) and key):
                        continue
                    if not isinstance(value, tuple) or len(value) != 2:
                        continue
                    raw_expires_at, payload = value
                    if isinstance(raw_expires_at, bool) or not isinstance(
                        raw_expires_at, (int, float)
                    ):
                        continue
                    if payload is not None and not isinstance(payload, dict):
                        continue
                    if key not in self._metadata_entries:
                        yield key, (float(raw_expires_at), payload)

            self._metadata_entries.update(valid_entries())
        except Exception:
            logger.warning("lp_metadata_cache_warm_load_failed", exc_info=True)


    def _prune_metadata_cache(self, now: datetime) -> None:
        """Prune the backing store at most once per process per hour."""

        cache_store = self._metadata_cache
        if cache_store is None:
            return
        now_epoch = now.timestamp()
        with self._metadata_lock:
            due = (
                now_epoch - self._metadata_last_prune_epoch
                >= LP_METADATA_CACHE_TTL_SECONDS
            )
            if due:
                self._metadata_last_prune_epoch = now_epoch
        if not due:
            return
        try:
            cache_store.lp_metadata_cache_prune(now=now)
        except Exception:
            logger.warning("lp_metadata_cache_prune_failed", exc_info=True)

    def _record_metadata_entries(
        self,
        refresh_ids: tuple[str, ...],
        fetched: Mapping[str, dict[str, object]],
        *,
        metadata_checked_at: datetime,
        confirmed_absent_ids: frozenset[str] = frozenset(),
        failed_ids: Mapping[str, object] | None = None,
    ) -> None:
        """Write a completed refresh into the in-memory TTL cache.

        Only successful reads reach this point: confirmed-missing ids record
        negative entries, while failed or deferred ids leave any prior cache
        entry untouched.
        """

        read_epoch = metadata_checked_at.timestamp()
        expires_at = read_epoch + LP_METADATA_CACHE_TTL_SECONDS
        negative_expires_at = read_epoch + LP_METADATA_NEGATIVE_TTL_SECONDS
        updated: dict[str, tuple[float, dict[str, object] | None]] = {}
        for condition_id in refresh_ids:
            if failed_ids is not None and condition_id in failed_ids:
                continue
            value = fetched.get(condition_id)
            if value is not None:
                updated[condition_id] = (expires_at, value)
            elif condition_id in confirmed_absent_ids:
                updated[condition_id] = (negative_expires_at, None)
        if self._candidate_exclusions_enabled and self._metadata_cache is not None:
            allowed = set(self._metadata_cache.lp_candidate_conditions(tuple(updated), now=datetime.now(UTC)))
            updated = {cid: row for cid, row in updated.items() if cid in allowed}
        if not updated:
            return
        with self._metadata_lock:
            self._metadata_entries.update(updated)
        cache_store = self._metadata_cache
        if cache_store is not None:
            try:
                cache_store.lp_metadata_cache_store_entries(updated)
            except Exception:
                logger.warning(
                    "lp_metadata_cache_store_entries_failed", exc_info=True
                )

    def _fetch_lp_market_metadata(
        self,
        requested: tuple[str, ...],
        *,
        public: object,
        stop_event: threading.Event | None = None,
        closed_query: bool = False,
    ) -> tuple[dict[str, dict[str, object]], dict[str, object], frozenset[str]]:
        """Fetch LP market facts while preserving each completed sub-read."""

        metadata_checked_at = datetime.now(UTC)
        event_facts: dict[str, Mapping[str, object] | None] = {}
        event_failures: dict[str, str | Mapping[str, object]] = {}
        event_failures_lock = threading.Lock()
        rows: list[object] = []
        completed_market_ids: set[str] = set()
        failed_ids: dict[str, object] = {}
        response_facts_by_condition_ids: dict[
            frozenset[str], dict[str, object]
        ] = {}

        def read_market_batch(
            batch: tuple[str, ...],
        ) -> tuple[tuple[object, ...], bool]:
            if stop_event is not None and stop_event.is_set():
                return (), False
            return (
                _collect_lp_market_pages(
                    public.list_markets(
                        condition_ids=batch, page_size=100,
                        **({"closed": True} if closed_query else {}),
                    ),
                    set(batch),
                ),
                True,
            )

        market_batches = tuple(
            requested[offset : offset + LP_METADATA_MARKET_BATCH_SIZE]
            for offset in range(0, len(requested), LP_METADATA_MARKET_BATCH_SIZE)
        )
        response_facts_by_condition_ids = {
            frozenset(batch): {} for batch in market_batches
        }
        remove_response_hook = _install_lp_metadata_response_hook(
            public,
            len(requested),
            facts_by_condition_ids=response_facts_by_condition_ids,
        )
        try:
            with ThreadPoolExecutor(max_workers=min(8, len(market_batches))) as pool:
                futures = deque(
                    (batch, pool.submit(read_market_batch, batch))
                    for batch in market_batches
                )
                while futures:
                    batch, future = futures.popleft()
                    try:
                        batch_rows, completed = future.result()
                    except Exception as exc:
                        reason = _safe_metadata_failure(
                            "market",
                            exc,
                            response_facts_by_condition_ids.get(frozenset(batch)),
                        )
                        failed_ids.update((condition_id, reason) for condition_id in batch)
                        continue
                    finally:
                        del future
                    if completed:
                        completed_market_ids.update(batch)
                        rows.extend(batch_rows)
                    del batch_rows
        finally:
            if remove_response_hook is not None:
                remove_response_hook()

        numeric_event_keys: dict[int, list[str]] = {}
        direct_event_ids: list[str] = []
        missing = object()

        def project(raw: object, keys: set[str]) -> dict[str, object] | None:
            nested = _model_dict(raw)
            if nested is None:
                return None
            return {
                key: value for key in keys
                if (value := nested.get(key, missing)) is not missing
            }

        for value in rows:
            row = _model_dict(value)
            if row is None:
                continue
            condition_id = row.get("condition_id", row.get("conditionId"))
            if not isinstance(condition_id, str) or condition_id not in requested:
                continue
            # Nested Mapping reads belong to the whole-call parse boundary,
            # not the HTTP worker's per-batch failure boundary. SDK Market
            # models have already been projected inside the worker.
            facts = cast(dict[str, object], row)
            for name, keys in (
                ("state", {"accepting_orders", "closed", "resolved"}),
                ("trading", {"minimum_tick_size", "minimum_order_size", "fees_enabled", "fee_schedule"}),
                ("rewards", {"rewards_min_size", "rewards_max_spread"}),
                ("sports", {"game_id", "game_start_time"}),
                ("prices", {"one_day_price_change"}),
            ):
                facts[name] = project(facts.get(name), keys)
            trading = facts["trading"]
            if isinstance(trading, dict):
                trading["fee_schedule"] = project(
                    trading.get("fee_schedule"), {"rate", "exponent", "taker_only"}
                )
            outcomes = _model_dict(facts.get("outcomes"))
            facts["outcomes"] = {
                key: project(outcome, {"label", "token_id", "tokenId"})
                for key, outcome in outcomes.items()
            } if outcomes is not None else None
            del trading, outcomes
            raw_events = row.get("events")
            references = tuple(
                {key: reference[key] for key in ("id", "slug") if key in reference}
                for reference in map(_model_dict, _collect(raw_events))
                if reference is not None
            )
            # Canonical containers are repeatable. Keep other iterators' existing
            # consumption and failure semantics at this original read boundary.
            if raw_events is None or isinstance(raw_events, (tuple, list, Mapping, str, bytes)):
                cast(dict[str, object], row)["events"] = references
            del raw_events
            if len(references) != 1:
                continue
            raw_event_id = references[0].get("id")
            event_id = str(raw_event_id).strip() if raw_event_id is not None else ""
            if not event_id or event_id in event_facts:
                continue
            event_facts[event_id] = None
            if (
                event_id.isascii()
                and event_id.isdecimal()
                and str(int(event_id)) == event_id
            ):
                numeric_event_keys.setdefault(int(event_id), []).append(event_id)
            else:
                direct_event_ids.append(event_id)

        def mark_event_failure(
            event_ids: Sequence[object], reason: str | Mapping[str, object]
        ) -> None:
            with event_failures_lock:
                event_failures.update((str(value).strip(), reason) for value in event_ids)

        unresolved_numeric_ids = tuple(numeric_event_keys)
        for closed in (False, True):
            if not unresolved_numeric_ids:
                break
            event_batches = tuple(
                (
                    unresolved_numeric_ids[offset : offset + LP_METADATA_EVENT_BATCH_SIZE],
                    closed,
                )
                for offset in range(
                    0, len(unresolved_numeric_ids), LP_METADATA_EVENT_BATCH_SIZE
                )
            )

            def read_event_batch(
                query: tuple[tuple[int, ...], bool],
            ) -> tuple[tuple[object, ...], str | Mapping[str, object] | None]:
                batch, is_closed = query
                if stop_event is not None and stop_event.is_set():
                    reason = "event_read_cancelled"
                    mark_event_failure(batch, reason)
                    return (), reason
                list_events = getattr(public, "list_events", None)
                if not callable(list_events):
                    reason = "event_read_unavailable"
                    mark_event_failure(batch, reason)
                    return (), reason
                try:
                    # Project inside the reader so completed futures retain
                    # only LP facts, never the full SDK event/market trees.
                    return (
                        tuple(
                            facts
                            for value in _iter_reward_items(
                                list_events(
                                    ids=batch, closed=is_closed,
                                    page_size=LP_METADATA_EVENT_BATCH_SIZE,
                                ),
                                stop_event,
                            )
                            if (facts := _lp_event_facts(value)) is not None
                        ),
                        None,
                    )
                except _RewardReadCancelled:
                    reason = "event_read_cancelled"
                    mark_event_failure(batch, reason)
                    return (), reason
                except Exception as exc:
                    reason = _safe_metadata_failure("event", exc)
                    mark_event_failure(batch, reason)
                    return (), reason

            resolved: set[int] = set()
            with ThreadPoolExecutor(max_workers=min(8, len(event_batches))) as pool:
                futures = deque(
                    (batch, pool.submit(read_event_batch, query))
                    for query in event_batches
                    for batch in (query[0],)
                )
                while futures:
                    batch, future = futures.popleft()
                    event_rows, _error = future.result()
                    del future
                    for value in event_rows:
                        event = _model_dict(value)
                        if event is None:
                            continue
                        raw_id = event.get("id")
                        event_id = str(raw_id) if raw_id is not None else ""
                        if not event_id.isascii() or not event_id.isdecimal():
                            continue
                        numeric_id = int(event_id)
                        if (
                            event_id != str(numeric_id)
                            or numeric_id not in batch
                            or numeric_id not in numeric_event_keys
                        ):
                            continue
                        for key in numeric_event_keys[numeric_id]:
                            event_facts[key] = event
                            with event_failures_lock:
                                event_failures.pop(key, None)
                        resolved.add(numeric_id)
                    del event_rows
            unresolved_numeric_ids = tuple(
                event_id
                for event_id in unresolved_numeric_ids
                if event_id not in resolved
            )
        if stop_event is not None and stop_event.is_set():
            mark_event_failure(unresolved_numeric_ids, "event_read_cancelled")

        def read_direct_event(
            event_id: str,
        ) -> tuple[str, Mapping[str, object] | None, str | Mapping[str, object] | None]:
            if stop_event is not None and stop_event.is_set():
                return event_id, None, "event_read_cancelled"
            get_event = getattr(public, "get_event", None)
            if not callable(get_event):
                return event_id, None, "event_read_unavailable"
            try:
                event = _lp_event_facts(get_event(id=event_id))
            except Exception as exc:
                return event_id, None, _safe_metadata_failure("event", exc)
            if event is None or str(event.get("id") or "") != event_id:
                return event_id, None, None
            return event_id, event, None

        if direct_event_ids:
            with ThreadPoolExecutor(max_workers=min(8, len(direct_event_ids))) as pool:
                for event_id, event, error in pool.map(read_direct_event, direct_event_ids):
                    if event is not None:
                        event_facts[event_id] = event
                        with event_failures_lock:
                            event_failures.pop(event_id, None)
                    elif error is not None:
                        mark_event_failure((event_id,), error)
        result: dict[str, dict[str, object]] = {}
        for value in rows:
            row = _model_dict(value)
            if row is None:
                continue
            condition_id = row.get("condition_id", row.get("conditionId"))
            if not isinstance(condition_id, str) or condition_id not in requested:
                continue
            slug = row.get("slug")
            market_url = row.get("market_url", row.get("url"))
            state = _model_dict(row.get("state")) or {}
            trading = _model_dict(row.get("trading")) or {}
            rewards = _model_dict(row.get("rewards")) or {}
            fee_schedule = _model_dict(trading.get("fee_schedule")) or {}
            raw_spread = _lp_decimal(
                rewards.get("rewards_max_spread", row.get("rewards_max_spread"))
            )
            fees_enabled = trading.get("fees_enabled")
            taker_rate = _lp_decimal(
                fee_schedule.get("rate", row.get("taker_fee_rate"))
            )
            raw_outcomes = _model_dict(row.get("outcomes")) or {}
            outcomes: dict[str, dict[str, object]] = {}
            for key, raw_outcome in raw_outcomes.items():
                outcome = _model_dict(raw_outcome)
                if outcome is None:
                    continue
                token_id = outcome.get("token_id", outcome.get("tokenId"))
                if token_id is None:
                    continue
                outcome_key = str(key).strip().lower()
                outcomes[outcome_key] = {
                    "label": outcome.get("label", key),
                    "token_id": str(token_id),
                }
            events = tuple(
                event
                for raw_event in _collect(row.get("events"))
                if (event := _model_dict(raw_event)) is not None
            )
            event_reference = events[0] if len(events) == 1 else None
            event_id = event_reference.get("id") if event_reference else None
            event_key = str(event_id).strip() if event_id is not None else ""
            event = event_facts.get(event_key) if event_key else None
            if event_key in event_failures:
                failed_ids.setdefault(condition_id, event_failures[event_key])
            sports = _model_dict(row.get("sports")) or {}
            event_state = _model_dict(event.get("state")) or {} if event else {}
            event_schedule = _model_dict(event.get("schedule")) or {} if event else {}
            prices = _model_dict(row.get("prices")) or {}
            one_day_price_change = _lp_decimal(prices.get("one_day_price_change"))
            event_slug = (
                event.get("slug")
                if event is not None
                else event_reference.get("slug") if event_reference else None
            )
            if not market_url and isinstance(slug, str) and slug.strip():
                market_slug = slug.strip()
                if (
                    isinstance(event_slug, str)
                    and event_slug.strip()
                    and event_slug.strip() != market_slug
                ):
                    market_url = (
                        f"https://polymarket.com/event/{event_slug.strip()}/{market_slug}"
                    )
                else:
                    market_url = f"https://polymarket.com/event/{market_slug}"
            result[condition_id] = {
                "market_id": row.get("id", row.get("market_id")),
                "condition_id": condition_id,
                "metadata_checked_at": metadata_checked_at,
                "fees_checked_at": metadata_checked_at,
                "market_title": row.get("question", row.get("title")),
                "market_url": market_url,
                "event_id": event_id,
                "game_id": sports.get("game_id"),
                "game_start_time": sports.get("game_start_time"),
                "event_start_time": event_schedule.get("start_time"),
                "event_ended": event_state.get("ended"),
                "event_finished_at": event_schedule.get("finished_at"),
                "price_change_24h": one_day_price_change,
                "price_change_24h_source": (
                    "polymarket.prices.one_day_price_change"
                    if one_day_price_change is not None
                    else None
                ),
                "accepting_orders": state.get("accepting_orders"),
                "closed": state.get("closed"),
                "resolved": state.get("resolved"),
                "exchange_type": "CLOB",
                "tick_size": _lp_decimal(trading.get("minimum_tick_size")),
                "minimum_order_size": _lp_decimal(
                    trading.get("minimum_order_size")
                ),
                "fee": (
                    Decimal("0")
                    if fees_enabled is False or fee_schedule.get("taker_only") is True
                    else None
                ),
                "fees_enabled": fees_enabled,
                "fee_exponent": _lp_decimal(fee_schedule.get("exponent", 1)),
                "taker_fee_rate": taker_rate,
                "reward_min_size": _lp_decimal(
                    rewards.get("rewards_min_size", row.get("rewards_min_size"))
                ),
                "reward_max_spread": (
                    None if raw_spread is None else raw_spread / Decimal("100")
                ),
                "outcomes": outcomes,
            }
        confirmed_absent_ids = frozenset(
            condition_id
            for condition_id in completed_market_ids
            if condition_id not in result and condition_id not in failed_ids
            and not (stop_event is not None and stop_event.is_set())
        )
        if confirmed_absent_ids and not closed_query:
            missing = tuple(value for value in requested if value in confirmed_absent_ids)
            try:
                closed_markets, closed_failed, confirmed_absent_ids = self._fetch_lp_market_metadata(
                    missing, public=public, stop_event=stop_event, closed_query=True,
                )
            except Exception as exc:
                reason = _safe_metadata_failure("market", exc)
                closed_markets = {}
                closed_failed = dict.fromkeys(missing, reason)
                confirmed_absent_ids = frozenset()
            result.update(closed_markets)
            failed_ids.update(closed_failed)
        return result, failed_ids, confirmed_absent_ids

    def lp_order_books(
        self,
        token_ids: Sequence[str],
        *,
        stop_event: threading.Event | None = None,
    ) -> dict[str, dict[str, object]]:
        """Read current books in bounded SDK batches for the LP candidate catalog."""

        requested = tuple(
            dict.fromkeys(
                value.strip()
                for value in token_ids
                if isinstance(value, str) and value.strip()
            )
        )
        if not requested or (stop_event is not None and stop_event.is_set()):
            return {}
        result: dict[str, dict[str, object]] = {}
        public = self._public_client_factory()
        try:
            for offset in range(0, len(requested), 100):
                if stop_event is not None and stop_event.is_set():
                    return {}
                batch = requested[offset : offset + 100]
                rows = _collect(public.get_order_books(token_ids=batch))
                received_at = datetime.now(UTC)
                if stop_event is not None and stop_event.is_set():
                    return {}
                for value in rows:
                    row = _model_dict(value)
                    if row is None:
                        continue
                    token_id = row.get("token_id", row.get("asset_id"))
                    if not isinstance(token_id, str) or token_id not in batch:
                        continue
                    book = _lp_book(row)
                    if book is None:
                        continue
                    book["received_at"] = received_at
                    result[token_id] = book
        finally:
            close = getattr(public, "close", None)
            if callable(close):
                close()
        return result

    def lp_price_history(
        self,
        token_ids: Sequence[str],
        *,
        start_ts: int,
        end_ts: int,
        fidelity: int = 1,
        stop_event: threading.Event | None = None,
    ) -> dict[str, object]:
        """Read minute price histories in bounded public batches.

        The response is intentionally lossless about missing directions: a
        token with no valid rows is reported in ``unknown_token_ids`` rather
        than being given an empty or zero-priced range.
        """

        requested = tuple(
            dict.fromkeys(
                value.strip()
                for value in token_ids
                if isinstance(value, str) and value.strip()
            )
        )
        if not requested or type(start_ts) is not int or type(end_ts) is not int:
            return {
                "state": "unknown",
                "history": {},
                "unknown_token_ids": list(requested),
                "errors": {token: "request_invalid" for token in requested},
                "request_count": 0,
            }
        if end_ts < start_ts or fidelity != 1:
            return {
                "state": "unknown",
                "history": {},
                "unknown_token_ids": list(requested),
                "errors": {token: "request_invalid" for token in requested},
                "request_count": 0,
            }
        batches = tuple(
            requested[offset : offset + LP_PRICE_HISTORY_BATCH_SIZE]
            for offset in range(0, len(requested), LP_PRICE_HISTORY_BATCH_SIZE)
        )
        opener = self._urlopen_fn or urlopen

        def read_batch(
            batch: tuple[str, ...],
        ) -> tuple[tuple[str, ...], object, str | None, dict[str, object]]:
            if stop_event is not None and stop_event.is_set():
                return batch, None, "cancelled", {}
            body = json.dumps(
                {
                    "markets": list(batch),
                    "start_ts": start_ts,
                    "end_ts": end_ts,
                    "fidelity": fidelity,
                },
                separators=(",", ":"),
            ).encode("utf-8")
            request = Request(
                LP_PRICE_HISTORY_ENDPOINT,
                data=body,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "User-Agent": "OpenTrader/1.0",
                },
                method="POST",
            )
            try:
                with opener(request, timeout=LP_PRICE_HISTORY_TIMEOUT_SECONDS) as response:
                    raw = response.read()
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8")
                return batch, json.loads(raw), None, {}
            except Exception as exc:
                facts = _safe_history_response_facts(exc)
                return batch, None, str(facts["error_type"]), facts

        histories: dict[str, list[dict[str, object]]] = {}
        unknown: set[str] = set()
        errors: dict[str, str] = {}
        response_facts: dict[str, object] = {}
        with ThreadPoolExecutor(
            max_workers=min(LP_PRICE_HISTORY_MAX_CONCURRENCY, len(batches))
        ) as pool:
            for batch, payload, error, facts in pool.map(read_batch, batches):
                for name, value in facts.items():
                    response_facts.setdefault(name, value)
                if error is not None:
                    unknown.update(batch)
                    for token in batch:
                        errors[token] = error
                    continue
                raw_history = payload.get("history") if isinstance(payload, Mapping) else None
                if not isinstance(raw_history, Mapping):
                    unknown.update(batch)
                    for token in batch:
                        errors[token] = "history_shape_unknown"
                    continue
                for token in batch:
                    raw_rows = raw_history.get(token)
                    if not isinstance(raw_rows, Sequence) or isinstance(raw_rows, (str, bytes)):
                        unknown.add(token)
                        errors[token] = "history_missing"
                        continue
                    by_timestamp: dict[int, dict[str, object]] = {}
                    invalid = False
                    for raw_row in raw_rows:
                        if not isinstance(raw_row, Mapping):
                            invalid = True
                            continue
                        stamp = raw_row.get("t", raw_row.get("timestamp"))
                        price = _lp_decimal(raw_row.get("p", raw_row.get("price")))
                        if type(stamp) is not int:
                            invalid = True
                            continue
                        if price is None or price < 0 or price > 1:
                            invalid = True
                            continue
                        if stamp < start_ts or stamp > end_ts:
                            continue
                        by_timestamp[stamp] = {"t": stamp, "p": price}
                    rows = [by_timestamp[stamp] for stamp in sorted(by_timestamp)]
                    if rows and not invalid:
                        histories[token] = rows
                    elif invalid:
                        unknown.add(token)
                        errors[token] = "history_values_invalid"
                    else:
                        unknown.add(token)
                        errors[token] = "history_values_unknown"
        if stop_event is not None and stop_event.is_set():
            for token in requested:
                unknown.add(token)
                errors.setdefault(token, "cancelled")
        unknown.difference_update(histories)
        return {
            "state": "known" if not unknown else "partial" if histories else "unknown",
            "history": histories,
            "unknown_token_ids": [token for token in requested if token in unknown],
            "errors": errors,
            "request_count": len(batches),
            "start_ts": start_ts,
            "end_ts": end_ts,
            "fidelity": fidelity,
            **response_facts,
        }

    def _lp_selected_reward_catalog(
        self,
        condition_ids: Sequence[str],
        *,
        stop_event: threading.Event | None = None,
    ) -> dict[str, object]:
        """Read reward facts for a fixed market set without global calls."""

        checked_at = datetime.now(UTC)
        requested = tuple(
            dict.fromkeys(
                value.strip()
                for value in condition_ids
                if isinstance(value, str) and value.strip()
            )
        )
        if not requested:
            return {
                "state": "known",
                "complete": True,
                "checked_at": checked_at,
                "daily_pool_usd": Decimal("0"),
                "markets": (),
            }

        requests = tuple(
            (condition_id, sponsored)
            for condition_id in requested
            for sponsored in (False, True)
        )

        def close_public(public: object) -> None:
            close = getattr(public, "close", None)
            if callable(close):
                close()

        def read_rewards(
            request: tuple[str, bool],
        ) -> tuple[str, bool, tuple[object, ...], str | None, str | None]:
            condition_id, sponsored = request
            if stop_event is not None and stop_event.is_set():
                return condition_id, sponsored, (), "reward_read_cancelled", "cancelled"
            public = self._public_client_factory()
            try:
                reader = getattr(public, "list_market_rewards", None)
                if not callable(reader):
                    raise ValueError("selected_reward_reader_unavailable")
                return condition_id, sponsored, _collect(
                    reader(condition_id=condition_id, sponsored=sponsored), stop_event=stop_event
                ), None, None
            except _RewardReadCancelled:
                return condition_id, sponsored, (), "reward_read_cancelled", "cancelled"
            except Exception as exc:
                return condition_id, sponsored, (), "reward_read_failed", type(exc).__name__
            finally:
                close_public(public)

        results: dict[tuple[str, bool], tuple[tuple[object, ...], str | None, str | None]] = {}
        with ThreadPoolExecutor(
            max_workers=min(LP_REWARD_SELECTED_MAX_CONCURRENCY, len(requests)),
            thread_name_prefix="polymarket-selected-rewards",
        ) as executor:
            for condition_id, sponsored, rows, error, error_type in executor.map(
                read_rewards, requests
            ):
                results[(condition_id, sponsored)] = (rows, error, error_type)

        markets: list[dict[str, object]] = []
        known_count = 0
        total = Decimal("0")
        total_known = True
        as_of = checked_at.date()
        for condition_id in requested:
            market: dict[str, object] = {
                "condition_id": condition_id,
                "checked_at": checked_at,
                "reward_checked_at": checked_at,
                "rewards_max_spread": None,
                "rewards_min_size": None,
                "native_reward_configs": [],
                "combined_reward_configs": [],
                "sponsored_reward_configs": [],
                "native_daily_pool_usd": Decimal("0"),
                "sponsored_daily_pool_usd": Decimal("0"),
            }
            reason_codes: list[str] = []
            row_fingerprints: dict[bool, str] = {}
            config_signatures: dict[bool, dict[str, tuple[object, ...]]] = {
                False: {},
                True: {},
            }
            active_configs = 0
            unknown_asset = False
            native_total: Decimal | None = Decimal("0")
            combined_total: Decimal | None = Decimal("0")

            for sponsored in (False, True):
                rows, read_error, error_type = results[(condition_id, sponsored)]
                if read_error is not None:
                    reason_codes.append(read_error)
                    if error_type is not None:
                        market.setdefault("error_type", error_type)
                    continue
                for reward in rows:
                    row = _model_dict(reward)
                    if row is None or row.get("condition_id") != condition_id:
                        reason_codes.append("reward_identity_unknown")
                        continue
                    try:
                        fingerprint = json.dumps(
                            row,
                            sort_keys=True,
                            default=str,
                            separators=(",", ":"),
                        )
                    except (TypeError, ValueError):
                        reason_codes.append("reward_identity_unknown")
                        continue
                    previous_fingerprint = row_fingerprints.get(sponsored)
                    if previous_fingerprint is not None:
                        if previous_fingerprint == fingerprint:
                            continue
                        reason_codes.append("reward_identity_unknown")
                        continue
                    row_fingerprints[sponsored] = fingerprint

                    if sponsored:
                        combined_spread = _lp_decimal(
                            row.get("rewards_max_spread")
                        )
                        combined_min_size = _lp_decimal(
                            row.get("rewards_min_size")
                        )
                        if combined_spread is not None:
                            market["rewards_max_spread"] = combined_spread
                        if combined_min_size is not None:
                            market["rewards_min_size"] = combined_min_size
                    raw_configs = row.get("rewards_config")
                    if not isinstance(raw_configs, Sequence) or isinstance(
                        raw_configs, (str, bytes)
                    ):
                        reason_codes.append("reward_config_unknown")
                        continue
                    for raw_config in raw_configs:
                        normalized_parts = _normalize_lp_reward_config(
                            raw_config,
                            sponsored=sponsored,
                            require_id=False,
                        )
                        if normalized_parts is None:
                            reason_codes.append("reward_config_unknown")
                            continue
                        normalized, config_identity = normalized_parts
                        config_id, asset_key, start_date, end_date = config_identity
                        rate = cast(Decimal, normalized["rate_per_day"])
                        if config_id is not None:
                            config_key = str(config_id)
                            signature = (asset_key, start_date, end_date, rate)
                            previous_signature = config_signatures[sponsored].get(
                                config_key
                            )
                            if previous_signature is not None:
                                if previous_signature == signature:
                                    continue
                                reason_codes.append("reward_identity_unknown")
                                continue
                            config_signatures[sponsored][config_key] = signature
                        if not start_date <= as_of <= end_date:
                            continue
                        configs_key = (
                            "combined_reward_configs"
                            if sponsored
                            else "native_reward_configs"
                        )
                        cast(list[dict[str, object]], market[configs_key]).append(
                            normalized
                        )
                        active_configs += 1
                        if asset_key not in LP_REWARD_ASSET_USD_ADDRESSES:
                            unknown_asset = True
                            if sponsored:
                                combined_total = None
                            else:
                                native_total = None
                            continue
                        if sponsored:
                            if combined_total is not None:
                                combined_total += rate
                        elif native_total is not None:
                            native_total += rate

            if unknown_asset:
                reason_codes.append("reward_asset_unknown")
            reason_codes = list(dict.fromkeys(reason_codes))
            if reason_codes:
                market.update(
                    {
                        "state": "unknown",
                        "complete": False,
                        "reward_active": None,
                        "daily_pool_usd": None,
                        "reason_codes": reason_codes,
                    }
                )
                total_known = False
            else:
                native = native_total
                combined = combined_total
                if native is None or combined is None:
                    market.update(
                        {
                            "state": "unknown",
                            "complete": False,
                            "reward_active": None,
                            "daily_pool_usd": None,
                            "reason_codes": ["reward_total_unknown"],
                        }
                    )
                    total_known = False
                    markets.append(market)
                    continue
                if combined < native:
                    market.update(
                        {
                            "state": "unknown",
                            "complete": False,
                            "reward_active": None,
                            "daily_pool_usd": None,
                            "sponsored_daily_pool_usd": None,
                            "reason_codes": ["reward_totals_inconsistent"],
                        }
                    )
                    total_known = False
                    markets.append(market)
                    continue
                sponsored = combined - native
                daily_pool = combined
                market["native_daily_pool_usd"] = native
                market["sponsored_daily_pool_usd"] = sponsored
                market.update(
                    {
                        "state": "known",
                        "complete": True,
                        "reward_active": active_configs > 0,
                        "daily_pool_usd": daily_pool,
                        "reason_codes": [],
                    }
                )
                known_count += 1
                total += daily_pool
            markets.append(market)

        complete = known_count == len(requested)
        return {
            "state": "known"
            if complete
            else "partial"
            if known_count
            else "unknown",
            "complete": complete,
            "checked_at": checked_at,
            "daily_pool_usd": total if total_known else None,
            "markets": tuple(markets),
        }

    def lp_reward_catalog(
        self,
        *,
        condition_ids: Sequence[str] | None = None,
        stop_event: threading.Event | None = None,
    ) -> dict[str, object]:
        """Read complete active native and sponsored LP reward configurations."""

        if condition_ids is not None:
            return self._lp_selected_reward_catalog(
                condition_ids, stop_event=stop_event
            )

        checked_at = datetime.now(UTC)
        unknown = {
            "state": "unknown",
            "complete": False,
            "checked_at": checked_at,
            "daily_pool_usd": None,
            "markets": (),
        }
        response_facts: dict[str, object] = {}
        remove_response_hook: Callable[[], None] | None = None
        try:
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            public = self._public_client_factory()
            markets = LPReadScratch()
            seen: set[tuple[object, ...]] = set()
            as_of = checked_at.date()
            try:
                remove_response_hook = _install_lp_response_fact_hook(
                    public,
                    path="/rewards/markets/current",
                    facts=response_facts,
                )
                for sponsored in (False, True):
                    if stop_event is not None and stop_event.is_set():
                        raise _RewardReadCancelled
                    rewards = public.list_current_rewards(sponsored=sponsored)
                    for reward in _iter_reward_items(rewards, stop_event):
                        row = _model_dict(reward)
                        if row is None:
                            raise ValueError("reward_market_unknown")
                        condition_id = row.get("condition_id")
                        if not isinstance(condition_id, str) or not condition_id:
                            raise ValueError("reward_market_unknown")
                        raw_configs = row.get("rewards_config")
                        if not isinstance(raw_configs, Sequence) or isinstance(
                            raw_configs, (str, bytes)
                        ):
                            raise ValueError("reward_config_unknown")

                        market = markets.get(
                            condition_id,
                            {
                                "condition_id": condition_id,
                                "rewards_max_spread": _lp_decimal(
                                    row.get("rewards_max_spread")
                                ),
                                "rewards_min_size": _lp_decimal(
                                    row.get("rewards_min_size")
                                ),
                                "native_reward_configs": [],
                                "sponsored_reward_configs": [],
                                "native_daily_pool_usd": Decimal("0"),
                                "sponsored_daily_pool_usd": Decimal("0"),
                            },
                        )
                        configs_key = (
                            "sponsored_reward_configs"
                            if sponsored
                            else "native_reward_configs"
                        )
                        amount_key = (
                            "sponsored_daily_pool_usd"
                            if sponsored
                            else "native_daily_pool_usd"
                        )
                        for raw_config in raw_configs:
                            normalized_parts = _normalize_lp_reward_config(
                                raw_config,
                                sponsored=sponsored,
                            )
                            if normalized_parts is None:
                                raise ValueError("reward_config_unknown")
                            normalized, config_identity = normalized_parts
                            _, asset_key, start_date, end_date = config_identity
                            rate = cast(Decimal, normalized["rate_per_day"])
                            identity = (
                                condition_id,
                                *config_identity,
                                sponsored,
                            )
                            if identity in seen:
                                continue
                            seen.add(identity)
                            if not start_date <= as_of <= end_date:
                                continue

                            cast(list[dict[str, object]], market[configs_key]).append(
                                normalized
                            )
                            if asset_key not in LP_REWARD_ASSET_USD_ADDRESSES:
                                market[amount_key] = None
                                continue
                            current_amount = cast(Decimal | None, market[amount_key])
                            if current_amount is not None:
                                market[amount_key] = current_amount + rate

                        markets[condition_id] = market

            finally:
                if remove_response_hook is not None:
                    remove_response_hook()
                close = getattr(public, "close", None)
                if callable(close):
                    close()
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled

            total = Decimal("0")
            total_known = True

            def normalized_markets():
                nonlocal total, total_known
                for market in markets.values():
                    if stop_event is not None and stop_event.is_set():
                        raise _RewardReadCancelled
                    native = cast(Decimal | None, market["native_daily_pool_usd"])
                    sponsored = cast(Decimal | None, market["sponsored_daily_pool_usd"])
                    market["daily_pool_usd"] = (
                        None if native is None or sponsored is None else native + sponsored
                    )
                    pool = cast(Decimal | None, market["daily_pool_usd"])
                    if pool is None:
                        total_known = False
                    else:
                        total += pool
                    market["reward_active"] = True
                    yield market

            result_markets = LPReadRows(normalized_markets())
            return {
                "state": "known",
                "complete": True,
                "checked_at": datetime.now(UTC),
                "daily_pool_usd": total if total_known else None,
                "markets": result_markets,
            }
        except _RewardReadCancelled:
            unknown["reason"] = "cancelled"
            unknown.update(response_facts)
            return unknown
        except Exception as exc:
            unknown["reason"] = "reward_catalog_read_failed"
            unknown["error_type"] = type(exc).__name__
            unknown["error_chain"] = _safe_read_error_chain(exc)
            unknown.update(_safe_sqlite_error_facts(exc))
            unknown.update(response_facts)
            return unknown

    def _cached_lp_token_ids(
        self, condition_ids: Sequence[str]
    ) -> tuple[str, ...]:
        """Resolve condition ids to token ids without a probe-side metadata read."""

        requested = self._normalise_condition_ids(condition_ids)
        if not requested:
            return ()
        now = datetime.now(UTC)
        with self._metadata_lock:
            self._warm_load_metadata_cache(now)
            cached = tuple(
                self._metadata_entries.get(condition_id, (0.0, None))[1]
                for condition_id in requested
            )
        tokens: list[str] = []
        identities: list[tuple[str, str]] = []
        for condition_id, market in zip(requested, cached):
            if not isinstance(market, Mapping):
                continue
            outcomes = market.get("outcomes")
            if not isinstance(outcomes, Mapping):
                continue
            for value in outcomes.values():
                if not isinstance(value, Mapping):
                    continue
                token_id = value.get("token_id", value.get("tokenId"))
                if isinstance(token_id, str) and token_id.strip():
                    tokens.append(token_id.strip())
                    identities.append((condition_id, token_id.strip()))
        if self._candidate_exclusions_enabled and self._metadata_cache is not None:
            allowed = self._metadata_cache.lp_candidate_allowed(tuple(identities), now=now)
            tokens = [token for _cid, token in allowed]
        return tuple(dict.fromkeys(tokens))

    def lp_preparation_probe(
        self,
        *,
        stop_event: threading.Event | None = None,
        stage: str | None = None,
        condition_ids: Sequence[str] = (),
    ) -> dict[str, object]:
        """Read one first page of current rewards as a bounded health probe.

        The full reward catalog deliberately drains both native and sponsored
        paginators.  Recovery only needs to know whether the related public
        endpoint can answer, so this method performs one native first-page
        request and never follows its continuation cursor.
        """

        checked_at = datetime.now(UTC)
        result: dict[str, object] = {
            "state": "unknown",
            "complete": False,
            "checked_at": checked_at,
            "request_count": 0,
            "bounded": True,
            "stage": stage,
            "condition_ids": tuple(
                value.strip()
                for value in condition_ids
                if isinstance(value, str) and value.strip()
            ),
        }
        if stop_event is not None and stop_event.is_set():
            result["error_type"] = "cancelled"
            return result

        probe_stage = str(stage or "rewards").strip().lower()
        requested_ids = tuple(result["condition_ids"])
        if probe_stage == "history":
            if not requested_ids:
                result["error_type"] = "history_probe_identity_unknown"
                return result
            token_ids = self._cached_lp_token_ids(requested_ids)
            if not token_ids:
                result["error_type"] = "history_probe_token_cache_unknown"
                return result
            end_ts = int(checked_at.timestamp())
            history = self.lp_price_history(
                token_ids,
                start_ts=end_ts - 60,
                end_ts=end_ts,
                fidelity=1,
                stop_event=stop_event,
            )
            if (
                isinstance(history, Mapping)
                and history.get("state") == "known"
                and isinstance(history.get("history"), Mapping)
            ):
                result.update(
                    {
                        "state": "healthy",
                        "complete": True,
                        "request_count": 1,
                    }
                )
            else:
                for field in (
                    "status",
                    "retry_after_seconds",
                    "retry_after_at",
                    "error_chain",
                    "sqlite_errorcode",
                    "sqlite_errorname",
                ):
                    if isinstance(history, Mapping) and history.get(field) is not None:
                        result[field] = history[field]
                errors = history.get("errors") if isinstance(history, Mapping) else None
                if isinstance(errors, Mapping):
                    first_error = next(iter(errors.values()), None)
                    if isinstance(first_error, str) and first_error.replace("_", "").isalnum():
                        result["error_type"] = first_error
                result.setdefault("error_type", "history_probe_unknown")
            return result

        facts: dict[str, object] = {}
        public: object | None = None
        remove_response_hook: Callable[[], None] | None = None
        try:
            public = self._public_client_factory()
            remove_response_hook = _install_lp_response_fact_hook(
                public,
                path=(
                    "/markets/keyset"
                    if probe_stage == "metadata"
                    else "/rewards/markets/current"
                ),
                facts=facts,
            )
            if probe_stage == "metadata":
                if not requested_ids:
                    raise ValueError("metadata_probe_identity_unknown")
                paginator = public.list_markets(
                    condition_ids=requested_ids[:1], page_size=1
                )
            else:
                paginator = public.list_current_rewards(sponsored=False)
            first_page = getattr(paginator, "first_page", None)
            if not callable(first_page):
                raise ValueError("reward_probe_paginator_unknown")
            page = first_page()
            items = _field(page, "items")
            if not isinstance(items, Sequence) or isinstance(items, (str, bytes)):
                raise ValueError("reward_probe_page_unknown")
            has_more = _field(page, "has_more")
            if type(has_more) is not bool:
                raise ValueError("reward_probe_page_unknown")
            result.update(
                {
                    "state": "healthy",
                    "complete": True,
                    "request_count": 1,
                    "item_count": len(items),
                    "has_more": has_more,
                }
            )
        except _RewardReadCancelled:
            result["error_type"] = "cancelled"
        except Exception as exc:
            result["error_type"] = _safe_read_failure("reward_probe", exc)
            result["error_chain"] = _safe_read_error_chain(exc)
            result.update(_safe_sqlite_error_facts(exc))
        finally:
            if remove_response_hook is not None:
                remove_response_hook()
            if public is not None:
                close = getattr(public, "close", None)
                if callable(close):
                    close()

        result.update(facts)
        return result

    def lp_reward_rates(
        self, *, stop_event: threading.Event | None = None
    ) -> dict[str, object]:
        """Read current per-market native and sponsored reward shares."""

        checked_at = datetime.now(UTC)
        unknown = {
            "state": "unknown",
            "complete": False,
            "checked_at": checked_at,
            "markets": {},
        }
        try:
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            context = getattr(self._client, "_ctx", None)
            transport = getattr(context, "secure_clob", None)
            get_json = getattr(transport, "get_json", None)
            if not callable(get_json):
                raise ValueError("reward_transport_unknown")
            wallet_type = getattr(context, "wallet_type", None)
            signature_type = signature_type_for(wallet_type)
            as_of = checked_at.date()
            collected: dict[str, dict[str, object]] = {}
            identities: set[tuple[object, ...]] = set()

            for sponsored in (False, True):
                source = "sponsored" if sponsored else "native"
                for only_open_orders, only_open_positions in (
                    (True, False),
                    (False, True),
                ):
                    cursor: str | None = None
                    seen_cursors: set[str] = set()
                    while True:
                        if stop_event is not None and stop_event.is_set():
                            raise _RewardReadCancelled
                        params: dict[str, object] = {
                            "signature_type": signature_type,
                            "maker_address": self.config.wallet_address,
                            "sponsored": sponsored,
                            "only_open_orders": only_open_orders,
                            "only_open_positions": only_open_positions,
                            "page_size": 500,
                        }
                        if cursor is not None:
                            params["next_cursor"] = cursor
                        payload = get_json("/rewards/user/markets", params=params)
                        if stop_event is not None and stop_event.is_set():
                            raise _RewardReadCancelled
                        if not isinstance(payload, Mapping):
                            raise ValueError("reward_page_unknown")
                        rows = payload.get("data")
                        if not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)):
                            raise ValueError("reward_page_unknown")
                        for raw_row in rows:
                            row = _model_dict(raw_row)
                            if row is None:
                                raise ValueError("reward_row_unknown")
                            condition_id = row.get("condition_id")
                            if not isinstance(condition_id, str) or not condition_id:
                                raise ValueError("reward_market_unknown")
                            percentage = _lp_decimal(row.get("earning_percentage"))
                            if percentage is not None and not Decimal("0") <= percentage <= Decimal("100"):
                                percentage = None
                            raw_configs = row.get("rewards_config")
                            if not isinstance(raw_configs, Sequence) or isinstance(
                                raw_configs, (str, bytes)
                            ):
                                raise ValueError("reward_config_unknown")
                            active_configs: list[dict[str, object]] = []
                            for raw_config in raw_configs:
                                config = _model_dict(raw_config)
                                if config is None:
                                    raise ValueError("reward_config_unknown")
                                config_id = config.get("id")
                                asset_address = config.get("asset_address")
                                start_date = _reward_date(config.get("start_date"))
                                end_date = _reward_date(config.get("end_date"))
                                rate = _lp_decimal(config.get("rate_per_day"))
                                if (
                                    config_id is None
                                    or not isinstance(asset_address, str)
                                    or start_date is None
                                    or end_date is None
                                    or rate is None
                                    or rate < 0
                                ):
                                    raise ValueError("reward_config_unknown")
                                if not start_date <= as_of <= end_date:
                                    continue
                                normalized = dict(config)
                                normalized["rate_per_day"] = rate
                                normalized["sponsored"] = sponsored
                                normalized["source"] = source
                                active_configs.append(normalized)
                            market = collected.setdefault(
                                condition_id,
                                {"condition_id": condition_id, "sources": {}},
                            )
                            market_sources = cast(
                                dict[str, dict[str, object]], market["sources"]
                            )
                            source_result = market_sources.setdefault(
                                source,
                                {
                                    "source": source,
                                    "percentages": [],
                                    "reward_configs": [],
                                },
                            )
                            cast(list[Decimal | None], source_result["percentages"]).append(
                                percentage
                            )
                            for normalized in active_configs:
                                asset_address = str(normalized["asset_address"])
                                start_date = _reward_date(normalized["start_date"])
                                end_date = _reward_date(normalized["end_date"])
                                assert start_date is not None and end_date is not None
                                identity = (
                                    condition_id,
                                    str(normalized["id"]),
                                    asset_address.casefold(),
                                    start_date,
                                    end_date,
                                    sponsored,
                                )
                                if identity in identities:
                                    continue
                                identities.add(identity)
                                cast(
                                    list[dict[str, object]],
                                    source_result["reward_configs"],
                                ).append(normalized)
                        next_cursor = payload.get("next_cursor")
                        if not isinstance(next_cursor, str) or not next_cursor:
                            raise ValueError("reward_pagination_unknown")
                        if next_cursor == "LTE=":
                            break
                        if next_cursor in seen_cursors:
                            raise ValueError("reward_pagination_loop")
                        seen_cursors.add(next_cursor)
                        cursor = next_cursor

            # Issue #138 round 2: the authenticated payload's per-source
            # ``rate_per_day`` values overlap across asset-address
            # representations of the same reward, so pools never come from
            # summing the two authenticated sources.  The public selected
            # reward catalog provides the base pool N and the combined pool
            # T once per condition; the sponsored increment is S = T − N.
            catalog = self._lp_selected_reward_catalog(
                tuple(collected), stop_event=stop_event
            )
            raw_catalog_markets = catalog.get("markets")
            catalog_by_condition: dict[str, Mapping[str, object]] = {}
            if isinstance(raw_catalog_markets, (list, tuple)):
                for catalog_row in raw_catalog_markets:
                    if isinstance(catalog_row, Mapping) and catalog_row.get(
                        "condition_id"
                    ):
                        catalog_by_condition[str(catalog_row["condition_id"])] = (
                            catalog_row
                        )

            def share_percentage(source_result: object) -> Decimal | None:
                if not isinstance(source_result, Mapping):
                    return None
                percentages = cast(
                    list[Decimal | None], source_result["percentages"]
                )
                if (
                    percentages
                    and percentages[0] is not None
                    and all(item == percentages[0] for item in percentages)
                ):
                    return percentages[0]
                return None

            for market in collected.values():
                market_known = True
                hourly_total = Decimal("0")
                failure_reason: str | None = None
                source_rows = cast(dict[str, dict[str, object]], market["sources"])
                catalog_row = catalog_by_condition.get(
                    str(market["condition_id"])
                )
                if not isinstance(catalog_row, Mapping) or catalog_row.get(
                    "state"
                ) != "known":
                    market_known = False
                    failure_reason = "reward_pool_unknown"
                    reason_codes = (
                        catalog_row.get("reason_codes")
                        if isinstance(catalog_row, Mapping)
                        else None
                    )
                    if (
                        isinstance(reason_codes, (list, tuple))
                        and reason_codes
                        and reason_codes[0]
                    ):
                        failure_reason = str(reason_codes[0])
                else:
                    pools = (
                        (
                            "native",
                            cast(Decimal, catalog_row["native_daily_pool_usd"]),
                            cast(Decimal, catalog_row["native_daily_pool_usd"]),
                        ),
                        (
                            "sponsored",
                            cast(Decimal, catalog_row["sponsored_daily_pool_usd"]),
                            cast(Decimal, catalog_row["daily_pool_usd"]),
                        ),
                    )
                    for source, increment_pool, reported_pool in pools:
                        source_result = source_rows.get(source)
                        percentage = share_percentage(source_result)
                        if percentage is None and increment_pool > 0:
                            # A positive reward component must have a valid
                            # share; a zero component never forces one.
                            market_known = False
                            failure_reason = failure_reason or "reward_share_missing"
                            if source_result is not None:
                                source_result.update(
                                    {
                                        "state": "unknown",
                                        "earning_percentage": percentage,
                                        "daily_pool_usd": None,
                                        "hourly_reward_usd": None,
                                        "currency": None,
                                        "checked_at": checked_at,
                                    }
                                )
                                market[source] = source_result
                            continue
                        component = (
                            increment_pool
                            * percentage
                            / Decimal("100")
                            / Decimal("24")
                            if percentage is not None
                            else Decimal("0")
                        )
                        if source_result is not None:
                            source_result.update(
                                {
                                    "state": "known",
                                    "earning_percentage": percentage,
                                    "daily_pool_usd": reported_pool,
                                    "hourly_reward_usd": component,
                                    "currency": "USD",
                                    "checked_at": checked_at,
                                }
                            )
                            market[source] = source_result
                        hourly_total += component
                if market_known:
                    market["state"] = "known"
                    market["hourly_reward_usd"] = hourly_total
                    market["currency"] = "USD"
                else:
                    market["state"] = "unknown"
                    market["hourly_reward_usd"] = None
                    market["currency"] = None
                    market["reason"] = failure_reason or "reward_rate_unknown"
                market["checked_at"] = checked_at
                market["sources"] = tuple(
                    source
                    for source in ("native", "sponsored")
                    if source in source_rows
                )
            return {
                "state": "known",
                "complete": True,
                "checked_at": checked_at,
                "markets": collected,
            }
        except _RewardReadCancelled:
            unknown["reason"] = "cancelled"
            return unknown
        except Exception:
            return unknown

    def lp_reward_snapshots(
        self,
        reward_date: str,
        condition_ids: Sequence[str],
        *,
        stop_event: threading.Event | None = None,
    ) -> dict[str, dict[str, object]]:
        """Read one day's rewards for several conditions with one account read."""

        requested = tuple(dict.fromkeys(str(condition_id) for condition_id in condition_ids))
        if not requested:
            return {}
        unknown = {
            condition_id: {
                "state": "unknown",
                "reward_date": reward_date,
                "condition_id": condition_id,
                "maker_address": self.config.wallet_address,
            }
            for condition_id in requested
        }
        if not any(requested):
            return unknown
        try:
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            parsed_date = Date.fromisoformat(str(reward_date))
            context = getattr(self._client, "_ctx", None)
            transport = getattr(context, "secure_clob", None)
            get_json = getattr(transport, "get_json", None)
            if not callable(get_json):
                raise ValueError("reward_transport_unknown")
            wallet_type = getattr(context, "wallet_type", None)
            signature_type = signature_type_for(wallet_type)
            maker = self.config.wallet_address
            total_payload = get_json(
                "/rewards/user/total",
                params={
                    "date": parsed_date.isoformat(),
                    "signature_type": signature_type,
                    "maker_address": maker,
                    "sponsored": True,
                },
            )
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            total_rows = _reward_total_rows(total_payload)
            account_amount = _reward_amount(
                total_rows, parsed_date=parsed_date, maker=maker
            )
            account_raw_amounts = _reward_raw_amounts(
                total_rows, parsed_date=parsed_date, maker=maker
            )
            if account_raw_amounts is None or any(
                asset not in LP_REWARD_ASSET_USD_ADDRESSES
                for asset in account_raw_amounts
            ):
                raise ValueError("reward_total_unknown")
            account_accruals = _reward_accruals(account_raw_amounts)
            account_raw = account_accruals[0] if len(account_accruals) == 1 else None
            results: dict[str, dict[str, object]] = {}
            for condition_id in requested:
                if not condition_id:
                    continue
                try:
                    market_rows: list[Mapping[str, object]] = []
                    for sponsored in (False, True):
                        market_rows.extend(
                            self._lp_reward_market_rows(
                                parsed_date=parsed_date,
                                maker=maker,
                                condition_id=condition_id,
                                signature_type=signature_type,
                                sponsored=sponsored,
                                get_json=get_json,
                                stop_event=stop_event,
                            )
                        )
                    market_amount = _reward_amount(
                        market_rows,
                        parsed_date=parsed_date,
                        maker=maker,
                        condition_id=condition_id,
                    )
                    market_raw_amounts = _reward_raw_amounts(
                        market_rows,
                        parsed_date=parsed_date,
                        maker=maker,
                        condition_id=condition_id,
                    )
                    if market_raw_amounts is None or any(
                        asset not in LP_REWARD_ASSET_USD_ADDRESSES
                        for asset in market_raw_amounts
                    ):
                        raise ValueError("reward_market_unknown")
                    market_accruals = _reward_accruals(market_raw_amounts)
                    market_raw = market_accruals[0] if len(market_accruals) == 1 else None
                    usd_state = (
                        "known"
                        if account_amount is not None and market_amount is not None
                        else "unknown"
                    )
                    results[condition_id] = {
                        "state": usd_state,
                        "reward_date": parsed_date.isoformat(),
                        "condition_id": condition_id,
                        "maker_address": maker,
                        "account_amount": account_amount,
                        "market_amount": market_amount,
                        "account_amount_raw": account_raw.get("amount") if account_raw else None,
                        "account_asset": account_raw.get("asset") if account_raw else None,
                        "account_accruals_raw": account_accruals,
                        "market_amount_raw": market_raw.get("amount") if market_raw else None,
                        "market_asset": market_raw.get("asset") if market_raw else None,
                        "market_accruals_raw": market_accruals,
                        "usd_state": usd_state,
                        "account_reward": account_amount,
                        "market_reward": market_amount,
                        "currency": "USD",
                        "paid": False,
                        "reason": "usd_value_unknown" if usd_state == "unknown" else None,
                        "conversion_basis": (
                            "earnings at unit asset_rate for verified pUSD/USDC.e assets; "
                            "non-unit valuations UNKNOWN"
                        ),
                    }
                except _RewardReadCancelled:
                    raise
                except Exception as exc:
                    reason = str(exc) if isinstance(exc, ValueError) and str(exc) in {
                        "reward_market_unknown", "reward_total_unknown"
                    } else type(exc).__name__
                    results[condition_id] = {**unknown[condition_id], "reason": reason}
            return {condition_id: results.get(condition_id, unknown[condition_id]) for condition_id in requested}
        except _RewardReadCancelled:
            return {
                condition_id: {**unknown[condition_id], "reason": "cancelled"}
                for condition_id in requested
            }
        except Exception as exc:
            reason = str(exc) if isinstance(exc, ValueError) and str(exc) in {
                "reward_market_unknown", "reward_total_unknown", "reward_total_shape_unknown"
            } else type(exc).__name__
            return {condition_id: {**row, "reason": reason}
                    for condition_id, row in unknown.items()}


    def lp_reward_snapshot(
        self,
        reward_date: str,
        condition_id: str,
        *,
        stop_event: threading.Event | None = None,
    ) -> dict[str, object]:
        """Read one day's current platform reward record without trading."""

        return self.lp_reward_snapshots(
            reward_date, (condition_id,), stop_event=stop_event
        ).get(
            condition_id,
            {
                "state": "unknown",
                "reward_date": reward_date,
                "condition_id": condition_id,
                "maker_address": self.config.wallet_address,
            },
        )

    def lp_reward_percentages(self) -> dict[str, object]:
        """Read the account's official per-market reward percentages."""

        checked_at = datetime.now(UTC)
        unknown = {
            "state": "unknown",
            "scope": "account",
            "maker_address": self.config.wallet_address,
            "percentages": {},
            "checked_at": checked_at,
        }
        try:
            context = getattr(self._client, "_ctx", None)
            transport = getattr(context, "secure_clob", None)
            get_json = getattr(transport, "get_json", None)
            if not callable(get_json):
                raise ValueError("reward_percentage_transport_unknown")
            signature_type = signature_type_for(getattr(context, "wallet_type", None))
            payload = get_json(
                "/rewards/user/percentages",
                params={
                    "signature_type": signature_type,
                    "maker_address": self.config.wallet_address,
                },
            )
            if not isinstance(payload, Mapping):
                raise ValueError("reward_percentage_shape_unknown")
            percentages: dict[str, Decimal] = {}
            for raw_condition_id, raw_percentage in payload.items():
                if (
                    not isinstance(raw_condition_id, str)
                    or not raw_condition_id.strip()
                ):
                    raise ValueError("reward_percentage_identity_unknown")
                percentage = _lp_decimal(raw_percentage)
                if (
                    percentage is None
                    or percentage < Decimal("0")
                    or percentage > Decimal("100")
                ):
                    raise ValueError("reward_percentage_value_unknown")
                percentages[raw_condition_id] = percentage
            return {
                "state": "known",
                "scope": "account",
                "maker_address": self.config.wallet_address,
                "percentages": percentages,
                "checked_at": checked_at,
            }
        except Exception as exc:
            del exc
            return unknown

    def lp_market_competitiveness(
        self,
        *,
        start_cursor: str | None = None,
        stop_event: threading.Event | None = None,
        previous: Mapping[str, object] | None = None,
        publish_batch: Callable[..., None] | None = None, batch_size: int = 500,
    ) -> dict[str, object]:
        """Read official market competitiveness across all reward pages.

        The read never raises for transport failures: pages that succeed merge
        into the returned mapping, targets covered by failed pages keep their
        previous value and are flagged in ``not_updated`` so the caller can
        mark them as stale-this-round.  A round stopped early by transport
        failures carries the last successful page's ``next_cursor`` back as
        ``resume_cursor`` so the next round resumes instead of restarting;
        a completed round clears it.  Explicit zero competitiveness is kept
        as zero; the projection owns the danger-signal exclusion.
        The returned map is newly owned; previous is only read, never changed.
        With publish_batch, extraction is bounded and no full-round map is built.
        The callback commits each batch and advances a page only after its last batch.
        """

        if batch_size < 1:
            raise ValueError("competition_batch_size_invalid")
        checked_at = datetime.now(UTC)
        ended_condition_ids: list[str] = []

        def previous_entries():
            if not isinstance(previous, Mapping):
                return
            for key, value in previous.items():
                if not isinstance(key, str) or not key.strip():
                    continue
                if isinstance(value, tuple) and len(value) == 2:
                    stamp = value[1]
                    if isinstance(value[0], Decimal) and isinstance(stamp, datetime):
                        yield key, value

        # Issue #177: the bookmark for the next round — the next_cursor of
        # the last page that was read successfully, or the round's own
        # start when no page succeeded.  Cleared when the walk completes.
        cursor: str | None = start_cursor or None
        resume_cursor: str | None = cursor
        resumed = cursor is not None

        def finish(state: str, *, complete: bool = False) -> dict[str, object]:
            not_updated = []
            # Only interrupted/resumed walks retain untouched previous facts.
            for key, value in previous_entries():
                if key not in merged:
                    not_updated.append(key)
                    if not complete or resumed:
                        merged[key] = value
            return {
                "state": state,
                "complete": complete,
                "checked_at": checked_at,
                "round_checked_at": checked_at,
                "competitiveness": merged,
                "not_updated": sorted(not_updated),
                "resume_cursor": resume_cursor,
                "ended_condition_ids": tuple(ended_condition_ids),
            }

        merged: dict[str, tuple[Decimal, datetime]] = {}
        pages_ok = 0
        try:
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            opener = self._urlopen_fn or _lp_competition_direct_opener()
            seen_cursors: set[str] = set()
            while True:
                if stop_event is not None and stop_event.is_set():
                    raise _RewardReadCancelled
                params: dict[str, object] = {"page_size": 500}
                if cursor is not None:
                    params["next_cursor"] = cursor
                request = Request(
                    f"{LP_COMPETITIVENESS_ENDPOINT}?{urlencode(params)}",
                    headers={
                        "Accept": "application/json",
                        "User-Agent": "OpenTrader/1.0",
                    },
                )
                payload: object = None
                page_read = False
                last_error: Exception | None = None
                for attempt in range(LP_COMPETITIVENESS_PAGE_ATTEMPTS):
                    if attempt:
                        pause = LP_COMPETITIVENESS_RETRY_PAUSE_SECONDS
                        if stop_event is not None:
                            # A cooperative stop interrupts the retry wait.
                            if stop_event.wait(pause):
                                raise _RewardReadCancelled
                        elif pause:
                            time.sleep(pause)
                        if stop_event is not None and stop_event.is_set():
                            raise _RewardReadCancelled
                    try:
                        with opener(
                            request, timeout=LP_COMPETITIVENESS_TIMEOUT_SECONDS
                        ) as response:
                            raw = response.read()
                        if isinstance(raw, bytes):
                            raw = raw.decode("utf-8")
                        payload = json.loads(raw, parse_float=Decimal)
                        page_read = True
                        break
                    except Exception as exc:
                        last_error = exc
                if not page_read:
                    logger.warning(
                        "lp_market_competitiveness page abandoned after %d "
                        "attempts: cursor=%r pages_ok=%d error=%r",
                        LP_COMPETITIVENESS_PAGE_ATTEMPTS,
                        cursor,
                        pages_ok,
                        last_error,
                    )
                    raise ValueError("competitiveness_page_unreadable")
                if stop_event is not None and stop_event.is_set():
                    raise _RewardReadCancelled
                if not isinstance(payload, Mapping):
                    raise ValueError("competitiveness_page_unknown")
                rows = payload.get("data")
                if not isinstance(rows, Sequence) or isinstance(rows, (str, bytes)):
                    raise ValueError("competitiveness_page_unknown")
                next_cursor = payload.get("next_cursor")
                next_cursor = next_cursor if isinstance(next_cursor, str) and next_cursor and next_cursor != "LTE=" else None
                if next_cursor is not None and (next_cursor == cursor or next_cursor in seen_cursors):
                    raise ValueError("competitiveness_pagination_loop")
                batch: dict[str, tuple[Decimal, datetime]] = {}
                page_checked_at = datetime.now(UTC) if publish_batch is not None else checked_at
                for offset, raw_row in enumerate(rows):
                    row = _model_dict(raw_row) or {}
                    condition_id = row.get("condition_id")
                    if isinstance(condition_id, str) and condition_id.strip():
                        state = row.get("state")
                        state = state if isinstance(state, Mapping) else {}
                        if any(source.get(key) is True for source in (row, state) for key in ("closed", "resolved")):
                            ended_condition_ids.append(condition_id)
                        value = _lp_decimal(row.get("market_competitiveness"))
                        if value is not None and value >= 0:
                            (batch if publish_batch is not None else merged)[condition_id] = (value, page_checked_at)
                    if publish_batch is not None and ((offset + 1) % batch_size == 0 or offset + 1 == len(rows)):
                        if stop_event is not None and stop_event.is_set():
                            raise _RewardReadCancelled
                        publish_batch(batch, page_cursor=cursor,
                                      resume_cursor=next_cursor if offset + 1 == len(rows) else cursor,
                                      checked_at=checked_at, stop_event=stop_event)
                        batch = {}
                if publish_batch is not None and not rows:
                    publish_batch({}, page_cursor=cursor, resume_cursor=next_cursor,
                                  checked_at=checked_at, stop_event=stop_event)
                pages_ok += 1
                if next_cursor is None:
                    resume_cursor = None
                    break
                seen_cursors.add(next_cursor)
                cursor = next_cursor
                resume_cursor = next_cursor
            return finish("known", complete=True)
        except _RewardReadCancelled:
            return finish("unknown")
        except Exception:
            # Some pages succeeded: keep the partial round.  Nothing arrived:
            # the whole read failed and must not block the funnel.
            return finish("partial" if pages_ok else "unknown")

    @staticmethod
    def _lp_reward_market_rows(
        *,
        parsed_date: Date,
        maker: str,
        condition_id: str,
        signature_type: int,
        sponsored: bool,
        get_json: Callable[..., object],
        stop_event: threading.Event | None = None,
    ) -> list[Mapping[str, object]]:
        rows: list[Mapping[str, object]] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()
        while True:
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            params: dict[str, object] = {
                "date": parsed_date.isoformat(),
                "signature_type": signature_type,
                "maker_address": maker,
                "sponsored": sponsored,
            }
            if cursor is not None:
                params["next_cursor"] = cursor
            payload = get_json("/rewards/user", params=params)
            if stop_event is not None and stop_event.is_set():
                raise _RewardReadCancelled
            if not isinstance(payload, Mapping):
                raise ValueError("reward_page_unknown")
            page_rows = payload.get("data")
            if not isinstance(page_rows, Sequence) or isinstance(page_rows, (str, bytes)):
                raise ValueError("reward_page_unknown")
            for row in page_rows:
                if not isinstance(row, Mapping):
                    raise ValueError("reward_row_unknown")
                rows.append(row)
            next_cursor = payload.get("next_cursor")
            if not isinstance(next_cursor, str) or not next_cursor:
                raise ValueError("reward_pagination_unknown")
            if next_cursor == "LTE=":
                return rows
            if next_cursor in seen_cursors:
                raise ValueError("reward_pagination_loop")
            seen_cursors.add(next_cursor)
            cursor = next_cursor

    def _lp_market_facts(
        self,
        request: Mapping[str, object],
        condition_id: str,
        market: Mapping[str, object],
        book: Mapping[str, object],
    ) -> dict[str, object]:
        """Normalize market admission facts after financial facts are ready."""
        state = _model_dict(market.get("state")) or {}
        outcomes = _model_dict(market.get("outcomes")) or {}
        selected = str(request.get("outcome") or "").lower()
        selected_outcome = _model_dict(outcomes.get(selected)) or {}
        trading = _model_dict(market.get("trading")) or {}
        rewards = _model_dict(market.get("rewards")) or {}
        fee_schedule = _model_dict(trading.get("fee_schedule")) or {}
        fees_enabled = trading.get("fees_enabled")
        reward_min = rewards.get("rewards_min_size")
        reward_spread = rewards.get("rewards_max_spread")
        if reward_min is None or reward_spread is None:
            reward_reader = getattr(self._client, "list_market_rewards", None)
            if callable(reward_reader):
                with _lp_read_stage("market_rewards"):
                    reward_rows = tuple(_collect(reward_reader(condition_id=condition_id)))
                if reward_rows:
                    reward = _model_dict(reward_rows[0]) or {}
                    reward_min = reward.get("rewards_min_size")
                    reward_spread = reward.get("rewards_max_spread")
        tick_size = book.get("tick_size", trading.get("minimum_tick_size"))
        minimum_order_size = book.get("min_order_size", trading.get("minimum_order_size"))
        taker_rate = fee_schedule.get("rate")
        if taker_rate is None:
            taker_rate = market.get("taker_fee_rate")
        with _lp_read_stage("market_validate"):
            if taker_rate is None and fees_enabled is not False:
                raise ValueError("fee_rate_unknown")
        raw_reward_spread = _lp_decimal(reward_spread)
        normalized_reward_spread = (
            None if raw_reward_spread is None else raw_reward_spread / Decimal("100")
        )
        fee_value: Decimal | None
        if fees_enabled is False or fee_schedule.get("taker_only") is True:
            fee_value = Decimal("0")
        else:
            fee_value = None
        return {
            "market_id": market.get("id"),
            "condition_id": market.get("condition_id"),
            "token_id": selected_outcome.get("token_id"),
            "outcome": str(selected_outcome.get("label") or request.get("outcome") or "").upper(),
            "accepting_orders": state.get("accepting_orders"),
            "exchange_type": "CLOB",
            "tick_size": _lp_decimal(tick_size),
            "minimum_order_size": _lp_decimal(minimum_order_size),
            "fee": fee_value,
            "fees_enabled": fees_enabled,
            "fee_exponent": _lp_decimal(fee_schedule.get("exponent", 1)),
            "taker_fee_rate": _lp_decimal(taker_rate),
            "reward_min_size": _lp_decimal(reward_min),
            "reward_max_spread": normalized_reward_spread,
        }

    def lp_order_result_snapshot(self, request: Mapping[str, object]) -> dict[str, object]:
        """Read authenticated execution results without financial transport/publication.

        The SDK list methods exhaust their pagination. Missing/malformed lists
        and exact receipts remain unknown, even when the open-order list is empty.
        This result deliberately contains no balance, allowance or account bundle.
        """
        started = datetime.now(UTC)
        open_snapshot = self.lp_open_orders_snapshot()
        complete = open_snapshot.get('open_orders_complete') is True
        wallet = str(self.config.wallet_address or '').strip().casefold()
        orders = list(open_snapshot.get('open_orders', ()))
        known_ids = {str(row['order_id']) for row in orders}
        exact_ids = {str(value) for value in _collect(request.get('owned_order_ids')) if value}
        errors = {}
        for order_id in sorted(exact_ids - known_ids):
            lookup = getattr(self._client, 'get_order', None)
            try:
                raw = lookup(order_id=order_id) if callable(lookup) else None
                row = _lp_order(raw)
                identity = _model_dict(raw) or {}
                if row is None:
                    errors[order_id] = 'order_lookup_unavailable' if raw is None else 'order_response_invalid'
                    continue
                # SDK owner is a credential identifier. maker_address is the wallet.
                maker = str(identity.get('maker_address') or '').strip().casefold()
                if (row['order_id'] != order_id or not maker or maker != wallet
                        or not row.get('condition_id') or not row.get('token_id')
                        or row.get('side') not in ('BUY', 'SELL') or not row.get('status')
                        or row.get('price') is None or row.get('fill_quantity_known') is not True):
                    errors[order_id] = 'order_response_invalid'
                    complete = False
                    continue
                orders.append(row)
            except Exception:
                errors[order_id] = 'order_read_failed'
        trades, positions = [], []
        trades_complete = positions_complete = True
        try:
            raw_trades = self._client.list_account_trades()
            if raw_trades is None:
                trades_complete = False
            else:
                for raw in _collect(raw_trades):
                    row = _lp_trade(raw)
                    if row is None:
                        trades_complete = False
                        continue
                    if isinstance(row.get('maker_orders'), list):
                        row['maker_orders'] = [maker for maker in row['maker_orders']
                            if _lp_maker_order_is_self(maker, wallet)]
                    trades.append(row)
        except Exception:
            trades_complete = False
        try:
            raw_positions = self._client.list_positions()
            if raw_positions is None:
                positions_complete = False
            else:
                for raw in _collect(raw_positions):
                    row = _lp_position(raw)
                    if (row is None or not row.get('condition_id') or row.get('size') is None
                            or row['size'] < 0):
                        positions_complete = False
                        continue
                    positions.append(row)
        except Exception:
            positions_complete = False
        ended = datetime.now(UTC)
        return dict(result_only=True, authenticated=open_snapshot.get('authenticated') is True,
            wallet_address=self.config.wallet_address, read_started_at=started,
            read_ended_at=ended, checked_at=ended,
            open_orders=list(open_snapshot.get('open_orders', ())), open_orders_complete=complete,
            pagination_complete=complete and trades_complete and positions_complete,
            orders=orders, order_read_errors=errors, trades=trades, positions=positions,
            trades_complete=trades_complete, positions_complete=positions_complete)

    def lp_snapshot(self, request: Mapping[str, object]) -> dict[str, object]:
        """Read the authenticated and public facts used by one LP session.

        This adapter deliberately returns order, trade, position, market and
        book facts rather than a precomputed LP result.  The LP service owns
        attribution and risk arithmetic after these facts have been read.
        """

        market_id = str(request.get("market_id") or "")
        condition_id = str(request.get("condition_id") or "")
        token_id = str(request.get("token_id") or "")
        if not market_id or not condition_id or not token_id:
            raise ValueError("external_snapshot_unknown")
        try:
            account_round = request.get("_lp_account_round")
            account_generation: int | None = None
            bundle_trade_generation: int | None = None
            with _lp_read_stage("account"):
                if account_round is None:
                    account = self._lp_account_facts(include_raw_trades=True)
                else:
                    if (
                        not isinstance(account_round, _LpAccountRound)
                        or account_round.client is not self
                    ):
                        raise LpAccountRoundInvalid("lp_account_round_invalid")
                    account, account_generation, bundle_trade_generation = (
                        self._lp_account_snapshot_for_round(account_round)
                    )
                    account = deepcopy(account)
            open_orders = account['open_orders']
            if account.get("trades_complete") is not True:
                raise ValueError("external_snapshot_unknown")
            order_facts: list[object] = list(open_orders)
            known_ids = {
                str(_field(order, "id", _field(order, "order_id", "")))
                for order in order_facts
            }
            order_ids = {
                str(value) for value in (
                    *(request.get(key) for key in ("entry_order_id", "passive_exit_order_id", "protected_exit_order_id")),
                    *_collect(request.get("augment_order_ids")),
                    *_collect(request.get("owned_order_ids")),
                ) if value
            }
            # The service supplies durable terminal receipts separately from
            # identity. Keep every owned ID for trade attribution, and let a
            # current open-order observation override historical state.
            for order_id, receipt in request.get("_lp_terminal_orders", {}).items():
                if order_id in order_ids and order_id not in known_ids:
                    order_facts.append(receipt)
                    known_ids.add(order_id)
            raw_trades = account.get("raw_trades", ())
            trades = tuple(
                trade
                for trade in raw_trades
                if _lp_full_trade_is_relevant(
                    trade,
                    condition_id=condition_id,
                    token_id=token_id,
                    exact_order_ids=order_ids,
                )
            )
            order_read_errors = {}
            missing_order_ids = order_ids - known_ids
            bundle_receipt_facts = (
                _lp_bundle_receipt_facts(
                    account.get("raw_trades", ()),
                )
                if missing_order_ids
                else {}
            )
            for order_id in sorted(order_ids):
                if order_id in known_ids:
                    with self._lp_order_read_lock:
                        self._lp_order_read_failures.pop(order_id, None)
                    continue
                with self._lp_order_read_lock:
                    failure = self._lp_order_read_failures.get(order_id)
                if failure and time.monotonic() < failure[1]:
                    order_read_errors[order_id] = failure[0]
                    continue
                get_order = getattr(self._client, "get_order", None)
                if not callable(get_order):
                    continue
                try:
                    with _lp_read_stage("required_order"):
                        order = get_order(order_id=order_id)
                except Exception as exc:
                    # SDK 0.2 parses HTTP 200 JSON null as OpenOrder and wraps
                    # the root ValidationError. Null is unavailable, not terminal.
                    from pydantic import ValidationError
                    cause = exc.__cause__
                    order_read_errors[order_id] = ('order_lookup_unavailable' if _null_order_response(exc)
                        else 'order_response_invalid' if isinstance(cause, ValidationError)
                        else 'order_read_failed')
                    with self._lp_order_read_lock:
                        self._lp_order_read_failures[order_id] = (order_read_errors[order_id], time.monotonic() + 60)
                    continue
                normalized = _lp_order(order)
                if normalized is not None:
                    if account_round is not None:
                        raw_receipt = _model_dict(order) or {}
                        receipt_matched = _lp_decimal(
                            normalized.get("size_matched")
                        )
                        receipt_trades = {
                            str(value)
                            for value in _collect(raw_receipt.get("associate_trades"))
                            if value
                        }
                        bundle_matched, bundle_trades = bundle_receipt_facts.get(
                            str(normalized.get("order_id") or ""),
                            (Decimal("0"), set()),
                        )
                        if receipt_matched is None or bundle_matched is None:
                            # Exact consistency cannot be proven; the consumer
                            # must stay UNKNOWN without guessing chronology.
                            # The get_order response itself was valid. Do not
                            # cool it down like a transport or parse failure;
                            # fresh complete history can resolve immediately.
                            order_read_errors[order_id] = "order_receipt_unknown"
                            continue
                        if receipt_matched > bundle_matched or receipt_trades - bundle_trades:
                            self._lp_account_round_matches(
                                account_round, account_generation or 0
                            )
                            raise LpNewerAccountFacts(
                                observed_trade_generation=bundle_trade_generation or 0
                            )
                    order_facts.append(normalized)
                    known_ids.add(order_id)
                    with self._lp_order_read_lock:
                        self._lp_order_read_failures.pop(order_id, None)
                else:
                    order_read_errors[order_id] = ('order_lookup_unavailable' if order is None
                                                  else 'order_response_invalid')
                    with self._lp_order_read_lock:
                        self._lp_order_read_failures[order_id] = (order_read_errors[order_id], time.monotonic() + 60)

            # Normalize complete financial facts before the optional public
            # lane can fail; settlement and market admission stay separate.
            account_facts = {
                key: value
                for key, value in account.items()
                if key not in {"raw_trades", "trades", "trades_complete"}
            }
            account_facts["open_orders"] = list(open_orders)
            order_rows = order_facts
            order_statuses = {
                str(_field(order, "id", _field(order, "order_id", ""))): str(
                    _field(order, "status", "")
                ).upper()
                for order in order_rows
            }
            orders_terminal = not order_ids or all(
                order_statuses.get(order_id) in {
                    "FILLED", "MATCHED", "CANCELED", "CANCELLED",
                    "REJECTED", "EXPIRED", "FAILED",
                }
                for order_id in order_ids
            )
            with _lp_read_stage("trades_normalize"):
                trade_rows = [_lp_trade(trade) for trade in trades]
                if any(row is None for row in trade_rows):
                    raise ValueError("external_snapshot_unknown")
            position_flat = not any(
                str(_field(position, "token_id", _field(position, "asset_id", "")))
                == token_id
                and (_decimal(_field(position, "size", 0)) > 0)
                for position in account["positions"]
            )
            market_facts = None
            book = None
            public_read_errors: dict[str, object] = {}
            market_model, book_model, book_received_at, public_error = (
                self._read_lp_public_snapshot(
                    f"{condition_id}\0{token_id}",
                    market_id,
                    token_id,
                    wait=request.get("lp_public_wait") is not False,
                    condition_id=condition_id,
                )
            )
            if public_error is not None:
                public_read_errors[condition_id] = public_error
            else:
                try:
                    with _lp_read_stage("market_book_normalize"):
                        market = _model_dict(market_model)
                        book = _lp_book(book_model)
                        if market is None or book is None:
                            raise ValueError("market_response_invalid")
                        book["received_at"] = book_received_at
                    market_facts = self._lp_market_facts(
                        request, condition_id, market, book
                    )
                except Exception as exc:
                    public_read_errors[condition_id] = {
                        "error_type": (
                            str(exc)
                            if isinstance(exc, ValueError) and str(exc)
                            else type(exc).__name__
                        ),
                        "stage": "market_book",
                    }
            result: dict[str, object] = {
                "account": account_facts,
                "market": market_facts,
                "book": book,
                "orders": order_rows,
                "order_read_errors": order_read_errors,
                "market_read_errors": public_read_errors,
                "trades": trade_rows,
                "orders_terminal": orders_terminal,
                "position_flat": position_flat,
                "account_checked_at": account["checked_at"],
                "book_checked_at": book.get("received_at") if book else None,
                "_lp_trade_generation": bundle_trade_generation,
            }
            if account_round is not None:
                self._lp_account_round_matches(account_round, account_generation)
            return result
        except PolymarketTradingError:
            raise ValueError("external_snapshot_unknown") from None
        except ValueError:
            raise
        except Exception:
            raise ValueError("external_snapshot_unknown") from None

    def lp_create_limit_order(self, **kwargs: object) -> object:
        """Create one explicit post-only GTD signed LP order."""

        expiration = kwargs.get("expiration")
        post_only = kwargs.get("post_only")
        signed = self._client.create_limit_order(
            token_id=str(kwargs["token_id"]),
            price=cast(Decimal, kwargs["price"]),
            size=cast(Decimal, kwargs["quantity"]),
            side=cast(str, kwargs["side"]),
            post_only=post_only is True,
            expiration=cast(int | None, expiration),
        )
        if post_only is not True:
            raise PolymarketTradingError("order_shape_mismatch")
        expected_type = "GTC" if expiration is None else "GTD"
        if _field(signed, "post_only") is not True or str(_field(signed, "order_type", "")).upper() != expected_type:
            raise PolymarketTradingError("order_shape_mismatch")
        return signed

    def lp_post_order(self, signed_order: object) -> object:
        return self._client.post_order(signed_order)

    def get_order_scoring(self, order_id: str) -> bool:
        return self._client.get_order_scoring(order_id=order_id) is True

    def submit_protected_sell(
        self, *, token_id: str, quantity: Decimal, min_price: Decimal
    ) -> object:
        if min_price <= 0 or quantity <= 0:
            raise ValueError("protected_exit_floor_invalid")
        signed = self._client.create_market_order(
            token_id=token_id,
            side="SELL",
            shares=quantity,
            min_price=min_price,
            order_type="FOK",
        )
        return self._client.post_order(signed)

    def _collateral_balance_allowance(self) -> tuple[Decimal, Decimal]:
        balance = self._client.get_balance_allowance(asset_type="COLLATERAL")
        p_usd_balance = _decimal(_field(balance, "balance"), base_units=True)
        allowances = _field(balance, "allowances", {})
        environment = getattr(self._client, "environment", PRODUCTION)
        spender = getattr(environment, "standard_exchange", None)
        if not isinstance(spender, str) or not isinstance(allowances, Mapping):
            return p_usd_balance, Decimal("0")
        selected = next(
            (
                value
                for key, value in allowances.items()
                if isinstance(key, str) and key.lower() == spender.lower()
            ),
            0,
        )
        return p_usd_balance, _decimal(selected, base_units=True)

    def readiness_snapshot(self) -> dict[str, object]:
        """Return a fresh, explicit gasless-relayer and merge capability fact."""

        checked_at = datetime.now(UTC)
        p_usd_balance, p_usd_allowance = self._collateral_balance_allowance()
        merge_capable = callable(getattr(self._client, "merge_positions", None))
        if isinstance(self._client, SecureClient):
            gasless_ready = self._authenticated_relayer_probe()
        else:
            # Test/dry-run collaborators may expose an explicit readiness fact.
            # The real SecureClient path above never trusts its deprecated,
            # unconditional is_gasless_ready() implementation.
            gasless_method = getattr(self._client, "is_gasless_ready", None)
            gasless_ready = False
            if callable(gasless_method):
                try:
                    gasless_ready = gasless_method() is True
                except Exception as exc:
                    code = _safe_error_code(exc)
                    if code in {"network", "timeout", "unavailable"}:
                        raise PolymarketTradingError(code) from None
                    gasless_ready = False
        merge_ready = merge_capable and gasless_ready
        return {
            "checked_at": checked_at,
            "wallet": "ready",
            "wallet_address": self.config.wallet_address,
            "p_usd_balance": p_usd_balance,
            "p_usd_allowance": p_usd_allowance,
            "merge_capability": merge_capable,
            "merge_ready": merge_ready,
            "merge": "ready" if merge_ready else "unavailable",
            "relayer_ready": gasless_ready,
            "relayer": "ready" if gasless_ready else "unavailable",
            "ready": merge_ready,
        }

    def _authenticated_relayer_probe(self) -> bool:
        """Prove the configured non-EOA wallet can read relayer parameters."""

        try:
            context = self._client._ctx  # type: ignore[attr-defined]
            wallet_type = str(getattr(context, "wallet_type", ""))
            if wallet_type == "EOA":
                return False
            relay_type = {
                "POLY_PROXY": "PROXY",
                "GNOSIS_SAFE": "SAFE",
                "DEPOSIT_WALLET": "WALLET",
            }.get(wallet_type)
            relayer = getattr(context, "relayer", None)
            signer = str(getattr(getattr(context, "signer", None), "address", ""))
            if relay_type is None or not signer or not callable(getattr(relayer, "get_json", None)):
                return False
            path = "/relay-payload" if wallet_type == "POLY_PROXY" else "/v1/account/transactions/params"
            payload = relayer.get_json(
                path,
                params={"address": signer, "type": relay_type},
            )
            if not isinstance(payload, Mapping):
                return False
            address = payload.get("address")
            nonce = payload.get("nonce")
            return (
                isinstance(address, str)
                and _ADDRESS_RE.fullmatch(address) is not None
                and isinstance(nonce, str)
                and bool(nonce)
                and nonce.isdigit()
            )
        except Exception as exc:
            code = _safe_error_code(exc)
            if code in {"network", "timeout", "unavailable"}:
                raise PolymarketTradingError(code) from None
            return False

    def _identity_summary(self) -> tuple[str, str]:
        signer = _address_from_client(self._client, "signer")
        wallet = _address_from_client(self._client, "wallet")
        signer_match = "yes" if signer is not None and signer.lower() == self.config.signer_address.lower() else "no"
        wallet_match = "yes" if wallet is not None and wallet.lower() == self.config.wallet_address.lower() else "no"
        return signer_match, wallet_match

    def _sign_leg(
        self,
        *,
        token_id: str,
        amount: Decimal,
        max_price: Decimal,
        max_spend: Decimal | None = None,
    ) -> object:
        return self._client.create_market_order(
            token_id=token_id,
            side="BUY",
            amount=amount,
            max_spend=max_spend if max_spend is not None else amount,
            max_price=max_price,
            order_type="FOK",
        )

    def submit_n_leg_leg_once(
        self,
        *,
        client_order_id: str,
        token_id: str,
        quantity_lots: int,
        max_cost_units: int,
        timeout_seconds: int = 15,
    ) -> dict[str, object]:
        """Issue #64: ONE FOK BUY attempt for one N-leg batch leg.

        Exactly one attempt is made — a timeout, exception or unrecognized
        receipt is reported as ``UNKNOWN`` and the caller must open an
        incident; this adapter never retries. Units follow the N-leg
        convention (1,000,000 units per $); the whole FOK fill is bounded by
        ``max_cost_units``, so a successful fill books that conservative
        upper bound as the cumulative cost.
        """
        if type(quantity_lots) is not int or quantity_lots <= 0:
            return {"state": "UNKNOWN", "error_code": "invalid_quantity"}
        if type(max_cost_units) is not int or max_cost_units <= 0:
            return {"state": "UNKNOWN", "error_code": "invalid_cost_bound"}
        max_price = Decimal(max_cost_units) / (
            Decimal(quantity_lots) * _NLEG_UNITS_PER_DOLLAR
        )
        amount = Decimal(quantity_lots)
        executor = ThreadPoolExecutor(max_workers=1)
        try:
            future = executor.submit(
                self._sign_leg,
                token_id=str(token_id),
                amount=amount,
                max_price=max_price,
                max_spend=Decimal(max_cost_units) / _NLEG_UNITS_PER_DOLLAR,
            )
            try:
                response = future.result(timeout=max(1, int(timeout_seconds)))
            except FuturesTimeoutError:
                future.cancel()
                return {"state": "UNKNOWN", "error_code": "timeout"}
        except Exception as exc:
            code = _safe_error_code(exc)
            del exc
            return {"state": "UNKNOWN", "error_code": code or "submit_error"}
        finally:
            executor.shutdown(wait=False, cancel_futures=True)
        return _interpret_fok_response(response)

    @staticmethod
    def _field_alias(value: object, *names: str, default: object = None) -> object:
        for name in names:
            found = _field(value, name, None)
            if found is not None:
                return found
        return default

    @staticmethod
    def _positive_decimal(value: object) -> Decimal | None:
        if not isinstance(value, Decimal) or not value.is_finite() or value <= 0:
            return None
        return value

    def _validate_intent(
        self,
        intent: PairIntent,
        *,
        account: AccountSnapshot,
        tick_size: Decimal,
        require_economics: bool = True,
    ) -> str | None:
        if not isinstance(intent, PairIntent):
            return "invalid"
        if not all(
            isinstance(value, str) and value.strip()
            for value in (
                intent.event_id,
                intent.market_id,
                intent.condition_id,
                intent.yes_token_id,
                intent.no_token_id,
            )
        ):
            return "invalid"
        decimal_fields = (
            intent.quantity,
            intent.yes_max_price,
            intent.no_max_price,
            intent.yes_max_cost,
            intent.no_max_cost,
            intent.total_max_cost,
            intent.minimum_profit,
            intent.net_edge,
        )
        if not all(isinstance(value, Decimal) and value.is_finite() for value in decimal_fields):
            return "invalid"
        if any(
            self._positive_decimal(value) is None
            for value in (
                intent.quantity,
                intent.yes_max_price,
                intent.no_max_price,
                intent.yes_max_cost,
                intent.no_max_cost,
                intent.total_max_cost,
            )
        ):
            return "invalid"
        if intent.yes_token_id == intent.no_token_id:
            return "invalid"
        if intent.yes_max_price > 1 or intent.no_max_price > 1:
            return "invalid"
        if intent.yes_max_cost % CENT or intent.no_max_cost % CENT:
            return "invalid"
        if intent.total_max_cost != intent.yes_max_cost + intent.no_max_cost:
            return "invalid"
        if intent.total_max_cost > MAX_NORMAL_COST:
            return "invalid"
        if require_economics and (
            intent.minimum_profit < MIN_ESTIMATED_PROFIT
            or intent.net_edge < MIN_NET_EDGE
        ):
            return "invalid"
        if account.p_usd_balance < 0 or account.p_usd_allowance < 0:
            return "account_insufficient"
        if account.p_usd_balance > MAX_WALLET_BALANCE:
            return "account_insufficient"
        if intent.total_max_cost > account.p_usd_balance or intent.total_max_cost > account.p_usd_allowance:
            return "account_insufficient"
        yes_expected = protected_buy_quantity(
            spend=intent.yes_max_cost,
            price=intent.yes_max_price,
            tick_size=tick_size,
        )
        no_expected = protected_buy_quantity(
            spend=intent.no_max_cost,
            price=intent.no_max_price,
            tick_size=tick_size,
        )
        if yes_expected is None or no_expected is None:
            return "order_amount_mismatch"
        if yes_expected != intent.quantity or no_expected != intent.quantity:
            return "order_amount_mismatch"
        return None

    @staticmethod
    def _signed_quantity(signed: object, expected: Decimal) -> Decimal | None:
        raw_values = [
            value
            for value in (
                _field(signed, "taker_amount"),
                _field(signed, "requested_amount"),
            )
            if value is not None
        ]
        if not raw_values:
            return None
        quantities: list[Decimal] = []
        for raw in raw_values:
            try:
                parsed = _decimal(raw)
            except ValueError:
                return None
            # The SDK serializes shares as six-decimal base units. Accept a
            # direct Decimal/int in test doubles only when it is exact.
            quantities.append(
                parsed if parsed == expected else parsed / COLLATERAL_BASE_UNITS
            )
        return quantities[0] if all(quantity == quantities[0] for quantity in quantities) else None

    @staticmethod
    def _signed_quantity_base_units(raw: object, expected: Decimal) -> Decimal | None:
        try:
            parsed = _decimal(raw)
        except ValueError:
            return None
        if parsed == expected:
            return parsed
        return parsed / COLLATERAL_BASE_UNITS

    def _signed_pair(
        self, intent: PairIntent, *, tick_size: Decimal
    ) -> tuple[object, object, str | None]:
        try:
            yes = self._sign_leg(
                token_id=intent.yes_token_id,
                amount=intent.yes_max_cost,
                max_price=intent.yes_max_price,
            )
            no = self._sign_leg(
                token_id=intent.no_token_id,
                amount=intent.no_max_cost,
                max_price=intent.no_max_price,
            )
        except Exception as exc:
            return object(), object(), _safe_error_code(exc)
        expected_tokens = (intent.yes_token_id, intent.no_token_id)
        for signed, expected_token in zip((yes, no), expected_tokens, strict=True):
            if _field(signed, "order_type") != "FOK" or _field(signed, "side") != "BUY":
                return yes, no, "order_shape_mismatch"
            if _field(signed, "token_id") not in (None, expected_token):
                return yes, no, "order_shape_mismatch"
        yes_quantity = self._signed_quantity(yes, intent.quantity)
        no_quantity = self._signed_quantity(no, intent.quantity)
        if yes_quantity != intent.quantity or no_quantity != intent.quantity:
            return yes, no, "order_amount_mismatch"
        if yes_quantity != no_quantity:
            return yes, no, "order_amount_mismatch"
        return yes, no, None

    def no_submit_preflight(
        self,
        intent: PairIntent,
        *,
        tick_size: Decimal = DEFAULT_TICK_SIZE,
        account: AccountSnapshot | None = None,
        require_economics: bool = True,
    ) -> dict[str, object]:
        self._readiness_key = None
        signer_match, wallet_match = self._identity_summary()
        summary: dict[str, object] = {
            "signer_match": signer_match,
            "wallet_match": wallet_match,
            "posted": False,
            "account_reads": "fail",
            "fok_pair_signed_not_submitted": "fail",
            "equal_requested_shares": "fail",
            "error_code": "none",
            "result": "BLOCKED",
        }
        if signer_match != "yes" or wallet_match != "yes":
            summary["error_code"] = "auth"
            return summary
        if account is None:
            try:
                account = self.account_snapshot()
            except PolymarketTradingError as exc:
                summary["error_code"] = exc.error_code
                return summary
        summary["account_reads"] = "pass"
        if not self.geoblock_allowed():
            summary["geoblock"] = "blocked"
            summary["error_code"] = "geoblock_blocked"
            return summary
        summary["geoblock"] = "allowed"
        error_code = self._validate_intent(
            intent,
            account=account,
            tick_size=tick_size,
            require_economics=require_economics,
        )
        if error_code is None:
            _, _, error_code = self._signed_pair(intent, tick_size=tick_size)
        if error_code is not None:
            summary["error_code"] = error_code
            return summary
        summary["fok_pair_signed_not_submitted"] = "pass"
        summary["equal_requested_shares"] = "pass"
        summary["result"] = "PASS"
        self._readiness_key = (intent, tick_size)
        return summary

    def _probe_candidates(
        self,
        *,
        price: Decimal,
        size: Decimal,
        minimum: Decimal,
        tick_size: Decimal,
    ) -> dict[Decimal, Decimal]:
        candidates: dict[Decimal, Decimal] = {}
        for cents in range(1, int(MAX_NORMAL_COST / CENT) + 1):
            spend = CENT * cents
            quantity = protected_buy_quantity(
                spend=spend, price=price, tick_size=tick_size
            )
            if quantity is None or quantity < minimum or quantity > size:
                continue
            candidates.setdefault(quantity, spend)
        return candidates

    def _discover_probe(self) -> tuple[PairIntent, Decimal]:
        try:
            public = self._public_client_factory()
            page = public.list_markets(
                closed=False,
                order="volume24hr",
                ascending=False,
                page_size=100,
            )
            markets = _collect(_field(page.first_page(), "items"))
            eligible: list[tuple[Decimal, str, object]] = []
            for market in markets:
                state = _field(market, "state")
                trading = _field(market, "trading")
                outcomes = _field(market, "outcomes")
                metrics = _field(market, "metrics")
                if not (
                    _field(state, "active") is True
                    and _field(state, "closed") is False
                    and _field(state, "archived") is False
                    and _field(state, "accepting_orders") is True
                    and _field(state, "enable_order_book") is True
                    and _field(state, "neg_risk") is False
                    and _field(trading, "fees_enabled") is False
                ):
                    continue
                volume = self._field_alias(metrics, "volume_24hr", "volume24hr")
                market_id = self._field_alias(market, "id", default="")
                try:
                    volume_decimal = _decimal(volume)
                except ValueError:
                    continue
                if volume_decimal < 0 or not isinstance(market_id, str):
                    continue
                eligible.append((volume_decimal, market_id, market))
            if not eligible:
                raise PolymarketTradingError("market_probe_unavailable")
            for _, market_id, market in sorted(eligible, reverse=True):
                outcomes = _field(market, "outcomes")
                yes = _field(outcomes, "yes")
                no = _field(outcomes, "no")
                yes_token = self._field_alias(yes, "token_id", "tokenId")
                no_token = self._field_alias(no, "token_id", "tokenId")
                condition_id = self._field_alias(
                    market, "condition_id", "conditionId", default=""
                )
                trading = _field(market, "trading")
                tick_value = self._field_alias(
                    trading, "minimum_tick_size", "minimumTickSize"
                )
                minimum_value = self._field_alias(
                    trading, "minimum_order_size", "minimumOrderSize"
                )
                if not (
                    isinstance(yes_token, str)
                    and isinstance(no_token, str)
                    and isinstance(condition_id, str)
                ):
                    continue
                yes_book = public.get_order_book(token_id=yes_token)
                no_book = public.get_order_book(token_id=no_token)
                yes_asks = _collect(_field(yes_book, "asks"))
                no_asks = _collect(_field(no_book, "asks"))
                if not yes_asks or not no_asks:
                    continue
                try:
                    yes_level = min(
                        yes_asks, key=lambda level: _decimal(_field(level, "price"))
                    )
                    no_level = min(
                        no_asks, key=lambda level: _decimal(_field(level, "price"))
                    )
                    yes_price = _decimal(_field(yes_level, "price"))
                    no_price = _decimal(_field(no_level, "price"))
                    yes_size = _decimal(_field(yes_level, "size"))
                    no_size = _decimal(_field(no_level, "size"))
                except ValueError:
                    continue
                if not isinstance(tick_value, Decimal):
                    tick_value = _field(yes_book, "tick_size")
                if not isinstance(minimum_value, Decimal):
                    minimum_value = _field(yes_book, "min_order_size")
                if not isinstance(tick_value, Decimal) or not isinstance(
                    minimum_value, Decimal
                ):
                    continue
                yes_candidates = self._probe_candidates(
                    price=yes_price,
                    size=yes_size,
                    minimum=minimum_value,
                    tick_size=tick_value,
                )
                no_candidates = self._probe_candidates(
                    price=no_price,
                    size=no_size,
                    minimum=minimum_value,
                    tick_size=tick_value,
                )
                common = sorted(
                    quantity
                    for quantity in set(yes_candidates) & set(no_candidates)
                    if yes_candidates[quantity] + no_candidates[quantity]
                    <= MAX_NORMAL_COST
                )
                if not common:
                    continue
                quantity = common[0]
                yes_cost = yes_candidates[quantity]
                no_cost = no_candidates[quantity]
                return (
                    PairIntent(
                        event_id=market_id,
                        market_id=market_id,
                        condition_id=condition_id,
                        yes_token_id=yes_token,
                        no_token_id=no_token,
                        quantity=quantity,
                        yes_max_price=yes_price,
                        no_max_price=no_price,
                        yes_max_cost=yes_cost,
                        no_max_cost=no_cost,
                        total_max_cost=yes_cost + no_cost,
                        minimum_profit=quantity - yes_cost - no_cost,
                        net_edge=(quantity - yes_cost - no_cost) / quantity,
                    ),
                    tick_value,
                )
            raise PolymarketTradingError("market_probe_unavailable")
        except PolymarketTradingError:
            raise
        except Exception as exc:
            code = _safe_error_code(exc)
            if code in {"network", "timeout", "unavailable"}:
                raise PolymarketTradingError(code) from None
            raise PolymarketTradingError("market_probe_unavailable") from None

    def preflight_report(self) -> dict[str, object]:
        report: dict[str, object] = {
            "sdk_version": "unknown",
            "signer_match": "no",
            "wallet_match": "no",
            "geoblock": "blocked",
            "account_reads": "fail",
            "fok_pair_signed_not_submitted": "fail",
            "equal_requested_shares": "fail",
            "merge_capability": "unavailable",
            "relayer_readiness": "fail",
            "secret_scan": "pass",
            "posted": False,
            "error_code": "none",
            "result": "BLOCKED",
        }
        try:
            report["sdk_version"] = importlib.metadata.version("polymarket-client")
        except importlib.metadata.PackageNotFoundError:
            pass
        signer_match, wallet_match = self._identity_summary()
        report["signer_match"] = signer_match
        report["wallet_match"] = wallet_match
        if signer_match != "yes" or wallet_match != "yes":
            report["error_code"] = "auth"
            return report
        try:
            account = self.account_snapshot()
        except PolymarketTradingError as exc:
            report["error_code"] = exc.error_code
            return report
        report["account_reads"] = "pass"
        try:
            readiness = self.readiness_snapshot()
        except PolymarketTradingError as exc:
            report["error_code"] = exc.error_code
            return report
        except Exception as exc:
            report["error_code"] = _safe_error_code(exc)
            return report
        report["merge_capability"] = (
            "present_not_invoked" if readiness.get("merge_capability") is True else "unavailable"
        )
        report["relayer_readiness"] = (
            "pass" if readiness.get("ready") is True else "fail"
        )
        if report["relayer_readiness"] != "pass":
            report["error_code"] = "sdk_error"
            return report
        try:
            intent, tick_size = self._discover_probe()
        except PolymarketTradingError as exc:
            report["error_code"] = exc.error_code
            return report
        summary = self.no_submit_preflight(
            intent,
            tick_size=tick_size,
            account=account,
            require_economics=False,
        )
        report["signer_match"] = summary["signer_match"]
        report["wallet_match"] = summary["wallet_match"]
        report["geoblock"] = summary.get("geoblock", "blocked")
        report["fok_pair_signed_not_submitted"] = summary[
            "fok_pair_signed_not_submitted"
        ]
        report["equal_requested_shares"] = summary["equal_requested_shares"]
        report["posted"] = summary.get("posted", False)
        report["error_code"] = summary.get("error_code", "sdk_error")
        if (
            report["sdk_version"] == "0.2.0"
            and
            report["signer_match"] == "yes"
            and report["wallet_match"] == "yes"
            and report["geoblock"] == "allowed"
            and report["account_reads"] == "pass"
            and report["fok_pair_signed_not_submitted"] == "pass"
            and report["equal_requested_shares"] == "pass"
            and report["merge_capability"] == "present_not_invoked"
            and report["relayer_readiness"] == "pass"
            and report["secret_scan"] == "pass"
        ):
            report["result"] = "PASS"
        return report

    @staticmethod
    def _ambiguous_pair() -> PairSubmission:
        return PairSubmission(
            yes=LegResult("YES", False, "ambiguous", "", Decimal("0"), (), "ambiguous"),
            no=LegResult("NO", False, "ambiguous", "", Decimal("0"), (), "ambiguous"),
        )

    @staticmethod
    def _blocked_pair(error_code: str) -> PairSubmission:
        return PairSubmission(
            yes=LegResult("YES", False, "blocked", "", Decimal("0"), (), error_code),
            no=LegResult("NO", False, "blocked", "", Decimal("0"), (), error_code),
        )

    @staticmethod
    def _leg_result(leg: Literal["YES", "NO"], response: object) -> LegResult:
        accepted_value = _field(response, "ok", _field(response, "success", False))
        accepted = accepted_value is True
        if accepted:
            status = _safe_string(_field(response, "status", "accepted"))
            error_code = "none"
            order_id = _safe_string(_field(response, "order_id", ""))
            filled = _field(response, "taking_amount", Decimal("0"))
            trades = _field(response, "trade_ids", ())
        else:
            raw_code = _field(response, "code", "rejected")
            error_code = raw_code if isinstance(raw_code, str) and re.fullmatch(r"[a-z_]+", raw_code) else "rejected"
            status = "rejected"
            order_id = ""
            filled = Decimal("0")
            trades = ()
        try:
            filled_quantity = _decimal(filled)
        except ValueError:
            filled_quantity = Decimal("0")
        trade_ids = tuple(item for item in trades if isinstance(item, str)) if isinstance(trades, (tuple, list)) else ()
        return LegResult(leg, accepted, status, order_id, filled_quantity, trade_ids, error_code)

    def submit_pair_once(
        self, intent: PairIntent, *, tick_size: Decimal = DEFAULT_TICK_SIZE
    ) -> PairSubmission:
        self._last_submit_error = None
        if self._readiness_key != (intent, tick_size):
            return self._blocked_pair("preflight_required")
        signer_match, wallet_match = self._identity_summary()
        if signer_match != "yes" or wallet_match != "yes":
            return self._blocked_pair("auth")
        if not self.geoblock_allowed():
            return self._blocked_pair("geoblock_blocked")
        try:
            account = self.account_snapshot()
        except PolymarketTradingError as exc:
            return self._blocked_pair(exc.error_code)
        error_code = self._validate_intent(
            intent, account=account, tick_size=tick_size, require_economics=True
        )
        if error_code is not None:
            return self._blocked_pair(error_code)
        yes, no, error_code = self._signed_pair(intent, tick_size=tick_size)
        if error_code is not None:
            return self._blocked_pair(error_code)
        try:
            responses = tuple(self._client.post_orders((yes, no)))
        except Exception as exc:
            # A POST may have reached the venue; never retry or claim rejection.
            self._last_submit_error = _submit_error_detail(exc)
            return self._ambiguous_pair()
        if len(responses) != 2:
            return self._ambiguous_pair()
        return PairSubmission(
            yes=self._leg_result("YES", responses[0]),
            no=self._leg_result("NO", responses[1]),
        )

    @staticmethod
    def _ambiguous_threshold(intent: ThresholdHedgeIntent) -> ThresholdHedgeSubmission:
        return ThresholdHedgeSubmission(
            leg_a=ThresholdLegResult(
                "A",
                intent.leg_a.outcome,
                intent.leg_a.condition_id,
                intent.leg_a.token_id,
                False,
                "ambiguous",
                "",
                Decimal("0"),
                (),
                "ambiguous",
            ),
            leg_b=ThresholdLegResult(
                "B",
                intent.leg_b.outcome,
                intent.leg_b.condition_id,
                intent.leg_b.token_id,
                False,
                "ambiguous",
                "",
                Decimal("0"),
                (),
                "ambiguous",
            ),
        )

    @staticmethod
    def _blocked_threshold(
        intent: ThresholdHedgeIntent, error_code: str
    ) -> ThresholdHedgeSubmission:
        return ThresholdHedgeSubmission(
            leg_a=ThresholdLegResult(
                "A",
                intent.leg_a.outcome,
                intent.leg_a.condition_id,
                intent.leg_a.token_id,
                False,
                "blocked",
                "",
                Decimal("0"),
                (),
                error_code,
            ),
            leg_b=ThresholdLegResult(
                "B",
                intent.leg_b.outcome,
                intent.leg_b.condition_id,
                intent.leg_b.token_id,
                False,
                "blocked",
                "",
                Decimal("0"),
                (),
                error_code,
            ),
        )

    @staticmethod
    def _threshold_leg_valid(leg: ThresholdHedgeLeg) -> bool:
        if not isinstance(leg, ThresholdHedgeLeg):
            return False
        if leg.label not in {"A", "B"} or leg.outcome not in {"YES", "NO"}:
            return False
        if not all(
            isinstance(value, str) and value.strip()
            for value in (leg.condition_id, leg.market_id, leg.token_id)
        ):
            return False
        if not all(
            isinstance(value, Decimal) and value.is_finite() and value > 0
            for value in (leg.quantity, leg.max_price, leg.max_cost, leg.tick_size)
        ):
            return False
        if leg.max_price > 1 or leg.max_cost % CENT:
            return False
        return (
            protected_buy_quantity(
                spend=leg.max_cost,
                price=leg.max_price,
                tick_size=leg.tick_size,
            )
            == leg.quantity
        )

    def _validate_threshold_intent(
        self,
        intent: ThresholdHedgeIntent,
        *,
        account: AccountSnapshot,
        require_economics: bool = True,
    ) -> str | None:
        if not isinstance(intent, ThresholdHedgeIntent):
            return "invalid"
        if not all(
            isinstance(value, str) and value.strip()
            for value in (intent.relation_id, intent.event_id, intent.relation)
        ):
            return "invalid"
        if intent.relation not in {"A_IMPLIES_B", "B_IMPLIES_A"}:
            return "invalid"
        if not self._threshold_leg_valid(intent.leg_a) or not self._threshold_leg_valid(
            intent.leg_b
        ):
            return "invalid"
        if intent.leg_a.label != "A" or intent.leg_b.label != "B":
            return "invalid"
        if intent.leg_a.condition_id == intent.leg_b.condition_id:
            return "invalid"
        if intent.leg_a.token_id == intent.leg_b.token_id:
            return "invalid"
        if not isinstance(intent.quantity, Decimal) or intent.quantity <= 0:
            return "invalid"
        if intent.leg_a.quantity != intent.quantity or intent.leg_b.quantity != intent.quantity:
            return "order_amount_mismatch"
        for value in (
            intent.maximum_fee,
            intent.total_max_cost,
            intent.minimum_payout,
            intent.minimum_profit,
            intent.net_edge,
        ):
            if not isinstance(value, Decimal) or not value.is_finite():
                return "invalid"
        if intent.maximum_fee < 0 or intent.total_max_cost <= 0:
            return "invalid"
        if intent.total_max_cost != (
            intent.leg_a.max_cost + intent.leg_b.max_cost + intent.maximum_fee
        ):
            return "invalid"
        if intent.minimum_payout != intent.quantity:
            return "invalid"
        if intent.minimum_profit != intent.minimum_payout - intent.total_max_cost:
            return "invalid"
        if intent.total_max_cost > MAX_NORMAL_COST:
            return "invalid"
        if require_economics and (intent.minimum_profit <= 0 or intent.net_edge <= 0):
            return "invalid"
        if account.p_usd_balance < 0 or account.p_usd_allowance < 0:
            return "account_insufficient"
        if account.p_usd_balance > MAX_WALLET_BALANCE:
            return "account_insufficient"
        if intent.total_max_cost > account.p_usd_balance or intent.total_max_cost > account.p_usd_allowance:
            return "account_insufficient"
        return None

    def _signed_threshold_pair(
        self, intent: ThresholdHedgeIntent
    ) -> tuple[object, object, str | None]:
        try:
            # The venue fee is budgeted in intent.maximum_fee. If max_spend only
            # covered leg.max_cost, the SDK would shrink the buy to fit the fee
            # inside it and sign fewer shares than intent.quantity. One cent is
            # added because the SDK shrinks on <=; it only widens the SDK's
            # internal prep cap (not the signed order) and keeps the boundary
            # valid when one leg consumes the entire fee budget.
            signed_a = self._sign_leg(
                token_id=intent.leg_a.token_id,
                amount=intent.leg_a.max_cost,
                max_price=intent.leg_a.max_price,
                max_spend=intent.leg_a.max_cost + intent.maximum_fee + CENT,
            )
            signed_b = self._sign_leg(
                token_id=intent.leg_b.token_id,
                amount=intent.leg_b.max_cost,
                max_price=intent.leg_b.max_price,
                max_spend=intent.leg_b.max_cost + intent.maximum_fee + CENT,
            )
        except Exception as exc:
            return object(), object(), _safe_error_code(exc)
        for signed, leg in ((signed_a, intent.leg_a), (signed_b, intent.leg_b)):
            if _field(signed, "order_type") != "FOK" or _field(signed, "side") != "BUY":
                return signed_a, signed_b, "order_shape_mismatch"
            if _field(signed, "token_id") not in (None, leg.token_id):
                return signed_a, signed_b, "order_shape_mismatch"
            if self._signed_quantity(signed, leg.quantity) != leg.quantity:
                return signed_a, signed_b, "order_amount_mismatch"
        return signed_a, signed_b, None

    @staticmethod
    def _threshold_leg_result(
        leg: ThresholdHedgeLeg, response: object
    ) -> ThresholdLegResult:
        accepted_value = _field(response, "ok", _field(response, "success", False))
        accepted = accepted_value is True
        if accepted:
            status = _safe_string(_field(response, "status", "accepted"))
            error_code = "none"
            order_id = _safe_string(_field(response, "order_id", ""))
            filled = _field(response, "taking_amount", Decimal("0"))
            trades = _field(response, "trade_ids", ())
        else:
            raw_code = _field(response, "code", "rejected")
            error_code = (
                raw_code
                if isinstance(raw_code, str) and re.fullmatch(r"[a-z_]+", raw_code)
                else "rejected"
            )
            status = "rejected"
            order_id = ""
            filled = Decimal("0")
            trades = ()
        try:
            filled_quantity = _decimal(filled)
        except ValueError:
            filled_quantity = Decimal("0")
        trade_ids = (
            tuple(item for item in trades if isinstance(item, str))
            if isinstance(trades, (tuple, list))
            else ()
        )
        return ThresholdLegResult(
            leg.label,
            leg.outcome,
            leg.condition_id,
            leg.token_id,
            accepted,
            status,
            order_id,
            filled_quantity,
            trade_ids,
            error_code,
        )

    def no_submit_threshold_preflight(
        self,
        intent: ThresholdHedgeIntent,
        *,
        account: AccountSnapshot | None = None,
        require_economics: bool = True,
    ) -> dict[str, object]:
        self._readiness_key = None
        self._threshold_readiness_key = None
        signer_match, wallet_match = self._identity_summary()
        summary: dict[str, object] = {
            "signer_match": signer_match,
            "wallet_match": wallet_match,
            "posted": False,
            "account_reads": "fail",
            "fok_pair_signed_not_submitted": "fail",
            "equal_requested_shares": "fail",
            "conditions": [intent.leg_a.condition_id, intent.leg_b.condition_id]
            if isinstance(intent, ThresholdHedgeIntent)
            else [],
            "merge": "not_required",
            "error_code": "none",
            "result": "BLOCKED",
        }
        if signer_match != "yes" or wallet_match != "yes":
            summary["error_code"] = "auth"
            return summary
        if account is None:
            try:
                account = self.account_snapshot()
            except PolymarketTradingError as exc:
                summary["error_code"] = exc.error_code
                return summary
        summary["account_reads"] = "pass"
        if not self.geoblock_allowed():
            summary["geoblock"] = "blocked"
            summary["error_code"] = "geoblock_blocked"
            return summary
        summary["geoblock"] = "allowed"
        error_code = self._validate_threshold_intent(
            intent, account=account, require_economics=require_economics
        )
        if error_code is None:
            _, _, error_code = self._signed_threshold_pair(intent)
        if error_code is not None:
            summary["error_code"] = error_code
            return summary
        summary["fok_pair_signed_not_submitted"] = "pass"
        summary["equal_requested_shares"] = "pass"
        summary["result"] = "PASS"
        self._threshold_readiness_key = intent
        return summary

    def submit_threshold_hedge_once(
        self, intent: ThresholdHedgeIntent
    ) -> ThresholdHedgeSubmission:
        self._last_submit_error = None
        if self._threshold_readiness_key != intent:
            return self._blocked_threshold(intent, "preflight_required")
        signer_match, wallet_match = self._identity_summary()
        if signer_match != "yes" or wallet_match != "yes":
            return self._blocked_threshold(intent, "auth")
        if not self.geoblock_allowed():
            return self._blocked_threshold(intent, "geoblock_blocked")
        try:
            account = self.account_snapshot()
        except PolymarketTradingError as exc:
            return self._blocked_threshold(intent, exc.error_code)
        error_code = self._validate_threshold_intent(
            intent, account=account, require_economics=True
        )
        if error_code is not None:
            return self._blocked_threshold(intent, error_code)
        signed_a, signed_b, error_code = self._signed_threshold_pair(intent)
        if error_code is not None:
            return self._blocked_threshold(intent, error_code)
        try:
            responses = tuple(self._client.post_orders((signed_a, signed_b)))
        except Exception as exc:
            self._last_submit_error = _submit_error_detail(exc)
            return self._ambiguous_threshold(intent)
        if len(responses) != 2:
            return self._ambiguous_threshold(intent)
        return ThresholdHedgeSubmission(
            leg_a=self._threshold_leg_result(intent.leg_a, responses[0]),
            leg_b=self._threshold_leg_result(intent.leg_b, responses[1]),
        )

    @staticmethod
    def _cross_leg_fields(
        leg: object,
    ) -> tuple[str, str, str, Decimal, Decimal] | None:
        exchange = _field(leg, "exchange")
        condition_id = _field(leg, "condition_id")
        token_id = _field(leg, "token_id")
        outcome = _field(leg, "outcome")
        quantity = _field(leg, "net_quantity")
        max_price = _field(leg, "max_price")
        max_cost = _field(leg, "max_cost")
        if (
            exchange != "polymarket"
            or not isinstance(condition_id, str)
            or not condition_id
            or not isinstance(token_id, str)
            or not token_id
            or outcome not in {"YES", "NO"}
            or not isinstance(quantity, Decimal)
            or not isinstance(max_price, Decimal)
            or not isinstance(max_cost, Decimal)
            or quantity <= 0
            or max_price <= 0
            or max_price > 1
            or max_cost <= 0
        ):
            return None
        return condition_id, token_id, outcome, quantity, max_price

    @staticmethod
    def _blocked_cross_leg(leg: object, error_code: str) -> ThresholdLegResult:
        fields = PolymarketTradingClient._cross_leg_fields(leg)
        if fields is None:
            return ThresholdLegResult(
                "polymarket", "YES", "", "", False, "blocked", "", Decimal("0"), (), "invalid"
            )
        condition_id, token_id, outcome, _quantity, _max_price = fields
        return ThresholdLegResult(
            "polymarket", outcome, condition_id, token_id, False, "blocked", "", Decimal("0"), (), error_code
        )

    def no_submit_cross_leg_preflight(
        self, leg: object, *, account: AccountSnapshot | None = None
    ) -> dict[str, object]:
        self._cross_leg_readiness_key = None
        summary: dict[str, object] = {
            "posted": False,
            "account_reads": "fail",
            "fok_leg_signed_not_submitted": "fail",
            "error_code": "none",
            "result": "BLOCKED",
        }
        fields = self._cross_leg_fields(leg)
        signer_match, wallet_match = self._identity_summary()
        if fields is None:
            summary["error_code"] = "invalid"
            return summary
        if signer_match != "yes" or wallet_match != "yes":
            summary["error_code"] = "auth"
            return summary
        if account is None:
            try:
                account = self.account_snapshot()
            except PolymarketTradingError as exc:
                summary["error_code"] = exc.error_code
                return summary
        summary["account_reads"] = "pass"
        if not self.geoblock_allowed():
            summary["error_code"] = "geoblock_blocked"
            return summary
        condition_id, token_id, _outcome, quantity, max_price = fields
        max_cost = _field(leg, "max_cost")
        if (
            not isinstance(max_cost, Decimal)
            or max_cost > account.p_usd_balance
            or max_cost > account.p_usd_allowance
        ):
            summary["error_code"] = "account_insufficient"
            return summary
        try:
            signed = self._sign_leg(
                token_id=token_id, amount=max_cost, max_price=max_price
            )
        except Exception as exc:
            summary["error_code"] = _safe_error_code(exc)
            return summary
        if (
            _field(signed, "order_type") != "FOK"
            or _field(signed, "side") != "BUY"
            or _field(signed, "token_id") not in (None, token_id)
            or self._signed_quantity(signed, quantity) != quantity
        ):
            summary["error_code"] = "order_shape_mismatch"
            return summary
        del condition_id
        summary["fok_leg_signed_not_submitted"] = "pass"
        summary["result"] = "PASS"
        self._cross_leg_readiness_key = leg
        return summary

    def submit_cross_leg_once(self, leg: object) -> ThresholdLegResult:
        if self._cross_leg_readiness_key != leg:
            return self._blocked_cross_leg(leg, "preflight_required")
        fields = self._cross_leg_fields(leg)
        if fields is None:
            return self._blocked_cross_leg(leg, "invalid")
        _condition_id, token_id, _outcome, quantity, max_price = fields
        max_cost = _field(leg, "max_cost")
        if not isinstance(max_cost, Decimal):
            return self._blocked_cross_leg(leg, "invalid")
        try:
            signed = self._sign_leg(
                token_id=token_id, amount=max_cost, max_price=max_price
            )
            if (
                _field(signed, "order_type") != "FOK"
                or _field(signed, "side") != "BUY"
                or self._signed_quantity(signed, quantity) != quantity
            ):
                return self._blocked_cross_leg(leg, "order_shape_mismatch")
            responses = tuple(self._client.post_orders((signed,)))
        except Exception:
            return ThresholdLegResult(
                "polymarket", _outcome, _condition_id, token_id, False, "ambiguous", "", Decimal("0"), (), "ambiguous"
            )
        if len(responses) != 1:
            return ThresholdLegResult(
                "polymarket", _outcome, _condition_id, token_id, False, "ambiguous", "", Decimal("0"), (), "ambiguous"
            )
        return self._threshold_leg_result(
            ThresholdHedgeLeg(
                "polymarket",
                _condition_id,
                str(_field(leg, "market_id", _condition_id)),
                _outcome,
                token_id,
                quantity,
                max_price,
                max_cost,
                DEFAULT_TICK_SIZE,
            ),
            responses[0],
        )

    def reconcile_cross_leg(
        self, leg: object, result: ThresholdLegResult, *, since: datetime
    ) -> dict[str, object]:
        fields = self._cross_leg_fields(leg)
        if fields is None or not isinstance(result, ThresholdLegResult):
            return {"status": "unknown", "verified": False, "conclusively_absent": False}
        condition_id, token_id, outcome, quantity, max_price = fields
        max_cost = _field(leg, "max_cost")
        if not isinstance(max_cost, Decimal):
            return {"status": "unknown", "verified": False, "conclusively_absent": False}
        try:
            minimum_order_size = _decimal(_field(leg, "minimum_order_size"))
        except ValueError:
            minimum_order_size = None
        actual, proof = self._reconcile_threshold_leg(result, since=since)
        position = proof.get("position_ref")
        position_quantity = (
            _decimal(position.get("quantity"))
            if isinstance(position, Mapping)
            else Decimal("0")
        ) or Decimal("0")
        if proof.get("positions_verified") is True and actual > 0:
            reconciled: dict[str, object] = {
                "status": "verified",
                "verified": True,
                "conclusively_absent": False,
                "filled_quantity": actual,
                "position_quantity": position_quantity,
                "execution_proof": {"verified": True, "venue": "polymarket", **proof},
            }
            actual_fee = proof.get("fee")
            if isinstance(actual_fee, Decimal) and actual_fee >= 0:
                reconciled["actual_fee"] = actual_fee
            if minimum_order_size is not None and minimum_order_size > 0:
                reconciled["minimum_order_size"] = minimum_order_size
            return reconciled
        if not result.accepted and result.status != "ambiguous":
            try:
                positions = _collect(self._client.list_positions(market=[condition_id]))
                for item in positions:
                    if _field(item, "token_id", _field(item, "tokenId", "")) != token_id:
                        continue
                    amount = _decimal(
                        _field(item, "size", _field(item, "quantity", _field(item, "shares")))
                    )
                    if amount is not None and amount > 0:
                        return {"status": "unknown", "verified": False, "conclusively_absent": False}
            except Exception:
                return {"status": "unknown", "verified": False, "conclusively_absent": False}
            return {
                "status": "absent",
                "verified": False,
                "conclusively_absent": True,
                "filled_quantity": Decimal("0"),
                "position_quantity": Decimal("0"),
            }
        return {
            "status": "unknown",
            "verified": False,
            "conclusively_absent": False,
            "filled_quantity": actual,
            "position_quantity": position_quantity,
            "execution_proof": {"verified": False, "venue": "polymarket", **proof},
        }

    def reconcile(
        self,
        *,
        condition_id: str,
        since: datetime,
        yes_token_id: str | None = None,
        no_token_id: str | None = None,
        yes_order_id: str | None = None,
        no_order_id: str | None = None,
        yes_trade_ids: Sequence[str] = (),
        no_trade_ids: Sequence[str] = (),
        yes_order_ids: Sequence[str] | None = None,
        no_order_ids: Sequence[str] | None = None,
    ) -> dict[str, object]:
        """Prove one execution's fills from fresh, reference-matched trades."""

        empty_refs: dict[str, object] = {
            "token_id": "",
            "order_ids": [],
            "trade_ids": [],
        }
        proof: dict[str, object] = {
            "verified": False,
            "adapter_verified": True,
            "venue": "polymarket",
            "positions_verified": False,
            "matched_refs": {"YES": dict(empty_refs), "NO": dict(empty_refs)},
            "position_refs": {},
        }
        try:
            yes_orders = _string_refs(yes_order_ids) | _string_refs(yes_order_id)
            no_orders = _string_refs(no_order_ids) | _string_refs(no_order_id)
            yes_trades = _string_refs(yes_trade_ids)
            no_trades = _string_refs(no_trade_ids)
            if not (yes_orders or yes_trades) or not (no_orders or no_trades):
                return {
                    "status": "blocked",
                    "error_code": "reconciliation_unverified",
                    "execution_proof": proof,
                }
            if not isinstance(since, datetime):
                return {
                    "status": "blocked",
                    "error_code": "reconciliation_unverified",
                    "execution_proof": proof,
                }
            since_utc = since.astimezone(UTC) if since.tzinfo else since.replace(tzinfo=UTC)
            trades = _collect(
                self._client.list_account_trades(
                    market=condition_id, after=since_utc.isoformat()
                )
            )
            quantities = {"YES": Decimal("0"), "NO": Decimal("0")}
            matched: dict[str, dict[str, object]] = {
                "YES": {"token_id": str(yes_token_id or ""), "order_ids": [], "trade_ids": []},
                "NO": {"token_id": str(no_token_id or ""), "order_ids": [], "trade_ids": []},
            }
            seen: set[tuple[str, str]] = set()
            accepted_statuses = {"CONFIRMED"}
            for trade in trades:
                matched_at = _trade_timestamp(trade)
                if matched_at is None or matched_at < since_utc:
                    continue
                trade_condition = _field(
                    trade, "condition_id", _field(trade, "market", "")
                )
                if trade_condition not in (None, "", condition_id):
                    continue
                status = _safe_string(_field(trade, "status", "")).upper()
                if status not in accepted_statuses:
                    continue
                if _safe_string(_field(trade, "side", "")).upper() != "BUY":
                    continue
                raw_trade_id = _field(trade, "id", _field(trade, "trade_id", ""))
                raw_order_id = _field(
                    trade,
                    "taker_order_id",
                    _field(trade, "order_id", _field(trade, "orderId", "")),
                )
                raw_token_id = _field(
                    trade,
                    "token_id",
                    _field(trade, "tokenId", _field(trade, "asset_id", "")),
                )
                trade_id = raw_trade_id.strip() if isinstance(raw_trade_id, str) else ""
                order_id = raw_order_id.strip() if isinstance(raw_order_id, str) else ""
                token_id = raw_token_id.strip() if isinstance(raw_token_id, str) else ""
                if not trade_id and not order_id:
                    continue
                quantity = None
                for name in ("size", "quantity", "shares", "taking_amount"):
                    quantity = _decimal(_field(trade, name))
                    if quantity is not None:
                        break
                if quantity is None or quantity <= 0:
                    continue
                for leg, token, order_refs, trade_refs in (
                    ("YES", yes_token_id, yes_orders, yes_trades),
                    ("NO", no_token_id, no_orders, no_trades),
                ):
                    if token and token_id and token_id != token:
                        continue
                    if not ((order_id and order_id in order_refs) or (trade_id and trade_id in trade_refs)):
                        continue
                    identity = (leg, trade_id or f"{order_id}:{matched_at.isoformat()}")
                    if identity in seen:
                        continue
                    seen.add(identity)
                    quantities[leg] += quantity
                    if order_id and order_id not in matched[leg]["order_ids"]:
                        matched[leg]["order_ids"].append(order_id)
                    if trade_id and trade_id not in matched[leg]["trade_ids"]:
                        matched[leg]["trade_ids"].append(trade_id)
                    break
            if not (
                quantities["YES"] > 0 or quantities["NO"] > 0
            ):
                proof["matched_refs"] = matched
                return {
                    "status": "blocked",
                    "error_code": "reconciliation_unverified",
                    "execution_proof": proof,
                }
            for leg in ("YES", "NO"):
                if quantities[leg] > 0 and not (
                    matched[leg]["trade_ids"] or matched[leg]["order_ids"]
                ):
                    proof["matched_refs"] = matched
                    return {
                        "status": "blocked",
                        "error_code": "reconciliation_unverified",
                        "execution_proof": proof,
                    }
            positions = _collect(self._client.list_positions(market=[condition_id]))
            position_quantities = {"YES": Decimal("0"), "NO": Decimal("0")}
            position_refs: dict[str, dict[str, str]] = {}
            for position in positions:
                position_condition = _field(
                    position, "condition_id", _field(position, "market", "")
                )
                if position_condition not in (None, "", condition_id):
                    continue
                token_id = _field(
                    position,
                    "token_id",
                    _field(position, "tokenId", _field(position, "asset_id", "")),
                )
                if not isinstance(token_id, str) or token_id not in (
                    yes_token_id,
                    no_token_id,
                ):
                    continue
                position_timestamp = _trade_timestamp(position)
                if position_timestamp is not None and position_timestamp < since_utc:
                    continue
                size = None
                for name in ("size", "quantity", "shares"):
                    size = _decimal(_field(position, name))
                    if size is not None:
                        break
                if size is None or size <= 0:
                    continue
                leg = "YES" if token_id == yes_token_id else "NO"
                position_quantities[leg] += size
                position_refs[leg] = {
                    "token_id": token_id,
                    "quantity": format(position_quantities[leg], "f"),
                }
            positions_verified = all(
                quantities[leg] <= 0 or position_quantities[leg] >= quantities[leg]
                for leg in ("YES", "NO")
            )
            proof["matched_refs"] = matched
            proof["position_refs"] = position_refs
            proof["positions_verified"] = positions_verified
            if not positions_verified:
                return {
                    "status": "blocked",
                    "error_code": "reconciliation_unverified",
                    "execution_proof": proof,
                }
            if quantities["YES"] <= 0 or quantities["NO"] <= 0:
                proof["partial_verified"] = True
                return {
                    "status": "partial",
                    "yes_quantity": quantities["YES"],
                    "no_quantity": quantities["NO"],
                    "execution_proof": proof,
                }
            proof["verified"] = True
            return {
                "status": "ok",
                "yes_quantity": quantities["YES"],
                "no_quantity": quantities["NO"],
                "execution_proof": proof,
            }
        except Exception as exc:
            code = _safe_error_code(exc)
            del exc
            return {
                "status": "blocked",
                "error_code": code,
                "execution_proof": proof,
            }

    def _reconcile_threshold_leg(
        self, leg: ThresholdLegResult, *, since: datetime
    ) -> tuple[Decimal, dict[str, object]]:
        empty: dict[str, object] = {
            "token_id": leg.token_id,
            "order_ids": [],
            "trade_ids": [],
        }
        refs = _string_refs(leg.order_id) | _string_refs(leg.trade_ids)
        matched: dict[str, object] = {
            "token_id": leg.token_id,
            "order_ids": [],
            "trade_ids": [],
        }
        if not refs or not isinstance(since, datetime):
            return Decimal("0"), {
                "matched_refs": matched,
                "position_ref": None,
                "positions_verified": False,
            }
        since_utc = since.astimezone(UTC) if since.tzinfo else since.replace(tzinfo=UTC)
        quantity = Decimal("0")
        actual_fee = Decimal("0")
        fees_verified = True
        seen: set[tuple[str, str]] = set()
        try:
            trades = _collect(
                self._client.list_account_trades(
                    market=leg.condition_id, after=since_utc.isoformat()
                )
            )
            for trade in trades:
                matched_at = _trade_timestamp(trade)
                if matched_at is None or matched_at < since_utc:
                    continue
                condition = _field(trade, "condition_id", _field(trade, "market", ""))
                if condition not in (None, "", leg.condition_id):
                    continue
                status = _safe_string(_field(trade, "status", "")).upper()
                if status not in {"CONFIRMED", "MATCHED", "FILLED"}:
                    continue
                if _safe_string(_field(trade, "side", "")).upper() != "BUY":
                    continue
                token = _field(
                    trade,
                    "token_id",
                    _field(trade, "tokenId", _field(trade, "asset_id", "")),
                )
                if token not in (None, "", leg.token_id):
                    continue
                trade_id = _field(trade, "id", _field(trade, "trade_id", ""))
                order_id = _field(
                    trade,
                    "taker_order_id",
                    _field(trade, "order_id", _field(trade, "orderId", "")),
                )
                trade_ref = trade_id.strip() if isinstance(trade_id, str) else ""
                order_ref = order_id.strip() if isinstance(order_id, str) else ""
                if not ((trade_ref and trade_ref in refs) or (order_ref and order_ref in refs)):
                    continue
                identity = (trade_ref, order_ref)
                if identity in seen:
                    continue
                seen.add(identity)
                raw_quantity: Decimal | None = None
                for name in ("size", "quantity", "shares", "taking_amount"):
                    try:
                        raw_quantity = _decimal(_field(trade, name))
                    except ValueError:
                        raw_quantity = None
                    if raw_quantity is not None:
                        break
                if raw_quantity is None or raw_quantity <= 0:
                    continue
                quantity += raw_quantity
                if _safe_string(_field(trade, "trader_side", "")).upper() != "TAKER":
                    fees_verified = False
                else:
                    try:
                        price = _decimal(_field(trade, "price"))
                        fee_rate_bps = _decimal(
                            _field(trade, "fee_rate_bps", _field(trade, "feeRateBps"))
                        )
                    except ValueError:
                        fees_verified = False
                    else:
                        if not (Decimal("0") < price <= Decimal("1")) or fee_rate_bps < 0:
                            fees_verified = False
                        else:
                            actual_fee += (
                                raw_quantity
                                * fee_rate_bps
                                / Decimal("10000")
                                * price
                                * (Decimal("1") - price)
                            )
                if order_ref and order_ref not in matched["order_ids"]:
                    matched["order_ids"].append(order_ref)  # type: ignore[union-attr]
                if trade_ref and trade_ref not in matched["trade_ids"]:
                    matched["trade_ids"].append(trade_ref)  # type: ignore[union-attr]

            position_quantity = Decimal("0")
            position_ref: dict[str, str] | None = None
            positions = _collect(self._client.list_positions(market=[leg.condition_id]))
            for position in positions:
                condition = _field(
                    position, "condition_id", _field(position, "market", "")
                )
                if condition not in (None, "", leg.condition_id):
                    continue
                token = _field(
                    position,
                    "token_id",
                    _field(position, "tokenId", _field(position, "asset_id", "")),
                )
                if token != leg.token_id:
                    continue
                position_at = _trade_timestamp(position)
                if position_at is not None and position_at < since_utc:
                    continue
                size: Decimal | None = None
                for name in ("size", "quantity", "shares"):
                    try:
                        size = _decimal(_field(position, name))
                    except ValueError:
                        size = None
                    if size is not None:
                        break
                if size is None or size <= 0:
                    continue
                position_quantity += size
                position_ref = {
                    "token_id": leg.token_id,
                    "quantity": format(position_quantity, "f"),
                }
            proof = {
                "matched_refs": matched,
                "position_ref": position_ref,
                "positions_verified": quantity > 0
                and position_quantity >= quantity,
            }
            if quantity > 0 and fees_verified:
                proof["fee"] = actual_fee
            return quantity, proof
        except Exception:
            return Decimal("0"), {
                "matched_refs": matched,
                "position_ref": None,
                "positions_verified": False,
            }

    def reconcile_threshold_hedge(
        self,
        *,
        intent: ThresholdHedgeIntent,
        since: datetime,
        leg_a: ThresholdLegResult,
        leg_b: ThresholdLegResult,
    ) -> dict[str, object]:
        """Reconcile each threshold leg against its own condition and token."""

        if not isinstance(intent, ThresholdHedgeIntent):
            return {"status": "blocked", "error_code": "invalid"}
        quantity_a, proof_a = self._reconcile_threshold_leg(leg_a, since=since)
        quantity_b, proof_b = self._reconcile_threshold_leg(leg_b, since=since)
        proof: dict[str, object] = {
            "venue": "polymarket",
            "adapter_verified": True,
            "positions_verified": proof_a["positions_verified"] is True
            and proof_b["positions_verified"] is True,
            "matched_refs": {
                "A": proof_a["matched_refs"],
                "B": proof_b["matched_refs"],
            },
            "position_refs": {
                "A": proof_a["position_ref"],
                "B": proof_b["position_ref"],
            },
            "condition_ids": {
                "A": intent.leg_a.condition_id,
                "B": intent.leg_b.condition_id,
            },
            "token_ids": {
                "A": intent.leg_a.token_id,
                "B": intent.leg_b.token_id,
            },
        }
        if quantity_a > 0 and quantity_b > 0:
            proof["verified"] = proof["positions_verified"] is True
            return {
                "status": "ok" if proof["verified"] else "blocked",
                "leg_a_quantity": quantity_a,
                "leg_b_quantity": quantity_b,
                "execution_proof": proof,
            }
        if quantity_a > 0 or quantity_b > 0:
            proof["partial_verified"] = proof["positions_verified"] is True
            return {
                "status": "partial" if proof["partial_verified"] else "blocked",
                "leg_a_quantity": quantity_a,
                "leg_b_quantity": quantity_b,
                "execution_proof": proof,
            }
        return {
            "status": "blocked",
            "error_code": "reconciliation_unverified",
            "leg_a_quantity": Decimal("0"),
            "leg_b_quantity": Decimal("0"),
            "execution_proof": proof,
        }

    def cancel_orders(self, order_ids: tuple[str, ...]) -> tuple[str, ...]:
        try:
            response = self._client.cancel_orders(order_ids=order_ids)
            canceled = _field(response, "canceled", ())
            return tuple(item for item in canceled if isinstance(item, str))
        except Exception as exc:
            code = _safe_error_code(exc)
            del exc
            raise PolymarketTradingError(code) from None

    def cancel_orders_detailed(self, order_ids: tuple[str, ...]) -> dict[str, object]:
        try:
            response = self._client.cancel_orders(order_ids=order_ids)
            canceled = _field(response, "canceled", ())
            not_canceled = _field(response, "not_canceled", {})
            return {
                "canceled": tuple(
                    item for item in canceled if isinstance(item, str)
                ),
                "not_canceled": (
                    dict(not_canceled) if isinstance(not_canceled, Mapping) else {}
                ),
            }
        except Exception as exc:
            code = _safe_error_code(exc)
            del exc
            raise PolymarketTradingError(code) from None

    def remediation_options(
        self,
        *,
        condition_id: str,
        yes_token_id: str,
        no_token_id: str,
        filled_leg: str,
        filled_quantity: Decimal,
        since: datetime,
    ) -> dict[str, object]:
        """Return fresh, bounded completion and unwind choices without posting."""

        del condition_id, since
        if (
            filled_leg not in {"YES", "NO"}
            or not isinstance(filled_quantity, Decimal)
            or not filled_quantity.is_finite()
            or filled_quantity <= 0
        ):
            return {"fresh": False}
        try:
            account = self.account_snapshot()
            if account.open_order_ids:
                return {"fresh": False}
            checked_at = _venue_timestamp(account.checked_at)
            if checked_at is None:
                return {"fresh": False}
            account_now = datetime.now(UTC)
            account_age = (account_now - checked_at).total_seconds()
            if account_age < 0 or account_age > REMEDIATION_BOOK_FRESHNESS_SECONDS:
                return {"fresh": False}
            positions = account.positions
            filled_token = yes_token_id if filled_leg == "YES" else no_token_id
            position_quantity = Decimal("0")
            for position in positions:
                token = position.get("token_id", position.get("tokenId", position.get("asset_id", "")))
                if token != filled_token:
                    continue
                size = _decimal(position.get("size", position.get("quantity", position.get("shares"))))
                if size is not None and size > 0:
                    position_quantity += size
            if position_quantity < filled_quantity:
                return {"fresh": False}
            public = self._public_client_factory()
            token_by_leg = {"YES": yes_token_id, "NO": no_token_id}
            books = {
                leg: public.get_order_book(token_id=token)
                for leg, token in token_by_leg.items()
            }
            now = datetime.now(UTC)
            book_timestamps: dict[str, datetime] = {}
            for leg, book in books.items():
                timestamp = _venue_timestamp(_field(book, "timestamp"))
                if timestamp is None:
                    return {"fresh": False}
                age = (now - timestamp).total_seconds()
                if age < 0 or age > REMEDIATION_BOOK_FRESHNESS_SECONDS:
                    return {"fresh": False}
                book_timestamps[leg] = timestamp

            def best(book: object, side: str) -> tuple[Decimal, Decimal, Decimal] | None:
                rows = _collect(_field(book, side, ()))
                levels: list[tuple[Decimal, Decimal]] = []
                for row in rows:
                    price = _decimal(_field(row, "price"))
                    size = _decimal(_field(row, "size"))
                    if price is None or size is None or price <= 0 or size < filled_quantity or price > 1:
                        continue
                    levels.append((price, size))
                if not levels:
                    return None
                price, size = (
                    min(levels, key=lambda item: item[0])
                    if side == "asks"
                    else max(levels, key=lambda item: item[0])
                )
                tick = _decimal(_field(book, "tick_size", _field(book, "minimum_tick_size")))
                if tick not in {
                    Decimal("0.1"), Decimal("0.01"), Decimal("0.005"),
                    Decimal("0.0025"), Decimal("0.001"), Decimal("0.0001"),
                }:
                    return None
                return price, size, tick

            missing_leg = "NO" if filled_leg == "YES" else "YES"
            ask = best(books[missing_leg], "asks")
            bid = best(books[filled_leg], "bids")
            if ask is None or bid is None:
                return {"fresh": False}
            amount: Decimal | None = None
            # Emergency completion is deliberately bounded to the approved
            # two-dollar loss ceiling; an over-cap book yields no executable
            # option and therefore no signed order attempt.
            for cents in range(1, 201):
                candidate = Decimal("0.01") * cents
                if protected_buy_quantity(
                    spend=candidate,
                    price=ask[0],
                    tick_size=ask[2],
                ) == filled_quantity:
                    amount = candidate
                    break
            if amount is None:
                return {"fresh": False}
            return {
                "fresh": True,
                # The combined read is only as fresh as its oldest venue
                # snapshot; never replace it with a local wall-clock marker.
                "checked_at": min(book_timestamps.values()),
                "complete": {
                    "leg": missing_leg,
                    "side": "BUY",
                    "token_id": token_by_leg[missing_leg],
                    "quantity": filled_quantity,
                    "amount": amount,
                    "max_spend": amount,
                    "max_price": ask[0],
                    # Completion spends the bounded amount of collateral.  A
                    # $1.20 order is therefore a $1.20 emergency cost for the
                    # safety policy, even though the resulting pair may later
                    # redeem for $1.00.
                    "loss": amount,
                },
                "unwind": {
                    "leg": filled_leg,
                    "side": "SELL",
                    "token_id": token_by_leg[filled_leg],
                    "shares": filled_quantity,
                    "quantity": filled_quantity,
                    "min_price": bid[0],
                    "loss": max(Decimal("0"), filled_quantity * (Decimal("1") - bid[0])),
                },
            }
        except Exception:
            return {"fresh": False}

    def cross_remediation_option(
        self,
        *,
        venue: str,
        market_id: str,
        condition_id: str,
        token_id: str,
        outcome: str,
        side: str,
        quantity: Decimal,
        maximum_fee: Decimal,
    ) -> dict[str, object]:
        """Return one current cross-venue completion or unwind option, never submit.

        This is deliberately a narrow adapter callback rather than a second
        venue abstraction.  The caller still chooses between this option and
        the other venue's independently refreshed option.
        """

        if (
            venue != "polymarket"
            or not all(isinstance(value, str) and value.strip() for value in (market_id, condition_id, token_id, outcome))
            or side not in {"BUY", "SELL"}
            or self._positive_decimal(quantity) is None
            or not isinstance(maximum_fee, Decimal)
            or not maximum_fee.is_finite()
            or maximum_fee < 0
        ):
            return {"fresh": False}
        try:
            account = self.account_snapshot()
            account_stamp = _venue_timestamp(account.checked_at)
            now = datetime.now(UTC)
            if (
                account_stamp is None
                or account.open_order_ids
                or (now - account_stamp).total_seconds() < 0
                or (now - account_stamp).total_seconds() > REMEDIATION_BOOK_FRESHNESS_SECONDS
            ):
                return {"fresh": False}
            if side == "BUY" and (
                account.p_usd_balance <= 0 or account.p_usd_allowance <= 0
            ):
                return {"fresh": False}
            if side == "SELL":
                position = sum(
                    (
                        _decimal(row.get("size", row.get("quantity", row.get("shares")))) or Decimal("0")
                        for row in account.positions
                        if row.get("condition_id", row.get("conditionId")) == condition_id
                        and row.get("token_id", row.get("tokenId", row.get("asset_id"))) == token_id
                    ),
                    Decimal("0"),
                )
                if position < quantity:
                    return {"fresh": False}
            book = self._public_client_factory().get_order_book(token_id=token_id)
            stamp = _venue_timestamp(_field(book, "timestamp"))
            now = datetime.now(UTC)
            if (
                stamp is None
                or (now - stamp).total_seconds() < 0
                or (now - stamp).total_seconds() > REMEDIATION_BOOK_FRESHNESS_SECONDS
            ):
                return {"fresh": False}
            levels = _collect(_field(book, "asks" if side == "BUY" else "bids", ()))
            valid: list[tuple[Decimal, Decimal]] = []
            for row in levels:
                price = _decimal(_field(row, "price"))
                size = _decimal(_field(row, "size"))
                if price is None or size is None or not (Decimal("0") < price <= Decimal("1")) or size < quantity:
                    continue
                valid.append((price, size))
            if not valid:
                return {"fresh": False}
            price = min(valid, key=lambda item: item[0])[0] if side == "BUY" else max(valid, key=lambda item: item[0])[0]
            option: dict[str, object] = {
                "venue": venue,
                "market_id": market_id,
                "condition_id": condition_id,
                "token_id": token_id,
                "outcome": outcome,
                "side": side,
                "quantity": quantity,
                "executable_price": price,
                "fee": maximum_fee,
                "slippage": Decimal("0"),
                "residual_dust": Decimal("0"),
            }
            if side == "BUY":
                max_spend = quantity * price + maximum_fee
                if max_spend > account.p_usd_balance or max_spend > account.p_usd_allowance:
                    return {"fresh": False}
                option["max_spend"] = max_spend
            else:
                option.update({"shares": quantity, "min_price": price})
            return {"fresh": True, "checked_at": min(account_stamp, stamp), "option": option}
        except Exception:
            return {"fresh": False}

    def submit_remediation_once(self, order: dict[str, object]) -> LegResult:
        raw_leg = order.get("leg")
        if raw_leg not in ("YES", "NO"):
            return LegResult("YES", False, "blocked", "", Decimal("0"), (), "invalid")
        leg: Literal["YES", "NO"] = cast(Literal["YES", "NO"], raw_leg)
        side = order.get("side")
        token_id = order.get("token_id")
        if side not in ("BUY", "SELL") or not isinstance(token_id, str) or not token_id:
            return LegResult(leg, False, "blocked", "", Decimal("0"), (), "invalid")
        quantity = order.get("quantity")
        if side == "SELL" and not isinstance(quantity, Decimal):
            quantity = order.get("shares") if side == "SELL" else None
        if isinstance(quantity, Decimal) and self._positive_decimal(quantity) is None:
            return LegResult(leg, False, "blocked", "", Decimal("0"), (), "invalid")
        try:
            if side == "BUY":
                amount = order.get("amount", order.get("max_spend"))
                max_spend = order.get("max_spend", amount)
                max_price = order.get("max_price")
                if (
                    not isinstance(amount, Decimal)
                    or self._positive_decimal(amount) is None
                    or not isinstance(max_spend, Decimal)
                    or self._positive_decimal(max_spend) is None
                    or max_spend != amount
                    or not isinstance(max_price, Decimal)
                    or self._positive_decimal(max_price) is None
                    or max_price > 1
                ):
                    return LegResult(leg, False, "blocked", "", Decimal("0"), (), "invalid")
                if not isinstance(quantity, Decimal):
                    quantity = amount / max_price
                signed = self._sign_leg(
                    token_id=token_id, amount=amount, max_price=max_price
                )
                signed_quantity = self._signed_quantity(signed, quantity)
            else:
                shares = order.get("shares")
                min_price = order.get("min_price")
                if (
                    not isinstance(shares, Decimal)
                    or self._positive_decimal(shares) is None
                    or not isinstance(min_price, Decimal)
                    or self._positive_decimal(min_price) is None
                    or min_price > 1
                ):
                    return LegResult(leg, False, "blocked", "", Decimal("0"), (), "invalid")
                signed = self._client.create_market_order(
                    token_id=token_id,
                    side="SELL",
                    shares=shares,
                    min_price=min_price,
                    order_type="FOK",
                )
                raw_shares = _field(signed, "maker_amount")
                signed_quantity = self._signed_quantity_base_units(raw_shares, quantity)
            if (
                _field(signed, "order_type") != "FOK"
                or _field(signed, "side") != side
                or signed_quantity != quantity
            ):
                return LegResult(leg, False, "blocked", "", Decimal("0"), (), "order_shape_mismatch")
            responses = tuple(self._client.post_orders((signed,)))
        except Exception:
            return LegResult(leg, False, "ambiguous", "", Decimal("0"), (), "ambiguous")
        if len(responses) != 1:
            return LegResult(leg, False, "ambiguous", "", Decimal("0"), (), "ambiguous")
        return self._leg_result(leg, responses[0])

    def threshold_remediation_options(
        self,
        *,
        intent: ThresholdHedgeIntent,
        filled_leg: str,
        filled_quantity: Decimal,
        since: datetime,
        **_: object,
    ) -> dict[str, object]:
        """Return a fresh, two-dollar-bounded repair for one threshold leg."""

        if (
            not isinstance(intent, ThresholdHedgeIntent)
            or filled_leg not in {"A", "B"}
            or not isinstance(filled_quantity, Decimal)
            or not filled_quantity.is_finite()
            or filled_quantity <= 0
        ):
            return {"fresh": False}
        filled = intent.leg_a if filled_leg == "A" else intent.leg_b
        missing = intent.leg_b if filled_leg == "A" else intent.leg_a
        try:
            account = self.account_snapshot()
            checked_at = _venue_timestamp(account.checked_at)
            if checked_at is None or account.open_order_ids:
                return {"fresh": False}
            now = datetime.now(UTC)
            if (now - checked_at).total_seconds() < 0 or (now - checked_at).total_seconds() > REMEDIATION_BOOK_FRESHNESS_SECONDS:
                return {"fresh": False}
            filled_position = Decimal("0")
            for position in account.positions:
                token = position.get("token_id", position.get("tokenId", position.get("asset_id", "")))
                if token != filled.token_id:
                    continue
                size = _decimal(position.get("size", position.get("quantity", position.get("shares"))))
                if size is not None and size > 0:
                    filled_position += size
            if filled_position < filled_quantity:
                return {"fresh": False}
            public = self._public_client_factory()
            filled_book = public.get_order_book(token_id=filled.token_id)
            missing_book = public.get_order_book(token_id=missing.token_id)

            def best(book: object, side: str) -> tuple[Decimal, Decimal] | None:
                rows = _collect(_field(book, side, ()))
                levels: list[tuple[Decimal, Decimal]] = []
                for row in rows:
                    price = _decimal(_field(row, "price"))
                    size = _decimal(_field(row, "size"))
                    if price is None or size is None or price <= 0 or price > 1 or size < filled_quantity:
                        continue
                    levels.append((price, size))
                return (max(levels, key=lambda item: item[0]) if side == "bids" else min(levels, key=lambda item: item[0])) if levels else None

            ask = best(missing_book, "asks")
            bid = best(filled_book, "bids")
            if ask is None or bid is None:
                return {"fresh": False}
            for book in (filled_book, missing_book):
                stamp = _venue_timestamp(_field(book, "timestamp"))
                if stamp is None or (now - stamp).total_seconds() < 0 or (now - stamp).total_seconds() > REMEDIATION_BOOK_FRESHNESS_SECONDS:
                    return {"fresh": False}
            amount: Decimal | None = None
            for cents in range(1, 201):
                candidate = CENT * cents
                if protected_buy_quantity(
                    spend=candidate,
                    price=ask[0],
                    tick_size=missing.tick_size,
                ) == filled_quantity:
                    amount = candidate
                    break
            if amount is None:
                return {"fresh": False}
            return {
                "fresh": True,
                "checked_at": min(
                    _venue_timestamp(_field(filled_book, "timestamp")),
                    _venue_timestamp(_field(missing_book, "timestamp")),
                ),
                "complete": {
                    "leg": missing.label,
                    "side": "BUY",
                    "condition_id": missing.condition_id,
                    "token_id": missing.token_id,
                    "outcome": missing.outcome,
                    "quantity": filled_quantity,
                    "amount": amount,
                    "max_spend": amount,
                    "max_price": ask[0],
                    "tick_size": missing.tick_size,
                    "loss": amount,
                },
                "unwind": {
                    "leg": filled.label,
                    "side": "SELL",
                    "condition_id": filled.condition_id,
                    "token_id": filled.token_id,
                    "outcome": filled.outcome,
                    "shares": filled_quantity,
                    "quantity": filled_quantity,
                    "min_price": bid[0],
                    "loss": max(Decimal("0"), filled_quantity * (Decimal("1") - bid[0])),
                },
            }
        except Exception:
            return {"fresh": False}

    def submit_threshold_remediation_once(self, order: dict[str, object]) -> ThresholdLegResult:
        raw_label = order.get("leg")
        if raw_label not in {"A", "B"}:
            return ThresholdLegResult("A", "YES", "", "", False, "blocked", "", Decimal("0"), (), "invalid")
        label: Literal["A", "B"] = cast(Literal["A", "B"], raw_label)
        outcome = order.get("outcome")
        if outcome not in {"YES", "NO"}:
            outcome = "YES"
        condition_id = order.get("condition_id")
        token_id = order.get("token_id")
        side = order.get("side")
        if not isinstance(condition_id, str) or not condition_id or not isinstance(token_id, str) or not token_id or side not in {"BUY", "SELL"}:
            return ThresholdLegResult(label, cast(Literal["YES", "NO"], outcome), str(condition_id or ""), str(token_id or ""), False, "blocked", "", Decimal("0"), (), "invalid")
        quantity = order.get("quantity", order.get("shares"))
        if not isinstance(quantity, Decimal) or quantity <= 0:
            return ThresholdLegResult(label, cast(Literal["YES", "NO"], outcome), condition_id, token_id, False, "blocked", "", Decimal("0"), (), "invalid")
        try:
            if side == "BUY":
                amount = order.get("amount", order.get("max_spend"))
                max_price = order.get("max_price")
                tick_size = order.get("tick_size")
                if not isinstance(amount, Decimal) or not isinstance(max_price, Decimal) or not isinstance(tick_size, Decimal) or protected_buy_quantity(spend=amount, price=max_price, tick_size=tick_size) != quantity:
                    return ThresholdLegResult(label, cast(Literal["YES", "NO"], outcome), condition_id, token_id, False, "blocked", "", Decimal("0"), (), "invalid")
                signed = self._sign_leg(token_id=token_id, amount=amount, max_price=max_price)
                expected = self._signed_quantity(signed, quantity)
            else:
                min_price = order.get("min_price")
                if not isinstance(min_price, Decimal):
                    return ThresholdLegResult(label, cast(Literal["YES", "NO"], outcome), condition_id, token_id, False, "blocked", "", Decimal("0"), (), "invalid")
                signed = self._client.create_market_order(token_id=token_id, side="SELL", shares=quantity, min_price=min_price, order_type="FOK")
                expected = self._signed_quantity_base_units(_field(signed, "maker_amount"), quantity)
            if _field(signed, "order_type") != "FOK" or _field(signed, "side") != side or expected != quantity:
                return ThresholdLegResult(label, cast(Literal["YES", "NO"], outcome), condition_id, token_id, False, "blocked", "", Decimal("0"), (), "order_shape_mismatch")
            responses = tuple(self._client.post_orders((signed,)))
        except Exception:
            return ThresholdLegResult(label, cast(Literal["YES", "NO"], outcome), condition_id, token_id, False, "ambiguous", "", Decimal("0"), (), "ambiguous")
        if len(responses) != 1:
            return ThresholdLegResult(label, cast(Literal["YES", "NO"], outcome), condition_id, token_id, False, "ambiguous", "", Decimal("0"), (), "ambiguous")
        return self._threshold_leg_result(
            ThresholdHedgeLeg(label, condition_id, str(order.get("market_id", condition_id)), cast(Literal["YES", "NO"], outcome), token_id, quantity, order.get("max_price", order.get("min_price")), order.get("amount", Decimal("0")), order.get("tick_size", DEFAULT_TICK_SIZE)),
            responses[0],
        )

    def merge_once(self, *, condition_id: str, quantity: Decimal) -> dict[str, object]:
        if not condition_id or not isinstance(quantity, Decimal) or not quantity.is_finite() or quantity <= 0:
            return {"status": "blocked", "error_code": "invalid"}
        try:
            amount = int((quantity * COLLATERAL_BASE_UNITS).to_integral_exact(rounding=ROUND_HALF_EVEN))
            handle = self._client.merge_positions(condition_id=condition_id, amount=amount)
        except Exception as exc:
            code = _safe_error_code(exc)
            del exc
            return {"status": "blocked", "error_code": code}

        result: dict[str, object] = {}
        error: list[BaseException] = []

        def wait_for_completion() -> None:
            try:
                result["value"] = handle.wait()
            except BaseException as exc:  # pragma: no cover - defensive thread boundary
                error.append(exc)

        thread = threading.Thread(target=wait_for_completion, daemon=True)
        thread.start()
        thread.join(MERGE_WAIT_TIMEOUT_SECONDS)
        if thread.is_alive():
            return {"status": "timeout", "error_code": "timeout"}
        if error:
            return {"status": "blocked", "error_code": _safe_error_code(error[0])}
        outcome = result.get("value")
        transaction_hash = _field(
            outcome, "transaction_hash", _field(outcome, "tx_hash", None)
        )
        transaction_id = _field(outcome, "transaction_id", None)
        if not isinstance(transaction_hash, str) or not transaction_hash.strip():
            return {
                "status": "ambiguous",
                "confirmed": False,
                "error_code": "transaction_unconfirmed",
            }
        if transaction_id is not None and (
            not isinstance(transaction_id, str) or not transaction_id.strip()
        ):
            return {
                "status": "ambiguous",
                "confirmed": False,
                "error_code": "transaction_unconfirmed",
            }
        response: dict[str, object] = {
            "status": "confirmed",
            "confirmed": True,
            "adapter_confirmed": True,
            "error_code": "none",
            "transaction_hash": transaction_hash,
        }
        if transaction_id is not None:
            response["transaction_id"] = transaction_id
        return response


__all__ = [
    "AccountSnapshot",
    "GEOBLOCK_URL",
    "KEYCHAIN_ACCOUNTS",
    "KEYCHAIN_SERVICE",
    "PREDICT_API_KEY_ACCOUNT",
    "PREDICT_PRIVATE_KEY_ACCOUNT",
    "PREDICT_KEYCHAIN_SERVICE",
    "KeychainError",
    "LegResult",
    "PairSubmission",
    "PolymarketTradingClient",
    "PolymarketTradingError",
    "PredictConfig",
    "ThresholdHedgeSubmission",
    "ThresholdLegResult",
    "TradingConfig",
    "load_keychain_secret",
    "load_predict_api_key",
    "load_predict_private_key",
    "load_trading_config",
    "store_keychain_secret",
    "store_predict_api_key",
]
