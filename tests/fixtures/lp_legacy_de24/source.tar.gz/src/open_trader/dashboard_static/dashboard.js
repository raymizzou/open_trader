"use strict";

const state = {
  dashboard: null,
  dashboardError: null,
  accountSnapshot: null,
  accountEtag: "",
  accountError: null,
  accountRequestInFlight: false,
  accountValuationUpdates: new Set(),
  accountIntervalId: null,
  marketFilter: "ALL",
  brokerFilter: "futu",
  workspaceView: "portfolio",
  selectedKellyExperimentId: "",
  selectedHoldingKey: "",
  selectedHoldingDetail: "decision",
  selectedDecisionTab: "final",
  selectedTrendBroker: "",
  selectedTrendKind: "",
  accountViews: {tiger: "real", phillips: "real", eastmoney: "real"},
  trendSimulatePositions: {},
  trendReportHistories: {},
  trendHistoricalReports: {},
  trendKellyObservationPages: new Map(),
  trendKellyObservationPayloads: new Map(),
  trendKellyObservationReports: new Map(),
  decisionDeepLinkRestored: false,
  detailLanguage: "zh",
  statementUpload: {broker: "", busy: false, message: "", error: false},
  researchChat: {
    holdingKey: "",
    sessionId: "",
    busy: false,
    messageCount: 0,
    messages: [],
  },
  standardBacktest: {
    options: null,
    source: "holdings",
    symbolKey: "",
    strategyId: "trend_pullback/v1",
    rangePreset: "1Y",
    customStart: "",
    customEnd: "",
    initialCash: "100000",
    maxWeight: "10%",
    commissionBps: "10",
    slippageBps: "5",
    busy: false,
    error: "",
    result: null,
  },
  predictionMarket: {
    activeTab: "lp",
    payload: null,
    venuesPayload: null,
    venuesError: "",
    venuesRequestInFlight: false,
    lpDashboard: null,
    lpDashboardError: "",
    strategy: "yes_no",
    historyKind: "signals",
    error: "",
    lpCancelSummary: "",
    lpCancelFeedback: null,
    lpCancelFeedbackTimer: null,
    lpCancelInFlight: false,
    lpCancelRequestSeq: 0,
    lpAutoDraft: null,
    lpAutoBusy: false,
    lpAutoMessage: "",
    lpSubmitToasts: [],
    lpSubmitCooldown: null,
    pollId: null,
    stateRequestInFlight: false,
    lpDashboardRequestInFlight: false,
    lpPreparationRecoveryInFlight: false,
    lpDirectionSelections: {},
    signalPollId: null,
    signalRequestInFlight: false,
    signalLastSuccessAt: "",
    signalError: "",
    signalPollEpoch: 0,
    signalHistoryGeneration: 0,
    nLegStatus: "unknown",
    nLegReadGeneration: 0,
    stateRequestController: null,
    historyRequestController: null,
    nlegReportRequestController: null,
    relationReviewRequestController: null,
    relationDetailRequestController: null,
    csrfToken: "",
    llmSwitchInFlight: "",
    activeExecutionId: "",
    filter: {engine: "all", kind: "all", legs: null, scope: null},
    observationFilter: "all",
    relationReview: {open: false, view: "pending_approval", offset: 0, items: [], total: 0, pendingCount: 0, detail: null, loading: false},
  },
};

const elements = {};

const WORKSPACE_VIEWS = new Set(["portfolio", "prediction_market", "kelly_lab", "standard_backtest", "trend_report"]);

const ACCOUNT_STRATEGY_PROFILES = {
  futu: {horizon: "趋势", strategy: "美股趋势交易"},
  tiger: {horizon: "已调仓", strategy: "现金管理"},
  phillips: {horizon: "趋势", strategy: "港股趋势交易"},
  eastmoney: {horizon: "偏短线", strategy: "趋势交易"},
};

const ACCOUNT_BROKERS = Object.keys(ACCOUNT_STRATEGY_PROFILES);
const ACCOUNT_SOURCE_GROUPS = [
  {label: "实时账户", brokers: ["futu", "tiger"]},
  {label: "券商结单", brokers: ["phillips", "eastmoney"]},
];
const TREND_ACCOUNT_BROKERS = ["futu", "phillips", "eastmoney"];
const ACCOUNT_VIEW_KEYS = ["real", "simulate", "report"];

const DECISION_TABS = [
  { key: "final", label: "最终决策" },
  { key: "tradingagents", label: "TradingAgents" },
  { key: "kline", label: "趋势 / K 线" },
  { key: "news", label: "新闻 / 舆论" },
  { key: "futu", label: "富途异动" },
];

const ACTION_LABELS = {
  ADD: "加仓",
  BUY: "买入",
  HOLD: "观察",
  REVIEW: "人工复核",
  SELL_STOP: "止损卖出",
  TAKE_PROFIT: "止盈",
  TRIM: "减仓",
  accumulate: "加仓",
  buy: "买入",
  hold: "观察",
  reduce: "减仓",
  review: "人工复核",
  sell: "卖出",
  trim: "减仓",
  watch: "观察",
  Neutral: "中性",
  Overweight: "超配",
  Underweight: "低配",
  neutral: "中性",
  overweight: "超配",
  underweight: "低配",
};

const ACTION_STATUS_LABELS = {
  active: "有效",
  error: "错误",
  ok: "正常",
  manual_review: "需复核",
  ready: "待确认",
  review: "需复核",
  watch: "观察中",
};

const DETAIL_LANGUAGE_LABELS = {
  zh: "中文",
  en: "English",
};

const PRIORITY_LABELS = {
  critical: "紧急",
  high: "高",
  low: "低",
  medium: "中",
};

const TRIGGER_STATUS_LABELS = {
  add_zone: "接近加仓价",
  entry_zone: "进入买入区间",
  missing_quote: "缺失行情",
  stop_loss_hit: "达到止损价",
  target_1_hit: "达到第一目标价",
  target_2_hit: "达到第二目标价",
  watch: "未触发",
};

const REASON_LABELS = {
  "Current price is at or below the stop loss.": "当前价格已达到或低于止损价。",
  "Current price is at or above target 1.": "当前价格已达到或高于第一目标价。",
  "Current price is at or above target 2.": "当前价格已达到或高于第二目标价。",
  "Current price is inside the planned entry zone.": "当前价格位于计划买入区间。",
  "Current price is near the planned add price.": "当前价格接近计划加仓价。",
  "No plan trigger is active.": "暂无触发中的交易计划。",
  "Futu did not return a quote.": "Futu 未返回行情。",
  "missing quote": "缺失行情。",
};

document.addEventListener("DOMContentLoaded", () => {
  bindElements();
  bindEvents();
  if (predictionOnly()) {
    setWorkspaceView("prediction_market");
    return;
  }
  loadDashboard();
  scheduleAccountPolling();
});

function bindElements() {
  [
    "main-topbar",
    "main-navigation",
    "dashboard-header",
    "header-market-filters",
    "current-view-label",
    "current-view-value",
    "current-view-holding-value",
    "current-view-holding-weight",
    "current-view-cash-note",
    "broker-summary-cards",
    "source-status-list",
    "dashboard-shell",
    "workspace-grid",
    "prediction-market-workspace",
    "prediction-market-root",
    "prediction-market-modal-root",
    "kelly-lab-panel",
    "holdings-panel",
    "open-kelly-lab",
    "return-to-portfolio",
    "summary-value",
    "summary-holding-bar",
    "summary-holding-value",
    "summary-holding-weight",
    "summary-cash-note",
    "summary-refresh-status",
    "summary-refresh-note",
    "summary-brokers",
    "summary-detail-month",
    "summary-health",
    "summary-health-note",
    "market-filters",
    "broker-filters",
    "visible-count",
    "symbol-detail-panel",
    "account-tabs",
    "account-holdings",
    "action-count",
    "trade-actions",
    "connection-status",
    "connection-success",
    "connection-poll",
    "connection-task",
    "research-chat-layer",
    "research-chat-title",
    "research-chat-context-note",
    "research-chat-context-list",
    "research-chat-messages",
    "research-chat-input",
    "research-chat-send",
    "research-chat-close",
    "research-chat-finalize",
    "research-chat-status",
    "open-standard-backtest",
    "standard-backtest-workspace",
    "trend-report-workspace",
    "standard-backtest-form",
    "backtest-symbol-source",
    "backtest-symbol",
    "backtest-strategy-cards",
    "backtest-range-controls",
    "backtest-custom-range",
    "backtest-custom-start",
    "backtest-custom-end",
    "backtest-initial-cash",
    "backtest-max-weight",
    "backtest-commission",
    "backtest-slippage",
    "run-standard-backtest",
    "standard-backtest-status",
    "standard-backtest-results",
  ].forEach((id) => {
    elements[id] = document.getElementById(id);
  });
  elements["holdings-body"] = elements["account-holdings"];
}

function bindEvents() {
  elements["main-navigation"].addEventListener("click", (event) => {
    const button = event.target.closest("[data-workspace]");
    if (!button) return;
    const workspace = button.dataset.workspace || "portfolio";
    if (workspace === "standard_backtest") {
      return openStandardBacktest();
    }
    if (workspace === "portfolio") {
      return returnToPortfolio();
    }
    setWorkspaceView(workspace);
  });
  elements["prediction-market-root"].addEventListener("click", handlePredictionMarketClick);
  elements["prediction-market-root"].addEventListener("keydown", handlePredictionTabKeydown);
  elements["prediction-market-root"].addEventListener("change", handlePredictionMarketChange);
  elements["prediction-market-root"].addEventListener("input", handleLpAutoInput);
  elements["prediction-market-modal-root"].addEventListener("click", handlePredictionModalClick);
  elements["prediction-market-modal-root"].addEventListener("input", handlePredictionModalInput);
  document.addEventListener("keydown", handlePredictionModalKeydown);
  if (typeof window !== "undefined" && typeof window.matchMedia === "function") {
    window.matchMedia("(max-width: 760px)").addEventListener?.(
      "change",
      syncCnTrendBuyAccessibility,
    );
  }
  if (elements["kelly-lab-panel"]) {
    elements["kelly-lab-panel"].addEventListener("click", (event) => {
      const strategyTab = event.target.closest("[data-kelly-experiment]");
      if (strategyTab) {
        state.selectedKellyExperimentId = strategyTab.dataset.kellyExperiment || "";
        renderKellyLab();
        return;
      }
    });
  }
  elements["header-market-filters"].addEventListener("click", (event) => {
    const button = event.target.closest("[data-market]");
    if (!button) {
      return;
    }
    state.marketFilter = button.dataset.market || "ALL";
    state.selectedHoldingKey = "";
    state.selectedHoldingDetail = "decision";
    state.selectedDecisionTab = "final";
    syncDecisionDeepLink();
    setActiveFilter(elements["header-market-filters"], button);
    renderDashboardViews();
  });
  elements["account-tabs"].addEventListener("click", handleBrokerSelection);
  elements["account-tabs"].addEventListener("keydown", handleBrokerTabKeydown);
  elements["broker-summary-cards"].addEventListener("click", handleBrokerSelection);
  elements["account-holdings"].addEventListener("click", (event) => {
    if (handleTrendOptionDialog(event)) return;
    if (handleTrendHoldingTab(event)) return;
    if (handleTrendKellyObservationPagination(event)) return;
    const industryMetric = event.target.closest?.("[data-trend-industry-help]");
    if (industryMetric) {
      if (industryMetric.dataset.trendIndustryHelpOpen === "pinned") {
        closeTrendIndustryHelp(industryMetric);
      } else {
        showTrendIndustryHelp(industryMetric, true);
      }
      return;
    }
    const accountView = event.target.closest("[data-account-view]");
    if (accountView) {
      setAccountView(
        accountView.dataset.accountBroker || "",
        accountView.dataset.accountView || "",
      );
      return;
    }
    const currentReport = event.target.closest("[data-current-trend-report]");
    if (currentReport) {
      showCurrentTrendReport(currentReport.dataset.currentTrendReport || "");
      return;
    }
    const reportHistory = event.target.closest("[data-report-history]");
    if (reportHistory) {
      openTrendReportHistory(reportHistory.dataset.reportHistory || "");
      return;
    }
    const historyArtifact = event.target.closest("[data-history-artifact]");
    if (historyArtifact) {
      loadHistoricalTrendReport(
        historyArtifact.dataset.historyBroker || state.brokerFilter,
        historyArtifact.dataset.historyArtifact || "",
      );
      return;
    }
    const statementUpload = event.target.closest("[data-statement-upload]");
    if (statementUpload) {
      if (!accountActionsEnabled()) return;
      const broker = statementUpload.dataset.statementUpload || "";
      elements["account-holdings"].querySelector(
        `[data-statement-file="${broker}"]`,
      )?.click();
      return;
    }
    const trendReview = event.target.closest("[data-trend-review]");
    if (trendReview) {
      openTrendReview(trendReview.dataset.trendReview || "");
      return;
    }
    const trendReport = event.target.closest("[data-trend-report]");
    if (trendReport) {
      openTrendReport(trendReport.dataset.trendReport || "");
      return;
    }
    const button = event.target.closest("[data-detail-key]");
    if (button) {
      showSymbolDetail(button.dataset.detailKey || "", button.dataset.detailMode || "decision");
      return;
    }
    handleSymbolDetailClick(event);
  });
  elements["account-holdings"].addEventListener("mouseover", (event) => {
    const trigger = event.target.closest?.("[data-trend-industry-help]");
    if (!trigger || (event.relatedTarget && trigger.contains?.(event.relatedTarget))) return;
    showTrendIndustryHelp(trigger);
  });
  elements["account-holdings"].addEventListener("mouseout", (event) => {
    const trigger = event.target.closest?.("[data-trend-industry-help]");
    if (!trigger || (event.relatedTarget && trigger.contains?.(event.relatedTarget))) return;
    if (trigger.dataset.trendIndustryHelpOpen !== "pinned") closeTrendIndustryHelp(trigger);
  });
  elements["account-holdings"].addEventListener("focusin", (event) => {
    const trigger = event.target.closest?.("[data-trend-industry-help]");
    if (trigger) showTrendIndustryHelp(trigger);
  });
  elements["account-holdings"].addEventListener("focusout", (event) => {
    const trigger = event.target.closest?.("[data-trend-industry-help]");
    if (!trigger || (event.relatedTarget && trigger.contains?.(event.relatedTarget))) return;
    if (trigger.dataset.trendIndustryHelpOpen !== "pinned") closeTrendIndustryHelp(trigger);
  });
  document.addEventListener("click", (event) => {
    if (!event.target.closest?.("[data-trend-industry-help]")) closeTrendIndustryHelp();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeTrendIndustryHelp();
  });
  elements["account-holdings"].addEventListener("keydown", handleAccountViewTabKeydown);
  elements["account-holdings"].addEventListener("keydown", handleTrendHoldingTabKeydown);
  elements["account-holdings"].addEventListener("change", handleStatementFileSelection);
  if (elements["trade-actions"]) {
    elements["trade-actions"].addEventListener("click", (event) => {
      const button = event.target.closest("[data-action-detail]");
      if (!button) {
        return;
      }
      openTradeActionDetail(button.dataset.actionDetail || "");
    });
  }
  elements["research-chat-close"].addEventListener("click", closeResearchChat);
  elements["research-chat-send"].addEventListener("click", sendResearchChatMessage);
  elements["research-chat-finalize"].addEventListener("click", finalizeResearchChat);
  elements["research-chat-input"].addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      sendResearchChatMessage();
    }
  });
  elements["symbol-detail-panel"].addEventListener("click", handleSymbolDetailClick);
  elements["open-kelly-lab"].addEventListener("click", () => setWorkspaceView("kelly_lab"));
  elements["return-to-portfolio"].addEventListener("click", returnToPortfolio);
  elements["trend-report-workspace"].addEventListener("click", (event) => {
    if (handleTrendOptionDialog(event)) return;
    if (handleTrendHoldingTab(event)) return;
    if (handleTrendKellyObservationPagination(event)) return;
    if (event.target.closest("[data-close-trend-report]")) returnToPortfolio();
  });
  elements["trend-report-workspace"].addEventListener("keydown", handleTrendHoldingTabKeydown);
  elements["open-standard-backtest"].addEventListener("click", openStandardBacktest);
  elements["backtest-symbol-source"].addEventListener("click", handleBacktestChoice);
  elements["backtest-strategy-cards"].addEventListener("click", handleBacktestChoice);
  elements["backtest-range-controls"].addEventListener("click", handleBacktestChoice);
  elements["backtest-symbol"].addEventListener("change", (event) => {
    state.standardBacktest.symbolKey = event.target.value;
  });
  elements["standard-backtest-form"].addEventListener("submit", submitStandardBacktest);
}

async function openStandardBacktest() {
  setWorkspaceView("standard_backtest");
  if (!state.standardBacktest.options) {
    elements["standard-backtest-status"].textContent = "正在加载回测选项…";
    try {
      const response = await fetch("/api/backtests/options", { cache: "no-store" });
      if (!response.ok) throw new Error(`options ${response.status}`);
      state.standardBacktest.options = await response.json();
      const defaults = state.standardBacktest.options.defaults || {};
      state.standardBacktest.rangePreset = defaults.range || state.standardBacktest.rangePreset;
      state.standardBacktest.maxWeight = decimalAsPercent(defaults.max_strategy_weight, "10%");
      state.standardBacktest.initialCash = String(defaults.initial_cash || "100000");
      state.standardBacktest.commissionBps = String(defaults.commission_bps || "10");
      state.standardBacktest.slippageBps = String(defaults.slippage_bps || "5");
      elements["standard-backtest-status"].textContent = "";
    } catch (error) {
      state.standardBacktest.error = "回测选项加载失败，请稍后重试。";
      elements["standard-backtest-status"].textContent = state.standardBacktest.error;
    }
  }
  renderStandardBacktest();
}

function openTrendReport(broker) {
  const report = state.dashboard?.trend_reports?.[broker];
  if (!report?.available) return;
  state.selectedTrendBroker = broker;
  state.selectedTrendKind = "report";
  elements["trend-report-workspace"].innerHTML = renderTrendReportWorkspace(report);
  setWorkspaceView("trend_report");
  syncCnTrendBuyAccessibility();
  elements["return-to-portfolio"].focus();
}

function openTrendReview(broker) {
  const review = state.dashboard?.trend_reviews?.[broker];
  if (!review?.available) return;
  state.selectedTrendBroker = broker;
  state.selectedTrendKind = "review";
  elements["trend-report-workspace"].innerHTML = renderTrendReviewWorkspace(review);
  setWorkspaceView("trend_report");
  elements["return-to-portfolio"].focus();
}

function returnToPortfolio() {
  const trendBroker = state.selectedTrendBroker;
  const trendKind = state.selectedTrendKind;
  if (state.workspaceView === "standard_backtest") syncStandardBacktestInputs();
  state.selectedTrendBroker = "";
  state.selectedTrendKind = "";
  setWorkspaceView("portfolio");
  renderAccountHoldings();
  if (trendBroker) {
    const attribute = trendKind === "review" ? "data-trend-review" : "data-trend-report";
    document.querySelector(`#account-${trendBroker} [${attribute}]`)?.focus();
  }
}

function handleBacktestChoice(event) {
  const source = event.target.closest("[data-backtest-source]");
  const strategy = event.target.closest("[data-strategy-id]");
  const range = event.target.closest("[data-range-preset]");
  if (source) {
    syncStandardBacktestInputs();
    state.standardBacktest.source = source.dataset.backtestSource;
    state.standardBacktest.symbolKey = "";
  } else if (strategy && !strategy.disabled) {
    state.standardBacktest.strategyId = strategy.dataset.strategyId;
  } else if (range) {
    syncStandardBacktestInputs();
    state.standardBacktest.rangePreset = range.dataset.rangePreset;
  } else {
    return;
  }
  renderStandardBacktest();
}

function renderStandardBacktest() {
  const options = state.standardBacktest.options;
  if (!options) return;
  const backtest = state.standardBacktest;
  elements["backtest-symbol-source"].innerHTML = [
    ["holdings", "当前持仓"], ["watchlist", "关注列表"],
  ].map(([key, label]) => `<button class="filter-button ${backtest.source === key ? "active" : ""}" type="button" data-backtest-source="${key}" aria-pressed="${backtest.source === key}">${label}</button>`).join("");
  const universe = backtest.source === "holdings"
    ? accountBacktestUniverse()
    : (options.universe && options.universe[backtest.source]) || [];
  if (!universe.some((row) => `${row.market}:${row.symbol}` === backtest.symbolKey)) {
    backtest.symbolKey = universe.length ? `${universe[0].market}:${universe[0].symbol}` : "";
  }
  elements["backtest-symbol"].innerHTML = universe.length
    ? universe.map((row) => `<option value="${escapeHtml(`${row.market}:${row.symbol}`)}" ${`${row.market}:${row.symbol}` === backtest.symbolKey ? "selected" : ""}>${escapeHtml(`${row.market} · ${row.symbol}${row.name ? ` · ${row.name}` : ""}`)}</option>`).join("")
    : '<option value="">暂无可回测标的</option>';
  elements["backtest-strategy-cards"].innerHTML = options.strategies.map((strategy) => `
    <button class="backtest-strategy-card ${strategy.id === backtest.strategyId ? "active" : ""}" type="button" data-strategy-id="${escapeHtml(strategy.id)}" aria-pressed="${strategy.id === backtest.strategyId}">
      <strong>${escapeHtml(strategy.name_zh)}</strong><span>${escapeHtml(strategy.description_zh)}</span>
    </button>`).join("") + '<button class="backtest-strategy-card" type="button" disabled aria-disabled="true" aria-pressed="false"><strong>自定义策略</strong><span>后续版本</span></button>';
  elements["backtest-range-controls"].innerHTML = options.ranges.map((range) => `<button class="filter-button ${range === backtest.rangePreset ? "active" : ""}" type="button" data-range-preset="${range}" aria-pressed="${range === backtest.rangePreset}">${range === "CUSTOM" ? "自定义" : range}</button>`).join("");
  const custom = backtest.rangePreset === "CUSTOM";
  elements["backtest-custom-range"].hidden = !custom;
  elements["backtest-custom-range"].classList.toggle("hidden", !custom);
  elements["backtest-custom-start"].required = custom;
  elements["backtest-custom-start"].value = backtest.customStart;
  elements["backtest-custom-end"].value = backtest.customEnd;
  elements["backtest-initial-cash"].value = backtest.initialCash;
  elements["backtest-max-weight"].value = backtest.maxWeight;
  elements["backtest-commission"].value = backtest.commissionBps;
  elements["backtest-slippage"].value = backtest.slippageBps;
}

function accountBacktestUniverse() {
  const seen = new Set();
  return (state.accountSnapshot?.positions || []).flatMap((position) => {
    const market = String(position.market || "").toUpperCase();
    const symbol = String(position.symbol || "").toUpperCase();
    const asset = String(position.asset_class || "").toLowerCase();
    const key = `${market}:${symbol}`;
    if (!["CN", "HK", "US"].includes(market)
        || !["stock", "etf"].includes(asset)
        || !symbol || seen.has(key)) return [];
    seen.add(key);
    return [{market, symbol, name: String(position.name || "")}];
  });
}

function syncStandardBacktestInputs() {
  if (!elements["backtest-max-weight"]) return;
  state.standardBacktest.customStart = elements["backtest-custom-start"].value;
  state.standardBacktest.customEnd = elements["backtest-custom-end"].value;
  state.standardBacktest.initialCash = elements["backtest-initial-cash"].value;
  state.standardBacktest.maxWeight = elements["backtest-max-weight"].value;
  state.standardBacktest.commissionBps = elements["backtest-commission"].value;
  state.standardBacktest.slippageBps = elements["backtest-slippage"].value;
}

function buildStandardBacktestRequest() {
  const backtest = state.standardBacktest;
  const separator = backtest.symbolKey.indexOf(":");
  const request = {
    market: backtest.symbolKey.slice(0, separator),
    symbol: backtest.symbolKey.slice(separator + 1),
    strategy_id: backtest.strategyId,
    range_preset: backtest.rangePreset,
    initial_cash: backtest.initialCash,
    max_strategy_weight: backtest.maxWeight,
    commission_bps: backtest.commissionBps,
    slippage_bps: backtest.slippageBps,
  };
  if (backtest.rangePreset === "CUSTOM") {
    request.custom_start = backtest.customStart;
    request.custom_end = backtest.customEnd;
  }
  return request;
}

async function submitStandardBacktest(event) {
  event.preventDefault();
  syncStandardBacktestInputs();
  const backtest = state.standardBacktest;
  if (!backtest.symbolKey || backtest.busy) return;
  const validationError = validateStandardBacktestDates();
  if (validationError) {
    elements["standard-backtest-status"].textContent = validationError;
    return;
  }
  backtest.busy = true;
  elements["run-standard-backtest"].disabled = true;
  elements["standard-backtest-status"].textContent = "正在运行回测…";
  try {
    const response = await fetch("/api/backtests/standard/run", {
      method: "POST", headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify(buildStandardBacktestRequest()),
    });
    let payload = null;
    try { payload = await response.json(); } catch (_) { payload = null; }
    if (!response.ok) {
      elements["standard-backtest-status"].textContent = safeBacktestErrorMessage(payload);
      return;
    }
    if (!payload || typeof payload !== "object") {
      elements["standard-backtest-status"].textContent = "回测请求失败，请稍后重试。";
      return;
    }
    backtest.result = payload;
    renderStandardBacktestResult(payload);
    elements["standard-backtest-status"].textContent = "回测运行成功。";
  } catch (_) {
    elements["standard-backtest-status"].textContent = "回测请求失败，请稍后重试。";
  } finally {
    backtest.busy = false;
    elements["run-standard-backtest"].disabled = false;
  }
}

function renderStandardBacktestResult(result) {
  const target = document.getElementById("standard-backtest-results");
  if (!target || !result || typeof result !== "object") return;
  target.innerHTML = [
    renderBacktestComparisonMetrics(result),
    renderBacktestEquityComparison(result),
    renderBacktestPriceActions(result),
    renderBacktestTradeTable(result),
    renderBacktestRunAssumptions(result),
  ].join("");
  target.hidden = false;
}

function renderBacktestComparisonMetrics(result) {
  const strategy = result.strategy || {};
  const buyHold = result.buy_hold || {};
  const benchmark = result.market_benchmark;
  const benchmarkLabel = result.benchmark_symbol || "市场指数";
  const rows = [
    ["策略收益", strategy.total_return_pct, "pnl"],
    ["买入持有", buyHold.total_return_pct, "pnl"],
    [benchmarkLabel, benchmark && benchmark.total_return_pct, "pnl"],
    ["相对买入持有", result.strategy_excess_return_pct, "pnl"],
    ["相对市场指数", benchmark && result.market_excess_return_pct, "pnl"],
    ["最大回撤", strategy.max_drawdown_pct, "drawdown"],
    ["交易次数", Array.isArray(strategy.trades) ? strategy.trades.filter((trade) => Number(trade.quantity) !== 0).length : 0, "count"],
    ["胜率", strategy.win_rate_pct, "percent"],
  ];
  return `<section class="backtest-result-section" aria-labelledby="backtest-comparison-title"><h3 id="backtest-comparison-title">回测对比</h3><div class="backtest-comparison-grid">${rows.map(([label, value, kind]) => {
    const unavailable = (label === benchmarkLabel || label === "相对市场指数") && !benchmark;
    const rawDisplay = unavailable ? "基准行情缺失，无法比较" : kind === "count" ? formatDisplayNumber(value) : backtestPercent(value);
    const display = kind === "pnl" ? formatSignedPnl(rawDisplay)
      : kind === "drawdown" ? drawdownPercent(value, backtestPercent)
        : rawDisplay;
    const tone = kind === "pnl" || kind === "drawdown" ? pnlClass(display) : "";
    return `<article class="backtest-metric-card${unavailable ? " benchmark-unavailable" : ""}"><span>${escapeHtml(label)}</span><strong${tone ? ` class="${tone}"` : ""}>${escapeHtml(display)}</strong></article>`;
  }).join("")}</div></section>`;
}

function renderBacktestEquityComparison(result) {
  return `<section class="backtest-result-section"><h3>净值曲线</h3>${renderThreeSeriesBacktestChart(
    result.strategy && result.strategy.equity_curve,
    result.buy_hold && result.buy_hold.equity_curve,
    result.market_benchmark && result.market_benchmark.equity_curve,
    result.benchmark_symbol,
    (result.strategy && result.strategy.trades || []).map((trade) => trade.execution_date),
  )}</section>`;
}

function renderThreeSeriesBacktestChart(strategyRows, buyHoldRows, marketRows, benchmarkSymbol, actionDates) {
  const preserved = new Set(Array.isArray(actionDates) ? actionDates.map(String) : []);
  const series = [
    ["策略", downsampleBacktestRows(strategyRows, "equity", preserved), "backtest-line-strategy"],
    ["买入持有", downsampleBacktestRows(buyHoldRows, "equity", preserved), "backtest-line-buy-hold"],
    [benchmarkSymbol || "市场指数", downsampleBacktestRows(marketRows, "equity", preserved), "backtest-line-market"],
  ];
  const points = series.flatMap(([, rows]) => rows).map((row) => Number(row.equity));
  const dates = [...new Set(series.flatMap(([, rows]) => Array.isArray(rows) ? rows.map((row) => String(row.date || "")) : []).filter(Boolean))].sort();
  const [min, max] = finiteBacktestExtent(points);
  const path = (rows) => {
    const byDate = new Map((Array.isArray(rows) ? rows : []).map((row) => [String(row.date || ""), Number(row.equity)]));
    let started = false;
    return dates.map((date, index) => {
      const value = byDate.get(date);
      if (!Number.isFinite(value)) return "";
      const x = dates.length > 1 ? 20 + index * 560 / (dates.length - 1) : 300;
      const y = 180 - (value - min) * 150 / (max - min || 1);
      const command = started ? "L" : "M";
      started = true;
      return `${command}${x.toFixed(1)},${y.toFixed(1)}`;
    }).filter(Boolean).join(" ");
  };
  const legend = series.map(([label, , className]) => `<span class="${className}">${escapeHtml(label)}</span>`).join("");
  const paths = series.map(([, rows, className]) => `<path class="${className}" d="${path(rows)}" fill="none" vector-effect="non-scaling-stroke"></path>`).join("");
  return `<div class="backtest-chart" role="img" aria-label="策略、买入持有与市场指数净值曲线"><div class="backtest-chart-legend">${legend}</div><svg viewBox="0 0 600 200" aria-hidden="true">${paths}</svg></div>`;
}

function renderBacktestPriceActions(result) {
  const strategy = result.strategy || {};
  const rows = Array.isArray(strategy.equity_curve) ? strategy.equity_curve : [];
  const trades = Array.isArray(strategy.trades) ? strategy.trades : [];
  return `<section class="backtest-result-section"><h3>价格与动作</h3>${renderPriceActionChart(rows, trades)}</section>`;
}

function renderPriceActionChart(rows, trades) {
  const allowed = new Set(["BUY", "ADD", "REDUCE", "EXIT"]);
  const validDates = new Set((Array.isArray(rows) ? rows : []).filter((row) => row && Number.isFinite(Number(row.close))).map((row) => String(row.date || "")));
  const grouped = new Map();
  for (const trade of Array.isArray(trades) ? trades : []) {
    const action = String(trade.action || "");
    const executionDate = String(trade.execution_date || "");
    const price = Number(trade.raw_price);
    if (!allowed.has(action) || !validDates.has(executionDate) || !Number.isFinite(price)) continue;
    const key = `${executionDate}\u0000${action}`;
    const current = grouped.get(key);
    if (current) current.count += 1;
    else grouped.set(key, { execution_date: executionDate, action, raw_price: price, count: 1 });
  }
  const allGroups = [...grouped.values()];
  const actionGroups = sampleBacktestActionGroups(allGroups, 600);
  rows = downsampleBacktestRows(rows, "close", new Set(actionGroups.map((group) => group.execution_date)));
  const prices = rows.map((row) => Number(row.close));
  const [min, max] = finiteBacktestExtent(prices);
  const dateIndex = new Map(rows.map((row, index) => [String(row.date || ""), index]));
  const xy = (date, price) => {
    const index = dateIndex.get(String(date || "")) || 0;
    return [rows.length > 1 ? 20 + index * 560 / (rows.length - 1) : 300, 180 - (Number(price) - min) * 150 / (max - min || 1)];
  };
  const displayedGroups = actionGroups.filter((group) => dateIndex.has(group.execution_date));
  const omittedGroups = allGroups.length - displayedGroups.length;
  const pricePath = rows.map((row, index) => { const [x, y] = xy(row.date, row.close); return `${index ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`; }).join(" ");
  const explanations = { BUY: "买入", ADD: "加仓", REDUCE: "减仓", EXIT: "退出" };
  const markers = displayedGroups.map((group) => {
    const [x, y] = xy(group.execution_date, group.raw_price);
    const count = group.count > 1 ? ` ×${formatDisplayNumber(group.count)}` : "";
    return `<g class="backtest-action-marker action-${group.action.toLowerCase()}"><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5"></circle><text x="${x.toFixed(1)}" y="${(y - 9).toFixed(1)}">${group.action}${count}</text></g>`;
  }).join("");
  const summary = displayedGroups.map((group) => `${group.execution_date} ${group.action}（${explanations[group.action]}）${group.count > 1 ? `共 ${formatDisplayNumber(group.count)} 笔` : ""}`).join("；");
  const omittedNotice = omittedGroups ? `另有 ${formatDisplayNumber(omittedGroups)} 组交易标记未显示` : "";
  return `<div class="backtest-chart" role="img" aria-label="价格曲线与交易动作。${escapeHtml(summary || "没有执行动作")}。${omittedNotice}。HOLD（观察）不绘制标记。"><svg viewBox="0 0 600 200" aria-hidden="true"><path class="backtest-price-line" d="${pricePath}" fill="none" vector-effect="non-scaling-stroke"></path>${markers}</svg></div>`;
}

function sampleBacktestActionGroups(groups, limit) {
  if (groups.length <= limit) return groups;
  const selected = new Set([0, groups.length - 1]);
  const actions = ["BUY", "ADD", "REDUCE", "EXIT"];
  for (const action of actions) {
    const first = groups.findIndex((group) => group.action === action);
    if (first >= 0) selected.add(first);
    for (let index = groups.length - 1; index >= 0; index -= 1) {
      if (groups[index].action === action) { selected.add(index); break; }
    }
  }
  const remaining = limit - selected.size;
  const step = (groups.length - 1) / (remaining + 1);
  for (let index = 1; index <= remaining; index += 1) selected.add(Math.round(index * step));
  if (selected.size < limit) {
    for (let index = 0; index < groups.length && selected.size < limit; index += 1) selected.add(index);
  }
  return [...selected].sort((left, right) => left - right).slice(0, limit).map((index) => groups[index]);
}

function renderBacktestTradeTable(result) {
  const trades = result.strategy && Array.isArray(result.strategy.trades) ? result.strategy.trades : [];
  if (!trades.length) return '<section class="backtest-result-section"><h3>交易记录</h3><p class="backtest-empty-state">所选区间内没有触发交易</p></section>';
  const visible = trades.slice(0, 500);
  const notice = trades.length > visible.length ? `<p>仅显示前 500 笔，共 ${formatDisplayNumber(trades.length)} 笔</p>` : "";
  return `<section class="backtest-result-section"><h3>交易记录</h3>${notice}<div class="backtest-table-wrap"><table class="backtest-trades-table"><thead><tr><th>执行日期</th><th>动作</th><th>数量</th><th>成交价</th><th>费用</th><th>原因</th></tr></thead><tbody>${visible.map((trade) => `<tr><td>${escapeHtml(trade.execution_date)}</td><td>${escapeHtml(trade.action)}</td><td>${escapeHtml(formatDisplayNumber(trade.quantity))}</td><td>${escapeHtml(formatDisplayNumber(trade.execution_price))}</td><td>${escapeHtml(formatDisplayNumber(trade.fees))}</td><td>${escapeHtml(trade.reason)}</td></tr>`).join("")}</tbody></table></div></section>`;
}

function renderBacktestRunAssumptions(result) {
  const strategy = result.strategy || {};
  const trades = Array.isArray(strategy.trades) ? strategy.trades : [];
  const totalFees = trades.reduce((sum, trade) => sum + (Number(trade.fees) || 0), 0);
  const assumptions = result.assumptions || {};
  const definition = result.strategy_definition || {};
  const parameterLabels = { sma_short: "短期均线周期", sma_long: "长期均线周期", atr_period: "真实波幅周期", rsi_period: "强弱指标周期", stop_multiplier: "止损倍数", high_period: "突破周期", volume_period: "成交量周期", volume_multiplier: "成交量倍数", sma_exit: "退出均线周期", bollinger_period: "布林带周期", stddev_multiplier: "标准差倍数" };
  const parameters = definition.parameters && typeof definition.parameters === "object" ? Object.entries(definition.parameters) : [];
  const signals = Array.isArray(result.signals) ? result.signals : [];
  const holdSignals = signals.filter((signal) => signal.action === "HOLD");
  const artifacts = [["manifest_path", "运行清单"], ["signals_path", "策略信号"], ["trades_path", "交易记录"], ["equity_curve_path", "策略净值"], ["buy_hold_equity_path", "买入持有净值"], ["market_benchmark_equity_path", "市场指数净值"], ["metrics_path", "指标数据"], ["report_path", "回测报告"]];
  return `<section class="backtest-result-section"><h3>运行详情</h3><dl class="backtest-run-details"><dt>请求范围</dt><dd>${escapeHtml(result.requested_start || "-")} 至 ${escapeHtml(result.requested_end || "-")}</dd><dt>实际数据</dt><dd>${escapeHtml(result.actual_start || "-")} 至 ${escapeHtml(result.actual_end || "-")}</dd><dt>策略版本</dt><dd>${escapeHtml(result.strategy_id || "-")}</dd><dt>策略名称</dt><dd>${escapeHtml(definition.name_zh || "-")} · ${escapeHtml(definition.description_zh || "-")}</dd><dt>执行器版本</dt><dd>${escapeHtml(result.adapter_version || "-")}</dd><dt>运行编号</dt><dd>${escapeHtml(result.run_id || "-")}</dd></dl><h4>交易假设</h4><dl class="backtest-run-details"><dt>初始资金</dt><dd>${escapeHtml(formatDisplayNumber(assumptions.initial_cash))}</dd><dt>最大策略仓位</dt><dd>${backtestPercent(Number(assumptions.max_strategy_weight) * 100)}</dd><dt>佣金</dt><dd>${escapeHtml(formatDisplayNumber(assumptions.commission_bps))} 基点</dd><dt>滑点</dt><dd>${escapeHtml(formatDisplayNumber(assumptions.slippage_bps))} 基点</dd><dt>已实现交易费用</dt><dd>${escapeHtml(formatDisplayNumber(totalFees.toFixed(2)))}</dd></dl><h4>固定参数</h4><dl class="backtest-run-details">${parameters.map(([key, value]) => `<dt>${escapeHtml(parameterLabels[key] || key)}</dt><dd>${escapeHtml(formatDisplayNumber(value))}</dd>`).join("")}</dl><p class="backtest-signal-summary">HOLD（观察）信号 ${formatDisplayNumber(holdSignals.length)} 次${holdSignals.length ? `；${escapeHtml(holdSignals.slice(0, 10).map((signal) => signal.decision_date).join("、"))}` : ""}</p><h4>结果文件</h4><ul class="backtest-artifacts">${artifacts.filter(([key]) => result[key]).map(([key, label]) => `<li><span>${label}</span><code>${escapeHtml(result[key])}</code></li>`).join("")}</ul></section>`;
}

function finiteBacktestExtent(values) {
  let min = Infinity; let max = -Infinity;
  for (const value of values) {
    const number = Number(value);
    if (!Number.isFinite(number)) continue;
    if (number < min) min = number;
    if (number > max) max = number;
  }
  return min === Infinity ? [0, 1] : [min, max];
}

function downsampleBacktestRows(rows, valueKey, preservedDates, limit = 600) {
  const valid = (Array.isArray(rows) ? rows : []).filter((row) => row && String(row.date || "") && Number.isFinite(Number(row[valueKey])));
  if (valid.length <= limit) return valid;
  const selected = new Set([0, valid.length - 1]);
  const preserveIndexes = [];
  valid.forEach((row, index) => { if (preservedDates && preservedDates.has(String(row.date))) preserveIndexes.push(index); });
  const preserveStep = Math.max(1, Math.ceil(preserveIndexes.length / Math.max(1, limit - 2)));
  for (let index = 0; index < preserveIndexes.length && selected.size < limit; index += preserveStep) selected.add(preserveIndexes[index]);
  const remaining = limit - selected.size;
  if (remaining > 0) {
    const step = (valid.length - 1) / (remaining + 1);
    for (let index = 1; index <= remaining; index += 1) selected.add(Math.round(index * step));
  }
  return [...selected].sort((left, right) => left - right).slice(0, limit).map((index) => valid[index]);
}

function backtestPercent(value) {
  const number = Number(value);
  return Number.isFinite(number) ? `${number.toFixed(2)}%` : "-";
}

function drawdownPercent(value, formatter = decisionPlanPercent) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "-";
  const magnitude = Math.abs(number);
  const display = formatter(magnitude);
  return magnitude === 0 ? display : `-${display}`;
}

function validateStandardBacktestDates() {
  const backtest = state.standardBacktest;
  if (backtest.rangePreset !== "CUSTOM") return "";
  if (!backtest.customStart) return "自定义区间必须填写开始日期。";
  if (backtest.customEnd && backtest.customStart >= backtest.customEnd) return "开始日期必须早于结束日期。";
  return "";
}

function safeBacktestErrorMessage(payload) {
  const message = payload && typeof payload.message === "string" ? payload.message.trim() : "";
  const isSafeChinese = message && /[\u3400-\u9fff]/.test(message) && !/[A-Za-z]/.test(message);
  return isSafeChinese ? message : "回测请求失败，请稍后重试。";
}

function decimalAsPercent(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? `${formatDisplayNumber(number * 100)}%` : fallback;
}

function handleSymbolDetailClick(event) {
  const decisionTab = event.target.closest("[data-decision-tab]");
  if (decisionTab) {
    state.selectedDecisionTab = decisionTab.dataset.decisionTab || "final";
    syncDecisionDeepLink();
    renderHoldings();
    return;
  }
  const backButton = event.target.closest("[data-back-to-holdings]");
  if (backButton) {
    state.selectedHoldingKey = "";
    state.selectedHoldingDetail = "decision";
    state.selectedDecisionTab = "final";
    syncDecisionDeepLink();
    renderHoldings();
    return;
  }
  const languageButton = event.target.closest("[data-detail-language]");
  if (languageButton) {
    state.detailLanguage = languageButton.dataset.detailLanguage === "en" ? "en" : "zh";
    renderHoldings();
    return;
  }
  const chatButton = event.target.closest("[data-research-chat]");
  if (chatButton) {
    openResearchChat(chatButton.dataset.researchChat || "");
    return;
  }
  const rawButton = event.target.closest("[data-toggle-raw-report]");
  if (!rawButton) {
    return;
  }
  const section = rawButton.closest(".detail-section") || elements["symbol-detail-panel"];
  const rawReport = section.querySelector(".raw-report");
  if (!rawReport) {
    return;
  }
  const isHidden = rawReport.classList.toggle("hidden");
  if (rawButton.classList.contains("english-source-toggle")) {
    rawButton.textContent = isHidden ? "查看英文原文" : "隐藏英文原文";
  } else {
    rawButton.textContent = isHidden ? "查看原始报告" : "隐藏原始报告";
  }
}

async function loadDashboard() {
  try {
    const response = await fetch("/api/dashboard", { cache: "no-store" });
    if (!response.ok) {
      throw new Error(`dashboard ${response.status}`);
    }
    state.dashboard = await response.json();
    state.dashboardError = null;
    restoreDecisionDeepLink();
    renderDashboard();
  } catch (error) {
    renderLoadError(error);
  }
}

function restoreDecisionDeepLink() {
  if (state.decisionDeepLinkRestored || typeof window === "undefined") {
    return;
  }
  state.decisionDeepLinkRestored = true;
  const params = new URLSearchParams(window.location.search || "");
  const market = String(params.get("market") || "").toUpperCase();
  const symbol = String(params.get("symbol") || "").toUpperCase();
  if (!market || !symbol) {
    return;
  }
  const groups = accountHoldingGroups();
  const match = ACCOUNT_BROKERS.flatMap((broker) => {
    const group = groups.find((item) => item.broker === broker);
    return (group?.rows || []).map((row) => ({broker, row}));
  }).find(({row}) => (
    String(row.display.market || "").toUpperCase() === market
    && String(row.display.symbol || "").toUpperCase() === symbol
  ));
  if (!match) {
    return;
  }
  state.marketFilter = "ALL";
  state.brokerFilter = match.broker;
  state.selectedHoldingKey = match.row.key;
  state.selectedHoldingDetail = "decision";
  const decisionTab = String(params.get("decision_tab") || "final");
  state.selectedDecisionTab = DECISION_TABS.some((tab) => tab.key === decisionTab)
    ? decisionTab
    : "final";
}

function syncDecisionDeepLink() {
  if (typeof window === "undefined" || !window.history || !window.location) {
    return;
  }
  const params = new URLSearchParams(window.location.search || "");
  const selected = selectedHolding();
  if (selected) {
    params.set("market", String(selected.holding.market || ""));
    params.set("symbol", String(selected.holding.symbol || ""));
    params.set("decision_tab", state.selectedDecisionTab || "final");
  } else {
    params.delete("market");
    params.delete("symbol");
    params.delete("decision_tab");
  }
  const query = params.toString();
  window.history.replaceState(null, "", `${window.location.pathname}${query ? `?${query}` : ""}${window.location.hash || ""}`);
}

function scheduleAccountPolling() {
  if (state.accountIntervalId !== null) {
    window.clearInterval(state.accountIntervalId);
  }
  loadAccountSnapshot();
  state.accountIntervalId = window.setInterval(loadAccountSnapshot, 5000);
}

async function loadAccountSnapshot() {
  if (state.workspaceView === "prediction_market" || state.accountRequestInFlight) {
    return;
  }
  state.accountRequestInFlight = true;
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 4000);
  try {
    const headers = state.accountEtag ? {"If-None-Match": state.accountEtag} : {};
    const response = await fetch("/api/v1/account/snapshot", {
      cache: "no-store", headers, signal: controller.signal,
    });
    if (response.status === 304) {
      state.accountError = null;
      state.accountValuationUpdates.clear();
      return;
    }
    if (!response.ok) {
      throw new Error(`account snapshot ${response.status}`);
    }
    const payload = await response.json();
    state.accountValuationUpdates = accountValuationUpdates(
      state.accountSnapshot,
      payload,
    );
    state.accountSnapshot = payload;
    state.accountEtag = response.headers.get("ETag") || "";
    state.accountError = null;
  } catch (error) {
    state.accountError = error;
  } finally {
    window.clearTimeout(timeout);
    state.accountRequestInFlight = false;
    renderHeaderSummary();
    renderSummary();
    renderBrokerCards();
    renderSourceStatusListIntoHeader();
    renderConnectionPanel();
    renderHoldings();
    if (state.workspaceView === "standard_backtest") renderStandardBacktest();
    updateCurrentTrendHoldingNote();
    state.accountValuationUpdates.clear();
  }
}

function renderDashboard() {
  renderBrokerCards();
  renderSourceStatusListIntoHeader();
  renderWorkspaceChrome();
  renderKellyLab();
  renderDashboardViews();
  renderTradeActions();
  renderConnectionPanel();
}

function predictionOnly() {
  return document.body?.dataset?.predictionOnly === "true";
}

function setWorkspaceView(view) {
  if (predictionOnly()) view = "prediction_market";
  const previousView = state.workspaceView;
  state.workspaceView = WORKSPACE_VIEWS.has(view) ? view : "portfolio";
  renderWorkspaceChrome();
  if (state.workspaceView === "kelly_lab") renderKellyLab();
  if (state.workspaceView === "prediction_market") {
    if (previousView !== "prediction_market") state.predictionMarket.activeTab = "lp";
    renderPredictionMarket();
    fetchPredictionVenues();
    fetchCurrentPredictionPane();
    startPredictionPolling();
  } else {
    stopPredictionPolling();
    stopPredictionSignalPolling();
    if (previousView === "prediction_market") {
      // Issue 162（定案 2，行为变化点）：离开 prediction 视图显式关闭全部
      // 弹窗 kind（含 order）——隐藏视图背后的模态没有存活理由。
      if (predictionModal?.kind) closePredictionModal();
      invalidatePredictionNLegReads();
      loadAccountSnapshot();
    }
  }
}

function renderWorkspaceChrome() {
  const view = state.workspaceView;
  document.body?.classList?.toggle?.("prediction-market-active", view === "prediction_market");
  const toolView = view !== "portfolio";
  elements["dashboard-shell"].classList.toggle("tool-workspace-view", toolView);
  elements["return-to-portfolio"].hidden = !toolView || predictionOnly();
  elements["return-to-portfolio"].classList.toggle("hidden", !toolView || predictionOnly());
  elements["dashboard-header"]?.classList.toggle("hidden", view === "prediction_market");
  elements["workspace-grid"].classList.toggle("hidden", view === "standard_backtest" || view === "trend_report" || view === "prediction_market");
  elements["holdings-panel"].classList.toggle("hidden", view !== "portfolio");
  elements["kelly-lab-panel"].classList.toggle("hidden", view !== "kelly_lab");
  if (elements["prediction-market-workspace"]) {
    elements["prediction-market-workspace"].hidden = view !== "prediction_market";
    elements["prediction-market-workspace"].classList.toggle("hidden", view !== "prediction_market");
  }
  elements["standard-backtest-workspace"].hidden = view !== "standard_backtest";
  elements["standard-backtest-workspace"].classList.toggle("hidden", view !== "standard_backtest");
  elements["trend-report-workspace"].hidden = view !== "trend_report";
  elements["trend-report-workspace"].classList.toggle("hidden", view !== "trend_report");
  const navigationButtons = typeof elements["main-navigation"]?.querySelectorAll === "function"
    ? elements["main-navigation"].querySelectorAll("[data-workspace]")
    : [];
  navigationButtons.forEach((button) => {
    button.hidden = predictionOnly() && button.dataset.workspace !== "prediction_market";
    button.classList.toggle("hidden", button.hidden);
    const active = button.dataset.workspace === view;
    button.setAttribute("aria-current", active ? "page" : "false");
  });
}

function renderKellyLab() {
  if (!elements["kelly-lab-panel"]) {
    return;
  }
  elements["kelly-lab-panel"].innerHTML = renderKellyLabPanel();
}

function renderKellyLabPanel() {
  if (state.workspaceView !== "kelly_lab") {
    return "";
  }

  const dashboard = state.dashboard || {};
  const lab = dashboard.kelly_lab;
  if (state.dashboardError) {
    return `
      <div class="section-heading compact kelly-lab-heading">
        <div>
          <h2>模拟盘策略实验室</h2>
          <p>看板数据加载失败。</p>
        </div>
        <div class="kelly-lab-heading-actions">
          <span class="status-pill status-failed">不可用</span>
        </div>
      </div>
      <div class="kelly-lab-empty">Kelly Lab 数据暂不可用。</div>
    `;
  }
  if (!state.dashboard) {
    return `
      <div class="section-heading compact kelly-lab-heading">
        <div>
          <h2>模拟盘策略实验室</h2>
          <p>等待看板数据。</p>
        </div>
        <div class="kelly-lab-heading-actions">
          <span class="status-pill status-muted">加载中</span>
        </div>
      </div>
      <div class="kelly-lab-empty">Kelly Lab 数据尚未加载。</div>
    `;
  }
  if (!lab || typeof lab !== "object" || !lab.available) {
    const message = lab && typeof lab === "object"
      ? firstPresent(lab.error, lab.message, lab.reason, "Kelly Lab 数据不可用。")
      : "缺少 Kelly Lab 数据。";
    return `
      <div class="section-heading compact kelly-lab-heading">
        <div>
          <h2>模拟盘策略实验室</h2>
          <p>${escapeHtml(formatPlain(message))}</p>
        </div>
        <div class="kelly-lab-heading-actions">
          <span class="status-pill status-muted">不可用</span>
        </div>
      </div>
      <div class="kelly-lab-empty">${escapeHtml(formatPlain(message))}</div>
    `;
  }

  const experiments = Array.isArray(lab.experiments) ? lab.experiments : [];
  const count = hasValue(lab.experiment_count) ? lab.experiment_count : experiments.length;
  const activeExperiment = activeKellyExperiment(experiments);
  const activeExperimentId = activeExperiment ? kellyExperimentKey(activeExperiment, experiments.indexOf(activeExperiment)) : "";
  const cards = activeExperiment
    ? renderKellyExperimentCard(activeExperiment)
    : `<div class="kelly-lab-empty">暂无实验。</div>`;
  return `
    <div class="section-heading compact kelly-lab-heading">
      <div>
        <h2>模拟盘策略实验室</h2>
        <p>只读实验结果。</p>
      </div>
      <div class="kelly-lab-heading-actions">
        <span class="count-pill">${escapeHtml(formatDisplayNumber(count))} 个实验</span>
      </div>
    </div>
    ${renderKellyStrategyTabs(experiments, activeExperimentId)}
    <div class="kelly-experiment-grid single">
      ${cards}
    </div>
  `;
}

const KELLY_LIFECYCLE_STATUSES = [
  {
    key: "watching",
    label: "观察中",
    meaning: "该标的在策略监控范围内，但当前没有入场信号，也没有持仓。",
    systemAction: "持续检查入场规则。",
    nextStep: "入场规则触发后进入「待下单」。",
    className: "status-muted",
  },
  {
    key: "pending_entry_order",
    label: "待下单",
    meaning: "入场规则触发，仓位计算与风控检查待执行。",
    systemAction: "等待仓位计算与风控检查。",
    nextStep: "风控检查允许入场后提交买入；未允许则记录拦截。",
    className: "status-ok",
  },
  {
    key: "holding",
    label: "持仓中",
    meaning: "模拟盘买入已成交，这笔策略样本正在进行中。",
    systemAction: "持续检查止盈、止损、移动止盈、时间退出。",
    nextStep: "任一退出规则触发后进入「待退出」。",
    className: "status-ok",
  },
  {
    key: "pending_exit_order",
    label: "待退出",
    meaning: "这笔持仓已经触发退出规则，但卖出还没有完成。",
    systemAction: "准备向模拟盘提交卖出订单。",
    nextStep: "卖出成交后进入「已完成」；卖出失败进入「执行失败」。",
    className: "status-warn",
  },
  {
    key: "completed",
    label: "已完成",
    meaning: "买入和卖出都已成交，交易样本已经闭环。",
    systemAction: "把净盈亏、持有天数、退出原因计入样本统计。",
    nextStep: "更新胜率 p、盈亏比 b、Kelly 仓位参数。",
    className: "status-muted",
  },
  {
    key: "risk_blocked",
    label: "风控拦截",
    meaning: "入场规则触发了，但账户或组合风控不允许下单。",
    systemAction: "不下单，不计入完成样本，只记录拦截事件。",
    nextStep: "风控条件解除后重新评估。",
    className: "status-warn",
  },
  {
    key: "execution_failed",
    label: "执行失败",
    meaning: "系统本来应该下单或退出，但模拟盘接口、订单同步、撤单或成交确认失败。",
    systemAction: "停止自动推进，标记需要人工检查。",
    nextStep: "人工处理后可以重试、取消，或手动标记结果。",
    className: "status-failed",
  },
];

function activeKellyExperiment(experiments) {
  const items = Array.isArray(experiments) ? experiments : [];
  if (!items.length) {
    return null;
  }
  const selected = formatPlain(state.selectedKellyExperimentId);
  return items.find((experiment, index) => kellyExperimentKey(experiment, index) === selected) || items[0];
}

function kellyExperimentKey(experiment, index) {
  const entry = experiment && typeof experiment === "object" ? experiment : {};
  const strategyVersion = [entry.strategy_id, entry.strategy_version].filter(hasValue).map(formatPlain).join(":");
  return firstPresent(entry.experiment_id, strategyVersion, entry.experiment_name, `experiment-${index}`);
}

function renderKellyStrategyTabs(experiments, activeExperimentId) {
  const items = Array.isArray(experiments) ? experiments : [];
  if (!items.length) {
    return "";
  }
  return `
    <div class="kelly-strategy-tabs" role="tablist" aria-label="Kelly 策略">
      ${items.map((experiment, index) => {
        const entry = experiment && typeof experiment === "object" ? experiment : {};
        const template = entry.template && typeof entry.template === "object" ? entry.template : {};
        const experimentId = kellyExperimentKey(entry, index);
        const active = experimentId === activeExperimentId;
        const label = firstPresent(entry.experiment_name, template.strategy_name, entry.strategy_id, "未命名策略");
        const detail = [entry.strategy_id, template.strategy_name, entry.strategy_version]
          .filter(hasValue)
          .map(formatPlain)
          .join(" · ");
        return `
          <button
            class="kelly-strategy-tab ${active ? "active" : ""}"
            type="button"
            role="tab"
            aria-selected="${active ? "true" : "false"}"
            data-kelly-experiment="${escapeHtml(formatPlain(experimentId))}"
          >
            <span>${escapeHtml(formatPlain(label))}</span>
            ${detail ? `<small>${escapeHtml(detail)}</small>` : ""}
          </button>
        `;
      }).join("")}
    </div>
  `;
}

function renderKellySymbolStates(experiment) {
  const entry = experiment && typeof experiment === "object" ? experiment : {};
  const lifecycleSamples = Array.isArray(entry.lifecycle_states)
    ? entry.lifecycle_states.filter((sample) => sample && typeof sample === "object")
    : [];
  const participants = Array.isArray(entry.participants)
    ? entry.participants.filter((participant) => participant && typeof participant === "object")
    : [];
  const samples = lifecycleSamples.length
    ? lifecycleSamples
    : participants.map((participant) => ({
      ...participant,
      status: "watching",
      reason: "等待该策略下一次入场信号。",
    }));
  if (!samples.length) {
    return "";
  }

  return `
    <section class="kelly-symbol-states" aria-label="Kelly 标的状态">
      <div class="kelly-symbol-states-header">
        <h4>标的状态</h4>
        <p>观察中 → 待下单 → 持仓中 → 待退出 → 已完成</p>
      </div>
      <div class="kelly-symbol-state-grid">
        ${samples.map(renderKellySymbolState).join("")}
      </div>
    </section>
  `;
}

function renderKellyOrderSync(experiment) {
  const entry = experiment && typeof experiment === "object" ? experiment : {};
  const sync = entry.order_sync && typeof entry.order_sync === "object" ? entry.order_sync : null;
  if (!sync) {
    return "";
  }
  const status = kellyOrderSyncStatus(sync.status);
  const rows = [
    ["环境", sync.environment],
    ["最近同步", sync.last_synced_at],
    ["订单", formatDisplayNumber(sync.order_count)],
    ["成交", formatDisplayNumber(sync.fill_count)],
  ];
  return `
    <section class="kelly-order-sync" aria-label="Kelly 订单同步">
      <div class="kelly-order-sync-header">
        <h4>订单同步</h4>
        <span class="status-pill ${escapeHtml(status.className)}">${escapeHtml(status.label)}</span>
      </div>
      <dl class="kelly-order-sync-grid">
        ${rows.map(([label, value]) => `
          <div>
            <dt>${escapeHtml(label)}</dt>
            <dd>${escapeHtml(formatPlain(value))}</dd>
          </div>
        `).join("")}
      </dl>
      ${hasValue(sync.message) ? `<p>${escapeHtml(formatPlain(sync.message))}</p>` : ""}
      ${hasValue(sync.next_action) ? `<small>${escapeHtml(formatPlain(sync.next_action))}</small>` : ""}
      ${renderKellyOrderSyncOrders(sync)}
    </section>
  `;
}

function renderKellyOrderSyncOrders(sync) {
  const orders = sync && Array.isArray(sync.orders)
    ? sync.orders.filter((order) => order && typeof order === "object")
    : [];
  if (!orders.length) {
    return `<p class="kelly-order-empty">暂无同步订单明细。</p>`;
  }
  const headers = ["标的", "方向", "下单时间", "订单价", "订单数量", "成交数量", "成交均价", "状态"];
  return `
    <div class="kelly-order-table" role="table" aria-label="Kelly 同步订单明细">
      <div class="kelly-order-row header" role="row">
        ${headers.map((header) => `<span role="columnheader">${escapeHtml(header)}</span>`).join("")}
      </div>
      ${orders.map(renderKellyOrderSyncOrder).join("")}
    </div>
  `;
}

function renderKellyOrderSyncOrder(order) {
  const item = order && typeof order === "object" ? order : {};
  const symbol = [item.market, item.symbol]
    .filter(hasValue)
    .map(formatPlain)
    .join(".");
  const symbolCell = `
    <strong>${escapeHtml(firstPresent(symbol, item.symbol, "-"))}</strong>
    ${hasValue(item.order_id) ? `<small>${escapeHtml(formatPlain(item.order_id))}</small>` : ""}
  `;
  const cells = [
    symbolCell,
    escapeHtml(kellyOrderSideLabel(item.side)),
    escapeHtml(formatPlain(item.submitted_at || "-")),
    escapeHtml(formatDisplayNumber(item.order_price)),
    escapeHtml(formatDisplayNumber(item.order_qty)),
    escapeHtml(formatDisplayNumber(item.filled_qty)),
    escapeHtml(formatDisplayNumber(item.avg_fill_price)),
    escapeHtml(kellyOrderStatusLabel(item.status)),
  ];
  return `
    <div class="kelly-order-row" role="row">
      ${cells.map((cell) => `<span role="cell">${cell}</span>`).join("")}
    </div>
  `;
}

function renderKellyOrderExecution(experiment) {
  const entry = experiment && typeof experiment === "object" ? experiment : {};
  const execution = entry.order_execution && typeof entry.order_execution === "object"
    ? entry.order_execution
    : null;
  if (!execution) {
    return "";
  }
  const status = kellyOrderExecutionStatus(execution.status);
  const rows = [
    ["环境", execution.environment],
    ["最近执行", execution.last_executed_at],
    ["执行", formatDisplayNumber(execution.execution_count)],
    ["预演", formatDisplayNumber(execution.dry_run_count)],
    ["提交", formatDisplayNumber(execution.submitted_count)],
    ["跳过", formatDisplayNumber(execution.skipped_count)],
    ["失败", formatDisplayNumber(execution.failed_count)],
  ];
  return `
    <section class="kelly-order-sync" aria-label="Kelly 订单执行">
      <div class="kelly-order-sync-header">
        <h4>订单执行</h4>
        <span class="status-pill ${escapeHtml(status.className)}">${escapeHtml(status.label)}</span>
      </div>
      <dl class="kelly-order-sync-grid">
        ${rows.map(([label, value]) => `
          <div>
            <dt>${escapeHtml(label)}</dt>
            <dd>${escapeHtml(formatPlain(value))}</dd>
          </div>
        `).join("")}
      </dl>
      ${hasValue(execution.message) ? `<p>${escapeHtml(formatPlain(execution.message))}</p>` : ""}
      ${renderKellyOrderExecutionRows(execution)}
    </section>
  `;
}

function renderKellyOrderExecutionRows(execution) {
  const executions = execution && Array.isArray(execution.executions)
    ? execution.executions.filter((item) => item && typeof item === "object")
    : [];
  if (!executions.length) {
    return `<p class="kelly-order-empty">暂无订单执行明细。</p>`;
  }
  const headers = ["标的", "方向", "价格", "数量", "计划金额", "富途订单", "状态", "错误"];
  return `
    <div class="kelly-order-table" role="table" aria-label="Kelly 订单执行明细">
      <div class="kelly-order-row header" role="row">
        ${headers.map((header) => `<span role="columnheader">${escapeHtml(header)}</span>`).join("")}
      </div>
      ${executions.map(renderKellyOrderExecutionRow).join("")}
    </div>
  `;
}

function renderKellyOrderExecutionRow(execution) {
  const item = execution && typeof execution === "object" ? execution : {};
  const symbol = firstPresent(
    item.futu_code,
    [item.market, item.symbol].filter(hasValue).map(formatPlain).join("."),
    item.symbol,
    "-",
  );
  const symbolCell = `
    <strong>${escapeHtml(formatPlain(symbol))}</strong>
    ${hasValue(item.executed_at) ? `<small>${escapeHtml(formatPlain(item.executed_at))}</small>` : ""}
  `;
  const cells = [
    symbolCell,
    escapeHtml(kellyOrderSideLabel(item.side)),
    escapeHtml(formatDisplayNumber(item.price)),
    escapeHtml(formatDisplayNumber(item.qty)),
    escapeHtml(formatDisplayNumber(item.planned_notional)),
    escapeHtml(formatPlain(item.futu_order_id || "-")),
    escapeHtml(kellyExecutionStatusLabel(item.execution_status)),
    escapeHtml(formatPlain(item.error || "-")),
  ];
  return `
    <div class="kelly-order-row" role="row">
      ${cells.map((cell) => `<span role="cell">${cell}</span>`).join("")}
    </div>
  `;
}

function kellyOrderSideLabel(side) {
  const labels = {
    buy: "买入",
    sell: "卖出",
  };
  const key = formatPlain(side).toLowerCase();
  return labels[key] || firstPresent(side, "-");
}

function kellyExecutionStatusLabel(status) {
  const labels = {
    dry_run: "预演",
    failed: "执行失败",
    skipped: "已跳过",
    submitted: "已提交",
  };
  const key = formatPlain(status).toLowerCase();
  return labels[key] || firstPresent(status, "-");
}

function kellyOrderStatusLabel(status) {
  const labels = {
    cancelled: "已撤单",
    failed: "失败",
    filled: "已成交",
    partial_filled: "部分成交",
    pending: "待成交",
    rejected: "拒单",
    submitted: "待成交",
  };
  const key = formatPlain(status).toLowerCase();
  return labels[key] || firstPresent(status, "-");
}

function kellyOrderExecutionStatus(status) {
  const labels = {
    failed: { label: "执行失败", className: "status-failed" },
    partial: { label: "部分执行", className: "status-partial" },
    running: { label: "执行中", className: "status-partial" },
    success: { label: "执行成功", className: "status-ok" },
  };
  const key = formatPlain(status).toLowerCase();
  return labels[key] || { label: firstPresent(status, "未执行"), className: "status-muted" };
}

function kellyOrderSyncStatus(status) {
  const labels = {
    failed: { label: "同步失败", className: "status-failed" },
    ok: { label: "同步成功", className: "status-ok" },
    partial: { label: "部分同步", className: "status-partial" },
    running: { label: "同步中", className: "status-partial" },
    stale: { label: "同步过期", className: "status-stale" },
    success: { label: "同步成功", className: "status-ok" },
  };
  const key = formatPlain(status).toLowerCase();
  return labels[key] || { label: firstPresent(status, "未同步"), className: "status-muted" };
}

function renderKellySymbolState(sample) {
  const item = sample && typeof sample === "object" ? sample : {};
  const status = kellyLifecycleStatus(item.status);
  const symbol = [item.market, item.symbol]
    .filter(hasValue)
    .map(formatPlain)
    .join(".");
  return `
    <article class="kelly-symbol-state-card">
      <div class="kelly-symbol-state-heading">
        <strong>${escapeHtml(firstPresent(symbol, item.symbol, "未命名标的"))}</strong>
        <span class="status-pill ${escapeHtml(status.className)}">${escapeHtml(status.label)}</span>
      </div>
      <p>${escapeHtml(formatPlain(item.reason))}</p>
      <dl>
        <div>
          <dt>状态含义</dt>
          <dd>${escapeHtml(formatPlain(status.meaning))}</dd>
        </div>
        <div>
          <dt>系统动作</dt>
          <dd>${escapeHtml(firstPresent(item.action, status.systemAction))}</dd>
        </div>
        <div>
          <dt>下一步</dt>
          <dd>${escapeHtml(formatPlain(status.nextStep))}</dd>
        </div>
      </dl>
      ${hasValue(item.updated_at) ? `<small>${escapeHtml(formatPlain(item.updated_at))}</small>` : ""}
    </article>
  `;
}

function kellyLifecycleStatus(status) {
  const key = formatPlain(status);
  return KELLY_LIFECYCLE_STATUSES.find((item) => item.key === key)
    || { label: key, className: "status-muted" };
}

function renderKellyStrategyCapital(experiment) {
  const entry = experiment && typeof experiment === "object" ? experiment : {};
  const capital = entry.capital && typeof entry.capital === "object" ? entry.capital : null;
  if (!capital || capital.available === false) {
    return `
      <section class="kelly-strategy-capital unavailable" aria-label="Kelly 策略资金">
        <div class="kelly-strategy-capital-header">
          <div>
            <h4>策略资金</h4>
            <p>策略资金数据暂不可用。</p>
          </div>
        </div>
      </section>
    `;
  }

  const currency = formatPlain(firstPresent(capital.currency, entry.budget_currency, "USD"));
  const positionWidth = capitalSegmentWidth(capital.position_notional, capital.budget);
  const reservedWidth = capitalSegmentWidth(capital.reserved_order_notional, capital.budget, positionWidth);
  const utilization = hasValue(capital.utilization_pct)
    ? `${formatPlain(capital.utilization_pct)}%`
    : "";
  const metrics = [
    ["总资金", formatCapitalMoney(capital.budget, currency), ""],
    ["已占用", formatCapitalMoney(capital.occupied_notional, currency), ""],
    ["可用资金", formatCapitalMoney(capital.available_notional, currency), "primary"],
    ["占用率", firstPresent(utilization, "-"), ""],
    ["未完成买单", formatDisplayNumber(capital.open_buy_order_count), ""],
    ["已实现盈亏", formatSignedMoney(capital.realized_pnl, currency), pnlClass(capital.realized_pnl)],
  ];
  return `
    <section class="kelly-strategy-capital" aria-label="Kelly 策略资金">
      <div class="kelly-strategy-capital-header">
        <div>
          <h4>策略资金</h4>
          ${hasValue(capital.updated_at) ? `<p>更新于 ${escapeHtml(formatPlain(capital.updated_at))}</p>` : ""}
        </div>
      </div>
      <dl class="kelly-capital-metric-grid">
        ${metrics.map(([label, value, className]) => `
          <div${className ? ` class="${escapeHtml(className)}"` : ""}>
            <dt>${escapeHtml(label)}</dt>
            <dd>${escapeHtml(formatPlain(value))}</dd>
          </div>
        `).join("")}
      </dl>
      <div class="kelly-capital-utilization-bar" aria-label="Kelly 资金占用率">
        <span class="position" style="width: ${escapeHtml(formatPlain(positionWidth))}%"></span>
        <span class="reserved" style="width: ${escapeHtml(formatPlain(reservedWidth))}%"></span>
      </div>
      <div class="kelly-capital-breakdown-grid">
        ${renderKellyCapitalBreakdownPane(capital, currency)}
        ${renderKellyCapitalSymbolPane(capital, currency)}
        ${renderKellyCapitalNextOrderPane(capital, currency)}
      </div>
    </section>
  `;
}

function renderKellyCapitalBreakdownPane(capital, currency) {
  const rows = [
    ["持仓占用", formatCapitalMoney(capital.position_notional, currency)],
    ["待成交买单", formatCapitalMoney(capital.reserved_order_notional, currency)],
    ["保守口径 / 买单提交即占用", "已启用"],
  ];
  return `
    <div class="kelly-capital-pane">
      <h5>占用拆分</h5>
      ${rows.map(([label, value]) => renderKellyCapitalLine(label, value)).join("")}
    </div>
  `;
}

function renderKellyCapitalSymbolPane(capital, currency) {
  const occupancy = kellyCapitalSymbolOccupancy(capital.symbol_occupancy);
  const lines = occupancy.length
    ? occupancy.map((item) => {
      const symbol = kellyCapitalSymbol(item);
      const value = firstPresent(item.occupied_notional, item.notional, item.value);
      return renderKellyCapitalLine(symbol, formatCapitalMoney(value, currency));
    }).join("")
    : renderKellyCapitalLine("标的", "暂无占用");
  return `
    <div class="kelly-capital-pane">
      <h5>标的占用</h5>
      ${lines}
    </div>
  `;
}

function renderKellyCapitalNextOrderPane(capital, currency) {
  const impact = capital.next_order_impact && typeof capital.next_order_impact === "object"
    ? capital.next_order_impact
    : null;
  if (!impact) {
    return `
      <div class="kelly-capital-pane">
        <h5>下一笔下单影响</h5>
        ${renderKellyCapitalLine("状态", "暂无待评估订单")}
      </div>
    `;
  }
  const status = kellyCapitalRiskStatus(impact.risk_status);
  const rows = [
    ["标的", kellyCapitalSymbol(impact)],
    ["预计金额", formatCapitalMoney(impact.estimated_notional, currency)],
    ["下单后可用", formatCapitalMoney(impact.available_after_order, currency)],
    ["风控", status],
  ];
  if (hasValue(impact.reason)) {
    rows.push(["原因", impact.reason]);
  }
  return `
    <div class="kelly-capital-pane">
      <h5>下一笔下单影响</h5>
      ${rows.map(([label, value]) => renderKellyCapitalLine(label, value)).join("")}
    </div>
  `;
}

function kellyCapitalSymbolOccupancy(value) {
  if (Array.isArray(value)) {
    return value.filter((item) => item && typeof item === "object");
  }
  if (value && typeof value === "object") {
    return Object.entries(value).map(([symbol, notional]) => {
      if (notional && typeof notional === "object") {
        return { symbol, ...notional };
      }
      return { symbol, occupied_notional: notional };
    });
  }
  return [];
}

function kellyCapitalSymbol(value) {
  const item = value && typeof value === "object" ? value : {};
  const rawSymbol = firstPresent(item.symbol, item.code);
  const formattedSymbol = hasValue(rawSymbol) ? formatPlain(rawSymbol) : "";
  const marketSymbol = formattedSymbol.includes(".")
    ? formattedSymbol
    : [item.market, formattedSymbol]
    .filter(hasValue)
    .map(formatPlain)
    .join(".");
  return firstPresent(item.futu_code, marketSymbol, formattedSymbol, "-");
}

function renderKellyCapitalLine(label, value) {
  return `
    <div class="kelly-capital-line">
      <span>${escapeHtml(formatPlain(label))}</span>
      <strong>${escapeHtml(formatPlain(value))}</strong>
    </div>
  `;
}

function kellyCapitalRiskStatus(status) {
  const key = formatPlain(status).toLowerCase();
  if (key === "approved" || key === "ok" || key === "pass") {
    return "资金足够";
  }
  if (key === "blocked" || key === "failed" || key === "rejected") {
    return "资金不足";
  }
  return firstPresent(status, "-");
}

function formatCapitalMoney(value, currency) {
  if (!hasValue(value)) {
    return "-";
  }
  return formatMoney(value, currency);
}

function capitalSegmentWidth(value, budget, offset = 0) {
  const amount = Number.parseFloat(String(value || "").replace(/,/g, ""));
  const total = Number.parseFloat(String(budget || "").replace(/,/g, ""));
  const used = Number.parseFloat(String(offset || ""));
  if (!Number.isFinite(amount) || !Number.isFinite(total) || total <= 0) {
    return 0;
  }
  const raw = Math.min(100, Math.max(0, (amount / total) * 100));
  return Math.min(raw, Math.max(0, 100 - (Number.isFinite(used) ? used : 0)));
}

function renderKellyExperimentCard(experiment) {
  const entry = experiment && typeof experiment === "object" ? experiment : {};
  const template = entry.template && typeof entry.template === "object" ? entry.template : {};
  const stats = entry.stats && typeof entry.stats === "object" ? entry.stats : {};
  const name = firstPresent(entry.experiment_name, entry.experiment_id, "未命名实验");
  const status = kellyExperimentStatusLabel(entry.status);
  const stage = kellySampleStageLabel(stats.sample_stage);
  const strategyId = formatPlain(template.strategy_id);
  const strategyName = formatPlain(template.strategy_name);
  const strategyVersion = hasValue(template.strategy_version) ? ` · ${formatPlain(template.strategy_version)}` : "";
  const ruleDescriptions = kellyStrategyRuleDescriptions(template);
  const entrySummary = firstPresent(ruleDescriptions.entry, template.entry_rule_description);
  const budget = hasValue(entry.experiment_budget)
    ? `${formatMoney(entry.experiment_budget, formatPlain(entry.budget_currency || "USD"))}`
    : "-";
  const pool = kellyMarketCapitalPool(entry);
  const metricRows = [
    ["市场", entry.market],
    ["模拟资金池", pool],
    ["阶段", stage],
    ["已完成", formatDisplayNumber(stats.completed_samples)],
    ["进行中", formatDisplayNumber(stats.open_samples)],
    ["胜率", stats.observed_win_rate],
    ["预算", budget],
    ["资金使用", hasValue(entry.capital_utilization_pct) ? `${formatPlain(entry.capital_utilization_pct)}%` : ""],
  ];
  return `
    <article class="kelly-experiment-card">
      <header class="kelly-experiment-card-header">
        <div>
          <h3>${escapeHtml(formatPlain(name))}</h3>
          <span>${escapeHtml(strategyId)} · ${escapeHtml(strategyName)}${escapeHtml(strategyVersion)}</span>
        </div>
        <span class="status-pill ${escapeHtml(status.className)}">${escapeHtml(status.label)}</span>
      </header>
      <p class="kelly-entry-rule">${escapeHtml(formatPlain(entrySummary))}</p>
      ${renderKellyStrategyCapital(entry)}
      ${renderKellyOrderSync(entry)}
      ${renderKellyOrderExecution(entry)}
      ${renderKellyStrategyRules(template, ruleDescriptions)}
      <dl class="kelly-stat-grid">
        ${metricRows.map(([label, value]) => `
          <div>
            <dt>${escapeHtml(label)}</dt>
            <dd>${escapeHtml(formatPlain(value))}</dd>
          </div>
        `).join("")}
      </dl>
      ${renderKellyParameterDerivation(stats)}
      ${renderKellySymbolStates(entry)}
    </article>
  `;
}

function kellyMarketCapitalPool(experiment) {
  const entry = experiment && typeof experiment === "object" ? experiment : {};
  const pool = entry.market_capital_pool && typeof entry.market_capital_pool === "object"
    ? entry.market_capital_pool
    : {};
  if (pool.enabled === false) {
    return "未启用";
  }
  const currency = firstPresent(pool.currency, entry.budget_currency);
  const amount = firstPresent(pool.amount, entry.experiment_budget);
  return hasValue(currency) && hasValue(amount) ? `${formatPlain(currency)} ${formatDisplayNumber(amount)}` : "";
}

function renderKellyStrategyRules(template, ruleDescriptions) {
  const item = template && typeof template === "object" ? template : {};
  const generated = ruleDescriptions && typeof ruleDescriptions === "object" ? ruleDescriptions : {};
  const ruleRows = [
    ["入场", firstPresent(generated.entry, item.entry_rule_description)],
    ["止损", firstPresent(generated.stopLoss, item.stop_loss_rule_description)],
    ["止盈", firstPresent(generated.takeProfit, item.take_profit_rule_description)],
    ["移动止盈", firstPresent(generated.trailingStop, item.trailing_stop_rule_description)],
    ["时间退出", firstPresent(generated.timeExit, item.time_exit_rule_description)],
  ];
  if (
    !hasValue(generated.stopLoss)
    && !hasValue(item.stop_loss_rule_description)
    && !hasValue(generated.takeProfit)
    && !hasValue(item.take_profit_rule_description)
  ) {
    ruleRows.push(["退出", item.exit_rule_description]);
  }
  const visibleRows = ruleRows.filter(([, value]) => hasValue(value));
  if (!visibleRows.length) {
    return "";
  }

  return `
    <section class="kelly-strategy-rules" aria-label="Kelly 策略详情">
      <h4>策略详情</h4>
      <div class="kelly-rule-grid">
        ${visibleRows.map(([label, value]) => `
          <div>
            <span>${escapeHtml(label)}</span>
            <strong>${escapeHtml(formatPlain(value))}</strong>
          </div>
        `).join("")}
      </div>
    </section>
  `;
}

function kellyStrategyRuleDescriptions(template) {
  const rules = template && template.rules && typeof template.rules === "object"
    ? template.rules
    : {};
  return {
    entry: describeKellyRule(rules.entry, "entry"),
    stopLoss: describeKellyRule(rules.stop_loss, "stop_loss"),
    takeProfit: describeKellyRule(rules.take_profit, "take_profit"),
    trailingStop: describeKellyRule(rules.trailing_stop, "trailing_stop"),
    timeExit: describeKellyRule(rules.time_exit, "time_exit"),
  };
}

function describeKellyRule(rule, slot) {
  const item = rule && typeof rule === "object" ? rule : {};
  const type = formatPlain(item.type);
  if (slot === "entry" && type === "pullback_to_moving_average") {
    const trend = item.trend_filter && typeof item.trend_filter === "object" ? item.trend_filter : {};
    const direction = trend.direction === "up" ? "向上" : formatPlain(trend.direction);
    const trendText = hasValue(trend.ma_days)
      ? `，且 ${formatPlain(trend.ma_days)} 日均线斜率${direction}`
      : "";
    const tolerance = hasValue(item.tolerance_pct) ? ` ±${formatPlain(item.tolerance_pct)}% 内` : "附近";
    return `价格回调到 ${formatPlain(item.ma_days)} 日均线${tolerance}${trendText}。`;
  }
  if (slot === "entry" && type === "volume_breakout_high") {
    const volumeText = hasValue(item.volume_multiple)
      ? `，成交量不低于 ${formatPlain(item.volume_multiple)} 倍均量`
      : "";
    return `价格放量突破近 ${formatPlain(item.lookback_days)} 个交易日高点${volumeText}。`;
  }
  if (slot === "stop_loss" && ["any_of", "min_of"].includes(type)) {
    const children = Array.isArray(item.rules) ? item.rules : [];
    const parts = children
      .map((child) => describeKellyRuleFragment(child, "stop_loss"))
      .filter(hasValue);
    return parts.length ? `${parts.join(" 或")}。` : "";
  }
  if (slot === "take_profit" && type === "risk_multiple") {
    return `价格达到入场价 + ${formatPlain(item.trigger_r)}R 时卖出 ${formatPlain(item.sell_pct)}%。`;
  }
  if (slot === "trailing_stop" && type === "close_below_moving_average") {
    return `剩余仓位收盘跌破 ${formatPlain(item.ma_days)} 日均线时退出。`;
  }
  if (slot === "trailing_stop" && type === "close_below_recent_low") {
    return `剩余仓位收盘跌破最近 ${formatPlain(item.lookback_days)} 日最低价时退出。`;
  }
  if (slot === "time_exit" && type === "max_holding_days") {
    if (item.exit_if === "no_take_profit_or_stop_loss") {
      return `持有满 ${formatPlain(item.days)} 个交易日仍未触发止盈或止损则退出。`;
    }
    if (item.exit_if === "minimum_unrealized_r_not_reached") {
      return `持有满 ${formatPlain(item.days)} 个交易日仍未达到 ${formatPlain(item.min_unrealized_r)}R 浮盈则退出。`;
    }
    return `持有满 ${formatPlain(item.days)} 个交易日则退出。`;
  }
  return "";
}

function describeKellyRuleFragment(rule, slot) {
  const item = rule && typeof rule === "object" ? rule : {};
  const type = formatPlain(item.type);
  if (slot === "stop_loss" && type === "pct_below_moving_average") {
    return `跌破 ${formatPlain(item.ma_days)} 日均线 ${formatPlain(item.pct)}%`;
  }
  if (slot === "stop_loss" && type === "recent_swing_low_break") {
    return "跌破最近波段低点";
  }
  if (slot === "stop_loss" && type === "pct_below_reference_price") {
    return `跌回${formatPlain(item.reference || "参考价")}下方 ${formatPlain(item.pct)}%`;
  }
  if (slot === "stop_loss" && type === "atr_below_entry") {
    return `跌破入场价 - ${formatPlain(item.atr_multiple)} ATR`;
  }
  return "";
}

function renderKellyParameterDerivation(stats) {
  const item = stats && typeof stats === "object" ? stats : {};
  const sampleStageLabel = item.sample_stage === "sufficient"
    ? "样本充足"
    : item.sample_stage === "insufficient"
      ? "样本不足"
      : item.sample_stage;
  const hasDerivation = [
    item.sample_stage,
    item.completed_samples,
    item.open_samples,
    item.raw_win_rate,
    item.adjusted_win_rate,
    item.payoff_ratio,
    item.full_kelly_pct,
    item.fractional_kelly_pct,
    item.suggested_position_pct,
    item.sample_adjustment,
    item.parameter_source,
    item.skipped_order_count,
    item.source_trade_samples_generated_at,
    item.last_sample_closed_at,
    item.last_recomputed_at,
  ].some(hasValue);
  if (!hasDerivation) {
    return "";
  }

  const winLossCount = hasValue(item.winning_samples) || hasValue(item.losing_samples)
    ? `${formatDisplayNumber(item.winning_samples)} 赢 / ${formatDisplayNumber(item.losing_samples)} 亏`
    : "";
  const payoffRatio = hasValue(item.payoff_ratio) ? formatDisplayNumber(item.payoff_ratio) : "";
  const payoffDetail = [item.avg_net_win_pct, item.avg_net_loss_pct]
    .filter(hasValue)
    .map(formatSignedPnl)
    .join(" / ");
  const sourceLabel = item.parameter_source === "futu_paper_order_samples"
    ? "富途模拟盘订单样本"
    : item.parameter_source;
  const rows = [
    ["样本状态", sampleStageLabel],
    ["已完成样本", hasValue(item.completed_samples) ? formatDisplayNumber(item.completed_samples) : item.completed_samples],
    ["进行中样本", hasValue(item.open_samples) ? formatDisplayNumber(item.open_samples) : item.open_samples],
    ["原始胜率", [item.raw_win_rate, winLossCount].filter(hasValue).map(formatPlain).join(" · ")],
    ["修正胜率", [item.adjusted_win_rate, item.sample_adjustment].filter(hasValue).map(formatPlain).join(" · ")],
    ["盈亏比 b", [payoffRatio, payoffDetail].filter(hasValue).map(formatPlain).join(" · ")],
    ["Full Kelly", item.full_kelly_pct],
    ["保守 Kelly", item.fractional_kelly_pct],
    ["建议仓位", item.suggested_position_pct],
    ["参数来源", sourceLabel],
    ["跳过订单", hasValue(item.skipped_order_count) ? formatDisplayNumber(item.skipped_order_count) : item.skipped_order_count],
    ["来源样本时间", item.source_trade_samples_generated_at],
    ["最近完成样本", item.last_sample_closed_at],
    ["最近计算", item.last_recomputed_at],
  ].filter(([, value]) => hasValue(value));

  return `
    <section class="kelly-derivation" aria-label="Kelly 参数推导">
      <h4>参数推导</h4>
      <div class="kelly-derivation-grid">
        ${rows.map(([label, value]) => `
          <div>
            <span>${escapeHtml(label)}</span>
            <strong>${escapeHtml(formatPlain(value))}</strong>
          </div>
        `).join("")}
      </div>
      <p>f* = p - (1 - p) / b</p>
    </section>
  `;
}

let predictionModal = {kind: "", previousFocus: null, busy: false, epoch: 0, data: null};

function predictionValue(value, fallback = "-") {
  return value === null || value === undefined || value === "" ? fallback : String(value);
}

function predictionHktTimestamp(value, fallback = "-") {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return predictionValue(value, fallback);
  const formatted = new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Hong_Kong",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(date).replace(/\//g, "-");
  return `${formatted} HKT`;
}

function predictionRelativeAge(value, now = Date.now()) {
  const timestamp = new Date(value).getTime();
  if (!Number.isFinite(timestamp)) return "";
  const seconds = Math.max(0, Math.floor((Number(now) - timestamp) / 1000));
  if (seconds < 5) return "刚刚";
  if (seconds < 60) return `${seconds} 秒前`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} 分钟前`;
  const hours = Math.floor(minutes / 60);
  return `${hours} 小时前`;
}

function predictionClock(label, value, {danger = false} = {}) {
  const timestamp = predictionHktTimestamp(value);
  const age = predictionRelativeAge(value);
  const suffix = age ? `（${age}）` : "";
  return `<span class="pm-clock${danger ? " pm-clock-danger" : ""}"><span>${escapeHtml(label)}：${escapeHtml(timestamp)}</span>${suffix ? `<small>${escapeHtml(suffix)}</small>` : ""}</span>`;
}

function predictionNumber(value, fallback = "-") {
  const number = Number(value);
  return Number.isFinite(number) ? number.toLocaleString("en-US", {maximumFractionDigits: 2}) : fallback;
}

function predictionMoney(value, fallback = "-") {
  const number = Number(value);
  return Number.isFinite(number) ? `$${number.toFixed(2)}` : (String(value || fallback));
}

function predictionExactMoney(value, fallback = "-") {
  if (value === null || value === undefined || String(value).trim() === "") return fallback;
  const text = String(value).trim();
  if (!/^-?(?:\d+|\d*\.\d+)$/.test(text)) return fallback;
  return `$${text}`;
}

function predictionNLegUnitsMoney(value, fallback = "-") {
  const number = Number(value);
  return Number.isFinite(number) ? `$${(number / 1000000).toFixed(2)}` : (String(value || fallback));
}

function predictionPrice(value, fallback = "-") {
  const number = Number(value);
  return Number.isFinite(number) ? `$${number.toFixed(3)}` : (String(value || fallback));
}

function predictionSignedMoney(value, fallback = "-") {
  const number = Number(value);
  return Number.isFinite(number) ? `${number >= 0 ? "+" : "-"}$${Math.abs(number).toFixed(2)}` : fallback;
}

function predictionVolume(value, fallback = "-") {
  const number = Number(value);
  if (!Number.isFinite(number)) return String(value || fallback);
  if (Math.abs(number) >= 1000000) return `$${(number / 1000000).toFixed(number % 1000000 ? 1 : 0)}M`;
  if (Math.abs(number) >= 1000) return `$${(number / 1000).toFixed(number % 1000 ? 1 : 0)}K`;
  return `$${number.toFixed(2)}`;
}

function predictionTone(value) {
  const text = String(value || "").toLowerCase();
  if (text.includes("fail") || text.includes("error") || text.includes("block") || text.includes("lock") || text.includes("禁止") || text.includes("事故") || text.includes("熔断")) return "pm-tone-danger";
  if (text.includes("warn") || text.includes("check") || text.includes("执行") || text.includes("等待") || text.includes("待")) return "pm-tone-warning";
  return "pm-tone-ok";
}

function predictionReasonLabel(value) {
  const raw = String(value || "").trim();
  if (!raw) return "暂不可参与";
  const key = raw.toLowerCase();
  const labels = {
    neg_risk: "已订阅 · Negative Risk 暂不可参与",
    fee_unverified_or_enabled: "已订阅 · 收费市场不可参与",
    readiness_stale: "交易检查未完成",
    readiness_unavailable: "交易账户检查不可用",
    book_stale: "盘口过期，等待更新",
    remediation_unsafe: "安全补救路径未通过",
    insufficient_funds: "余额或授权不足",
    llm_rejected: "LLM 校验拒绝",
    deterministic_rejected: "确定性规则校验拒绝",
    llm_unavailable: "LLM 校验不可用",
    no_threshold_candidate: "已订阅 · 净利润未达到策略门槛",
    monitor_degraded: "数据连接异常，暂不可参与",
    opportunity_unavailable: "机会已变化或已失效",
    annualized_yield_below_minimum: "年化低于 15% 入场门槛",
    annualized_yield_unavailable: "年化无法计算，禁止入场",
    operator_paused: "操作员已暂停自动下单",
    notification_delivery_failed: "通知发送失败，已暂停自动下单",
    not_armed: "自动下单未启用",
    scope_observe_only: "当前范围只读 · 不可下单",
    partial_fill_proof_required: "缺少成交证明 · 不可下单",
    execution_fingerprint_mismatch: "方案指纹已变化 · 资格失效",
    unsettled_cap_exceeded: "超出未结算资金上限",
    manual_canary: "手动模式 · 可人工确认下单",
    manual_canary_requires_manual: "手动模式 · 当前范围不可下单",
    insufficient_depth: "盘口深度不足",
    fee_charging_unmodeled: "收费市场，费用未建模，禁止下单",
    fee_unknown: "费率未知，禁止下单",
  };
  return labels[key] || raw.replaceAll("_", " ");
}

function predictionIncidentReasonLabel(value) {
  const raw = String(value || "").trim();
  const labels = {
    one_leg_fill: "YES 成交、NO 被拒",
    no_safe_remediation: "未找到安全处置方案",
    remediation_unverified: "自动处置未确认",
    remediation_reconciliation_unverified: "处置后持仓未确认归零",
    remediation_merge_not_confirmed: "处置后的合并未确认",
    startup_open_orders: "重启时发现未完成订单",
    startup_directional_imbalance: "重启时发现单腿持仓",
    merge_not_confirmed: "合并未确认",
  };
  if (raw === "cross_dust") return "残余头寸（dust incident）";
  if (raw === "cross_circuit_breaker_open") return "跨所熔断";
  return labels[raw] || predictionReasonLabel(raw);
}

function predictionIncidentStatusLabel(value) {
  const raw = String(value || "").trim();
  const labels = {
    resolved_clean: "已确认无敞口 · 已解除熔断",
    directional_incident: "已消除敞口 · 待解除熔断",
    neutralized_incident: "已处置 · 待解除熔断",
    merge_incident: "合并未确认 · 待人工处理",
    remediating: "自动处置中",
  };
  if (raw === "dust_incident") return "残余头寸待人工处理（dust incident）";
  return labels[raw] || raw;
}

function predictionExecutionStatusLabel(value) {
  const raw = String(value || "").trim();
  if (raw === "submit_failed_cleared") return "下单失败 · 已核实无成交，自动恢复";
  return raw;
}

function predictionGeoblockLabel(value) {
  const raw = String(value || "").trim().toLowerCase();
  if (["allowed", "allow", "ok", "ready", "pass"].includes(raw)) return "允许交易";
  if (["blocked", "denied", "fail", "failed", "error"].includes(raw)) return "检查失败";
  return value;
}

function predictionHealthIsNormal(payload) {
  return payload?.stale !== true
    && String(payload?.health?.status || "").trim().toLowerCase() === "healthy";
}

function predictionWatcherIsConnected(payload) {
  const overall = String(payload?.status || payload?.health?.status || "").trim().toLowerCase();
  if (["unavailable", "unknown", "mystery", "error", "failed"].includes(overall)) return false;
  const websocket = payload?.relation_discovery?.websocket;
  const status = String(websocket?.status || "").trim().toLowerCase();
  if (status) return status === "connected";
  const reasons = Array.isArray(payload?.health?.degraded_reasons) ? payload.health.degraded_reasons : [];
  return !reasons.some((reason) => ["heartbeat_missing", "heartbeat_stale", "stream_disconnected"].includes(String(reason)));
}

function predictionFailureReason(payload) {
  const reasons = payload?.health?.degraded_reasons;
  return payload?.failure_reason
    || (Array.isArray(reasons) ? reasons[0] : "")
    || payload?.readiness?.reason
    || "";
}

function predictionFailureReasonLabel(payload) {
  const raw = String(predictionFailureReason(payload) || "").trim();
  const labels = {
    configuration_unavailable: "预测市场配置不可用",
    heartbeat_missing: "盘口心跳尚未返回",
    heartbeat_stale: "盘口心跳已过期",
    stream_disconnected: "盘口数据连接已断开",
    universe_unavailable: "监控市场数据未返回",
    universe_stale: "监控市场数据已过期",
    universe_refresh_failed: "监控市场刷新失败",
    universe_retry_exhausted: "监控市场连续刷新失败",
    books_stale: "可参与盘口已过期",
    readiness_stale: "交易账户检查已过期",
    readiness_unavailable: "交易账户检查不可用",
    store_write_failed: "监控记录保存失败",
    api_key_pending: "Predict API Key 待分配",
    predict_unavailable: "Predict.fun 数据暂不可用",
    predict_degraded: "Predict.fun 数据连接降级",
    predict_construction_failed: "Predict.fun 监控初始化失败",
    predict_not_configured: "Predict.fun 尚未配置",
    cross_venue_unavailable: "跨交易所监控暂不可用",
    predict_stale: "Predict.fun 数据已过期",
    predict_auth_blocked: "Predict.fun API Key 认证受阻",
  };
  if (raw === "predict_account_unavailable") return "Predict.fun 账户状态不可用";
  return raw ? (labels[raw] || raw.replaceAll("_", " ")) : "状态详情未返回";
}

function predictionExecutionIsActive(payload) {
  const status = String(
    payload?.current_execution?.status || payload?.current_execution?.state || ""
  ).toLowerCase();
  return ["running", "executing", "pending", "submitted", "reconciling", "validating", "final_validating", "submitting", "merging"]
    .some((value) => status.includes(value));
}

function predictionHasValue(value) {
  return value !== null && value !== undefined && String(value).trim() !== "";
}

function predictionCanonicalUtcCutoff(value) {
  const match = typeof value === "string"
    ? /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?Z$/.exec(value)
    : null;
  if (!match) return null;
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) return null;
  const date = new Date(timestamp);
  const fraction = match[7] || "";
  const milliseconds = Number(fraction.slice(0, 3).padEnd(3, "0") || "0");
  return date.getUTCFullYear() === Number(match[1])
    && date.getUTCMonth() + 1 === Number(match[2])
    && date.getUTCDate() === Number(match[3])
    && date.getUTCHours() === Number(match[4])
    && date.getUTCMinutes() === Number(match[5])
    && date.getUTCSeconds() === Number(match[6])
    && date.getUTCMilliseconds() === milliseconds
    ? timestamp
    : null;
}

function predictionFutureCanonicalUtcCutoff(value) {
  const timestamp = predictionCanonicalUtcCutoff(value);
  return timestamp !== null && timestamp > Date.now();
}

function predictionPolicyIsComplete(policy) {
  return ["max_wallet_balance", "max_normal_cost", "max_emergency_loss", "min_estimated_profit"]
    .every((key) => predictionHasValue(policy?.[key]) && Number.isFinite(Number(policy[key])));
}

function predictionTradingAvailable(payload, strategy = "yes_no") {
  strategy = strategy === "llm_hedge" ? "llm_hedge" : "yes_no";
  const readiness = payload?.readiness || {};
  const geoblock = String(readiness.geoblock || readiness.region || readiness.region_status || "").toLowerCase();
  const relayer = String(readiness.relayer || readiness.relayer_readiness || "").toLowerCase();
  const blockedReadiness = ["unavailable", "blocked", "fail", "failed", "error"]
    .includes(String(readiness.status || "").toLowerCase());
  const relation = payload?.relation_discovery || {};
  const degradedReasons = Array.isArray(payload?.health?.degraded_reasons)
    ? payload.health.degraded_reasons.map((reason) => String(reason || ""))
    : [];
  const topTwentyOnlyReasons = new Set([
    "books_stale",
    "universe_unavailable",
    "universe_stale",
    "universe_refresh_failed",
    "universe_retry_exhausted",
  ]);
  const hasCriticalDegradation = degradedReasons.some(
    (reason) => !topTwentyOnlyReasons.has(reason)
  );
  const topTwentyOnlyDegradation = degradedReasons.length > 0
    && degradedReasons.every((reason) => topTwentyOnlyReasons.has(reason));
  const llmGlobalHealthSafe = !hasCriticalDegradation
    && (predictionHealthIsNormal(payload) || topTwentyOnlyDegradation);
  const strategyHealthy = strategy === "llm_hedge"
    ? llmGlobalHealthSafe
      && predictionWatcherIsConnected(payload)
      && String(relation.status || "").toLowerCase() === "healthy"
      && String(relation.catalog?.status || "").toLowerCase() === "healthy"
    : predictionHealthIsNormal(payload);
  return strategyHealthy
    && !blockedReadiness
    && ["allowed", "allow", "ok", "ready", "pass"].includes(geoblock)
    && ["allowed", "allow", "ok", "ready", "pass"].includes(relayer)
    && predictionHasValue(readiness.p_usd_balance ?? readiness.balance ?? payload?.balances?.p_usd)
    && predictionHasValue(
      readiness.masked_address
        || payload?.wallet?.masked_address
        || payload?.masked_wallet
        || readiness.wallet_address
    )
    && predictionPolicyIsComplete(payload?.policy_limits)
    && payload?.breaker?.open === false
    && !predictionExecutionIsActive(payload);
}

function predictionMarketTypeLabel(value) {
  const raw = String(value || "").trim();
  if (raw === "threshold_hedge") return "阈值关系套利";
  return raw === "standard_binary" ? "普通二元" : raw || "-";
}

function predictionFeeStatusLabel(value) {
  const raw = String(value || "").trim();
  return raw === "fee_free" ? "免手续费" : raw || "-";
}

function predictionStatusLabel(payload) {
  return predictionWatcherIsConnected(payload)
    ? ["Watcher 正常", "ok"]
    : ["Watcher 不可用", "danger"];
}

function predictionOpportunityDisplay(value) {
  const source = value && typeof value === "object" ? value : {};
  const result = {...source};
  result.opportunity_id = source.opportunity_id ?? source.id ?? source.opportunityId;
  result.title = source.title ?? source.question ?? source.market_title ?? source.event_title ?? "数据未返回";
  result.yes_price = source.yes_price ?? source.yes_max_price ?? source.yes_best_bid;
  result.no_price = source.no_price ?? source.no_max_price ?? source.no_best_bid;
  result.yes_cost = source.yes_cost ?? source.yes_max_cost;
  result.no_cost = source.no_cost ?? source.no_max_cost;
  result.max_cost = source.max_cost ?? source.total_max_cost ?? source.cost;
  result.profit = source.profit ?? source.minimum_profit ?? source.estimated_profit ?? source.gross_upper_bound;
  result.quantity = source.quantity ?? source.size;
  if (String(result.market_type || "") === "threshold_hedge") {
    result.question_a = source.question_a ?? source.market_a_question;
    result.question_b = source.question_b ?? source.market_b_question;
    result.condition_id_a = source.condition_id_a ?? source.conditionA;
    result.condition_id_b = source.condition_id_b ?? source.conditionB;
    result.buy_legs = Array.isArray(source.buy_legs) ? source.buy_legs : [];
    result.llm_status = source.llm_status;
    result.llm_decision = source.llm_decision;
    result.llm_summary = source.llm_summary;
    result.llm_reason_codes = source.llm_reason_codes;
    result.llm_evidence = source.llm_evidence;
    result.llm_uncertainties = source.llm_uncertainties;
  }
  return result;
}

function predictionOpportunityIsComplete(value) {
  const opportunity = predictionOpportunityDisplay(value);
  if (predictionIsCrossVenue(opportunity)) {
    const legs = Array.isArray(opportunity.legs) ? opportunity.legs : [];
    const exchanges = new Set(legs.map((leg) => String(leg?.exchange || "").toLowerCase()));
    return [
      opportunity.opportunity_id,
      opportunity.title,
      opportunity.market_type,
      opportunity.quantity,
      opportunity.net_quantity,
      opportunity.max_cost,
      opportunity.minimum_payout,
      opportunity.profit,
      opportunity.annualized_yield,
      opportunity.canonical_cutoff,
    ].every(predictionHasValue)
      && predictionFutureCanonicalUtcCutoff(opportunity.canonical_cutoff)
      && legs.length === 2
      && exchanges.size === 2
      && exchanges.has("predict.fun")
      && exchanges.has("polymarket")
      && legs.every((leg) => [leg?.exchange, leg?.outcome, leg?.token_id, leg?.settlement_asset, leg?.net_quantity, leg?.max_price, leg?.max_cost]
        .every(predictionHasValue));
  }
  if (String(opportunity.market_type || "") === "threshold_hedge") {
    const legs = Array.isArray(opportunity.buy_legs) ? opportunity.buy_legs : [];
    return [
      opportunity.opportunity_id,
      opportunity.question_a,
      opportunity.question_b,
      opportunity.relation,
      opportunity.condition_id_a,
      opportunity.condition_id_b,
    ].every(predictionHasValue)
      && predictionHasValue(opportunity.quantity)
      && predictionHasValue(opportunity.max_cost)
      && predictionHasValue(opportunity.profit)
      && legs.length === 2
      && legs.every((leg) => [leg?.label, leg?.outcome, leg?.condition_id, leg?.token_id, leg?.quantity, leg?.max_price, leg?.max_cost]
        .every(predictionHasValue) && Number.isFinite(Number(leg.max_price)) && Number.isFinite(Number(leg.max_cost)));
  }
  const textFields = [
    opportunity.opportunity_id,
    opportunity.title,
    opportunity.market_type,
    opportunity.fee_status,
  ];
  const numericFields = [
    opportunity.yes_price,
    opportunity.no_price,
    opportunity.quantity,
    opportunity.max_cost,
    opportunity.profit,
  ];
  return textFields.every(predictionHasValue)
    && numericFields.every((item) => predictionHasValue(item) && Number.isFinite(Number(item)));
}

function predictionEventDisplay(value) {
  const source = value && typeof value === "object" ? value : {};
  const result = {...source};
  const rawOpportunities = Array.isArray(source.opportunities) ? source.opportunities : [];
  const rawMarkets = Array.isArray(source.markets) ? source.markets : [];
  const nested = (rawOpportunities.length ? rawOpportunities : rawMarkets)
    .filter((item) => item && typeof item === "object")
    .map(predictionOpportunityDisplay);
  result.title = source.title ?? source.question ?? source.event_title ?? source.market_title ?? nested[0]?.title ?? "数据未返回";
  result.volume_24h = source.volume_24h ?? source.volume24h ?? nested[0]?.volume_24h;
  result.market_count = source.market_count ?? (Array.isArray(source.markets) ? source.markets.length : source.markets);
  result.opportunities = nested;
  result.actionable = source.actionable === true || nested.some((item) => item.actionable === true);
  result.profit = source.profit ?? source.minimum_profit ?? source.gross_upper_bound ?? nested[0]?.profit;
  if (!Array.isArray(source.details) && nested.length) {
    result.details = nested.map((item) => [
      item.title || item.market_title || "数据未返回",
      item.actionable ? "可参与" : predictionReasonLabel(item.reason || item.eligibility_reason || item.status),
    ]);
  }
  return result;
}

function predictionEvents(payload) {
  const events = Array.isArray(payload?.events) ? payload.events.filter((item) => item && typeof item === "object") : [];
  const opportunities = Array.isArray(payload?.opportunities) ? payload.opportunities : [];
  if (events.length) {
    const knownEventIds = new Set(events.map((event) => String(event.event_id || event.id || "")));
    const crossEvents = opportunities.filter((opportunity) => (
      opportunity && typeof opportunity === "object"
      && predictionIsCrossVenue(opportunity)
      && !knownEventIds.has(String(opportunity.event_id || opportunity.opportunity_id || ""))
    )).map((opportunity, index) => ({
      event_id: opportunity.event_id || opportunity.opportunity_id || `cross-opportunity-${index}`,
      ...predictionEventDisplay({...predictionOpportunityDisplay(opportunity), opportunities: [opportunity]}),
    }));
    return [...events.map(predictionEventDisplay), ...crossEvents];
  }
  return opportunities.map((opportunity, index) => ({
    event_id: opportunity.event_id || opportunity.opportunity_id || `opportunity-${index}`,
    ...predictionEventDisplay({
      ...predictionOpportunityDisplay(opportunity),
      opportunities: [opportunity],
    }),
  }));
}

function predictionOpportunities(payload) {
  return (Array.isArray(payload?.opportunities) ? payload.opportunities : [])
    .filter((item) => item && typeof item === "object")
    .map(predictionOpportunityDisplay);
}

function predictionOpportunityFilter(payload, filter) {
  const active = filter || {};
  const kind = active.kind || "all";
  const kinds = [
    ["all", "全部"], ["yes_no", "YES/NO"], ["llm_hedge", "LLM"],
    ["native", "原生"], ["mechanical", "机械"], ["semantic", "语义"],
  ];
  const kindButtons = kinds.map(([key, label]) =>
    `<button type="button" data-prediction-filter-kind="${key}" aria-pressed="${kind === key}">${label}</button>`
  ).join("");
  const engine = active.engine || "all";
  const engineLabel = engine === "all" ? "引擎 ▾" : `${engine} ▾`;
  const legsLabel = active.legs !== null && active.legs !== undefined ? `${active.legs} 腿 ▾` : "腿数 ▾";
  const scopeLabel = active.scope === "cross_venue" ? "跨所 ▾" : active.scope === "same_venue" ? "同所 ▾" : "范围 ▾";
  return `<nav class="pm-strategy-tabs" aria-label="机会筛选"><button type="button" data-prediction-filter-engine aria-pressed="${engine !== "all"}">${engineLabel}</button>${kindButtons}<button type="button" data-prediction-filter-legs aria-pressed="${active.legs !== null && active.legs !== undefined}">${legsLabel}</button><button type="button" data-prediction-filter-scope aria-pressed="${active.scope !== null && active.scope !== undefined}">${scopeLabel}</button></nav>`;
}

function predictionUnifiedFilteredRows(payload, filter) {
  const active = filter || {};
  const rows = (Array.isArray(payload?.qualified_opportunities) ? payload.qualified_opportunities : [])
    .filter((item) => (
      item && typeof item === "object"
      && ["QUALIFIED_VERIFIED", "QUALIFIED_FEASIBLE"].includes(item?.qualification?.status)
    ));
  return rows.filter((item) => {
    const strategy = String(item.strategy_type || "");
    const relation = String(item.relation_type || "");
    const kind = active.kind || "all";
    if (kind !== "all") {
      if (kind === "yes_no" && strategy !== "yes_no") return false;
      if (kind === "llm_hedge" && strategy !== "llm_hedge") return false;
      if (kind === "native" && relation !== "NATIVE_COMPLEMENT") return false;
      if (kind === "mechanical" && relation !== "MECHANICAL") return false;
      if (kind === "semantic" && !["IMPLIES", "MUTUALLY_EXCLUSIVE", "EXACTLY_ONE"].includes(relation)) return false;
    }
    if (active.legs !== null && active.legs !== undefined && Number(item.leg_count) !== Number(active.legs)) return false;
    if (active.scope && item?.scope?.venue !== active.scope) return false;
    const engine = active.engine || "all";
    if (engine !== "all") {
      const owners = String(item.engine_owner || "").split("/").map((part) => part.trim());
      if (!owners.includes(engine)) return false;
    }
    return true;
  });
}

function predictionUnifiedLegRows(row) {
  const opportunity = predictionOpportunityDisplay(row);
  if (predictionIsCrossVenue(opportunity)) {
    const legs = Array.isArray(opportunity.legs) ? opportunity.legs : [];
    return legs.map((leg, index) => {
      const venue = String(leg.exchange || "").toLowerCase() === "predict.fun" ? "Predict.fun" : "Polymarket";
      return `<div class="pm-order-leg"><span>第 ${index + 1} 腿 · ${escapeHtml(venue)} · BUY ${escapeHtml(leg.outcome || "")}</span><strong>${escapeHtml(predictionValue(leg.net_quantity, "-"))} 份 · 最高 ${escapeHtml(predictionPrice(leg.max_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(leg.max_cost))} · ${escapeHtml(predictionValue(leg.settlement_asset, "-"))}</small></div>`;
    }).join("");
  }
  if (String(opportunity.market_type || "") === "threshold_hedge") {
    const legs = Array.isArray(opportunity.buy_legs) ? opportunity.buy_legs : [];
    return legs.map((leg, index) => `<div class="pm-order-leg"><span>第 ${index + 1} 腿 · Polymarket · BUY ${escapeHtml(leg.outcome || "")}</span><strong>${escapeHtml(predictionValue(leg.quantity, "-"))} 份 · 最高 ${escapeHtml(predictionPrice(leg.max_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(leg.max_cost))} · pUSD</small></div>`).join("");
  }
  const yes = `<div class="pm-order-leg"><span>第 1 腿 · Polymarket · BUY YES</span><strong>${escapeHtml(predictionValue(opportunity.quantity, "-"))} 份 · 最高 ${escapeHtml(predictionPrice(opportunity.yes_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(opportunity.yes_cost))} · pUSD</small></div>`;
  const no = `<div class="pm-order-leg"><span>第 2 腿 · Polymarket · BUY NO</span><strong>${escapeHtml(predictionValue(opportunity.quantity, "-"))} 份 · 最高 ${escapeHtml(predictionPrice(opportunity.no_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(opportunity.no_cost))} · pUSD</small></div>`;
  return `${yes}${no}`;
}

function predictionUnifiedMetric(label, value, className = "", extra = "", hint = "") {
  // Issue #106: small "!" badge beside the label; hovering/focus shows the
  // plain-language meaning above the tile.
  const hintNode = hint
    ? `<span class="pm-metric-hint" tabindex="0" role="note" aria-label="${escapeHtml(hint)}">!<span class="pm-metric-tip">${escapeHtml(hint)}</span></span>`
    : "";
  return `<div class="pm-metric"><span class="pm-metric-label">${escapeHtml(label)}${hintNode}</span><strong class="${className}">${value}</strong>${extra}</div>`;
}

function predictionNLegExecutionPlan(opportunity) {
  const solution = opportunity?.n_leg_solution && typeof opportunity.n_leg_solution === "object" ? opportunity.n_leg_solution : null;
  if (!solution) return "";
  const market = solution.market && typeof solution.market === "object" ? solution.market : {};
  const execution = solution.execution && typeof solution.execution === "object" ? solution.execution : {};
  const legs = Array.isArray(execution.legs) && execution.legs.length
    ? execution.legs
    : Array.isArray(market.legs) ? market.legs : [];
  const legRows = legs.map((leg, index) => {
    const venueRaw = String(leg.venue || "").toLowerCase();
    const venue = venueRaw === "predict.fun" ? "Predict.fun" : venueRaw === "polymarket" ? "Polymarket" : (leg.venue || "Polymarket");
    const expiresAt = String(leg.expires_at || "").slice(0, 10);
    return `<div class="pm-order-leg"><span>第 ${index + 1} 腿 · ${escapeHtml(venue)} · BUY ${escapeHtml(predictionValue(leg.outcome, ""))}</span><strong>${escapeHtml(predictionValue(leg.quantity_lots, "-"))} 份 · 最高 ${escapeHtml(predictionPrice(leg.max_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(leg.max_cost))} · ${escapeHtml(predictionValue(leg.settlement_asset, "pUSD"))}</small><small>场所 <span class="pm-pill venue">${escapeHtml(venue)}</span> · 到期 <span style="white-space:nowrap">${escapeHtml(expiresAt || "-")}</span></small></div>`;
  }).join("");
  const ready = execution.order_ready === true;
  const fingerprint = String(execution.execution_solution_fingerprint || "");
  const shortFingerprint = fingerprint.startsWith("sha256:") ? `sha256:${fingerprint.slice(7, 9)}…` : predictionValue(fingerprint, "-");
  return `<div class="pm-execution-plan"><h4>下单计划 · would-submit</h4>${legRows ? `<div class="pm-order-legs">${legRows}</div>` : ""}<dl><dt>可下单</dt><dd>${ready ? "是" : "否"}</dd><dt>原因</dt><dd>${escapeHtml(predictionReasonLabel(execution.reason))}</dd><dt>成交证明</dt><dd>${escapeHtml(predictionValue(execution.partial_fill_proof, "-"))}</dd><dt>方案指纹</dt><dd>${escapeHtml(shortFingerprint)}</dd><dt>预计占用</dt><dd>${escapeHtml(predictionNLegUnitsMoney(execution.projected_total_units))} / ${escapeHtml(predictionNLegUnitsMoney(execution.max_total_unsettled_capital_units))}</dd></dl></div>`;
}

function predictionUnifiedOpportunityCard(row, mode, legacyRetired) {
  const opportunity = predictionOpportunityDisplay(row);
  const qualification = opportunity.qualification && typeof opportunity.qualification === "object" ? opportunity.qualification : {};
  const nLegSolution = opportunity.n_leg_solution && typeof opportunity.n_leg_solution === "object" ? opportunity.n_leg_solution : null;
  const nLegExecution = nLegSolution?.execution && typeof nLegSolution.execution === "object" ? nLegSolution.execution : null;
  const nLegReady = nLegExecution?.order_ready === true;
  const orderReady = nLegExecution ? nLegReady : qualification.order_ready === true;
  const checks = Array.isArray(qualification.checks) ? qualification.checks : [];
  const checkValue = (key) => {
    const item = checks.find((entry) => entry && entry.key === key);
    return item ? item.value : undefined;
  };
  const checkThreshold = (key) => {
    const item = checks.find((entry) => entry && entry.key === key);
    return item ? item.threshold : undefined;
  };
  const thresholdPercent = (key, fallback) => {
    const num = Number(checkThreshold(key));
    return Number.isFinite(num) ? `${Math.round(num * 1000) / 10}%` : fallback;
  };
  const statusClass = qualification.status === "QUALIFIED_VERIFIED" ? "ok" : "warn";
  const status = predictionValue(qualification.status, "UNKNOWN");
  const edge = Number(checkValue("net_margin") ?? checkValue("net_edge"));
  const edgePercent = Number.isFinite(edge) ? `${(Math.trunc(edge * 100 * 10) / 10).toFixed(1)}%` : "-";
  const remaining = Number(opportunity.remaining_days);
  const tenor = Number.isFinite(remaining) && remaining > 0
    ? `${Number.isInteger(remaining) ? remaining : remaining.toFixed(1)} 天`
    : "不可计算";
  const legs = Array.isArray(opportunity.legs) ? opportunity.legs : [];
  const exchanges = new Set(legs.map((leg) => String(leg?.exchange || "").toLowerCase()).filter(Boolean));
  const venueLabel = exchanges.has("predict.fun") && exchanges.has("polymarket")
    ? "Predict.fun × Polymarket"
    : String(opportunity.venue || "Polymarket");
  const subtitle = `${escapeHtml(venueLabel)} · ${escapeHtml(predictionValue(opportunity.scope_label, ""))}`;
  const episode = opportunity.episode && typeof opportunity.episode === "object" ? opportunity.episode : {};
  // Issue #106: live episode badge — short id, status, and elapsed duration.
  const episodeId = predictionValue(episode.opportunity_episode_id, "");
  const episodeOngoing = Boolean(episodeId) && episode.status === "ONGOING";
  const episodeMinutes = (value) => {
    const total = Math.max(0, Math.floor(Number(value || 0) / 60));
    return total >= 60 ? `${Math.floor(total / 60)} 小时 ${total % 60} 分钟` : `${total} 分钟`;
  };
  const episodeDurationText = episodeMinutes(episode.duration_seconds);
  const episodeLabel = episodeId
    ? `Episode #${String(episodeId).replace(/-/g, "").slice(0, 8)} · ${episodeOngoing ? "进行中" : "已结束"} · ${episodeDurationText}`
    : "Episode —";
  const episodePill = episodeId
    ? `<span class="pm-pill episode${episodeOngoing ? " live" : ""}">${episodeOngoing ? '<span class="dot"></span>' : ""}${escapeHtml(episodeLabel)}</span>`
    : "";
  // #119: fee pill rides the tag row (same zero-shape pattern as the
  // episode pill) — charging+modeled shows rate+total, free shows 免费,
  // missing/unknown shows nothing.
  const feeBlock = nLegSolution?.market?.fee && typeof nLegSolution.market.fee === "object" ? nLegSolution.market.fee : null;
  const feePill = feeBlock && feeBlock.status === "fee_charging" && feeBlock.modeled === true
    ? `<span class="pm-pill">taker 费 ${escapeHtml(predictionNLegUnitsMoney(feeBlock.taker_fee_units))} · 费率 ${Number(feeBlock.taker_fee_rate_bps) / 100}%</span>`
    : feeBlock && feeBlock.status === "fee_free"
    ? `<span class="pm-pill">免费市场</span>`
    : "";
  const plainTagLabels = [
    opportunity.relation_type,
    opportunity.discovery_source,
    opportunity.leg_count ? `${opportunity.leg_count} 腿` : "",
    opportunity.qualification_policy_version ? `资格 ${opportunity.qualification_policy_version}` : "",
  ].filter(Boolean);
  // Issue #106: the episode badge rides the tag row as one more pill —
  // no extra line in the title block, layout stays the #105 shape.
  const tags = [
    episodePill,
    feePill,
    ...plainTagLabels.map((tag, index) => `<span class="pm-pill${index === 0 ? " blue" : ""}">${escapeHtml(String(tag))}</span>`),
  ].filter(Boolean).join("");
  const metrics = [
    predictionUnifiedMetric(
      "保证最低利润",
      escapeHtml(predictionSignedMoney(opportunity.profit)),
      "pm-positive",
      // Issue #106: episode best/would-submit ride as the first tile's
      // sub-line; metrics stay exactly one 4-tile row.
      episodeId
        ? `<small style="color:var(--muted)">Episode 最佳 ${escapeHtml(predictionMoney(episode.best_guaranteed_profit))} · would-submit 累计 ${escapeHtml(episodeMinutes(episode.would_submit_ready_seconds))}</small>`
        : "",
      "按当前盘口锁定下单后，无论行情如何走都至少赚到的金额（绝对值）。",
    ),
    predictionUnifiedMetric("净边际", escapeHtml(edgePercent), "", `<small style="color:var(--muted)">门槛 ≥${thresholdPercent("net_margin", "1%")}</small>`, "保证利润 ÷ 总赔付额：每经手 $100 盘口稳赚多少。衡量利润厚度与抗波动能力；门槛 ≥1% 淘汰薄利润机会。"),
    predictionUnifiedMetric("年化收益", escapeHtml(predictionAnnualizedPercent(opportunity.annualized_yield, 1)), "", `<small style="color:var(--muted)">门槛 ≥${thresholdPercent("annualized_return", "15%")}</small>`, "把保证利润按资金占用时长折算成一年的收益率；资本释放越近，年化越高。"),
    predictionUnifiedMetric("资本释放", escapeHtml(tenor), "", `<small style="color:var(--muted)">上限 ${escapeHtml(String(checkThreshold("capital_release") ?? "30"))} 天</small>`, "本金最晚多少天后收回；上限 30 天是资格门槛之一，越近越安全。"),
  ].join("");
  // Issue #106: the 极端风险 tile is gone (N_LEG rows carry no extreme-loss
  // source) and order_ready moved into the single unified action line
  // instead of duplicating tile + footer. The retired branch renders the
  // same unified line (the 410 notice is gone); only a non-retired
  // order-ready MANUAL row keeps the manual-confirm button.
  const orderReadyReason = predictionValue(
    nLegExecution?.reason ? predictionReasonLabel(nLegExecution.reason) : qualification.order_ready_reason,
    "不可下单",
  );
  const unifiedActionLine = `<div class="pm-opportunity-action"><p>order_ready ${orderReady ? "是" : "否"} · ${escapeHtml(orderReadyReason)} · ${orderReady ? "可人工确认" : "不可下单"}。</p></div>`;
  const action = predictionWritesBlocked()
    ? `<div class="pm-opportunity-action"><p>order_ready ${orderReady ? "是" : "否"} · ${escapeHtml(orderReadyReason)} · ${escapeHtml(predictionServiceIdentity().label)} · 写操作不可用。</p></div>`
    : legacyRetired === true
    ? (nLegReady
      ? `<div class="pm-opportunity-action"><p>order_ready ${orderReady ? "是" : "否"} · ${escapeHtml(orderReadyReason)} · ${orderReady ? "可人工确认" : "不可下单"}。</p><button type="button" class="pm-button primary" data-action="nleg-confirm" data-opportunity-id="${escapeHtml(predictionValue(opportunity.opportunity_id, ""))}">人工确认下单</button></div>`
      : unifiedActionLine)
    : orderReady && mode === "MANUAL"
    ? `<div class="pm-opportunity-action"><p>确认时重新读取两所 REST、盘口、余额与未结算额度。</p><button type="button" class="pm-button primary" data-action="participate" data-opportunity-id="${escapeHtml(predictionValue(opportunity.opportunity_id, ""))}">人工确认下单</button></div>`
    : unifiedActionLine;
  return `<article class="pm-opportunity"><div class="pm-opportunity-title"><div><h3>${escapeHtml(predictionValue(opportunity.title || opportunity.question, "数据未返回"))}</h3><p>${subtitle}</p></div><span class="pm-pill ${statusClass}">${escapeHtml(status)}</span></div><div class="pm-tags">${tags}</div>${legs.length && !nLegSolution ? `<div class="pm-order-legs">${predictionUnifiedLegRows(opportunity)}</div>` : ""}<div class="pm-metrics">${metrics}</div>${predictionNLegExecutionPlan(opportunity)}${action}</article>`;
}

function predictionUnifiedOpportunityList(payload, filter) {
  const rows = predictionUnifiedFilteredRows(payload, filter);
  const legacyRetired = predictionLegacyControlsRetired(payload);
  const cards = rows.map((row) => predictionUnifiedOpportunityCard(row, "MANUAL", legacyRetired)).join("");
  const empty = rows.length ? "" : `<div class="pm-empty"><strong>当前无更多合格机会</strong><p style="margin:4px 0 0">低于门槛的正收益、未经批准、证明未完成、UNKNOWN 和陈旧结果只进漏斗/历史。</p></div>`;
  return `<section class="pm-panel" aria-label="机会列表"><div class="pm-panel-heading"><div><h2>机会列表</h2><p>只读投影 · 前端不重算利润/年化/期限/安全状态。</p></div></div><div style="padding:0 14px">${predictionOpportunityFilter(payload, filter)}</div>${cards}${empty}</section>`;
}

function predictionCapitalUsage(payload) {
  const usage = payload?.capital_usage && typeof payload.capital_usage === "object" ? payload.capital_usage : {};
  const set = usage.max_total_unsettled_capital_set === true && predictionHasValue(usage.max_total_unsettled_capital);
  return `<section class="pm-readiness" aria-label="资金占用"><div class="pm-readiness-item"><span>max_total_unsettled_capital</span><strong>${escapeHtml(predictionMoney(set ? usage.max_total_unsettled_capital : "0.00"))}</strong><small>${set ? "显式设置" : "首次 Canary 前需显式设置"}</small></div><div class="pm-readiness-item"><span>当前保守占用</span><strong>${escapeHtml(predictionMoney(usage.current_conservative))}</strong><small>active batch 预留 ${escapeHtml(predictionMoney(usage.active_batch_reserved))}</small></div><div class="pm-readiness-item"><span>剩余额度</span><strong>${escapeHtml(predictionMoney(usage.remaining))}</strong><small>只投影服务端账本</small></div></section>`;
}

function predictionObservationCoverage(payload) {
  const coverage = payload?.n_leg_coverage && typeof payload.n_leg_coverage === "object"
    ? payload.n_leg_coverage
    : null;
  const observation = payload?.n_leg_observation && typeof payload.n_leg_observation === "object"
    ? payload.n_leg_observation
    : null;
  if (!coverage && !observation) return "";
  const display = (value, fallback = "—") => predictionHasValue(value) ? String(value) : fallback;
  const count = (...keys) => {
    for (const key of keys) {
      if (predictionHasValue(coverage?.[key])) return String(coverage[key]);
      if (predictionHasValue(observation?.[key])) return String(observation[key]);
    }
    return "—";
  };
  const poolCount = count("pool_count");
  const poolLimit = count("pool_limit");
  const capacity = predictionHasValue(coverage?.capacity)
    ? String(coverage.capacity)
    : poolCount !== "—" && poolLimit !== "—" ? `${poolCount}/${poolLimit}` : "—";
  const latestCount = count("latest_count");
  const freshCount = count("fresh_count");
  const positiveCount = count("positive_count");
  const nonPositiveCount = count("non_positive_count");
  const blockedCount = count("blocked_count");
  const statusKey = String(observation?.status || coverage?.status || "UNKNOWN").toUpperCase();
  const statusLabels = {
    READY: "已就绪",
    EMPTY: "明确为空",
    STALE: "数据过期",
    ERROR: "读取失败",
    UNKNOWN: "未知",
  };
  const statusLabel = statusLabels[statusKey] || statusKey || "未知";
  const sourceScope = display(
    coverage?.source_scope || observation?.source_scope || "官方来源范围未返回",
  );
  const generation = display(coverage?.generation ?? observation?.generation);
  const updatedAt = coverage?.updated_at || observation?.updated_at;
  const latest = Array.isArray(observation?.latest) ? observation.latest : [];
  const results = Array.isArray(observation?.results) ? observation.results : [];
  const waitingStages = new Set(["WAITING", "PENDING", "PENDING_QUOTE", "CANDIDATE"]);
  const excludedStages = new Set(["EXCLUDED", "REJECTED", "INVALID"]);
  const poolStages = new Set(["OBSERVING", "IN_POOL", "POOL"]);
  const rowIdentity = (row) => String(row?.identity || row?.id || row?.event_id || "");
  const rowStage = (row) => String(row?.stage || "").toUpperCase();
  const isPoolRow = (row) => {
    const stage = rowStage(row);
    return !excludedStages.has(stage) && (row?.in_pool === true || poolStages.has(stage));
  };
  const isMemberRow = (row) => !excludedStages.has(rowStage(row));
  const latestByIdentity = new Map();
  const resultsByIdentity = new Map();
  const allRowsByIdentity = new Map();
  for (const row of latest) {
    const identity = rowIdentity(row);
    if (identity) {
      latestByIdentity.set(identity, row);
      allRowsByIdentity.set(identity, row);
    }
  }
  for (const row of results) {
    const identity = rowIdentity(row);
    if (identity) {
      resultsByIdentity.set(identity, row);
      allRowsByIdentity.set(identity, {...(allRowsByIdentity.get(identity) || {}), ...row});
    }
  }
  const members = Array.isArray(observation?.members)
    ? observation.members.filter((row) => row && typeof row === "object" && !Array.isArray(row))
    : null;
  const memberRows = members
    ? members.filter(isMemberRow).map((row) => {
      const identity = rowIdentity(row);
      return {...row, ...(latestByIdentity.get(identity) || {}), ...(resultsByIdentity.get(identity) || {})};
    })
    : [];
  const memberIdentities = new Set(memberRows.map(rowIdentity).filter(Boolean));
  if (!members) {
    for (const [identity, row] of allRowsByIdentity) {
      if (isPoolRow(row)) memberIdentities.add(identity);
    }
  }
  const poolRows = (members
    ? (() => {
      const ordered = [];
      const seen = new Set();
      for (const row of results) {
        const identity = rowIdentity(row);
        if (!identity || !memberIdentities.has(identity) || seen.has(identity)) continue;
        const base = memberRows.find((item) => rowIdentity(item) === identity) || {};
        ordered.push({...base, ...row});
        seen.add(identity);
      }
      for (const row of memberRows) {
        const identity = rowIdentity(row);
        if (!identity || seen.has(identity)) continue;
        ordered.push(row);
        seen.add(identity);
      }
      return ordered;
    })()
    : [...allRowsByIdentity.values()].filter((row) => memberIdentities.has(rowIdentity(row))))
    .filter((row) => !excludedStages.has(rowStage(row)));
  const waitingRows = [...allRowsByIdentity.values()].filter((row) => {
    const identity = rowIdentity(row);
    return !memberIdentities.has(identity)
      && !excludedStages.has(rowStage(row))
      && waitingStages.has(rowStage(row));
  });
  const rawFilter = state.predictionMarket.observationFilter || "all";
  const filter = ["all", "current", "blocked", "waiting"].includes(rawFilter) ? rawFilter : "all";
  const resultFor = (row) => row?.result && typeof row.result === "object" ? row.result : {};
  const currentFor = (row) => {
    const result = resultFor(row);
    return result.current === true && String(result.status || "").toUpperCase() === "PASS";
  };
  const blockedFor = (row) => {
    const result = resultFor(row);
    return result.current === false
      || ["BLOCKED", "ERROR"].includes(String(result.status || "").toUpperCase())
      || ["BLOCKED", "ERROR"].includes(rowStage(row));
  };
  const filteredRows = filter === "waiting"
    ? waitingRows
    : poolRows.filter((row) => filter === "current" ? currentFor(row) : filter === "blocked" ? blockedFor(row) : true);
  const observationMoney = (result, directKeys, unitKeys) => {
    const sources = [result, result?.economics].filter((value) => value && typeof value === "object");
    for (const source of sources) {
      for (const key of directKeys) {
        if (predictionHasValue(source?.[key])) return predictionMoney(source[key], "—");
      }
      for (const key of unitKeys) {
        if (predictionHasValue(source?.[key])) return predictionNLegUnitsMoney(source[key], "—");
      }
    }
    return "—";
  };
  const observationNet = (result) => {
    const sources = [result, result?.economics].filter((value) => value && typeof value === "object");
    for (const source of sources) {
      for (const key of ["net_amount", "profit"]) {
        if (predictionHasValue(source?.[key])) return predictionSignedMoney(source[key], "—");
      }
      if (predictionHasValue(source?.guaranteed_profit_units)) {
        const value = Number(source.guaranteed_profit_units);
        if (Number.isFinite(value)) return predictionSignedMoney(value / 1000000, "—");
      }
    }
    return "—";
  };
  const observationRoi = (result) => {
    if (!predictionHasValue(result?.net_roi)) return "—";
    const value = Number(result.net_roi);
    return Number.isFinite(value) ? `${value >= 0 ? "+" : ""}${(value * 100).toFixed(2)}%` : "—";
  };
  const reasonLabels = {
    STALE_BOOK: "盘口过期",
    FUTURE_BOOK: "盘口时间异常",
    STATE_FETCH_FAILED: "状态读取失败",
    SOURCE_RULES_CHANGED: "规则或结构待核验",
    UNKNOWN_MODEL_FACTS: "模型事实未知",
    MISSING_BOOKS: "缺少盘口",
    INSUFFICIENT_DEPTH: "盘口深度不足",
  };
  const observationReason = (value) => {
    const raw = String(value || "").trim();
    return raw ? (reasonLabels[raw.toUpperCase()] || predictionReasonLabel(raw)) : "";
  };
  const statusFor = (row, result) => {
    const stage = rowStage(row);
    if (waitingStages.has(stage)) return stage === "PENDING_QUOTE" ? "等待报价" : "等待入池";
    if (currentFor(row)) return "当前有效";
    if (blockedFor(row)) {
      const status = String(result?.status || "").toUpperCase();
      if (status === "ERROR") return "读取失败";
      const reason = observationReason(result?.reason || row?.reason);
      return reason ? `已阻断 · ${reason}` : "已阻断";
    }
    if (excludedStages.has(stage)) return "已排除";
    return result?.status ? observationReason(result.status) : "未计算";
  };
  const resultCell = (value, current, positive = false) => {
    const className = current && positive ? " pm-positive" : current ? "" : " pm-observation-historical";
    const history = !current && value !== "—" ? '<small class="pm-observation-history-label">上次结果</small>' : "";
    return `<span class="pm-observation-value${className}">${history}<strong>${escapeHtml(value)}</strong></span>`;
  };
  const rowHtml = filteredRows.slice(0, 30).map((row) => {
    const result = resultFor(row);
    const titleCandidates = [row?.title, row?.question, row?.market_title, row?.event_title, row?.event];
    const title = titleCandidates.find((value) => predictionHasValue(value) && !/^\d+$/.test(String(value).trim()));
    const eventId = row?.event_id || (/^\d+$/.test(String(row?.event || "").trim()) ? row.event : null);
    const relationId = row?.identity || row?.id;
    const name = title
      || (predictionHasValue(eventId) ? `事件 ID：${eventId}` : predictionHasValue(relationId) ? `关系 ID：${relationId}` : "未命名标的");
    const type = row?.relation_type || row?.type;
    const endDate = row?.end_date || row?.expected_end_date;
    const version = row?.version_id || result?.version_id;
    const fingerprint = row?.version_fingerprint || result?.version_fingerprint;
    const approval = row?.approval_status || row?.approval;
    const oldestBook = row?.oldest_book_at || result?.oldest_book_at;
    const attempt = row?.last_attempt_at || result?.last_attempt_at;
    const success = row?.last_success_at || result?.last_success_at;
    const capitalReleaseAt = row?.capital_release_at || result?.capital_release_at;
    const capitalReleaseStatus = row?.capital_release_status || result?.capital_release_status;
    const reason = result?.reason || row?.reason || result?.detail || row?.source_reason || "";
    const current = currentFor(row);
    const status = statusFor(row, result);
    const details = [
      ["类型", type],
      ["事件 ID", row?.event_id || (/^\d+$/.test(String(row?.event || "").trim()) ? row.event : null)],
      ["版本", version],
      ["版本指纹", fingerprint],
      ["审批", approval],
      ["数量", result?.quantity ?? result?.quantity_lots],
      ["订阅 token", Array.isArray(row?.tokens) ? row.tokens.length : row?.subscribed_token_count],
      ["最旧盘口", oldestBook],
      ["最近尝试", attempt],
      ["最近成功", success],
      ["资本释放", capitalReleaseAt || capitalReleaseStatus],
      ["释放状态", capitalReleaseStatus],
      ["诊断原因", reason ? `${observationReason(reason)} · ${reason}` : null],
      ["来源范围", row?.source_scope || sourceScope],
      ["是否逾期", row?.overdue === true ? "已超过预计结束时间" : "否"],
    ].filter(([, value]) => predictionHasValue(value));
    const cost = observationMoney(result, ["cost"], ["cost_upper_bound_units", "bounded_cost_units"]);
    const payout = observationMoney(result, ["payout", "minimum_payout"], ["payout_lower_bound_units", "bounded_payout_units"]);
    const net = observationNet(result);
    const roi = observationRoi(result);
    return `<tr data-observation-stage="${escapeHtml(String(row?.stage || ""))}" data-observation-current="${current ? "true" : "false"}"><td data-label="标的名称"><strong>${escapeHtml(String(name))}</strong><details data-observation-details><summary>详情</summary><dl>${details.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(display(value))}</dd></div>`).join("")}</dl></details></td><td data-label="净收益率">${resultCell(roi, current, Number(result?.net_roi) > 0)}</td><td data-label="净收益">${resultCell(net, current, Number(result?.net_amount ?? result?.profit ?? result?.guaranteed_profit_units) > 0)}</td><td data-label="当前状态"><span class="pm-observation-status${current ? " pm-observation-status-current" : " pm-observation-status-stale"}">${escapeHtml(status)}${row?.overdue === true ? " · 已超过预计结束时间" : ""}</span></td><td data-label="预计结束时间">${escapeHtml(endDate ? predictionHktTimestamp(endDate) : "—")}</td><td data-label="含费成本">${resultCell(cost, current)}</td><td data-label="最低赔付">${resultCell(payout, current)}</td></tr>`;
  }).join("");
  const emptyNotice = filteredRows.length
    ? ""
    : statusKey === "UNKNOWN"
      ? `<p class="pm-observation-empty">当前状态未知，尚未取得可确认的观测快照；不会显示为零。</p>`
      : statusKey === "EMPTY"
        ? `<p class="pm-observation-empty">当前已确认没有候选。</p>`
        : `<p class="pm-observation-empty">当前筛选没有可显示的候选。</p>`;
  const table = rowHtml
    ? `<div class="pm-observation-table-wrap" tabindex="0"><table class="pm-observation-table" aria-label="观测结果"><caption>持续观测结果（只读）</caption><thead><tr>${["标的名称", "净收益率", "净收益", "当前状态", "预计结束时间", "含费成本", "最低赔付"].map((label) => `<th scope="col">${label}</th>`).join("")}</tr></thead><tbody>${rowHtml}</tbody></table></div>`
    : "";
  const filterOptions = [["all", "全部（池内）"], ["current", "当前有效"], ["blocked", "阻断 / 陈旧"], ["waiting", "等待入池"]];
  return `<section class="pm-panel pm-observation-coverage" aria-label="观测覆盖"><header class="pm-panel-heading"><div><h2>持续观测池</h2><p>按预计结束时间入池，池内按净收益率排序；仅供观察。</p><p class="pm-observation-source">来源范围：${escapeHtml(sourceScope)} · 代数 ${escapeHtml(generation)}${updatedAt ? ` · 更新 ${escapeHtml(predictionHktTimestamp(updatedAt))}` : ""}</p></div><div class="pm-observation-header-actions"><span class="pm-pill" data-observation-status>${escapeHtml(statusLabel)}</span><label>筛选 <select data-observation-filter aria-label="观测结果筛选">${filterOptions.map(([value, label]) => `<option value="${value}"${filter === value ? " selected" : ""}>${label}</option>`).join("")}</select></label></div></header><div class="pm-observation-metrics"><div><span>池内</span><strong>${escapeHtml(capacity)}</strong></div><div><span>最新</span><strong>${escapeHtml(latestCount)}</strong></div><div><span>待入池</span><strong>${escapeHtml(count("waiting_count"))}</strong></div><div><span>来源待准备</span><strong>${escapeHtml(count("pending_preparation_count"))}</strong></div><div><span>排除</span><strong>${escapeHtml(count("excluded_count"))}</strong></div><div><span>原生</span><strong>${escapeHtml(count("native_count"))}</strong></div><div><span>三腿</span><strong>${escapeHtml(count("three_way_count"))}</strong></div><div><span>已订阅 token</span><strong>${escapeHtml(count("subscribed_tokens"))}</strong></div><div><span>全部腿已订阅组</span><strong>${escapeHtml(count("all_leg_subscribed_count"))}</strong></div><div><span>新鲜</span><strong>${escapeHtml(freshCount)}</strong></div><div><span>已计算</span><strong>${escapeHtml(count("computed_count"))}</strong></div><div><span>阻断</span><strong>${escapeHtml(blockedCount)}</strong></div><div><span>正收益</span><strong class="pm-positive">${escapeHtml(positiveCount)}</strong></div><div><span>非正收益</span><strong>${escapeHtml(nonPositiveCount)}</strong></div></div>${table}${emptyNotice}</section>`;
}

function predictionNLegMetrics(payload) {
  const metrics = payload?.n_leg_metrics && typeof payload.n_leg_metrics === "object" ? payload.n_leg_metrics : null;
  if (!metrics) return "";
  const windowSummary = (name, unit = "ms") => {
    const item = metrics[name] && typeof metrics[name] === "object" ? metrics[name] : {};
    const p50 = predictionHasValue(item.p50) ? `${Number(item.p50).toFixed(0)}` : "-";
    const p95 = predictionHasValue(item.p95) ? `${Number(item.p95).toFixed(0)}` : "-";
    const worst = predictionHasValue(item.worst) ? `${Number(item.worst).toFixed(0)}` : "-";
    return `${p50} / ${p95} / ${worst} ${unit}`;
  };
  const survival = metrics.opportunity_survival && typeof metrics.opportunity_survival === "object" ? metrics.opportunity_survival : {};
  const survivalP95 = predictionHasValue(survival.p95) ? `${Number(survival.p95).toFixed(1)}s` : "-";
  const selectionPending = metrics.selection_pending;
  const selectionFailures = metrics.selection_failures_consecutive;
  const hasSelection = predictionHasValue(selectionPending) && predictionHasValue(selectionFailures);
  const pending = hasSelection ? Number(selectionPending) : 0;
  const failures = hasSelection ? Number(selectionFailures) : 0;
  let selectionValue = "- / -";
  let selectionTone = "";
  let selectionNote = "数据未返回";
  if (hasSelection) {
    selectionValue = `${pending} / ${failures}`;
    if (failures > 0) {
      selectionTone = "pm-tone-danger";
      selectionNote = `连续失败 ${failures} 次`;
    } else if (pending > 0) {
      selectionTone = "pm-tone-warning";
      selectionNote = `${pending} 版待处理`;
    } else {
      selectionTone = "pm-tone-ok";
      selectionNote = "已追上最新 generation";
    }
  }
  const cards = [
    predictionUnifiedMetric("Selection 积压 / 连续失败", escapeHtml(selectionValue), selectionTone, `<small>${escapeHtml(selectionNote)}</small>`),
    predictionUnifiedMetric("编译 p50/p95/worst", escapeHtml(windowSummary("compile"))),
    predictionUnifiedMetric("求解 p50/p95/worst", escapeHtml(windowSummary("solve"))),
    predictionUnifiedMetric("端到端 p50/p95/worst", escapeHtml(windowSummary("end_to_end"))),
    predictionUnifiedMetric("队列合并 / 丢弃", escapeHtml(predictionValue(metrics.queue_merge_drop, "-")), "", "<small>latest-snapshot-wins</small>"),
    predictionUnifiedMetric("超时 / 陈旧拒绝", escapeHtml(`${predictionValue(metrics.timeout, "-")} / ${predictionValue(metrics.stale_reject, "-")}`)),
    predictionUnifiedMetric("机会存活时间", escapeHtml(`p95 ${survivalP95}`), "", "<small>内存 / 线程 / 队列有界</small>"),
  ].join("");
  // #64: the manual-confirm FIFO queue + caps acknowledgement ride as one
  // small line under the metrics grid — no new tile, no layout change.
  const ordersPayload = payload?.n_leg_orders && typeof payload.n_leg_orders === "object" ? payload.n_leg_orders : null;
  const queueRows = Array.isArray(ordersPayload?.queue) ? ordersPayload.queue : [];
  const caps = ordersPayload?.caps && typeof ordersPayload.caps === "object" ? ordersPayload.caps : null;
  const capsState = caps
    ? caps.configured === true && Number(caps.acknowledged_version) === Number(caps.safety_config_version)
      ? `四上限已确认 v${escapeHtml(predictionValue(caps.acknowledged_version, "-"))}`
      : "四上限未确认"
    : "四上限未确认";
  const incident = payload?.n_leg_incident && typeof payload.n_leg_incident === "object" ? payload.n_leg_incident : null;
  const queueLine = incident
    ? `<p class="pm-n-leg-order-queue">事故处理中（批次 ${escapeHtml(predictionValue(incident.execution_batch_id))}）· 下单队列已清空 · 解除后恢复 <button type="button" class="pm-relation-badge pm-n-leg-report-entry" data-action="open-nleg-report">执行报告</button></p>`
    : ordersPayload
    ? `<p class="pm-n-leg-order-queue">下单队列 ${queueRows.length} · ${queueRows.map((row, index) => `#${index + 1} ${row.state === "PENDING" ? "等待发单预检" : escapeHtml(String(row.state))}`).join(" · ") || "空"} · ${capsState} <button type="button" class="pm-relation-badge pm-n-leg-report-entry" data-action="open-nleg-report">执行报告</button></p>`
    : "";
  return `<section class="pm-metrics pm-n-leg-metrics-overview" aria-label="N_LEG 性能指标">${cards}${queueLine}</section>`;
}

const PREDICTION_RELATION_REVIEW_STATES = {
  PENDING_APPROVAL: {label: "待批准", short: "待批准", tone: ""},
  APPROVED_MODEL_INCOMPLETE: {label: "已批准 · 模型不完整", short: "模型不完整", tone: ""},
  COMPILED_PENDING_ACTIVATION: {label: "编译补全待激活", short: "编译补全待激活", tone: ""},
  ACTIVATION_BLOCKED: {label: "激活阻断", short: "激活阻断", tone: "block"},
  ACTIVATED: {label: "已激活", short: "已激活", tone: "ok"},
  SOURCE_CHANGED_REAPPROVAL: {label: "来源变化需重批", short: "需重批", tone: ""},
};

function predictionRelationReview(payload) {
  const review = payload?.relation_review && typeof payload.relation_review === "object" ? payload.relation_review : {};
  const counts = review.counts && typeof review.counts === "object" ? review.counts : {};
  const pending = Number(review.pending_count || 0);
  const chips = Object.entries(PREDICTION_RELATION_REVIEW_STATES).map(([key, meta]) => {
    const count = Number(counts[key] || 0);
    return `<button type="button" class="pm-relation-chip${meta.tone ? ` is-${meta.tone}` : ""}" data-open-relation-view="${key.toLowerCase()}"><span class="pm-relation-chip-label">${meta.label}</span><span class="pm-relation-chip-count">${Number.isFinite(count) ? count : 0}</span></button>`;
  }).join("");
  return `<section class="pm-relation-drawer" aria-label="关系审核概览"><header style="display:flex;justify-content:space-between;align-items:start"><div><h2>关系审核</h2><p>六态状态计数 · 点击任一状态进入对应审核视图。</p></div><button class="pm-relation-badge" type="button" data-action="open-relation-review">待批准 <strong>${Number.isFinite(pending) ? pending : 0}</strong></button></header><div class="pm-relation-chips">${chips}</div></section>`;
}

function predictionUnifiedPageHeader(payload) {
  const [health, tone] = predictionStatusLabel(payload);
  const heartbeat = payload?.heartbeat_at || payload?.heartbeat;
  const contractGeneration = payload?.n_leg?.contract_generation ?? payload?.contract_generation;
  const contract = contractGeneration
    ? ` · contract generation ${escapeHtml(contractGeneration)}`
    : "";
  const pending = Number(payload?.relation_review?.pending_count || 0);
  return `<header class="pm-page-head"><div><h2>多腿套利</h2><p>单一 N_LEG 机会 read model；历史 YES_NO / LLM_RELATION 只读保留。</p></div><div class="pm-updated"><button class="pm-relation-badge" type="button" data-action="open-relation-review">关系审核 <strong>${Number.isFinite(pending) ? pending : 0}</strong></button><span class="pm-status-line"><i class="pm-status-dot ${tone === "danger" ? "danger" : ""}"></i>${health}</span><br>${predictionClock("Watcher 数据时间", heartbeat)}${contract}</div></header>`;
}

function predictionNLegIncidentPanel(payload) {
  // #64: read-only incident banner + unlock entry. The panel shows what
  // happened and what was paid; the actual position fix happens out-of-band,
  // then the unlock button asks the server to re-check batch receipts and
  // the ledger before it re-opens the gate.
  const incident = payload?.n_leg_incident;
  if (!incident || typeof incident !== "object") return "";
  const legs = Array.isArray(incident.legs) ? incident.legs : [];
  const legRows = legs.map((leg) => `<div class="pm-check"><span>第 ${Number(leg.index)} 腿 · ${leg.direction === "BUY_YES" ? "买 YES" : "买 NO"} · ${escapeHtml(predictionValue(leg.title, "市场未返回"))}</span><strong>${leg.state === "FILLED" ? `已成交 ${escapeHtml(String(leg.filled_quantity))}/${escapeHtml(String(leg.quantity))} 份 · 成本 ${escapeHtml(predictionNLegUnitsMoney(leg.cost_units))}` : leg.state === "REJECTED" ? "未成交（FOK 全撤，未花钱）" : escapeHtml(String(leg.state))}</strong></div>`).join("");
  return `<section class="pm-alert danger" role="alert" aria-label="N_LEG 执行事故"><div class="pm-alert-body"><strong>N_LEG 执行事故 · 已停止全部新订单</strong><p>${incident.reason === "PARTIAL_FILL" ? "部分成交" : escapeHtml(String(incident.reason ?? "-"))} · 批次 ${escapeHtml(predictionValue(incident.execution_batch_id))} · 发生时间 ${escapeHtml(predictionValue(incident.happened_at))}</p>${legRows}<div class="pm-check"><span>已付现金</span><strong>${escapeHtml(predictionNLegUnitsMoney(incident.paid_cash_units))}</strong></div><small>处置：在系统外（Polymarket）处理未对冲敞口——补买另一腿或等待结算；完成后回此解除事故门。下单队列已清空，解除后恢复。</small></div>${predictionWritesBlocked() ? `<p class="sub" role="status">${escapeHtml(predictionServiceIdentity().label)} · 写操作不可用。</p>` : `<button class="pm-button danger" type="button" data-action="nleg-incident-unlock">对账完成，解除事故门</button>`}</section>`;
}

function predictionUnifiedPage(payload, filter) {
  const viewPayload = payload || {status: "loading", events: [], opportunities: []};
  const filterState = state.predictionMarket.filter || {engine: "all", kind: "all", legs: null, scope: null};
  return `${predictionUnifiedPageHeader(viewPayload)}${predictionModeBar(viewPayload)}${predictionNLegIncidentPanel(viewPayload)}${predictionNLegMetrics(viewPayload)}${predictionCapitalUsage(viewPayload)}${predictionObservationCoverage(viewPayload)}${predictionUnifiedOpportunityList(viewPayload, filterState)}${predictionRelationReview(viewPayload)}${predictionErrorAlert()}${predictionExecutionAlert(viewPayload)}${relationReviewDrawer()}${nlegReportDrawer()}`;
}

function predictionVenueSummary() {
  const payload = state.predictionMarket.venuesPayload;
  const error = state.predictionMarket.venuesError;
  const nLeg = payload?.n_leg && typeof payload.n_leg === "object" ? payload.n_leg : {};
  const summary = Array.isArray(payload?.venues) && payload.venues.length
    ? predictionReadinessStrip(payload)
    : `<section class="pm-readiness pm-venue-readiness" aria-label="交易所连接与账户状态"><article class="pm-readiness-item"><span>平台状态</span><strong>UNKNOWN</strong><small>${escapeHtml(error || "等待首次同步")}</small></article></section>`;
  const nLegStatus = predictionSplit() ? state.predictionMarket.nLegStatus : nLeg.status;
  const pauseNotice = nLegStatus === "paused"
    ? `<p class="pm-signal-error" role="status">多腿套利已暂停 · 仅保留 LP 请求</p>`
    : "";
  const stale = error
    ? `<p class="pm-signal-error" role="status">平台摘要读取失败 · UNKNOWN · ${escapeHtml(error)} · 保留上次成功状态</p>`
    : "";
  return pauseNotice + summary + stale;
}

function predictionMarketTabs() {
  const active = state.predictionMarket.activeTab === "multi_leg" ? "multi_leg" : "lp";
  return `<div class="pm-strategy-tabs" role="tablist" aria-label="预测市场子页面"><button id="prediction-market-tab-lp" type="button" role="tab" data-prediction-tab="lp" aria-controls="prediction-market-panel-lp" aria-selected="${active === "lp"}" tabindex="${active === "lp" ? "0" : "-1"}">LP 首页</button><button id="prediction-market-tab-multi-leg" type="button" role="tab" data-prediction-tab="multi_leg" aria-controls="prediction-market-panel-multi-leg" aria-selected="${active === "multi_leg"}" tabindex="${active === "multi_leg" ? "0" : "-1"}">多腿套利</button></div>`;
}

function predictionWorkspacePage() {
  const active = state.predictionMarket.activeTab === "multi_leg" ? "multi_leg" : "lp";
  const identity = predictionServiceIdentity();
  const serviceNotice = identity.state === "unknown"
    ? `<section class="pm-readiness" aria-label="Prediction 服务身份状态"><article class="pm-readiness-item"><span>服务身份</span><strong data-service-identity-status>服务身份 UNKNOWN</strong><small>mode/mutations 不一致或不可用；写操作已阻止。</small></article></section>`
    : predictionServiceReadOnly()
      ? `<section class="pm-readiness" aria-label="Shadow 模式状态"><article class="pm-readiness-item"><span>运行模式</span><strong data-shadow-status>Shadow 只读</strong><small>${state.predictionMarket.nLegStatus === "paused" ? "LP 实时数据暂不可用；这不是生产正常交易看板。" : "写操作已阻止；这不是生产正常交易看板。"}</small></article></section>`
      : "";
  const pane = active === "multi_leg"
    ? predictionUnifiedPage(state.predictionMarket.payload || {status: "loading", events: [], opportunities: []})
    : predictionLpCard({lp_dashboard: state.predictionMarket.lpDashboard, lp_error: state.predictionMarket.lpDashboardError});
  const panelId = active === "multi_leg" ? "prediction-market-panel-multi-leg" : "prediction-market-panel-lp";
  const tabId = active === "multi_leg" ? "prediction-market-tab-multi-leg" : "prediction-market-tab-lp";
  return `<header class="pm-page-head"><div><h1>预测市场</h1></div></header>${serviceNotice}${predictionVenueSummary()}${predictionMarketTabs()}<section id="${panelId}" role="tabpanel" aria-labelledby="${tabId}">${pane}</section>`;
}

function lpDashboardRows(value) {
  return Array.isArray(value)
    ? value.filter((row) => row && typeof row === "object" && !Array.isArray(row))
    : [];
}

function lpDashboardMoney(value) {
  return predictionHasValue(value) && Number.isFinite(Number(value))
    ? predictionMoney(value, "UNKNOWN")
    : "UNKNOWN";
}

function lpDashboardPrice(value) {
  const price = Number(value);
  if (!predictionHasValue(value) || !Number.isFinite(price) || price < 0 || price > 1) return "UNKNOWN";
  return (price * 100).toFixed(2).replace(/\.?0+$/, "") + "¢";
}

function lpMarketTitle(item) {
  return String(item.market_title || item.market || item.question || "标的未返回");
}

function lpMarketTitleLink(item) {
  const title = escapeHtml(lpMarketTitle(item));
  const url = String(item.market_url || "").trim();
  if (!/^https:\/\/polymarket\.com\/[^"'<>\\\s]+$/i.test(url)) return "<strong>" + title + "</strong>";
  return "<strong><a href=\"" + escapeHtml(url)
    + "\" rel=\"noopener noreferrer\" target=\"_blank\">" + title + "</a></strong>";
}

function lpDashboardRewards(value) {
  if (Array.isArray(value)) {
    return Object.fromEntries(value
      .filter((item) => item && typeof item === "object" && item.condition_id)
      .map((item) => [String(item.condition_id), item]));
  }
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function lpDashboardShareIsCurrent(share) {
  if (!share || typeof share !== "object"
      || share.state !== "known" || share.historical === true || share.stale === true) return false;
  const checkedAt = Date.parse(String(share.last_success_at || share.checked_at || ""));
  const age = Date.now() - checkedAt;
  return Number.isFinite(checkedAt) && age >= 0 && age < 30 * 1000;
}

function lpDashboardShareSignedDelta(value) {
  if (!predictionHasValue(value) || !Number.isFinite(Number(value))) return "UNKNOWN";
  const number = Number(value);
  return (number > 0 ? "+" : "") + String(value) + " 个百分点";
}

function lpDashboardSharePill(share, value) {
  let status = "target";
  if (value < 5) status = "space";
  else if (value > 8) status = "excess";
  const suppliedDelta = predictionHasValue(share.target_delta_percentage_points)
    ? String(share.target_delta_percentage_points)
    : status === "space"
      ? String(5 - value)
      : status === "excess" ? String(value - 8) : "0";
  const label = status === "space"
    ? "还有空间 " + suppliedDelta + " 个百分点"
    : status === "excess"
      ? "⚠ 份额超额 " + suppliedDelta + " 个百分点"
      : "已达目标";
  const tone = status === "excess" ? " class=\"pm-pill watch\"" : " class=\"pm-pill\"";
  return "<span" + tone + ">" + escapeHtml(label) + "</span>";
}

function lpDashboardBookSharePercent(value) {
  return Number(value).toFixed(1).replace(/\.0$/, "") + "%";
}

function lpDashboardBookShareLines(observation) {
  const directions = observation && typeof observation === "object"
    && Array.isArray(observation.risk_directions)
    ? observation.risk_directions.filter((row) => row && typeof row === "object")
    : [];
  const sideLabels = {BUY: "买侧", SELL: "卖侧"};
  const lines = [];
  directions.forEach((direction) => {
    const shares = direction.book_shares
      && typeof direction.book_shares === "object"
      && !Array.isArray(direction.book_shares)
      ? direction.book_shares : null;
    ["BUY", "SELL"].forEach((side) => {
      const entry = shares && shares[side] && typeof shares[side] === "object"
        ? shares[side] : null;
      const own = Number(entry && entry.own_side_quantity);
      const total = Number(entry && entry.side_total_quantity);
      const pct = Number(entry && entry.book_share_pct);
      if (entry && Number.isFinite(own) && own > 0
        && Number.isFinite(total) && total > 0 && Number.isFinite(pct)) {
        lines.push("<span class=\"sub\">盘口 <strong>"
          + escapeHtml(lpDashboardBookSharePercent(pct))
          + "</strong> · 我的挂单 " + escapeHtml(formatDisplayNumber(String(own)))
          + "／" + sideLabels[side] + " "
          + escapeHtml(formatDisplayNumber(String(total))) + " 份</span>");
      }
    });
  });
  return lines;
}

function lpDashboardShareCell(share, observation) {
  const bookLines = lpDashboardBookShareLines(observation);
  const hasDirections = observation && typeof observation === "object"
    && Array.isArray(observation.risk_directions)
    && observation.risk_directions.length > 0;
  const bookMarkup = bookLines.join("")
    + (bookLines.length === 0 && hasDirections
      ? "<span class=\"sub pm-lp-unknown\">盘口 UNKNOWN</span>"
      : "");
  const hasShare = share && typeof share === "object"
    && predictionHasValue(share.percentage) && Number.isFinite(Number(share.percentage));
  if (!hasShare) {
    return "<div class=\"num\"><span class=\"pm-lp-unknown\">奖励 UNKNOWN</span>"
      + bookMarkup + "</div>";
  }
  const actualValue = String(share.percentage);
  if (!lpDashboardShareIsCurrent(share)) {
    const checkedAt = predictionHasValue(share.last_success_at || share.checked_at)
      ? predictionHktTimestamp(share.last_success_at || share.checked_at)
      : "UNKNOWN";
    return "<div class=\"num pm-lp-unknown\">奖励 <strong>" + escapeHtml(actualValue)
      + "%</strong><span class=\"sub\">暂不可判断 · 上次值 " + escapeHtml(actualValue)
      + "% · 上次成功 " + escapeHtml(checkedAt) + "</span>" + bookMarkup + "</div>";
  }
  return "<div class=\"num\">奖励 <strong>" + escapeHtml(actualValue) + "%</strong> "
    + lpDashboardSharePill(share, Number(actualValue)) + bookMarkup + "</div>";
}

function lpDashboardObservations(value) {
  if (Array.isArray(value)) {
    return Object.fromEntries(value
      .filter((item) => item && typeof item === "object" && item.condition_id)
      .map((item) => [String(item.condition_id), item]));
  }
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function lpDashboardRate(value) {
  if (!predictionHasValue(value)) return "—";
  const number = Number(value);
  if (!Number.isFinite(number)) return "—";
  if (number === 0) return "0%／小时";
  if (number > 0 && number < 0.005) return "<0.01%／小时";
  return `${number.toFixed(2).replace(/\.?0+$/, "")}%／小时`;
}

function lpDashboardObservationReason(reason) {
  const labels = {
    current_yield_unknown: "当前收益率未知",
    reward_rate_unknown: "奖励率未知",
    reward_market_missing: "奖励市场缺失",
    reward_rates_unknown: "奖励数据未知",
    reward_rates_stale: "数据过期",
    reward_qualification_unknown: "计奖资格未知",
    risk_unknown: "风险未知",
    risk_warning: "风险已触线",
    yield_below_threshold: "收益率低于 0.1%／小时",
    trial_baseline_unrecorded: "小单基准未记录",
    no_exposure: "无占用本金",
    account_facts_unknown: "账户数据未知",
    account_snapshot_stale: "账户快照过期",
    account_facts_stale: "账户事实过期",
    observation_stale: "观察数据过期",
    exposure_changed: "账户敞口已变化，等待刷新",
    book_stale: "盘口过期",
    book_unknown: "盘口未知",
    fees_unknown: "费用未知",
    fee_unknown: "费用未知",
  };
  return labels[String(reason)] || (reason ? String(reason).replace(/_/g, " ") : "数据未知");
}

function lpDashboardAccountFactsStale(observation) {
  const reason = String(observation?.reason || "");
  return [
    "account_snapshot_stale",
    "account_facts_unknown",
    "account_facts_stale",
    "observation_stale",
    "exposure_changed",
  ].includes(reason);
}

function lpDashboardObservationDetail(observation, reward, risk) {
  const baseline = observation.trial_baseline && typeof observation.trial_baseline === "object"
    ? observation.trial_baseline
    : observation.trial_reference && typeof observation.trial_reference === "object"
      ? observation.trial_reference
    : null;
  const baselineText = baseline
    ? `试挂基准 ${escapeHtml(lpDashboardRate(baseline.yield_pct_per_hour))} · ${escapeHtml(lpDashboardMoney(baseline.occupied_capital_usd))} · ${escapeHtml(predictionValue(baseline.quantity, "UNKNOWN"))} 份 × ${escapeHtml(lpDashboardPrice(baseline.price))} · ${escapeHtml(predictionHktTimestamp(baseline.checked_at, "UNKNOWN"))}`
    : `试挂基准未记录 · ${escapeHtml(lpDashboardObservationReason(observation.reason || "trial_baseline_unrecorded"))}`;
  const accountFactsStale = lpDashboardAccountFactsStale(observation);
  const qualified = accountFactsStale
    ? "UNKNOWN"
    : observation.qualified === true
    ? "已确认"
    : observation.qualified === false
      ? "未确认"
      : "UNKNOWN";
  // Issue #140: show why the three-state qualification was derived.
  const qualificationBasisLabels = {
    orders_scoring: "依据：全部订单官方计分中",
    orders_not_scoring: "依据：全部订单官方未计分",
    reward_share_positive: "依据：奖励份额为正",
  };
  const qualificationBasis = accountFactsStale
    ? "依据：未知"
    : qualificationBasisLabels[observation.qualification_basis] || "依据：未知";
  const currentReward = observation.state === "known" && !accountFactsStale
    ? lpDashboardMoney(observation.current_hourly_reward_usd)
    : "UNKNOWN";
  const capital = accountFactsStale ? "UNKNOWN" : lpDashboardMoney(observation.occupied_capital_usd);
  const addRoom = !accountFactsStale && observation.add_room && observation.add_room.available === true ? "有" : "无";
  const addRoomReason = addRoom === "无"
    ? lpDashboardObservationReason(observation.add_room?.reason || observation.reason)
    : "当前收益与风险均满足门槛";
  const checkedAt = predictionHasValue(observation.checked_at)
    ? predictionHktTimestamp(observation.checked_at)
    : "UNKNOWN";
  const channelRows = observation.risk_alerts && typeof observation.risk_alerts === "object"
    ? Object.entries(observation.risk_alerts)
      .flatMap(([, alert]) => alert && typeof alert === "object" && alert.channels && typeof alert.channels === "object"
        ? Object.entries(alert.channels).map(([channel, result]) => `${channel}：${result && result.success === true ? "已发送" : result && result.suppressed === true ? "静音" : "未发送"}`)
        : [])
    : [];
  const alertRows = observation.risk_alerts && typeof observation.risk_alerts === "object"
    ? Object.values(observation.risk_alerts)
      .filter((alert) => alert && typeof alert === "object" && (predictionHasValue(alert.title) || predictionHasValue(alert.message)))
      .map((alert) => {
        const title = predictionHasValue(alert.title) ? escapeHtml(alert.title) : "";
        const message = predictionHasValue(alert.message)
          ? escapeHtml(alert.message).replace(/\r?\n/g, "<br>")
          : "";
        return `<div class="sub">飞书与语音原文：${title}${title && message ? "<br><br>" : ""}${message}</div>`;
      })
    : [];
  return `<details class="pm-lp-observation-details"><summary>详情</summary><div class="sub">预计小时奖励 ${escapeHtml(currentReward)} · 占用本金 ${escapeHtml(capital)} · 计奖资格 ${escapeHtml(qualified)} · ${escapeHtml(qualificationBasis)}</div><div class="sub">${baselineText}</div><div class="sub">加单空间 ${escapeHtml(addRoom)} · ${escapeHtml(addRoomReason)}</div><div class="sub">数据时间 ${escapeHtml(checkedAt)}</div>${channelRows.length ? `<div class="sub">告警投递：${escapeHtml(channelRows.join(" · "))}</div>` : ""}<div class="sub">奖励与到账：${reward}</div><div class="sub">风险与托管状态：${risk}</div><div class="sub">压力估算：实际持仓＋未成交买单余量；未成交部分按假设成交估算，不是已发生亏损。</div><div class="sub">通知时段：飞书全天；语音北京时间 23:00–08:00 静音。</div>${alertRows.join("")}</details>`;
}

function lpDashboardRatePercent(value) {
  const rate = lpDashboardRate(value);
  return rate.endsWith("／小时") ? rate.slice(0, -"／小时".length) : rate;
}

function lpDashboardYieldCell(observation) {
  const source = observation && typeof observation === "object" ? observation : null;
  const accountFactsStale = source ? lpDashboardAccountFactsStale(source) : false;
  const baselineSource = source
    && source.trial_baseline && typeof source.trial_baseline === "object"
    ? source.trial_baseline
    : source && source.trial_reference
      && typeof source.trial_reference === "object"
      ? source.trial_reference
      : null;
  const recommended = baselineSource
    && predictionHasValue(baselineSource.yield_pct_per_hour)
    && Number.isFinite(Number(baselineSource.yield_pct_per_hour))
    ? lpDashboardRatePercent(baselineSource.yield_pct_per_hour)
    : "—";
  const yieldKnown = source && source.state === "known" && !accountFactsStale
    && Number.isFinite(Number(source.current_yield_pct_per_hour));
  const actual = yieldKnown
    ? lpDashboardRatePercent(source.current_yield_pct_per_hour)
    : "待更新";
  const note = yieldKnown
    ? "<span class=\"sub\">%／小时</span>"
    : "<span class=\"sub\">市场奖励率未知 · 不按 0 计</span>";
  const actualTone = yieldKnown ? "" : " class=\"pm-lp-unknown\"";
  return "<div class=\"num\">推荐 <strong>" + escapeHtml(recommended)
    + "</strong> → 实际 <strong" + actualTone + ">" + escapeHtml(actual)
    + "</strong>" + note + "</div>";
}

// LP-TR-1: 当天委托表「今日奖励(累计 · $/小时)」格。累计行与结算卡
// lpDashboardRewardSummary 同源同值（market_rewards 载荷，市场级合计，
// 计奖日 UTC 当日累计）：仅 reward.state === "known" 按已知渲染——
// USD → predictionExactMoney 绿色金额；非 USD → 原始币种串；
// state 非 known（含读失败保留旧值与 usd_value_unknown 条目）一律
// UNKNOWN，但保留上次值/上次成功时间，绝不按 0 计。小时行与
// lpDashboardYieldCell 同一已知判定（state=known 且账户事实未过期），
// 金额经 lpDashboardMoney。
function lpDashboardTodayRewardCell(firstOrder, rewards, observation) {
  const identity = String(firstOrder?.condition_id || "");
  const reward = identity && rewards[identity] && typeof rewards[identity] === "object"
    ? rewards[identity] : {};
  const currency = String(reward.currency || "").toUpperCase();
  const rawAmount = reward.market_amount_raw ?? reward.raw_amount;
  const rawAsset = reward.asset || reward.market_asset
    || (currency !== "USD" ? reward.currency : "");
  const dataNote = "<span class=\"sub\">数据 "
    + escapeHtml(predictionHktTimestamp(reward.checked_at || reward.last_success_at, "UNKNOWN"))
    + " · 计奖日(UTC)当日累计</span>";
  const rewardReadFailed = reward.state !== "known"
    && ["reward_read_unknown", "reward_read_failed", "reward_catalog_read_failed"]
      .includes(String(reward.reason || ""));
  let amountLine;
  let noteLine;
  if (reward.state === "known" && currency === "USD"
    && predictionHasValue(reward.market_amount)) {
    amountLine = "今日已赚 <strong class=\"pm-tone-ok\">"
      + escapeHtml(predictionExactMoney(reward.market_amount, "UNKNOWN")) + "</strong>";
    noteLine = dataNote;
  } else if (predictionHasValue(rawAmount) && predictionHasValue(rawAsset)
    && reward.stale !== true && !rewardReadFailed) {
    const amount = escapeHtml(String(rawAmount) + " " + String(rawAsset));
    amountLine = "平台累计 <strong>" + amount + "</strong>";
    const usdNote = reward.state === "known" ? "" : "USD 估值 UNKNOWN · ";
    noteLine = "<span class=\"sub\">" + usdNote
      + (reward.paid === true ? "已核实到账" : "未核实到账") + "</span>" + dataNote;
  } else if (predictionHasValue(rawAmount) && predictionHasValue(rawAsset)
    && reward.stale === true) {
    const amount = escapeHtml(String(rawAmount) + " " + String(rawAsset));
    amountLine = "陈旧保留 <strong>" + amount + "</strong>";
    noteLine = "<span class=\"sub\">USD 估值 UNKNOWN · 未核实到账</span>" + dataNote;
  } else {
    amountLine = "今日已赚 <span class=\"pm-lp-unknown\">UNKNOWN</span>";
    const retained = predictionHasValue(reward.market_amount)
      || predictionHasValue(rawAmount)
      || predictionHasValue(reward.last_success_at);
    noteLine = retained
      ? "<span class=\"sub\">上次成功 "
        + escapeHtml(predictionHktTimestamp(reward.last_success_at || reward.checked_at, "UNKNOWN"))
        + " · 读取失败先保留旧值</span>"
      : "<span class=\"sub\">奖励数据未知 · 不按 0 计</span>";
  }
  const source = observation && typeof observation === "object" ? observation : null;
  const hourlyKnown = Boolean(source) && source.state === "known"
    && !lpDashboardAccountFactsStale(source)
    && predictionHasValue(source.current_hourly_reward_usd)
    && Number.isFinite(Number(source.current_hourly_reward_usd));
  const hourlyLine = hourlyKnown
    ? "≈<strong>" + escapeHtml(lpDashboardMoney(source.current_hourly_reward_usd)) + "</strong>/小时"
    : "≈<span class=\"pm-lp-unknown\">UNKNOWN</span>/小时";
  return "<div class=\"num\">" + amountLine + hourlyLine + noteLine + "</div>";
}

function lpDashboardRewardSummary(item, rewards) {
  const identity = String(item.condition_id || "");
  const reward = identity && rewards[identity] && typeof rewards[identity] === "object"
    ? rewards[identity] : {};
  const rawAmount = reward.market_amount_raw ?? reward.raw_amount;
  const rawAsset = reward.asset || reward.market_asset || (String(reward.currency || "").toUpperCase() !== "USD" ? reward.currency : "");
  const currency = String(reward.currency || "").toUpperCase();
  const amount = predictionHasValue(rawAmount) && predictionHasValue(rawAsset)
    ? String(rawAmount) + " " + String(rawAsset)
    : currency === "USD" && predictionHasValue(reward.market_amount)
      ? predictionExactMoney(reward.market_amount, "UNKNOWN")
      : "UNKNOWN";
  const paid = reward.paid === true ? "已核实到账" : "平台累计，未核实到账";
  const score = lpDashboardOfficialScoring(item);
  // Issue #140: a failed/stale scoring poll shows when the order was last
  // confirmed, instead of dressing the unknown status up with a fresh clock.
  const scoringTimeLabel = score === "官方计分 UNKNOWN"
    ? (predictionHasValue(item.scoring_last_success_at)
      ? "最后成功 " + predictionHktTimestamp(item.scoring_last_success_at)
      : "UNKNOWN")
    : "查询时间 " + (predictionHasValue(item.scoring_checked_at)
      ? predictionHktTimestamp(item.scoring_checked_at)
      : "UNKNOWN");
  const marketReward = "市场累计 " + amount;
  return "<div><strong>" + escapeHtml(score) + "</strong><span class=\"sub\">"
    + escapeHtml(scoringTimeLabel) + "</span><span class=\"sub\">" + escapeHtml(marketReward)
    + "</span><span class=\"sub\">" + escapeHtml(paid) + "</span></div>";
}

function lpDashboardOfficialScoring(order) {
  // Issue #140: the backend now emits "true"/"false"/"unknown" strings, but
  // rolling releases may still serve JSON booleans; accept both explicitly
  // and never let a falsy status collapse into "unknown" via `||`.
  const raw = order.scoring_status;
  const status = typeof raw === "boolean"
    ? String(raw)
    : String(raw ?? "").trim().toLowerCase();
  if (status === "true" || status === "scoring") return "官方计分中";
  if (status === "false" || status === "not_scoring") return "官方未计分";
  return "官方计分 UNKNOWN";
}

function lpDashboardRiskCell(item, session) {
  const manual = item.read_only === true || item.management === "manual_read_only";
  const owned = !manual && session && (
    String(session.entry_order_id || "") === String(item.order_id || "")
    || String(session.token_id || "") === String(item.token_id || "")
  );
  const stop = manual
    ? "未接管止损"
    : owned && session.stop_loss_latched === true
      ? "止损已触发"
      : owned && session.stop_loss_latched === false
        ? "止损未触发"
        : "止损状态 UNKNOWN";
  const realized = owned && predictionHasValue(session.trade_pnl)
    ? predictionSignedMoney(session.trade_pnl, "UNKNOWN")
    : "UNKNOWN";
  const residual = owned && predictionHasValue(session.residual_pnl)
    ? predictionSignedMoney(session.residual_pnl, "UNKNOWN")
    : "UNKNOWN";
  const trigger = owned && predictionHasValue(session.opening_loss)
    ? "<span class=\"sub\">触发估损 " + escapeHtml(predictionMoney(session.opening_loss, "UNKNOWN")) + "</span>"
    : "";
  return "<div>" + escapeHtml(stop) + trigger + "<span class=\"sub\">已实现 "
    + escapeHtml(realized) + "</span><span class=\"sub\">持仓 P&amp;L "
    + escapeHtml(residual) + "</span></div>";
}

function lpDashboardExposureRiskCell(item, session, observation) {
  const legacy = lpDashboardRiskCell(item, session);
  if (!observation || typeof observation !== "object") return legacy;
  const accountFactsStale = lpDashboardAccountFactsStale(observation);
  const directions = !accountFactsStale && Array.isArray(observation.risk_directions)
    ? observation.risk_directions.filter((row) => row && typeof row === "object")
    : [];
  const rows = directions.length ? directions : [{
    state: !accountFactsStale && observation.risk_state === "known" ? "known" : "unknown",
    warning: accountFactsStale ? null : observation.risk_warning,
    risk_principal: accountFactsStale ? null : observation.occupied_capital_usd,
    stress_loss: null,
    loss_ratio: null,
    reason_codes: [observation.reason],
  }];
  const riskMarkup = rows.map((direction) => {
    const directionLabel = rows.length > 1
      ? `${escapeHtml(predictionValue(direction.outcome, "UNKNOWN"))} `
      : "";
    const known = direction.state === "known"
      && Number.isFinite(Number(direction.loss_ratio))
      && Number.isFinite(Number(direction.stress_loss));
    if (!known) {
      const reason = Array.isArray(direction.reason_codes) && direction.reason_codes[0]
        ? direction.reason_codes[0]
        : observation.reason || "risk_unknown";
      return `<div><strong>${directionLabel}— · —</strong><span class="sub">${escapeHtml(lpDashboardObservationReason(reason))}</span></div>`;
    }
    const ratio = `${(Number(direction.loss_ratio) * 100).toFixed(2).replace(/\.?0+$/, "")}%`;
    const amount = lpDashboardMoney(direction.stress_loss);
    const status = direction.warning === true ? "已触线" : "未触线";
    const tone = direction.warning === true ? " class=\"pm-tone-danger\"" : "";
    return `<div><strong${tone}>${directionLabel}${escapeHtml(ratio)} · ${escapeHtml(amount)}</strong><span class="sub"${tone}>${status}</span></div>`;
  }).join("");
  return riskMarkup;
}

function lpDashboardTodayFilled(row) {
  return String(row.state || "").toLowerCase() === "filled"
    || String(row.status || "").toUpperCase() === "MATCHED";
}

function lpDashboardTodayHasActiveOrder(row) {
  if (!row || typeof row !== "object" || lpDashboardTodayFilled(row)) return false;
  const status = String(row.status || "").toUpperCase();
  if (["CANCELLED", "CANCELED", "REJECTED", "EXPIRED", "DONE", "CLOSED"].includes(status)) return false;
  let remaining = Number(row.remaining_quantity);
  if (!Number.isFinite(remaining)) {
    const quantity = Number(row.quantity);
    const filled = Number(row.filled_quantity);
    remaining = Number.isFinite(quantity) && Number.isFinite(filled) ? quantity - filled : NaN;
  }
  return Number.isFinite(remaining) && remaining > 0;
}

function lpDashboardTodayGroups(rows) {
  const groups = new Map();
  const unidentified = [];
  rows.forEach((row) => {
    const conditionId = String(row.condition_id || "").trim();
    if (!conditionId) {
      // A row without a usable condition id still belongs to the today
      // table: render it as its own group and let the market-row cells fall
      // back to the no-observation display instead of dropping the data.
      unidentified.push({conditionId: "", orders: [row]});
      return;
    }
    if (!groups.has(conditionId)) groups.set(conditionId, []);
    groups.get(conditionId).push(row);
  });
  return [...groups.entries()]
    .map(([conditionId, orders]) => ({conditionId, orders}))
    .concat(unidentified);
}

// Issue 166 R2: 行级会话归因按行内订单自带的 session_id 映射 lp_sessions——
// 恰一组→该组；零组（手动行，或旧快照行未带 session_id）→退回按 condition
// 取最新组的旧口径；≥2 组→整组返回，由行渲染按组分行、不渲染加量按钮
// （归属不明不猜测）。
function lpDashboardRowSessions(group, sessionsById, sessionByCondition) {
  const found = [];
  const seen = new Set();
  (group.orders || []).forEach((order) => {
    const id = String(order.session_id || "");
    if (id && sessionsById[id] && !seen.has(id)) {
      seen.add(id);
      found.push(sessionsById[id]);
    }
  });
  if (found.length) return found;
  const legacy = sessionByCondition[group.conditionId];
  return legacy ? [legacy] : [];
}

// Issue 166 R2: 同 condition ≥2 组并存时，会话事实按组分行如实显示——
// 每行以该组 outcome 开头，止损/已实现/持仓状态取自该组自己的会话。
function lpDashboardMultiSessionRiskCell(sessions) {
  return sessions.map((entry) => {
    const own = {
      token_id: entry.token_id,
      order_id: entry.entry_order_id,
      read_only: false,
    };
    return "<div><strong>" + escapeHtml(predictionValue(entry.outcome, "UNKNOWN"))
      + "</strong>" + lpDashboardRiskCell(own, entry) + "</div>";
  }).join("");
}

function lpDashboardTodayMarketOrder(groups, observations) {
  const keyOf = (group) => {
    const observation = observations[group.conditionId]
      && typeof observations[group.conditionId] === "object"
      ? observations[group.conditionId] : null;
    const known = Boolean(observation)
      && observation.state === "known"
      && !lpDashboardAccountFactsStale(observation)
      && Number.isFinite(Number(observation.current_yield_pct_per_hour));
    return {
      // 完结沉底：组内任一委托仍有在挂余量才算活跃；活跃区在前，
      // 完结区沉底，两区各自沿用收益率降序 → condition_id 字典序。
      active: group.orders.some((row) => lpDashboardTodayHasActiveOrder(row)),
      known,
      value: known ? Number(observation.current_yield_pct_per_hour) : 0,
      conditionId: group.conditionId,
    };
  };
  return [...groups].sort((a, b) => {
    const ka = keyOf(a);
    const kb = keyOf(b);
    if (ka.active !== kb.active) return ka.active ? -1 : 1;
    if (ka.known !== kb.known) return ka.known ? -1 : 1;
    if (ka.known && ka.value !== kb.value) return kb.value - ka.value;
    return ka.conditionId.localeCompare(kb.conditionId);
  });
}

// Cancellation receipts stay visible independently of the confirmation modal.
// A replacement receipt owns its expiry; an older timer cannot clear it.
function clearLpCancelFeedback() {
  const prediction = state.predictionMarket;
  if (prediction.lpCancelFeedbackTimer !== null) window.clearTimeout(prediction.lpCancelFeedbackTimer);
  prediction.lpCancelFeedbackTimer = null;
  prediction.lpCancelFeedback = null;
}

function showLpCancelFeedback(feedback, expires = true) {
  clearLpCancelFeedback();
  state.predictionMarket.lpCancelFeedback = feedback;
  if (expires) {
    state.predictionMarket.lpCancelFeedbackTimer = window.setTimeout(() => {
      if (state.predictionMarket.lpCancelFeedback !== feedback) return;
      clearLpCancelFeedback();
      renderPredictionMarket();
    }, 15000);
  }
}

function lpCancelReasonLabel(reason) {
  const value = String(reason || "").trim();
  if (value === "unknown_order") return "订单已不在当前委托中";
  if (value === "not_active") return "订单已无可撤份额";
  return value || "服务端未提供原因";
}

function setLpCancelFeedback(result) {
  if (!result || !Array.isArray(result.canceled) || !Array.isArray(result.skipped)
    || !result.not_canceled || typeof result.not_canceled !== "object" || Array.isArray(result.not_canceled)) {
    throw new Error("服务端未返回完整撤单结果");
  }
  const canceled = result.canceled;
  const skipped = result.skipped;
  const failures = Object.entries(result.not_canceled);
  const count = canceled.length + skipped.length + failures.length;
  const requested = result.requested;
  const validOrderId = (value) => typeof value === "string" && value.trim().length > 0;
  if (!Number.isSafeInteger(requested) || requested < 0 || requested !== count
    || canceled.some((orderId) => !validOrderId(orderId))
    || skipped.some((row) => !row || !validOrderId(row.order_id) || typeof row.reason !== "string")
    || failures.some(([orderId, reason]) => !validOrderId(orderId) || typeof reason !== "string")) {
    throw new Error("服务端撤单结果不完整或数量不一致");
  }
  const title = failures.length ? "撤单未全部成功" : skipped.length ? "撤单结果 · 含跳过"
    : canceled.length ? "撤单成功" : "无可撤委托";
  showLpCancelFeedback({
    title,
    tone: failures.length ? "danger" : skipped.length ? "warning" : canceled.length ? "success" : "info",
    summary: `请求 ${requested} 笔 · 成功 ${canceled.length} 笔 · 跳过 ${skipped.length} 笔 · 失败 ${failures.length} 笔`,
    details: [
      ...skipped.map((row) => `跳过 · ${String(row.order_id || "订单编号未返回")}：${lpCancelReasonLabel(row.reason)}`),
      ...failures.map(([orderId, reason]) => `失败 · ${orderId}：${lpCancelReasonLabel(reason)}`),
    ],
  });
}

function lpCancelFeedbackMarkup() {
  const feedback = state.predictionMarket.lpCancelFeedback;
  if (!feedback) return "";
  const details = (feedback.details || []).map((line) => `<li>${escapeHtml(line)}</li>`).join("");
  return `<section class="pm-alert ${feedback.tone} lp-cancel-feedback" role="status" aria-live="polite" aria-atomic="true" tabindex="-1"><div class="pm-alert-body"><strong>${escapeHtml(feedback.title)}</strong><p>${escapeHtml(feedback.summary)}</p>${details ? `<ul>${details}</ul>` : ""}</div></section>`;
}

async function confirmLpCancel() {
  const prediction = state.predictionMarket;
  if (prediction.lpCancelInFlight) return;
  const modalEpoch = predictionModal.epoch;
  const ownsModal = () => predictionModal.epoch === modalEpoch && predictionModal.kind === "lp_cancel";
  const data = predictionModal.data || {};
  const orders = Array.isArray(data.orders) ? data.orders : [];
  const body = {confirm: true};
  if (data.scope === "order") body.order_ids = orders.map((row) => String(row.order_id || ""));
  else if (data.scope === "market") body.condition_id = String(data.conditionId || "");
  else body.scope = "all";
  const requestSeq = ++prediction.lpCancelRequestSeq;
  prediction.lpCancelInFlight = true;
  setPredictionModalBusy(true);
  showLpCancelFeedback({title: "正在撤单", tone: "info", summary: "等待服务端结果，请勿重复提交。关闭弹窗不会中止已发送的请求。"}, false);
  renderPredictionMarket();
  try {
    const result = await predictionPost("/api/prediction-arbitrage/lp/orders/cancel", body);
    if (requestSeq !== prediction.lpCancelRequestSeq) return;
    setLpCancelFeedback(result);
  } catch (error) {
    if (requestSeq !== prediction.lpCancelRequestSeq) return;
    showLpCancelFeedback({
      title: "撤单结果待核对", tone: "warning",
      summary: "未收到完整撤单回执，不能确认成功或失败。请核对刷新后的委托列表；系统不会自动重试。",
      details: [error instanceof Error ? error.message : String(error)],
    });
  } finally {
    if (requestSeq === prediction.lpCancelRequestSeq) {
      prediction.lpCancelInFlight = false;
      const showResult = ownsModal();
      if (showResult) closePredictionModal();
      // A reopened confirmation may have been disabled by the pending request.
      // Do not redraw it, change its selection, focus it, or affect other modals.
      if (predictionModal.kind === "lp_cancel" && !predictionModal.busy) {
        const confirm = elements["prediction-market-modal-root"].querySelector("[data-modal-action='lp-cancel-confirm']");
        if (confirm) confirm.disabled = predictionWritesBlocked();
      }
      // Show the receipt before waiting for the independently fallible refresh.
      renderPredictionMarket();
      if (showResult && state.workspaceView === "prediction_market" && prediction.activeTab === "lp") {
        elements["prediction-market-root"]?.querySelector(".lp-cancel-feedback")?.focus();
      }
      await fetchPredictionLpDashboard({force: true});
    }
  }
}

function lpDashboardCancelButton(kind, target) {
  const cancelAll = kind === "all";
  const source = target && typeof target === "object" ? target : {};
  const targetAttribute = cancelAll
    ? "data-action=\"lp-cancel-market\" data-condition-id=\""
      + escapeHtml(String(source.conditionId || "")) + "\""
    : "data-action=\"lp-cancel-order\" data-order-id=\""
      + escapeHtml(String(source.orderId || "")) + "\"";
  return "<button class=\"pm-button lp-cancel" + (cancelAll ? "-all" : "")
    + "\" type=\"button\" " + targetAttribute + " title=\"撤单即时生效\""
    + (predictionWritesBlocked() || state.predictionMarket.lpCancelInFlight ? " disabled" : "") + ">"
    + (cancelAll ? "撤全部" : "撤单") + "</button>";
}

function lpDashboardTodayOrderQuantity(row) {
  const filled = Number(row.filled_quantity);
  const remaining = Number(row.remaining_quantity);
  const quantity = Number(row.quantity);
  if (Number.isFinite(quantity) && quantity > 0) return quantity;
  if (Number.isFinite(filled) && Number.isFinite(remaining)) return filled + remaining;
  return NaN;
}

function lpDashboardTodaySubtitle(orders) {
  const parts = [];
  const outcomes = new Set(orders.map((row) => predictionValue(row.outcome, "UNKNOWN")));
  if (outcomes.size === 1) parts.push([...outcomes][0]);
  const sides = new Set(orders.map((row) => String(row.side || "").toUpperCase()));
  if (sides.size === 1) {
    const side = [...sides][0];
    parts.push(side === "BUY" ? "买入" : side === "SELL" ? "卖出" : predictionValue([...sides][0], "UNKNOWN"));
  }
  const scorings = new Set(orders.map((row) => lpDashboardOfficialScoring(row)));
  if (scorings.size === 1) parts.push([...scorings][0]);
  return parts.join(" · ");
}

function lpDashboardTodayPurposeLabel(row) {
  const purpose = String(row?.purpose || "");
  if (purpose === "trial") return "试挂";
  if (purpose === "formal") return "正式";
  return "";
}

// Issue 152: LP BUY 队列位置保护副行（登记锚 + 保守估算展示）。
const LP_QUEUE_PROTECTION_ABBR_TITLE =
  "保守估算：下单后同价位任何减少均计入前方，不区分成交与撤单；比例为预计值，不承诺防成交";
const LP_QUEUE_PROTECTION_UNANCHORED_TEXT =
  "位置未知 · 尚未建立位置保护（网页手动挂单，无下单基线）";
// Issue 159: first-seen baseline fallback badge (verbatim approved copy).
const LP_FIRST_SEEN_BADGE_TIP =
  "首见基线：以系统首次观察到该单时的盘口登记，通常滞后下单不超过一个观察周期（10 秒级）。滞后期间该价位新增挂单全部计入前方，前方估算偏高、触发偏晚，属兜底路径固有偏差。";

function lpQueueProtectionPercent(ratio) {
  // Issue 152 review: a missing estimate (null/undefined) must render as
  // UNKNOWN, never as Number(null) === 0%.
  if (ratio === null || ratio === undefined || ratio === "") return "UNKNOWN";
  const value = Number(ratio);
  if (!Number.isFinite(value)) return "UNKNOWN";
  return (value * 100).toFixed(2).replace(/\.?0+$/, "");
}

function lpQueueProtectionClock(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return "UNKNOWN";
  return new Intl.DateTimeFormat("zh-CN", {
    timeZone: "Asia/Hong_Kong",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(date);
}

function lpQueueProtectionPill(state) {
  const pills = {
    monitoring: {tone: "", label: "位置保护 · 监控中"},
    canceling: {tone: " status-warn", label: "位置保护 · 撤单中"},
    canceled: {tone: " status-ok", label: "位置保护 · 已撤"},
    partially_filled: {tone: " status-partial", label: "位置保护 · 部分成交"},
    unknown: {tone: " status-unknown", label: "位置保护 · 未知"},
    blocked: {tone: " status-danger", label: "位置保护 · 撤单受阻"},
  };
  const pill = pills[state] || pills.unknown;
  return "<span class=\"status-pill" + pill.tone + "\">" + escapeHtml(pill.label) + "</span>";
}

function lpQueueProtectionFirstSeenBadge() {
  // Issue 159: keyboard-focusable badge whose tooltip explains the
  // first-seen baseline's inherent conservative bias.
  return "<span class=\"qp-first-seen\" tabindex=\"0\">首见 · 估算假设"
    + "<span class=\"qp-first-seen-tip\" role=\"tooltip\">"
    + escapeHtml(LP_FIRST_SEEN_BADGE_TIP) + "</span></span>";
}

function lpQueueProtectionSourceChip(row) {
  const anchored = row?.anchor === true;
  // Issue 159: a first-seen anchor row is a web-manual BUY registered by
  // observation, not by the submit boundary.
  if (anchored && row?.queue_protection?.baseline_source === "first_observation") {
    return "<span class=\"src-chip first-seen\">首见</span>";
  }
  return "<span class=\"src-chip" + (anchored ? " registered" : "") + "\">"
    + (anchored ? "登记" : "手动") + "</span>";
}

// Issue 167: per-price protection buckets (v2 view); legacy scalars and
// first-seen episodes render as the single fallback bucket.
function lpQueueProtectionBuckets(summary) {
  if (!summary || typeof summary !== "object") return [];
  if (summary.levels && typeof summary.levels === "object") {
    return Object.values(summary.levels).filter(
      (bucket) => bucket && typeof bucket === "object",
    );
  }
  return [summary];
}

function lpDashboardTodayQueueSummary(orders) {
  for (const row of orders) {
    if (row && typeof row === "object"
      && row.queue_protection && typeof row.queue_protection === "object") {
      return row.queue_protection;
    }
  }
  return null;
}

function lpQueueSamePriceBuyRows(orders, summary) {
  const price = summary?.baseline_price ?? null;
  return orders.filter((row) => {
    if (String(row.side || "").toUpperCase() !== "BUY") return false;
    if (price === null || price === undefined || price === "") return true;
    const rowPrice = Number(row.price);
    const target = Number(price);
    if (Number.isFinite(rowPrice) && Number.isFinite(target)) return rowPrice === target;
    return String(row.price ?? "") === String(price);
  });
}

function lpQueueProtectionBlockReason(summary) {
  const codes = Array.isArray(summary.reason_codes) ? summary.reason_codes : [];
  if (codes.includes("mutation_blocked")) return "撤单被熔断阻止";
  if (codes.includes("identity_conflict")) return "回执身份不符";
  if (codes.includes("account_read_failed")) return "账户读取失败";
  return codes[0] ? String(codes[0]) : "撤单未成功";
}

// Issue 167: one protection subrow per price bucket; each row leads with
// its price chip (.qp-price). Legacy scalar payloads (and first-seen
// episodes) render as the single fallback bucket with no merged scalars.
function lpDashboardTodayQueueProtectionRow(orders) {
  const summary = lpDashboardTodayQueueSummary(orders);
  if (summary && typeof summary === "object") {
    const buckets = lpQueueProtectionBuckets(summary);
    if (buckets.length) {
      return buckets
        .map((bucket) => lpQueueProtectionBucketRow(orders, bucket))
        .join("");
    }
  }
  const buys = orders.filter((row) => String(row.side || "").toUpperCase() === "BUY");
  const sellOnly = orders.length > 0 && buys.length === 0;
  const text = sellOnly ? "不适用（卖出）" : LP_QUEUE_PROTECTION_UNANCHORED_TEXT;
  return "<div class=\"lp-queue-protection qp-none\">" + escapeHtml(text) + "</div>";
}

function lpQueueProtectionBucketRow(orders, summary) {
  const priceText = summary.level_price ?? summary.baseline_price;
  const priceChip = "<span class=\"qp-price\">"
    + escapeHtml(String(priceText ?? "UNKNOWN")) + "</span>";
  const buys = orders.filter((row) => String(row.side || "").toUpperCase() === "BUY");
    const samePrice = lpQueueSamePriceBuyRows(orders, summary);
    const targetCount = samePrice.length;
    const remaining = samePrice.reduce((sum, row) => {
      const value = Number(row.remaining_quantity);
      return sum + (Number.isFinite(value) && value > 0 ? value : 0);
    }, 0);
    const ratioText = lpQueueProtectionPercent(summary.ratio);
    const thresholdText = lpQueueProtectionPercent(summary.threshold ?? 0.5) || "50";
    const clock = lpQueueProtectionClock(summary.data_time);
    const state = String(summary.state || "unknown");
    // Issue 152 review: settled states report the persisted episode counts
    // (cancel targets / canceled receipts / cancel-time remaining); resting
    // rows vanish once orders drop off the open-order snapshot, so they are
    // only a fallback for summaries without the persisted fields and the
    // live "trigger" preview for monitoring.
    const idList = (value) => (Array.isArray(value)
      ? value.map((item) => String(item || "")).filter(Boolean)
      : null);
    const canceledIds = idList(summary.canceled_order_ids);
    const targetIds = idList(summary.cancel_targets);
    const persistedCount = canceledIds ? canceledIds.length
      : targetIds ? targetIds.length : null;
    const persistedRemaining = Number(summary.canceled_remaining);
    const hasPersistedRemaining = Number.isFinite(persistedRemaining);
    // Issue 152 review: canceled_remaining=null means the episode total is
    // UNKNOWN (some target had no readable cancel-time remaining); render
    // UNKNOWN instead of letting Number(null)=0 fabricate a 0 total.
    const remainingUnknown = summary.canceled_remaining === null;
    const ratioHead = ratioText === "UNKNOWN"
      ? "A UNKNOWN"
      : "A " + escapeHtml(ratioText) + "%";
    let data = "";
    // Issue 167: buckets collected by a group sweep (any-level fill) or the
    // review deadline render their own copy instead of a trigger ratio.
    const sweepReason = String(summary.cancel_reason || "");
    if (state === "canceling" && sweepReason === "group_fill_collect") {
      data = "随组收单（组内已成交）· 撤单请求已发，等待回执 · " + escapeHtml(clock);
    } else if (state === "canceled" && sweepReason === "group_fill_collect") {
      const remainValue = remainingUnknown
        ? "UNKNOWN"
        : (hasPersistedRemaining ? persistedRemaining : remaining);
      data = "随组收单（组内已成交）· 合计余量 "
        + escapeHtml(formatDisplayNumber(String(remainValue))) + " 份 · "
        + escapeHtml(clock);
    } else if (state === "monitoring") {
      data = "<abbr title=\"" + escapeHtml(LP_QUEUE_PROTECTION_ABBR_TITLE)
        + "\">前方≈" + escapeHtml(formatDisplayNumber(String(summary.front_estimate ?? "UNKNOWN")))
        + "</abbr> / 同价位 " + escapeHtml(formatDisplayNumber(String(summary.level_total ?? "UNKNOWN")))
        + " · <strong>A " + escapeHtml(ratioText) + "%</strong>（触发线 "
        + escapeHtml(thresholdText) + "%）· 触发撤同价 <strong>" + escapeHtml(String(targetCount))
        + " 张</strong> · " + escapeHtml(clock);
    } else if (state === "canceling") {
      const requestCount = targetIds ? targetIds.length : targetCount;
      const triggerHead = ratioText === "UNKNOWN"
        ? "A UNKNOWN（触发线 " + escapeHtml(thresholdText) + "%）"
        : "A " + escapeHtml(ratioText) + "% ≤ " + escapeHtml(thresholdText) + "% 已触发";
      data = triggerHead + " · " + escapeHtml(String(requestCount))
        + " 张撤单请求已发，等待回执 · " + escapeHtml(clock);
    } else if (state === "canceled") {
      const count = persistedCount ?? targetCount;
      const manual = Math.max(count - 1, 0);
      const remainValue = remainingUnknown
        ? "UNKNOWN"
        : (hasPersistedRemaining ? persistedRemaining : remaining);
      data = ratioHead + " 已触发 · "
        + escapeHtml(String(count)) + " 张全撤成功（含 " + escapeHtml(String(manual))
        + " 张手动）· 合计余量 " + escapeHtml(formatDisplayNumber(String(remainValue)))
        + " 份 · " + escapeHtml(clock);
    } else if (state === "partially_filled") {
      const filled = Number(summary.partially_filled_quantity);
      const filledText = Number.isFinite(filled) && filled > 0
        ? formatDisplayNumber(String(filled))
        : "UNKNOWN";
      const remainValue = remainingUnknown
        ? "UNKNOWN"
        : (hasPersistedRemaining ? persistedRemaining : remaining);
      data = "已成交 " + escapeHtml(filledText) + " / 已撤余量 "
        + escapeHtml(formatDisplayNumber(String(remainValue))) + " · 不补买 · "
        + escapeHtml(clock);
    } else if (state === "blocked") {
      data = ratioHead + " 已触发 · "
        + escapeHtml(lpQueueProtectionBlockReason(summary)) + " · 残余 <strong>"
        + escapeHtml(formatDisplayNumber(String(remaining))) + " 份</strong> · "
        + escapeHtml(clock);
    } else {
      const codes = Array.isArray(summary.reason_codes) ? summary.reason_codes : [];
      const reason = codes.includes("remaining_unknown") ? "回执缺失，" : "";
      data = reason + "位置无法估算 · " + escapeHtml(clock);
    }
    const triggered = ["canceling", "canceled", "blocked", "partially_filled"].includes(state);
    // Issue 159: the first-seen badge sits between the pill and the data.
    const firstSeenBadge = String(summary.baseline_source || "") === "first_observation"
      ? lpQueueProtectionFirstSeenBadge()
      : "";
    return "<div class=\"lp-queue-protection\">"
      + priceChip
      + lpQueueProtectionPill(state)
      + firstSeenBadge
      + "<span class=\"qp-data num" + (triggered ? " qp-triggered" : "") + "\">" + data + "</span></div>";
}

// Issue 158: the augment button renders only on the market row that owns the
// active system session; pure manual web rows never get one.  No preset
// gating beyond the panel-level read-only rule (design decision 3).
// Issue 166: the button names its owning group explicitly and renders only
// while that group is still entry_open — augments only land there.
function lpDashboardAugmentButtonMarkup(orders, session) {
  if (!session || typeof session !== "object") return "";
  const sessionState = String(session.state || "").toLowerCase();
  if (sessionState !== "entry_open") return "";
  const conditionId = String(orders[0]?.condition_id || "");
  if (!conditionId || String(session.condition_id || "") !== conditionId) return "";
  // Issue 165: the button names its owning session explicitly so clicks
  // can be gated against the served lp_session.
  // Issue 167: the button renames to「追加」and unlocks the price level.
  return "<button class=\"pm-button lp-augment\" type=\"button\""
    + " data-action=\"lp-augment-entry\" data-condition-id=\"" + escapeHtml(conditionId) + "\""
    + " data-session-id=\"" + escapeHtml(String(session.session_id || "")) + "\""
    + " title=\"追加一张 post-only BUY：价位须为本组还没有在挂的价格（不高于当前买一）；同价补量请先撤该价位再追加\""
    + ((predictionWritesBlocked() || !state.predictionMarket.csrfToken || lpSubmitCooldownActive()) ? " disabled" : "")
    + ">追加</button>";
}

// 「需要核对」文案表：行内说明线、会话卡告警块与后端通知共用同一张表——
// main 是整句契约文本，counter 仅在数据失败计数为有限数且 >0 时非空。
function lpNeedsAttentionCopy(session) {
  const code = String(session?.reconciliation ?? "");
  let main;
  if (code === "unowned_target_order") {
    main = "账户里有一张挂在本市场、但不归本组管理的单（常见：手工挂的单）。"
      + "系统已暂停本组自动管理，追加暂不可用；那张单撤掉或成交后自动恢复，无需操作。";
  } else if (code === "external_snapshot_unknown"
    || code === "book_unknown"
    || code === "book_freshness_unknown") {
    main = "市场/账户数据连续读取失败，系统自动重试中。";
  } else if (code === "execution_lock") {
    main = "等待其他交易操作完成，随后自动继续核对。";
  } else if (code === "market_read_timeout"
    || code === "market_read_in_progress"
    || code === "market_read_cooling_down"
    || code === "market_read_capacity"
    || code === "account_read_cooling_down"
    || code === "facts_read_capacity"
    || code === "facts_read_in_progress") {
    main = "市场/账户读取暂时受限，系统按计划重试。";
  } else if (code === "credential_invalid" || code === "account_identity_mismatch") {
    main = "账户身份或凭据需要人工确认，核对完成前继续保留占资。";
  } else if (code === "account_facts_stale"
    || code === "account_round_invalid"
    || code === "session_changed"
    || code === "trade_change_pending"
    || code === "account_facts_incomplete") {
    main = "账户事实已变化或未完整返回，系统重新读取中。";
  } else if (code.includes("submit_unknown")) {
    main = "一笔提交结果未知，需要到 Polymarket 订单页核对该单状态。";
  } else if (/^(stop_cancel_|deadline_cancel_|group_collect_)/.test(code)) {
    main = "一次撤单操作失败，系统自动重试中，长时间未恢复需人工核对。";
  } else {
    main = "系统暂停了本组的自动管理（原因：" + (code || "unknown") + "）。";
  }
  const failures = Number(session?.queue_protection?.data_failures);
  const counter = Number.isFinite(failures) && failures > 0
    ? "数据读取失败 " + failures + "/10，满 10 次将保护性撤单。"
    : "";
  return { main, counter };
}

function lpDashboardTodayQuantityCell(orders, session) {
  const filledSum = orders.reduce((sum, row) => {
    const filled = Number(row.filled_quantity);
    return sum + (Number.isFinite(filled) && filled > 0 ? filled : 0);
  }, 0);
  const remainingSum = orders.reduce((sum, row) => {
    const remaining = Number(row.remaining_quantity);
    return sum + (Number.isFinite(remaining) && remaining > 0 ? remaining : 0);
  }, 0);
  const totalSum = filledSum + remainingSum;
  const openOrders = orders.filter((row) => !lpDashboardTodayFilled(row));
  const cancellable = orders.filter((row) => lpDashboardTodayHasActiveOrder(row));
  const unifiedPrice = openOrders.length === orders.length && orders.length > 0
    && new Set(orders.map((row) => String(row.price ?? ""))).size === 1
    ? lpDashboardPrice(orders[0].price)
    : null;
  const multi = orders.length > 1;
  let headline = unifiedPrice
    ? unifiedPrice + " × " + (multi ? "合计 " : "") + formatDisplayNumber(String(totalSum)) + " 份"
    : "合计 " + formatDisplayNumber(String(totalSum)) + " 份";
  const quantityOf = (row) => {
    const quantity = lpDashboardTodayOrderQuantity(row);
    return Number.isFinite(quantity) ? quantity : 0;
  };
  const buySum = orders.reduce((sum, row) => (
    String(row.side || "").toUpperCase() === "BUY" ? sum + quantityOf(row) : sum
  ), 0);
  const sellSum = orders.reduce((sum, row) => (
    String(row.side || "").toUpperCase() === "SELL" ? sum + quantityOf(row) : sum
  ), 0);
  if (Number.isFinite(buySum) && Number.isFinite(sellSum) && buySum > 0 && sellSum > 0) {
    headline += " · 买入 " + formatDisplayNumber(String(buySum))
      + " · 卖出 " + formatDisplayNumber(String(sellSum));
  }
  if (!multi) {
    // A single-order group has no detail rows, so its 试挂/正式 annotation
    // must live on the headline itself; missing purpose data adds nothing.
    const purpose = lpDashboardTodayPurposeLabel(orders[0]);
    if (purpose) headline += " · " + purpose;
  }
  const singleBuyChip = !multi
    && String(orders[0]?.side || "").toUpperCase() === "BUY"
    ? lpQueueProtectionSourceChip(orders[0])
    : "";
  // 组级成交状态 pill：三态复用生产 token（中性 / status-partial 琥珀 / status-ok 绿）。
  const orderedTotal = orders.reduce((sum, row) => {
    const quantity = lpDashboardTodayOrderQuantity(row);
    return sum + (Number.isFinite(quantity) ? quantity : 0);
  }, 0);
  const groupPill = filledSum > 0
    ? (filledSum === orderedTotal
      ? "<span class=\"pm-pill status-ok\">完全成交 "
        + formatDisplayNumber(String(filledSum)) + "/" + formatDisplayNumber(String(orderedTotal)) + "</span>"
      : "<span class=\"pm-pill status-partial\">部分成交 "
        + formatDisplayNumber(String(filledSum)) + "/" + formatDisplayNumber(String(orderedTotal)) + "</span>")
    : (cancellable.length > 0
      ? "<span class=\"pm-pill\">挂单中 · 已成交 " + formatDisplayNumber(String(filledSum)) + "</span>"
      : "<span class=\"pm-pill\">已完结 · 未成交</span>");
  // 「需要核对」可见性：needs_attention 时行头加琥珀 pill，行内加原因整句说明线。
  const attention = session && typeof session === "object"
    && String(session.state || "").toLowerCase() === "needs_attention"
    ? lpNeedsAttentionCopy(session)
    : null;
  const attentionPill = attention
    ? "<span class=\"pm-pill status-attention\">需要核对</span>"
    : "";
  const attentionLine = attention
    ? "<div class=\"lp-attention-line\">需要核对 · " + escapeHtml(attention.main)
      + (attention.counter ? " " + escapeHtml(attention.counter) : "") + "</div>"
    : "";
  const fillLine = "已成交 " + formatDisplayNumber(String(filledSum))
    + " · 剩余 " + formatDisplayNumber(String(remainingSum));
  const augmentButton = lpDashboardAugmentButtonMarkup(orders, session);
  const cancelRight = cancellable.length >= 2
    ? lpDashboardCancelButton("all", {conditionId: orders[0]?.condition_id})
    : orders.length === 1 && cancellable.length === 1
      ? lpDashboardCancelButton("one", {orderId: orders[0]?.order_id})
      : "";
  const headlineRight = (cancelRight || augmentButton)
    ? "<span style=\"display:flex;gap:6px;align-items:center\">" + cancelRight + augmentButton + "</span>"
    : "";
  let markup = "<div class=\"lp-line\"><div>" + escapeHtml(headline)
    + (singleBuyChip ? " " + singleBuyChip : "")
    + (groupPill ? " " + groupPill : "")
    + (attentionPill ? " " + attentionPill : "")
    + "<span class=\"sub\">" + escapeHtml(fillLine) + "</span></div>"
    + headlineRight + "</div>";
  if (attentionLine) markup += attentionLine;
  const progress = session?.lp_progress;
  if (progress && typeof progress === "object") {
    const actionText = {
      manual_review: "人工核对",
      read_only_reconcile: "只读重试核对",
      protected_exit: "保护卖出",
      passive_exit: "被动卖出",
      reconcile_retry: "重试核对",
      review_deadline: "到期复核",
      monitor: "持续监控"
    }[String(progress.next_action || "")] || "下一步未知";
    const reserved = predictionHasValue(progress.reserved_usd)
      ? lpDashboardMoney(progress.reserved_usd)
      : "UNKNOWN";
    const reasonCode = String(progress.reason || "");
    const reason = reasonCode === "execution_lock"
      ? "等待其他交易操作完成"
      : reasonCode === "market_read_timeout" || reasonCode === "external_snapshot_unknown"
        ? "市场/账户读取未完成，下一轮继续核对"
      : reasonCode === "market_read_capacity" || reasonCode === "facts_read_capacity"
        ? "核对通道已占用，等待可用执行容量"
      : reasonCode === "facts_read_in_progress"
        ? "账户核对正在读取，等待返回"
      : reasonCode === "market_read_in_progress"
        ? "市场数据正在读取，等待返回"
      : reasonCode === "market_read_cooling_down" || reasonCode === "account_read_cooling_down"
        ? "数据服务要求等待，按限流期限重试"
      : ["account_facts_stale", "account_round_invalid", "session_changed", "trade_change_pending"].includes(reasonCode)
        ? "账户事实已变化，重新读取中"
      : reasonCode === "account_identity_mismatch" || reasonCode === "credential_invalid"
        ? "账户身份或凭据需要人工确认"
      : reasonCode === "missing_reliable_order_id"
        ? "缺少可靠订单编号，需要人工核对"
      : reasonCode === "duplicate_order_identity" || reasonCode === "order_identity_conflict"
        ? "订单归属冲突，需要人工核对"
      : reasonCode
        ? lpNeedsAttentionCopy({reconciliation: reasonCode}).main
        : "正常核对中";
    const checked = predictionHasValue(progress.last_good_check_at)
      ? predictionHktTimestamp(progress.last_good_check_at)
      : "UNKNOWN";
    const retry = predictionHasValue(progress.retry_at)
      ? predictionHktTimestamp(progress.retry_at)
      : null;
    markup += "<div class=\"sub lp-session-progress\">保留 "
      + escapeHtml(reserved)
      + " · 原因 " + escapeHtml(reason)
      + " · 上次核对 " + escapeHtml(checked)
      + " · " + escapeHtml(actionText)
      + (retry ? " · " + escapeHtml(retry)
        : progress.retry_source === "scheduler_check_in_progress" ? " · 当前核对进行中，完成后安排重试"
        : reasonCode === "market_read_capacity" || reasonCode === "facts_read_capacity" ? " · 暂无可用核对容量"
        : reasonCode === "facts_read_in_progress" ? " · 等待本次读取完成"
        : " · 等待下一轮调度")
      + (progress.manual_attention ? " · 需要人工处理" : "")
      + "</div>";
  }
  if (multi) {
    const sidesConsistent = new Set(orders.map((row) => String(row.side || "").toUpperCase())).size === 1;
    const purposes = orders.map((row) => lpDashboardTodayPurposeLabel(row));
    const purposesConsistent = new Set(purposes).size === 1;
    markup += orders.map((row) => {
      const parts = [formatDisplayNumber(String(lpDashboardTodayOrderQuantity(row)))
        + " 份 @ " + lpDashboardPrice(row.price)];
      const side = String(row.side || "").toUpperCase();
      const isBuy = side === "BUY";
      if (!sidesConsistent) parts.push(isBuy ? "买入" : side === "SELL" ? "卖出" : predictionValue(row.side, "UNKNOWN"));
      if (row?.augment === true) parts.push("加量单");
      const purpose = lpDashboardTodayPurposeLabel(row);
      if (!purposesConsistent && purpose) parts.push(purpose);
      if (lpDashboardTodayFilled(row)) parts.push("已成交");
      else {
        const filled = Number(row.filled_quantity);
        if (Number.isFinite(filled) && filled > 0) parts.push("已成交 " + formatDisplayNumber(String(filled)));
      }
      // 逐笔着色 tag：既有文字全部保留（原文仍以纯文本渲染），pill 只追加颜色状态。
      const fillPill = lpDashboardTodayFilled(row)
        ? "<span class=\"pm-pill status-ok\">已成交</span>"
        : (() => {
          const filled = Number(row.filled_quantity);
          if (Number.isFinite(filled) && filled > 0) {
            return "<span class=\"pm-pill status-partial\">已成交 "
              + formatDisplayNumber(String(filled)) + "</span>";
          }
          return lpDashboardTodayHasActiveOrder(row) ? "<span class=\"pm-pill\">挂单中</span>" : "";
        })();
      const chip = isBuy ? lpQueueProtectionSourceChip(row) : "";
      const right = lpDashboardTodayHasActiveOrder(row)
        ? lpDashboardCancelButton("one", {orderId: row.order_id})
        : "";
      return "<div class=\"lp-line\"><div>" + parts.map((part) => escapeHtml(part)).join(" · ")
        + (chip ? " · " + chip : "")
        + (fillPill ? " · " + fillPill : "")
        + "</div>" + right + "</div>";
    }).join("");
  }
  // Issue 152: the group's protection sub-row closes the quantity cell.
  markup += lpDashboardTodayQueueProtectionRow(orders);
  return markup;
}

function lpDashboardTodayMarketRow(
  group, rewards, rewardShares, observations, sessions,
) {
  // Issue 166 R2: sessions 是该行归因出的组会话数组——恰一组用该组，
  // 零组（手动行/旧载荷）为 null，≥2 组走按组分行、无加量按钮的多组渲染。
  const rowSessions = Array.isArray(sessions) ? sessions : [];
  const session = rowSessions.length === 1 ? rowSessions[0] : null;
  const identity = group.conditionId;
  const orders = group.orders;
  const firstOrder = orders[0];
  const observation = observations[identity] && typeof observations[identity] === "object"
    ? observations[identity]
    : null;
  const rewardMarkup = observation
    ? lpDashboardYieldCell(observation)
    : lpDashboardRewardSummary(firstOrder, rewards);
  const share = rewardShares && typeof rewardShares === "object" ? rewardShares[identity] : null;
  const shareMarkup = lpDashboardShareCell(share || {}, observation);
  const multiSession = rowSessions.length > 1;
  const riskMarkup = multiSession
    ? (observation && typeof observation === "object"
        ? lpDashboardExposureRiskCell(firstOrder, null, observation)
        : "") + lpDashboardMultiSessionRiskCell(rowSessions)
    : lpDashboardExposureRiskCell(firstOrder, session, observation);
  const sessionRiskCell = multiSession
    ? lpDashboardMultiSessionRiskCell(rowSessions)
    : lpDashboardRiskCell(firstOrder, session);
  const detailsMarkup = observation
    ? lpDashboardObservationDetail(
      observation,
      lpDashboardRewardSummary(firstOrder, rewards),
      sessionRiskCell,
    )
    : "";
  const subtitle = lpDashboardTodaySubtitle(orders);
  // 实际占用资金列：observed 口径（持仓均成本 + 在挂买单），只认
  // occupied_capital_usd 现值；stale 或缺失一律 UNKNOWN，绝不填 0。
  const capitalStale = observation ? lpDashboardAccountFactsStale(observation) : false;
  const capitalValue = observation ? observation.occupied_capital_usd : null;
  const capitalKnown = Boolean(observation) && !capitalStale
    && predictionHasValue(capitalValue) && Number.isFinite(Number(capitalValue));
  const capitalMarkup = capitalKnown
    ? "<div>" + escapeHtml(lpDashboardMoney(capitalValue)) + "</div>"
      + "<span class=\"sub\">持仓均成本 + 在挂买单</span>"
    : "<div><span class=\"pm-lp-unknown\">UNKNOWN</span></div>"
      + "<span class=\"sub\">" + (capitalStale
        ? "账户数据过期"
        : "账户数据缺失 · 不以 0 代替") + "</span>";
  // 完结沉底：组内无任何在挂余量 → 整行加淡化类（CSS 使 td 与链接降为 muted 色）。
  // class 置于 data-lp-today-market 之后：与既有行的 tr 前缀形状保持一致。
  const done = !orders.some((row) => lpDashboardTodayHasActiveOrder(row));
  return "<tr data-lp-today-market=\"" + escapeHtml(identity) + "\""
    + (done ? " class=\"lp-today-done\"" : "") + ">"
    + "<td>" + lpMarketTitleLink(firstOrder) + "<span class=\"sub\">" + escapeHtml(subtitle)
    + "</span>" + detailsMarkup + "</td>"
    + "<td data-label=\"LP 收益率(推荐 → 实际)\">" + rewardMarkup + "</td>"
    + "<td data-label=\"今日奖励(累计 · $/小时)\" class=\"num\">"
      + lpDashboardTodayRewardCell(firstOrder, rewards, observation) + "</td>"
    + "<td data-label=\"份额占比\">" + shareMarkup + "</td>"
    + "<td data-label=\"实际占用资金\" class=\"num\">" + capitalMarkup + "</td>"
    + "<td data-label=\"压力损失(警戒线 10%)\">" + riskMarkup + "</td>"
    + "<td data-label=\"委托与成交量\">" + lpDashboardTodayQuantityCell(orders, session) + "</td></tr>";
}

function lpTrialCompetitionMarkup(competition) {
  // Issue #181: 官方竞争列密度化——数值旁标轻/中档位 pill；store 来源的
  // 行是本轮没拉到、回取数据库上次值，副行以「旧 · 时间」如实标注。
  const comp = competition && typeof competition === "object" ? competition : {};
  if (comp.state === "known" && predictionHasValue(comp.value)) {
    const tier = String(comp.tier || "");
    const pill = tier === "light"
      ? "<span class=\"pm-pill lp-tier-light\">轻</span>"
      : tier === "mid"
        ? "<span class=\"pm-pill lp-tier-mid\">中</span>"
        : "";
    const stamp = predictionHasValue(comp.checked_at)
      ? "<span class=\"sub\">"
        + (comp.source === "store"
          ? "旧 · " + escapeHtml(predictionHktTimestamp(comp.checked_at))
          : "数据 " + escapeHtml(predictionHktTimestamp(comp.checked_at)))
        + "</span>"
      : "";
    const updatedSub = comp.updated === false && comp.source !== "store"
      ? "<span class=\"sub\">本轮未更新</span>"
      : "";
    return "<div class=\"num\"><span>" + escapeHtml(String(comp.value)) + "</span>"
      + pill + stamp + updatedSub + "</div>";
  }
  const updatedSub = comp.updated === false
    ? "<span class=\"sub\">本轮未更新</span>"
    : "";
  const note = comp.stale === true
    ? "<span class=\"sub\">超 3 小时未更新</span>"
    : "<span class=\"sub\">不填 0 · 指标并列时排已知之后</span>";
  return "<div class=\"num pm-lp-unknown\">未知" + note + updatedSub + "</div>";
}

function lpTrialPlanCell(row) {
  const selected = row?.selected_direction && typeof row.selected_direction === "object"
    ? row.selected_direction : null;
  const price = predictionHasValue(selected?.price) ? lpDashboardPrice(selected.price) : null;
  const quantity = predictionHasValue(selected?.quantity)
    ? predictionValue(selected.quantity, "UNKNOWN") : null;
  const capital = predictionHasValue(selected?.required_capital)
    ? lpDashboardMoney(selected.required_capital) : null;
  if (price && quantity && capital) {
    return "<td data-label=\"拟挂方案（价 × 份 = 实际占资）\" class=\"num\"><div>"
      + escapeHtml(price) + " × " + escapeHtml(quantity) + " 份 = <strong>"
      + escapeHtml(capital) + "</strong></div>"
      + "<span class=\"sub\">买 " + escapeHtml(predictionValue(selected.outcome, "UNKNOWN"))
      + " · 实际占资</span></td>";
  }
  const reference = predictionHasValue(row?.reference_capital)
    ? lpDashboardMoney(row.reference_capital) : "<span class=\"pm-lp-unknown\">UNKNOWN</span>";
  return "<td data-label=\"拟挂方案（价 × 份 = 实际占资）\" class=\"num\"><div>"
    + "<span class=\"pm-lp-unknown\">UNKNOWN</span></div>"
    + "<span class=\"sub\">参考占资 " + reference + "</span></td>";
}

function lpTrialLossCell(row) {
  const selected = row?.selected_direction && typeof row.selected_direction === "object"
    ? row.selected_direction : null;
  const loss = predictionHasValue(selected?.estimated_exit_loss)
    ? lpDashboardMoney(selected.estimated_exit_loss) : null;
  const ratio = Number(selected?.estimated_exit_loss_ratio);
  const ratioText = Number.isFinite(ratio)
    ? (ratio * 100).toFixed(2).replace(/\.?0+$/, "") + "%" : "UNKNOWN";
  return "<td data-label=\"压力退出损失（金额 / 比例）\" class=\"num\"><div>"
    + (loss ? escapeHtml(loss) : "<span class=\"pm-lp-unknown\">UNKNOWN</span>")
    + " · " + escapeHtml(ratioText) + "</div>"
    + "<span class=\"sub\">压力退出情景估算</span></td>";
}

function lpTrialValidityCountdown(row) {
  // Issue #157: the pool row is valid until its own expires_at; the
  // remaining time is computed against the current clock at render time.
  const expiresAt = Date.parse(String(row?.expires_at || ""));
  if (!Number.isFinite(expiresAt)) return "";
  const remainingSeconds = Math.floor((expiresAt - Date.now()) / 1000);
  if (remainingSeconds <= 0) return "已到期";
  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  return "有效期剩余 " + minutes + "分" + String(seconds).padStart(2, "0") + "秒";
}

function lpTrialStatusCell(row, isCurrent) {
  const stamp = predictionHasValue(row?.updated_at)
    ? predictionHktTimestamp(row.updated_at) : "UNKNOWN";
  const countdown = lpTrialValidityCountdown(row);
  const countdownMarkup = countdown
    ? "<span class=\"sub\">" + escapeHtml(countdown) + "</span>" : "";
  if (row?.refresh_failed === true) {
    return "<td data-label=\"估值时间与状态\"><div>" + escapeHtml(stamp) + "</div>"
      + "<span class=\"pm-pill watch\">刷新失败 · 保留至原到期</span>"
      + "<span class=\"sub\">值为上次成功估值</span>" + countdownMarkup + "</td>";
  }
  if (isCurrent) {
    return "<td data-label=\"估值时间与状态\"><div>" + escapeHtml(stamp) + "</div>"
      + "<span class=\"pm-pill pm-tone-ok\">当前推荐</span>" + countdownMarkup + "</td>";
  }
  return "<td data-label=\"估值时间与状态\"><div>" + escapeHtml(stamp) + "</div>"
    + "<span class=\"pm-pill\">池内有效</span>" + countdownMarkup + "</td>";
}

function lpTrialQueryRateCell(row) {
  // Recommendation and auto BUY share the actual minimum scoring order.
  const cell = "<td data-label=\"最小计奖挂单 · 预计收益率/小时\" class=\"num\">";
  const hasEstimate = String(row?.estimate_state || "") === "known"
    && predictionHasValue(row?.estimated_yield_pct_per_hour);
  const targetCapital = predictionHasValue(row?.estimated_target_capital_usd)
    ? lpDashboardMoney(row.estimated_target_capital_usd) : "UNKNOWN";
  const targetQuantity = predictionHasValue(row?.estimated_target_quantity)
    ? predictionValue(row.estimated_target_quantity, "UNKNOWN") : "UNKNOWN";
  const selected = row?.selected_direction && typeof row.selected_direction === "object"
    ? row.selected_direction : null;
  const minTrial = predictionHasValue(selected?.required_capital)
    ? lpDashboardMoney(selected.required_capital)
      + "（" + predictionValue(selected?.quantity, "UNKNOWN") + " 份）"
    : "UNKNOWN";
  if (!hasEstimate) {
    return cell + "<span class=\"pm-lp-unknown\">待测</span>"
      + "<span class=\"sub\">估值缺失，不回退奖池上限</span></td>";
  }
  return cell + "<span>≈" + escapeHtml(String(row.estimated_yield_pct_per_hour)) + "%/小时</span>"
    + "<span class=\"sub\">挂单占资 " + escapeHtml(targetCapital)
    + "（" + escapeHtml(targetQuantity) + " 份）</span>"
    + "<span class=\"sub\">最小试挂 " + escapeHtml(minTrial) + "</span></td>";
}

function lpTrialEvidenceRow(row) {
  const summary = row?.summary && typeof row.summary === "object" ? row.summary : {};
  const details = [];
  if (predictionHasValue(summary.amplitude)) {
    details.push("24h 极差 " + escapeHtml(lpDashboardPrice(summary.amplitude)));
  }
  if (predictionHasValue(summary.sample_count)) {
    details.push("样本 " + escapeHtml(predictionNumber(summary.sample_count, "UNKNOWN")));
  }
  if (predictionHasValue(summary.window_start) && predictionHasValue(summary.window_end)) {
    details.push("窗口 " + escapeHtml(predictionHktTimestamp(summary.window_start))
      + " 至 " + escapeHtml(predictionHktTimestamp(summary.window_end)));
  }
  if (predictionHasValue(summary.valid_until)) {
    details.push("有效至 " + escapeHtml(predictionHktTimestamp(summary.valid_until)));
  }
  const evidenceLine = details.length
    ? "<li>" + escapeHtml(lpMarketTitle(row)) + "：" + details.join(" · ") + "。</li>"
    : "";
  const reasonList = Array.isArray(row?.reason) ? row.reason : [];
  const reasonLine = reasonList.length
    ? "<li>入选理由：" + reasonList.map((item) => escapeHtml(String(item))).join(" · ") + "。</li>"
    : "";
  if (!evidenceLine && !reasonLine) return "";
  const key = "lp-candidate-evidence-" + String(row?.condition_id || row?.market_id || "")
    + ":" + String(row?.outcome || "");
  return "<tr class=\"pm-lp-evidence-row\"><td colspan=\"8\"><details data-lp-details-key=\""
    + escapeHtml(key) + "\"><summary>筛选与依据（展开状态在刷新后保持）</summary><ul>"
    + evidenceLine + reasonLine + "</ul></details></td></tr>";
}

function lpTrialSelectedResultDiagnostics(selectedResults, recommendations) {
  if (recommendations.length || !selectedResults.length) return "";
  const head = selectedResults[0];
  if (!head || typeof head !== "object") return "";
  const directions = head.directions && typeof head.directions === "object"
    ? Object.entries(head.directions)
    : [];
  const reasonRows = directions.map(([outcome, direction]) => {
    if (!direction || typeof direction !== "object") return "";
    const reasons = Array.isArray(direction.reason_codes)
      ? direction.reason_codes.filter((reason) => predictionHasValue(reason))
      : [];
    if (!reasons.length) return "";
    const labels = reasons.map((reason) => {
      const code = String(reason);
      return escapeHtml(lpDashboardObservationReason(code)) + "（"
        + escapeHtml(code) + "）";
    }).join(" · ");
    return "<li><strong>" + escapeHtml(String(outcome)) + "</strong>：" + labels + "</li>";
  }).filter(Boolean).join("");
  if (!reasonRows) return "";
  const key = "lp-candidate-diagnostics-" + String(head.condition_id || head.market_id || "head");
  return "<details class=\"pm-lp-candidate-diagnostics\" data-lp-details-key=\""
    + escapeHtml(key) + "\"><summary>当前队首校验</summary><p class=\"sub\">"
    + lpMarketTitleLink(head) + "</p><ul>" + reasonRows + "</ul></details>";
}

function lpTrialCandidateRow(row, currentConditionId) {
  const rowKey = String(row?.condition_id || row?.market_id || "") + ":" + String(row?.outcome || "");
  const isCurrent = Boolean(currentConditionId)
    && String(row?.condition_id || "") === currentConditionId;
  const selected = row?.selected_direction && typeof row.selected_direction === "object"
    ? row.selected_direction : null;
  const selectedOutcome = selected?.outcome;
  const identity = "<td data-label=\"市场与方向\">" + lpMarketTitleLink(row)
    + "<span class=\"sub\">" + escapeHtml(predictionValue(row.market_id, row.condition_id))
    + " · 买 " + escapeHtml(predictionValue(selectedOutcome, "UNKNOWN")) + "</span></td>";
  const competition = "<td data-label=\"官方竞争 · 密度\">" + lpTrialCompetitionMarkup(row.competition) + "</td>";
  const pool = "<td data-label=\"日奖池\" class=\"num\">"
    + escapeHtml(lpDashboardMoney(row.daily_pool_usd)) + "</td>";
  const queryRate = lpTrialQueryRateCell(row);
  const plan = lpTrialPlanCell(row);
  const loss = lpTrialLossCell(row);
  const status = lpTrialStatusCell(row, isCurrent);
  // Issue 158: the title is already the Polymarket link; the action column
  // only hosts the system entry button (no preset gating — the server
  // decides; the read-only page keeps it disabled).
  const action = "<td data-label=\"操作\"><div>"
    + "<button class=\"pm-button\" type=\"button\" data-action=\"lp-order-entry\""
    + " data-condition-id=\"" + escapeHtml(String(row?.condition_id || "")) + "\""
    + " data-outcome=\"" + escapeHtml(String(selectedOutcome || "")) + "\""
    + ((predictionWritesBlocked() || !state.predictionMarket.csrfToken || lpSubmitCooldownActive()) ? " disabled" : "")
    + ">挂单</button>"
    + "</div></td>";
  return "<tr data-lp-trial-candidate=\"" + escapeHtml(rowKey) + "\">"
    + identity + competition + pool + queryRate + plan + loss + status + action + "</tr>"
    + lpTrialEvidenceRow(row);
}

function lpBudgetLineMarkup(budget, checkedAt) {
  const availableRaw = budget && typeof budget === "object" ? budget.available_capital : null;
  const hasAvailable = predictionHasValue(availableRaw) && Number.isFinite(Number(availableRaw));
  const availableText = hasAvailable
    ? "可用资金 <strong>" + escapeHtml(Number(availableRaw).toFixed(2)) + "</strong> USD（已扣未成交委托占用）"
    : "可用资金 <strong class=\"pm-lp-unknown\">未知</strong>（预算数据缺失）";
  const stamp = predictionHasValue(checkedAt)
    ? " · 数据 " + escapeHtml(predictionHktTimestamp(checkedAt))
    : "";
  return "<p class=\"pm-lp-budget-line\">" + availableText + stamp + "</p>";
}

function predictionLpAutoControls(auto, stale) {
  if (!auto || typeof auto !== "object") return "<p class=\"sub\">自动补位状态 UNKNOWN</p>";
  const prediction = state.predictionMarket;
  const running = auto.desired_running === true;
  const schedulerRunning = auto.scheduler_running === true;
  const serviceBlocked = predictionWritesBlocked();
  const busy = prediction.lpAutoBusy || !prediction.csrfToken || serviceBlocked;
  const blocked = Array.isArray(auto.block_reasons) ? auto.block_reasons : [];
  const draft = prediction.lpAutoDraft || auto;
  const locked = busy || stale || running || auto.pause_confirmed !== true || auto.slots?.occupied !== 0;
  const action = running ? "pause" : auto.ever_enabled ? "resume" : "enable";
  const actionLabel = running ? "暂停新增" : auto.ever_enabled ? "恢复新增" : "启用自动补位";
  const status = !schedulerRunning ? "调度未运行" : running ? "持续运行" : auto.ever_enabled ? "新增已暂停" : "尚未启用";
  const reasons = blocked.length ? ` · 系统受阻：${escapeHtml(blocked.join("、"))}` : "";
  return `<section aria-label="自动补位控制"><h3>自动补位 · ${status}</h3>
    <p>人工意愿：${running ? "运行" : "暂停"}${reasons}${stale ? " · 状态已过期" : ""}</p>
    <p class="sub">每分钟检查，跨日持续。暂停保留 BUY；挂单保护、库存退出和在途核对继续。</p>
    <button type="button" class="pm-button" data-lp-auto-action="${action}"${busy || (!running && (stale || !schedulerRunning)) ? " disabled" : ""}>${actionLabel}</button>
    <div class="pm-check"><label>策略总资金（USDC） <input data-lp-auto-field="budget_usd" aria-label="策略总资金" type="number" min="0" step="0.01" value="${escapeHtml(String(draft.budget_usd ?? ""))}"${locked ? " disabled" : ""}></label>
    <label>目标 BUY 数 <input data-lp-auto-field="target_buy_count" aria-label="目标 BUY 数" type="number" min="0" step="1" value="${escapeHtml(String(draft.target_buy_count ?? 0))}"${locked ? " disabled" : ""}></label>
    <button type="button" class="pm-button" data-lp-auto-action="config"${locked ? " disabled" : ""}>保存配置</button></div>
    <p class="sub">保存不交易。修改前须人工暂停，且自动 BUY（含撤单中）和未决提交全部终结。0 不撤单。</p>
    <p class="sub">最近检查 ${escapeHtml(predictionHktTimestamp(auto.last_check_at, "尚未检查"))} · 下次 ${escapeHtml(predictionHktTimestamp(auto.next_check_at, "等待本轮结束"))}${auto.check_in_progress ? " · 检查中" : ""}${auto.last_check_error ? ` · 检查失败：${escapeHtml(auto.last_check_error)}` : ""}</p>
    <p role="status">${escapeHtml(prediction.lpAutoMessage)}</p></section>`;
}

function handleLpAutoInput(event) {
  const field = event.target.closest?.("[data-lp-auto-field]");
  if (!field) return;
  const prediction = state.predictionMarket;
  if (!prediction.lpAutoDraft) {
    const auto = predictionLpAutoState() || {};
    prediction.lpAutoDraft = {budget_usd: auto.budget_usd ?? "", target_buy_count: auto.target_buy_count ?? 0, expected_config_version: auto.config_version};
  }
  prediction.lpAutoDraft[field.dataset.lpAutoField] = field.value;
}

async function controlLpAuto(action) {
  const prediction = state.predictionMarket;
  if (prediction.lpAutoBusy) return;
  prediction.lpAutoBusy = true;
  prediction.lpAutoMessage = "等待服务确认…";
  let body = {confirm: true};
  if (action === "config") {
    const auto = predictionLpAutoState() || {};
    const draft = prediction.lpAutoDraft || {budget_usd: auto.budget_usd, target_buy_count: auto.target_buy_count, expected_config_version: auto.config_version};
    body = {...draft, target_buy_count: Number(draft.target_buy_count)};
  }
  renderPredictionMarket();
  try {
    const result = await predictionPost(`/api/prediction-arbitrage/lp/auto/${action}`, body);
    if (action === "pause" && (result.desired_running !== false || result.pause_confirmed !== true)) throw new Error("暂停未获可靠确认");
    if ((action === "enable" || action === "resume") && result.desired_running !== true) throw new Error("运行意愿未获确认");
    prediction.lpDashboardRequestSeq = (prediction.lpDashboardRequestSeq || 0) + 1;
    if (predictionSplit()) {
      prediction.lpAutoRequestSeq = (prediction.lpAutoRequestSeq || 0) + 1;
      prediction.lpAutoPayload = {...prediction.lpAutoPayload, ...result};
      prediction.lpAutoError = "";
    } else prediction.lpDashboard = {...prediction.lpDashboard, auto: {...prediction.lpDashboard?.auto, ...result}};
    if (action === "config") prediction.lpAutoDraft = null;
    prediction.lpAutoMessage = action === "pause" ? "新增已暂停；已有挂单和仓位继续保护。" : action === "config" ? "配置已保存，未触发交易。" : "运行意愿已保存，立即核对；系统受阻时等待核清。";
  } catch (error) {
    prediction.lpAutoMessage = `操作未确认：${error instanceof Error ? error.message : String(error)}`;
  } finally {
    prediction.lpAutoBusy = false;
    // Replace any read invalidated by this operation, including a cancel refresh.
    await fetchPredictionLpDashboard({force: true});
    renderPredictionMarket();
  }
}

function predictionLpDailySummary(data) {
  if (!data?.today) return "<section aria-label=\"自动自然日汇总\"><h3>自动运行 · 自然日汇总</h3><p>数据待核对，尚无可用汇总。</p></section>";
  const render = (report, title) => {
    const value = (v) => escapeHtml(predictionValue(v, "未知"));
    const stamp = (v) => escapeHtml(predictionHktTimestamp(v, "未知"));
    const money = (v) => escapeHtml(lpDashboardMoney(v));
    const metrics = report.metrics || {};
    const funds = report.funds || {};
    const financial = report.financial_period || {};
    const runtime = report.runtime || {};
    const coverage = report.coverage || {};
    const metricRows = [["提交意图", "intent_count"], ["确认受理", "accepted_count"], ["确认拒绝", "rejected_count"], ["未决意图", "unknown_count"], ["发生过成交的订单", "filled_order_count"], ["成交数量", "filled_quantity"], ["确认撤单", "cancelled_order_count"]];
    const actionNames = {intent: "提交意图", accepted: "确认受理", rejected: "确认拒绝", unknown: "未决", fill: "成交", cancel: "确认撤单", cancel_requested: "请求撤单", open: "挂单中", cancel_pending: "撤单中"};
    const eventRows = (rows) => (rows || []).map((row) => `<tr><td>${value(row.market_title || row.condition_id || row.session_id)}</td><td>${value(row.order_id || "无可靠订单 ID")}<span class="sub">意图 ${value(row.intent_id)}</span></td><td>${value(row.status === "EXPIRED" ? "已到期" : actionNames[row.kind] || actionNames[row.state] || row.state || row.reason)}${row.carried_in ? " · 跨日存量" : ""}</td><td>${value(row.side)} @ ${value(row.price)}</td><td>${value(row.quantity ?? row.remaining_quantity)}</td><td>${stamp(row.occurred_at)}<span class="sub">观察 ${stamp(row.observed_at)}</span></td></tr>`).join("");
    const table = (rows) => `<div class="pm-table-wrap"><table class="pm-table"><thead><tr><th>标的</th><th>订单／意图</th><th>状态</th><th>方向／价格</th><th>数量</th><th>发生／观察时间</th></tr></thead><tbody>${eventRows(rows)}</tbody></table></div>`;
    const closing = report.closing_orders || [];
    const rewards = report.rewards?.observations || [];
    const rewardRows = rewards.map((row) => `<li>${value(row.condition_id)} · 平台计奖日 ${value(row.reward_date)} · 平台累计 ${money(row.market_amount)} · ${value(row.status || row.state || "unknown")} · 更新 ${stamp(row.last_attempt_at || row.checked_at)}</li>`).join("");
    const financialKnown = financial.status === "known";
    const inventories = Array.isArray(financial.inventories) ? financial.inventories : [];
    const detailKey = escapeHtml(`auto-report-${report.state}-${report.report_date}`);
    const runtimeLabel = {running: "运行中", paused: "人工暂停", blocked: "受阻", needs_attention: "待核对", disabled: "未启用"}[runtime.runtime_state] || runtime.runtime_state || "未知";
    return `<section class="pm-lp-natural-report" aria-label="${escapeHtml(title)}"><h4>${escapeHtml(title)}</h4>
      <p>北京时间 ${stamp(report.period_start)} 至 ${stamp(report.period_end)}（不含结束时刻） · 数据更新 ${stamp(report.data_updated_at)}</p>
      <p>首次启用 ${stamp(coverage.enabled_at)} · 实际覆盖起点 ${stamp(coverage.actual_start)} · ${value(runtimeLabel)}（状态更新 ${stamp(runtime.updated_at)}） · ${value(runtime.reason || (runtime.block_reasons || []).join("、") || "无阻塞原因")}</p>
      <p>${metricRows.map(([label, key]) => `${label} <strong>${value(metrics[key])}</strong>`).join(" · ")}</p>
      <p class="sub">按确认的发生时间归日；意图和订单去重，请求次数不计订单。部分成交后撤余量同时计入成交与撤单。未核实时间见待核对，不能当作零。</p>
      <p>策略资金 ${money(funds.total_usd)} · 挂单／在途总占用 ${money(funds.buy_reserved_usd)} · 其中在途 ${money(funds.pending_reserved_usd)} · 库存占用 ${money(funds.inventory_cost_usd)} · 可用 ${money(funds.available_usd)}</p>
      <p class="sub">资金为最近已核实投影（${value(funds.status)}），更新时间 ${stamp(funds.as_of)}；不是历史日末资金。奖励不进入可循环资金。</p>
      <p>本日已核实交易盈亏 ${money(financialKnown ? financial.realized_pnl_usd : null)} · 期末库存成本 ${money(financialKnown ? financial.inventory_cost_usd : null)} · 期末库存数量 ${value(financialKnown ? financial.inventory_quantity : null)} · ${value(financial.reason || financial.status || "待核对")}</p>
      ${inventories.length ? `<ul>${inventories.map((row) => `<li>${value(row.market_title || row.condition_id || row.session_id)} · ${value(row.quantity)} 份 · 成本 ${money(row.cost_usd)}</li>`).join("")}</ul>` : ""}
      <p>期末剩余挂单 ${value(report.closing_orders_status === "unknown" ? null : closing.filter((row) => row.state === "open").length)} · 撤单中 ${value(report.closing_orders_status === "unknown" ? null : closing.filter((row) => row.state === "cancel_pending").length)}。跨日订单是期末存量，不算当日新增。</p>
      ${closing.length ? table(closing.map((row) => ({...row, kind: null, quantity: row.remaining_quantity}))) : ""}
      <details data-lp-details-key="${detailKey}-events"><summary>当日订单动作与成交 (${(report.events || []).length})</summary>${table(report.events)}</details>
      <details data-lp-details-key="${detailKey}-pending"${report.pending?.length ? " open" : ""}><summary>待核对 (${(report.pending || []).length})</summary>${table(report.pending)}</details>
      ${report.late_events?.length ? `<details data-lp-details-key="${detailKey}-late"><summary>迟到事实 (${report.late_events.length}) · 归属时间与观察时间</summary>${table(report.late_events)}</details>` : ""}
      <details data-lp-details-key="${detailKey}-rewards"><summary>奖励读取结果 · 与交易盈亏分列</summary><p>平台按市场／计奖日累计，可能包含手动活动或其他时段；无法可靠分摊自动奖励，不提供自动合计，累计不代表到账。</p>${rewards.length ? `<ul>${rewardRows}</ul>` : "<p>奖励未知，等待平台读取。</p>"}</details>
      <p class="sub">保存／生成 ${stamp(report.generated_at)}${report.late_generated ? ` · 迟生成 ${value(report.generation_delay_seconds)} 秒／覆盖待核对` : ""} · ${value((coverage.gaps || []).join("、") || "仅覆盖已保存事实，缺失事实仍待核对")}</p>
    </section>`;
  };
  const reports = Array.isArray(data.reports) ? data.reports : [];
  const selected = state.predictionMarket.lpAutoReport;
  const selectedMatches = selected && selected.account_id === data.today.account_id && selected.auto_run_id === data.today.auto_run_id;
  return `<section aria-label="自动自然日汇总"><h3>自动运行 · 自然日汇总</h3>${render(data.today, "北京时间今天截至现在")}
    <details data-lp-details-key="auto-report-history"><summary>历史自然日日报 (${reports.length}) · 每天 00:05 保存前一天</summary><p>历史报告保留生成时事实；后续核对看当前状态。现有 08:00 财务日报口径保留。</p>${reports.map((report) => `<button type="button" class="pm-button" data-action="lp-auto-report-load" data-report-date="${escapeHtml(report.report_date)}">${escapeHtml(report.report_date)}${report.late_generated ? " · 迟生成" : ""}</button>`).join("") || "<p>暂无已保存日报。</p>"}${selectedMatches ? (selected.data ? render(selected.data, selected.report_date) : `<p role="status">${escapeHtml(selected.error || "正在读取日报…")}</p>`) : ""}</details></section>`;
}

async function loadLpAutoReport(day) {
  const today = state.predictionMarket.lpDashboard?.auto_summary?.today;
  if (!today) return;
  const selection = {account_id: today.account_id, auto_run_id: today.auto_run_id, report_date: day};
  state.predictionMarket.lpAutoReport = selection;
  renderPredictionMarket();
  try {
    const response = await fetch(predictionRequestUrl("/api/prediction-arbitrage/lp/auto/reports/" + encodeURIComponent(day)), {cache: "no-store", credentials: "same-origin"});
    if (!response.ok) throw new Error("日报读取失败 " + response.status);
    const report = await response.json();
    if (report.account_id !== selection.account_id || report.auto_run_id !== selection.auto_run_id) throw new Error("自动运行身份已变化，请刷新");
    selection.data = report;
  } catch (error) {
    selection.error = error instanceof Error ? error.message : String(error);
  }
  if (state.predictionMarket.lpAutoReport === selection) renderPredictionMarket();
}

function predictionLpCard(payload) {
  const dashboard = payload?.lp_dashboard && typeof payload.lp_dashboard === "object"
    ? payload.lp_dashboard : {};
  const lpOrdersToday = lpDashboardRows(dashboard.lp_orders_today);
  const candidates = lpDashboardRows(dashboard.candidates);
  const recommendations = lpDashboardRows(dashboard.recommendations);
  const selectedResults = lpDashboardRows(dashboard.selected_results);
  const rewards = lpDashboardRewards(dashboard.market_rewards);
  const rewardShares = lpDashboardRewards(dashboard.reward_shares);
  const observations = lpDashboardObservations(dashboard.lp_observations);
  const session = dashboard.lp_session;
  // Issue 166: 组卡列表来自服务端 lp_sessions（最新在前）；旧载荷缺失该键时
  // 回退旧 lp_session 单卡（旧快照兼容）。无活动组时服务端已放最近完结组。
  const rawSessionList = Array.isArray(dashboard.lp_sessions)
    ? dashboard.lp_sessions : [];
  const sessionList = (rawSessionList.length
    ? rawSessionList
    : (session && typeof session === "object"
      && String(session.state || "").toLowerCase() !== "none"
      ? [session] : []))
    .filter((row) => row && typeof row === "object"
      && String(row.state || "").toLowerCase() !== "none");
  // 每行当天委托按 condition_id 取自己组的会话数据，不再共用单一 lp_session。
  const sessionByCondition = {};
  for (const row of sessionList) {
    const key = String(row.condition_id || "");
    if (key && !sessionByCondition[key]) sessionByCondition[key] = row;
  }
  // Issue 166 R2: 行内 session_id → 组会话，供行级归因（见 lpDashboardRowSessions）。
  const sessionsById = {};
  for (const row of sessionList) {
    const id = String(row.session_id || "");
    if (id) sessionsById[id] = row;
  }
  const activeSession = sessionList.length > 0;
  const stale = dashboard.stale === true || dashboard.state === "stale";
  const snapshotPending = String(dashboard.state || "") === "snapshot_pending";
  const snapshotPendingMarkup = snapshotPending
    ? "<p class=\"pm-observation-empty\" role=\"status\">LP 面板快照准备中，首次加载约需 10 秒；页面每 5 秒自动刷新。</p>"
    : "";
  const candidateState = String(dashboard.candidate_state || "").toLowerCase();
  const candidatesStale = dashboard.candidate_stale === true || candidateState === "stale";
  const checkedAt = dashboard.last_success_at || dashboard.checked_at;
  const freshness = stale
    ? predictionHasValue(checkedAt)
      ? "<span class=\"pm-clock pm-clock-danger\">上次成功数据："
        + escapeHtml(predictionHktTimestamp(checkedAt))
        + " · 读取失败，已保留旧结果</span>"
      : "<span class=\"pm-clock pm-clock-danger\">读取失败 · UNKNOWN · "
        + escapeHtml(predictionValue(dashboard.error, "账户数据暂不可用"))
        + "</span>"
    : "<span class=\"pm-clock\">"
      + escapeHtml(predictionHasValue(checkedAt) ? "同步时间：" + predictionHktTimestamp(checkedAt) : "等待首次同步")
      + " · 每 5 秒刷新</span>";
  const todayGroups = lpDashboardTodayMarketOrder(
    lpDashboardTodayGroups(lpOrdersToday), observations,
  );
  const todayRowsHtml = todayGroups.length
    ? todayGroups.map((group) => lpDashboardTodayMarketRow(
      group, rewards, rewardShares, observations,
      lpDashboardRowSessions(group, sessionsById, sessionByCondition),
    )).join("")
    : "<tr><td colspan=\"7\" class=\"pm-observation-empty\">当天暂无 LP 委托。从上方待试挂候选点「挂单」登记第一笔，提交即受位置保护。</td></tr>";
  const nonLpRowCount = Number(dashboard.non_lp_row_count);
  const nonLpFootnote = Number.isFinite(nonLpRowCount) && nonLpRowCount > 0
    ? "<p class=\"sub\">账户另有 " + escapeHtml(String(nonLpRowCount))
      + " 行非 LP 订单/持仓，不在本表展示。</p>"
    : "";
  const funnel = dashboard.funnel && typeof dashboard.funnel === "object" ? dashboard.funnel : {};
  const funnelMarkup = predictionLpFunnel({
    ...funnel,
    state: dashboard.candidate_state,
    stale: candidatesStale,
    scanning: dashboard.scanning,
    complete: dashboard.complete,
    checked_at: dashboard.candidate_checked_at,
    last_success_at: dashboard.candidate_last_success_at,
    candidate_last_success_at: dashboard.candidate_last_success_at,
  });
  const notUpdatedCompetition = Array.isArray(funnel.competition_not_updated)
    ? funnel.competition_not_updated : [];
  const dataNoticeMarkup = notUpdatedCompetition.length
    ? "<p class=\"pm-lp-candidate-error\" role=\"status\"><strong>数据提示</strong>"
      + escapeHtml(String(notUpdatedCompetition.length))
      + " 个标的竞争值本轮未更新（读取失败页覆盖），已沿用旧值并标注数据时间；不影响其余标的排序。</p>"
    : "";
  const excluded = funnel.excluded && typeof funnel.excluded === "object" ? funnel.excluded : {};
  const overAvailableCount = Math.max(0, Number(excluded.over_available) || 0);
  const competitionEmptyCount = Math.max(0, Number(excluded.competition_empty) || 0);
  // Issue #181: 密度排除计数——重度/无数据/过薄，与既有取法同一防御。
  const competitionCrowdedCount = Math.max(0, Number(excluded.competition_too_crowded) || 0);
  const competitionMissingCount = Math.max(0, Number(excluded.competition_missing) || 0);
  const competitionThinCount = Math.max(0, Number(excluded.competition_too_thin) || 0);
  const densityExcludedCounts = "重度竞争 " + escapeHtml(String(competitionCrowdedCount))
    + " · 无数据 " + escapeHtml(String(competitionMissingCount))
    + " · 过薄 " + escapeHtml(String(competitionThinCount));
  const budget = funnel.budget && typeof funnel.budget === "object" ? funnel.budget : {};
  const budgetStampAt = dashboard.candidate_last_success_at || dashboard.candidate_checked_at;
  const budgetLineMarkup = lpBudgetLineMarkup(budget, budgetStampAt);
  const gapReason = predictionHasValue(funnel.gap_reason) ? String(funnel.gap_reason) : "";
  // Issue #157: the exploration is a continuous rolling pool — the status
  // line reports the pool counts, not a per-round scan progress.
  const scanStamp = predictionHasValue(dashboard.candidate_checked_at)
    ? predictionHktTimestamp(dashboard.candidate_checked_at) : "";
  const poolStatusMarkup = "<p class=\"pm-lp-pool-status\">候选池持续滚动：有效 "
    + escapeHtml(predictionValue(dashboard.candidate_valid_count, "UNKNOWN"))
    + " · 待探索 " + escapeHtml(predictionValue(dashboard.candidate_pending_count, "UNKNOWN"))
    + " · 刷新失败 " + escapeHtml(predictionValue(dashboard.candidate_failed_recent_count, "UNKNOWN"))
    + (scanStamp ? " · 最近发布 " + escapeHtml(scanStamp) : "")
    + "</p>";
  const currentConditionId = String(recommendations[0]?.condition_id || "");
  const visibleCandidates = candidates.filter((row) => {
    const selected = row?.selected_direction;
    const directions = row?.directions;
    return (selected && typeof selected === "object")
      || (directions && typeof directions === "object");
  });
  const candidateRowsHtml = visibleCandidates.length
    ? visibleCandidates.map((row) => lpTrialCandidateRow(
        row,
        currentConditionId,
      )).join("")
    : "<tr><td colspan=\"8\" class=\"pm-observation-empty\">"
      + (dashboard.scanning === true
        ? "候选探索进行中，当前没有有效期内的估值。"
        : "候选池当前没有有效期内的估值；未检查的市场不代表劣于已展示者。"
          + escapeHtml(densityExcludedCounts)
          + " · 竞争为 0 排除 " + escapeHtml(String(competitionEmptyCount))
          + " 个，超可用排除 " + escapeHtml(String(overAvailableCount)) + " 个。")
      + "</td></tr>";
  const competitionRoundAt = funnel.competition_round_checked_at;
  const competitionObservationMarkup = "<p class=\"pm-lp-competition-status sub\">竞争数据：最近一轮成功 "
    + escapeHtml(predictionHasValue(competitionRoundAt)
      ? predictionHktTimestamp(competitionRoundAt) : "UNKNOWN")
    + " · 覆盖 " + escapeHtml(String(Math.max(0, Number(funnel.competition_known) || 0)))
    + " · 轻 " + escapeHtml(String(Math.max(0, Number(funnel.competition_light) || 0)))
    + " · 中 " + escapeHtml(String(Math.max(0, Number(funnel.competition_mid) || 0)))
    + "</p>";
  const candidateSection = "<section aria-label=\"LP 待试挂候选\"><h3>待试挂候选"
    + "<span class=\"sub\">· 非全市场收益前十 · 已排除超可用资金 "
    + escapeHtml(String(overAvailableCount)) + " 个"
    + " · " + densityExcludedCounts
    + (gapReason ? " · " + escapeHtml(gapReason) : "")
    + "</span></h3>"
    + poolStatusMarkup
    + competitionObservationMarkup
    + "<div class=\"pm-table-wrap\"><table class=\"pm-table pm-lp-candidate-table\">"
    + "<thead><tr><th scope=\"col\">市场与方向</th><th scope=\"col\">官方竞争 · 密度</th><th scope=\"col\">日奖池</th>"
    + "<th scope=\"col\">最小计奖挂单 · 预计收益率/小时</th><th scope=\"col\">拟挂方案（价 × 份 = 实际占资）</th>"
    + "<th scope=\"col\">压力退出损失（金额 / 比例）</th><th scope=\"col\">检查时间与状态</th><th scope=\"col\">操作</th></tr></thead>"
    + "<tbody>" + candidateRowsHtml + "</tbody></table></div>"
    + "<p class=\"sub\">候选为持续滚动的候选池：探索线程按基础筛选队列分批轮转（每批最多 10 个市场、一次盘口读），估值成功即入池、每行自带 5 分钟有效期、到期自动让位；维护线程持续为当前展示前十续命；表内按实际最小合法/计奖挂单的预计收益率/小时降序，并列按估值时间新→旧、再按市场身份，第 1 名为当前推荐、退出由下一名自动补位；刷新失败的行保留至原到期并标注，值为上次成功估值；预计收益率为估值时盘口的估算、非保证收益，缺值显示待测、不回退奖池上限；未检查的市场不代表劣于已展示者；已有委托或持仓的市场不重复推荐；拟挂占资超过可用资金（已扣委托占用）的候选不进入队列；参考价有 1 小时新鲜门，过期进入备用队列；官方竞争按密度分档筛选，仅保留轻（[1,30)）中（[30,300)）两档，重度/过薄/零竞争/无数据市场整行排除并计入排除数；链接为普通跳转，实际下单前以 Polymarket 页面实时事实为准。</p></section>";
  // Issue 166: 一组沿用原标题；多组标题改「活动组 · N」，卡序=服务端顺序
  //（最新在前），完结组沉底照常显示。
  const sessionSummary = sessionList.length > 1
    ? "活动组 · " + escapeHtml(String(sessionList.length))
      + "<span class=\"sub\">· 最新在最上 · 完结组沉底 · 每组独立止损 $5、独立复核时间</span>"
    : "当前系统会话详情 · "
      + escapeHtml(predictionValue(
        sessionList[0]?.market_title || sessionList[0]?.market
          || sessionList[0]?.question, "系统会话"));
  const sessionDetails = activeSession
    ? "<details class=\"pm-lp-session-details\" data-lp-details-key=\"lp-session-details\"><summary>"
      + sessionSummary
      + "</summary><div class=\"lp-session-stack\">"
      + sessionList.map((row) => predictionLpSessionCard(
        {...payload, lp_session: row},
      )).join("")
      + "</div>"
      + "<p class=\"sub\">系统会话仍按北京时间 08:00 复盘并使用原 $5 止损触发线；候选是待测参考，不会创建或管理订单。</p></details>"
    : "";
  const error = payload?.lp_error || (session && session.error);
  const errorMarkup = error
    ? "<p class=\"pm-signal-error\">系统会话状态暂不可用；不会用缺失数据代替零。</p>"
    : "";
  const cancelSummary = String(state.predictionMarket.lpCancelSummary || "").trim();
  const cancelSummaryMarkup = cancelSummary
    ? `<p class="sub" role="status">${escapeHtml(cancelSummary)}</p>`
    : "";
  const readonlyLpUnavailable = predictionServiceReadOnly()
    && state.predictionMarket.nLegStatus === "paused"
    ? `<section class="pm-alert warning" role="status"><div class="pm-alert-body"><strong data-lp-realtime-status>LP 实时数据暂不可用</strong><p data-lp-realtime-note>这不是生产正常交易看板；写操作不可用。</p></div></section>`
    : "";
  return "<section class=\"pm-panel pm-lp-card\" aria-label=\"LP 会话\"><header class=\"pm-panel-heading\">"
    + "<div><h2>流动性提供试验</h2><p>手工挂单 · 自动补位 · 收益与风险观察</p></div>"
    + "<div class=\"pm-panel-heading-actions\">" + freshness
    + "<button class=\"pm-button\" type=\"button\" data-action=\"lp-dashboard-refresh\""
    + (predictionWritesBlocked() || predictionLpDisplayBusy() || state.predictionMarket.lpPreparationRecoveryInFlight || !state.predictionMarket.csrfToken ? " disabled" : "") + ">立即刷新</button>"
    + "<button class=\"pm-button danger\" type=\"button\" data-action=\"lp-cancel-all\""
    + (predictionWritesBlocked() || state.predictionMarket.lpCancelInFlight || predictionLpDisplayBusy() || state.predictionMarket.lpPreparationRecoveryInFlight || !state.predictionMarket.csrfToken ? " disabled" : "") + ">撤全部</button></div></header>"
    + readonlyLpUnavailable
    + errorMarkup
    + cancelSummaryMarkup
    + lpCancelFeedbackMarkup()
    + lpSubmitToastsMarkup()
    + snapshotPendingMarkup
    + budgetLineMarkup
    + predictionLpAutoControls(predictionSplit() ? predictionLpAutoState() : dashboard.auto, predictionSplit() ? Boolean(state.predictionMarket.lpAutoError) : dashboard.stale === true)
    + lpAutoFundsAndOrders(predictionSplit() ? predictionLpAutoState() : dashboard.auto)
    + "<section aria-label=\"当天 LP 委托\"><h3>当天 LP 委托 <span class=\"sub\">· 北京时间 08:00 起 · 活跃在前 · 已完结沉底 · 各按当前小时奖励率降序 · 一标的一行</span></h3><div class=\"pm-table-wrap\"><table class=\"pm-table pm-lp-order-table\">"
    + "<thead><tr><th scope=\"col\">标的</th><th scope=\"col\">LP 收益率(推荐 → 实际)</th><th scope=\"col\">今日奖励(累计 · $/小时)</th><th scope=\"col\">份额占比</th><th scope=\"col\">实际占用资金</th><th scope=\"col\">压力损失(警戒线 10%)</th><th scope=\"col\">委托与成交量</th></tr></thead>"
    + "<tbody>" + todayRowsHtml + "</tbody></table></div>"
    + nonLpFootnote
    + "<p class=\"sub\">预计 LP 毛奖励；压力损失不含奖励抵扣；10% 是风险警告线；「试挂/正式」由委托数量对比最小计分数量自动标注（买=最小计分数量→试挂；更大→正式；卖出单不标注）。份额预警已全量开启（奖励份额连续 >8% 一分钟语音告警，夜间静音）；撤单即时生效;已成交部分不可撤。</p></section>"
    + funnelMarkup
    + dataNoticeMarkup
    + lpTrialSelectedResultDiagnostics(selectedResults, recommendations)
    + candidateSection
    + sessionDetails + "</section>";
}
// Issue 167: per-level detail block on the session card (price / quantity /
// remaining / protection pill / A estimate) — one row per bucket.
function lpSessionLevelsBlock(source) {
  const buckets = lpQueueProtectionBuckets(source?.queue_protection);
  if (!buckets.length) return "";
  const history = source?.order_history && typeof source.order_history === "object"
    ? source.order_history : {};
  const rows = buckets.map((bucket) => {
    const price = String(bucket.baseline_price ?? bucket.level_price ?? "UNKNOWN");
    const orderId = String(bucket.order_id || "");
    const record = history[orderId] && typeof history[orderId] === "object"
      ? history[orderId] : {};
    const quantity = Number(record.quantity);
    const matched = Number(record.size_matched);
    const quantityText = Number.isFinite(quantity) && quantity > 0
      ? formatDisplayNumber(String(quantity)) : "UNKNOWN";
    const remainingText = Number.isFinite(quantity) && Number.isFinite(matched)
      ? formatDisplayNumber(String(quantity - matched)) : "UNKNOWN";
    const pill = lpQueueProtectionPill(String(bucket.state || "unknown"));
    const ratioText = lpQueueProtectionPercent(bucket.ratio);
    let estimate = "";
    if (ratioText !== "UNKNOWN") {
      estimate = "<span class=\"sub\">前方≈"
        + escapeHtml(formatDisplayNumber(String(bucket.front_estimate ?? "UNKNOWN")))
        + " / 同价位 "
        + escapeHtml(formatDisplayNumber(String(bucket.level_total ?? "UNKNOWN")))
        + " · A " + escapeHtml(ratioText) + "%</span>";
    }
    return "<div class=\"lp-level-row\"><span class=\"lp-level-price\">" + escapeHtml(price)
      + "</span><span>" + escapeHtml(quantityText) + " 份 · 剩余 " + escapeHtml(remainingText)
      + "</span>" + pill + estimate + "</div>";
  }).join("");
  return "<div class=\"lp-levels\" aria-label=\"价位明细\">" + rows + "</div>";
}

function predictionLpSessionCard(payload) {
  const source = payload?.lp_session && typeof payload.lp_session === "object"
    ? payload.lp_session
    : payload?.lp && typeof payload.lp === "object"
      ? payload.lp
      : null;
  const queryError = payload?.lp_error || source?.error;
  if (queryError) {
    return `<section class="pm-panel pm-lp-card" aria-label="LP 会话"><header class="pm-panel-heading"><div><h2>流动性提供试验</h2><p>单市场 · 单次开仓</p></div><span class="pm-pill pm-tone-danger">查询错误</span></header><div class="pm-alert danger" role="alert"><div class="pm-alert-body"><strong>LP 状态暂不可用</strong><p>${escapeHtml(predictionValue(queryError, "数据未返回"))}</p></div></div></section>`;
  }
  if (!source || String(source.state || "").toLowerCase() === "none") {
    return `<section class="pm-panel pm-lp-card" aria-label="LP 会话"><header class="pm-panel-heading"><div><h2>流动性提供试验</h2><p>单市场 · 单次开仓</p></div><span class="pm-pill watch">空闲</span></header><div class="pm-empty compact"><strong>当前没有进行中的 LP 会话</strong><p>预检查和启动一次固定价格订单后，会在这里显示订单角色、计分、库存与复盘状态。</p></div></section>`;
  }
  const stateLabels = {
    entry_submit_pending: "入场提交中",
    entry_open: "入场挂单中",
    passive_exit: "被动退出中",
    stop_loss_exit: "止损退出中",
    review: "待复盘",
    needs_attention: "需要核对",
    complete: "已完成",
    entry_rejected: "入场被拒",
  };
  const scoringLabels = {true: "计分中", false: "未计分", unknown: "UNKNOWN"};
  const rawState = String(source.state || "").trim();
  const stage = stateLabels[rawState] || predictionValue(rawState, "UNKNOWN");
  const scoring = scoringLabels[String(source.scoring_status || "unknown").toLowerCase()] || "UNKNOWN";
  const scoringTone = scoring === "计分中" ? "pm-tone-ok" : scoring === "UNKNOWN" ? "pm-tone-warning" : "pm-tone-danger";
  const market = source.market_title || source.market || source.question || source.title || "市场未返回";
  const outcome = predictionValue(source.outcome, "结果未返回");
  const entryOrder = source.entry_order_id ? `BUY · ${source.entry_order_id}` : "BUY · 未绑定订单";
  const passiveOrder = source.passive_exit_order_id ? `SELL · ${source.passive_exit_order_id}` : "未挂被动卖单";
  const protectedOrder = source.protected_exit_order_id ? `FOK SELL · ${source.protected_exit_order_id}` : "未提交主动卖单";
  // Issue #140: an unknown session scoring status shows the last confirmed
  // time instead of implying the unknown value was just queried.
  const scoringUnknown = String(source.scoring_status || "unknown").toLowerCase() === "unknown";
  const scoringTime = scoringUnknown
    ? (source.scoring_last_success_at
      ? predictionClock("最后成功", source.scoring_last_success_at)
      : "查询时间：UNKNOWN")
    : source.scoring_checked_at
      ? predictionClock("查询时间", source.scoring_checked_at)
      : "查询时间：UNKNOWN";
  const loss = predictionHasValue(source.opening_loss)
    ? predictionSignedMoney(source.opening_loss)
    : "UNKNOWN";
  const tradePnl = predictionHasValue(source.trade_pnl)
    ? predictionSignedMoney(source.trade_pnl)
    : "UNKNOWN";
  const total = predictionHasValue(source.total_pnl)
    ? predictionSignedMoney(source.total_pnl)
    : "UNKNOWN";
  const rewardObservation = source.reward_observation && typeof source.reward_observation === "object"
    ? source.reward_observation
    : {};
  const rewardObservationStatus = String(rewardObservation.status || "unknown").toLowerCase();
  const rewardStatusLabels = {below: "未达标", met: "已达门槛", unknown: "UNKNOWN"};
  const rewardStatus = rewardStatusLabels[rewardObservationStatus] || "UNKNOWN";
  const rewardTone = rewardObservationStatus === "met"
    ? "pm-tone-ok"
    : rewardObservationStatus === "below"
      ? "pm-tone-warning"
      : "pm-tone-danger";
  const rewardCurrency = String(rewardObservation.currency || "").toUpperCase();
  const rewardRawAmount = (amount, asset, accruals) => {
    const rows = Array.isArray(accruals) ? accruals.filter((row) => row && typeof row === "object") : [];
    if (rows.length) {
      return rows.map((row) => `${predictionValue(row.amount, "UNKNOWN")} ${predictionValue(row.asset, "UNKNOWN")}`).join(" + ");
    }
    return predictionHasValue(amount) && predictionHasValue(asset) ? `${amount} ${asset}` : null;
  };
  const rewardAmount = (value, raw, asset, accruals) => {
    if (rewardCurrency === "USD" && predictionHasValue(value)) return predictionExactMoney(value, "UNKNOWN");
    return rewardRawAmount(raw, asset, accruals) || "UNKNOWN";
  };
  const hasRawRewards = [
    rewardObservation.market_amount_raw,
    rewardObservation.account_amount_raw,
  ].some((value) => predictionHasValue(value))
    || [rewardObservation.market_accruals_raw, rewardObservation.account_accruals_raw]
      .some((value) => Array.isArray(value) && value.length > 0);
  const rewardHasRetainedAmounts = rewardObservationStatus === "unknown"
    && [rewardObservation.market_amount, rewardObservation.account_amount, rewardObservation.gap]
      .some((value) => predictionHasValue(value))
    || rewardObservationStatus === "unknown" && hasRawRewards;
  const rewardQueryAt = rewardHasRetainedAmounts
    ? (rewardObservation.last_success_at || rewardObservation.checked_at || rewardObservation.last_attempt_at)
    : (rewardObservation.last_attempt_at || rewardObservation.checked_at || rewardObservation.last_success_at);
  const rewardQuery = rewardQueryAt
    ? predictionClock(rewardHasRetainedAmounts ? "上次成功" : "最后查询", rewardQueryAt, {danger: rewardObservationStatus === "unknown"})
    : "最后查询：UNKNOWN";
  const rewardAttempt = rewardHasRetainedAmounts && rewardObservation.last_attempt_at
    ? predictionClock("最后尝试", rewardObservation.last_attempt_at, {danger: true})
    : "";
  const rewardValueSuffix = rewardHasRetainedAmounts ? "（保留值）" : "";
  const rewardPaid = rewardObservation.paid === false ? "平台累计，未核实到账" : "UNKNOWN";
  const rewardRow = `<div class="pm-relation-summary pm-lp-reward-observation" aria-label="LP 奖励观察"><span>计奖日（UTC） <strong>${escapeHtml(predictionValue(rewardObservation.reward_date, "UNKNOWN"))}</strong></span><span>市场累计${rewardValueSuffix} <strong>${escapeHtml(rewardAmount(rewardObservation.market_amount, rewardObservation.market_amount_raw, rewardObservation.market_asset, rewardObservation.market_accruals_raw))}</strong></span><span>账户累计${rewardValueSuffix} <strong>${escapeHtml(rewardAmount(rewardObservation.account_amount, rewardObservation.account_amount_raw, rewardObservation.account_asset, rewardObservation.account_accruals_raw))}</strong></span><span>距 $1 还差${rewardValueSuffix} <strong>${escapeHtml(rewardAmount(rewardObservation.gap))}</strong></span><span class="${rewardTone}">奖励状态 <strong>${escapeHtml(rewardStatus)}</strong></span><span>${rewardQuery}</span>${rewardAttempt ? `<span>${rewardAttempt}</span>` : ""}<span>到账 <strong>${escapeHtml(rewardPaid)}</strong></span></div>`;
  const exitStatus = source.stop_loss_latched === true
    ? `止损已锁定 · ${protectedOrder}`
    : `${stage} · ${passiveOrder}`;
  // 「需要核对」会话卡告警块：state 为 needs_attention 时置顶显示原因整句
  // 与数据失败计数，与行内说明线同源文案。
  let attentionAlert = "";
  if (rawState === "needs_attention") {
    const copy = lpNeedsAttentionCopy(source);
    const body = copy.main + " 恢复后自动继续；恢复前追加不可用。"
      + (copy.counter ? " " + copy.counter : "");
    attentionAlert = `<div class="pm-alert warning" role="status"><div class="pm-alert-body"><strong>本组已暂停自动管理</strong><p>${escapeHtml(body)}</p></div></div>`;
  }
  return `<section class="pm-panel pm-lp-card" aria-label="LP 会话"><header class="pm-panel-heading"><div><h2>${escapeHtml(String(market))} · ${escapeHtml(String(outcome))}</h2><p>单市场 LP · ${escapeHtml(stage)}</p></div><span class="pm-pill ${predictionTone(stage)}">${escapeHtml(stage)}</span></header>${attentionAlert}<div class="pm-relation-summary"><span>入场角色 <strong>BUY · post-only GTD</strong></span><span>订单 ${escapeHtml(entryOrder)}</span><span class="${scoringTone}">计分 <strong>${escapeHtml(scoring)}</strong></span><span>${scoringTime}</span></div><div class="pm-metrics pm-lp-metrics"><article class="pm-metric"><span>已买</span><strong>${escapeHtml(predictionValue(source.buy_filled_quantity, "UNKNOWN"))}</strong><small>目标 ${escapeHtml(predictionValue(source.quantity, "UNKNOWN"))} 份</small></article><article class="pm-metric"><span>已卖</span><strong>${escapeHtml(predictionValue(source.sold_quantity, "UNKNOWN"))}</strong><small>成交回款 ${escapeHtml(predictionMoney(source.sold_revenue, "UNKNOWN"))}</small></article><article class="pm-metric"><span>剩余</span><strong>${escapeHtml(predictionValue(source.residual_quantity, "UNKNOWN"))}</strong><small>按账户持仓核对</small></article><article class="pm-metric"><span>退出状态</span><strong>${escapeHtml(exitStatus)}</strong><small>开仓盈亏 ${escapeHtml(loss)}</small></article></div>${lpSessionLevelsBlock(source)}<div class="pm-relation-summary"><span>已实现交易 P&amp;L <strong>${escapeHtml(tradePnl)}</strong></span><span>总净额 <strong>${escapeHtml(total)}</strong></span><span>复盘时间 <strong>${escapeHtml(source.review_at ? predictionHktTimestamp(source.review_at) : "UNKNOWN")}</strong></span></div>${rewardRow}</section>`;
}

function predictionAnnualizedPercent(value, digits = 1) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "-";
  const scale = 10 ** digits;
  return `${(Math.trunc(number * 100 * scale) / scale).toFixed(digits)}%`;
}

function predictionReadinessStrip(payload, strategy = "yes_no") {
  const venues = Array.isArray(payload?.venues)
    ? payload.venues.filter((venue) => venue && typeof venue === "object")
    : [];
  if (venues.length) {
    const cards = venues.map((venue) => {
      const balance = venue.balance && typeof venue.balance === "object" ? venue.balance : {};
      const isPredict = String(venue.venue || "").toLowerCase() === "predict.fun";
      const venueName = isPredict ? "Predict.fun" : "Polymarket";
      const wallet = predictionMaskedWallet(venue.wallet);
      const rest = predictionValue(venue.rest, "unavailable");
      const ws = predictionValue(venue.ws, "unavailable");
      const asset = predictionValue(balance.asset, "-");
      const amount = predictionHasValue(balance.value) ? predictionMoney(balance.value) : "-";
      const balanceReason = isPredict && !predictionHasValue(balance.value) && venue.reason
        ? ` · 原因：${escapeHtml(predictionFailureReasonLabel({failure_reason: venue.reason}))}`
        : "";
      const allowance = venue.allowance && typeof venue.allowance === "object" ? venue.allowance : {};
      const allowanceLine = isPredict && predictionHasValue(allowance.value)
        ? `<small>授权 ${escapeHtml(predictionMoney(allowance.value))} ${escapeHtml(predictionValue(allowance.asset, "USDT"))}${allowance.spender ? ` · spender ${escapeHtml(predictionMaskedWallet(allowance.spender))}` : ""}</small>`
        : "";
      const healthLabel = (value) => String(value).toLowerCase() === "unavailable" ? "不可用" : value;
      const detail = venue.reason
        ? `<small>原因：${escapeHtml(predictionFailureReasonLabel({failure_reason: venue.reason}))}</small>`
        : venue.last_success ? `<small>最近成功 ${escapeHtml(predictionValue(venue.last_success))}</small>` : "";
      // #120: the Polymarket card carries the subscription-share counts.
      const subscription = !isPredict && payload?.monitor_subscription && typeof payload.monitor_subscription === "object" ? payload.monitor_subscription : null;
      const subLine = subscription
        ? `<small>盘口订阅 ${escapeHtml(predictionNumber(subscription.cross_venue_token_count, "0"))} · 套利监测 ${escapeHtml(predictionNumber(subscription.n_leg_cross_venue_token_count, "0"))}</small>`
        : "";
      return `<article class="pm-readiness-item pm-venue-card"><div class="pm-venue-card-title"><strong>${venueName}</strong><span class="pm-pill ${predictionTone(venue.mode)}">${escapeHtml(predictionValue(venue.mode, "只读"))}</span></div><div class="pm-venue-states"><span>REST：${escapeHtml(healthLabel(rest))}</span><span>WebSocket：${escapeHtml(healthLabel(ws))}</span></div>${subLine}<small>钱包 ${escapeHtml(wallet)}</small><small>可用余额 ${escapeHtml(amount)} ${escapeHtml(asset)}${balanceReason}</small>${allowanceLine}${isPredict && balanceReason ? "" : detail}</article>`;
    });
    const signer = payload?.privy_signer || payload?.signer;
    if (signer && typeof signer === "object") {
      const bnb = signer.bnb && typeof signer.bnb === "object" ? signer.bnb : {};
      cards.push(`<article class="pm-readiness-item pm-signer-card"><div class="pm-venue-card-title"><strong>Privy signer</strong><span class="pm-pill ${predictionTone(signer.mode)}">${escapeHtml(predictionValue(signer.mode, "只读"))}</span></div><div class="pm-venue-states"><span>BNB</span><span>当前 ${escapeHtml(predictionValue(bnb.current, "-"))} BNB</span></div><small>地址 ${escapeHtml(predictionValue(signer.address, "-"))}</small><small>需要 ${escapeHtml(predictionValue(bnb.required, "-"))} BNB · 最低保留 ${escapeHtml(predictionValue(bnb.minimum, "-"))} BNB</small></article>`);
    }
    return `<section class="pm-readiness pm-venue-readiness" aria-label="交易所连接与账户状态">${cards.join("")}</section>`;
  }
  const readiness = payload?.readiness || {};
  const balance = readiness.p_usd_balance ?? readiness.balance ?? payload?.balances?.p_usd;
  const wallet = readiness.masked_address || payload?.wallet?.masked_address || payload?.masked_wallet || readiness.wallet_address;
  const geoblock = predictionGeoblockLabel(readiness.geoblock || readiness.region || readiness.region_status);
  const policy = payload?.policy_limits || {};
  const policyReady = predictionPolicyIsComplete(policy);
  const available = predictionTradingAvailable(payload, strategy);
  const tradingNote = policyReady
    ? `单笔上限 ${predictionMoney(policy.max_normal_cost)} · 应急上限 ${predictionMoney(policy.max_emergency_loss)}`
    : "策略参数未返回";
  return `<section class="pm-readiness" aria-label="实盘就绪状态">
    <article class="pm-readiness-item"><span>交易钱包</span><strong>${escapeHtml(predictionValue(wallet, "-"))}</strong><small>独立低余额钱包 · Keychain</small></article>
    <article class="pm-readiness-item"><span>可用余额</span><strong>${escapeHtml(predictionMoney(balance, "-"))} pUSD</strong><small>不自动充值</small></article>
    <article class="pm-readiness-item"><span>地区与连接</span><strong class="${predictionTone(geoblock)}">${escapeHtml(predictionValue(geoblock, "-"))}</strong><small>官方 geoblock · 本机访问</small></article>
    <article class="pm-readiness-item"><span>实盘状态</span><strong class="${available ? "pm-tone-ok" : "pm-tone-danger"}">${available ? "可以交易" : "不可用"}</strong><small>${escapeHtml(tradingNote)}</small></article>
  </section>`;
}

function predictionSafeguardsHtml(payload) {
  const parts = [];
  const policy = payload?.policy_limits || {};
  if (predictionHasValue(policy.max_normal_cost)) {
    const first = String(policy.canary_status || "").toLowerCase() === "first_live_trade"
      || Number(policy.max_normal_cost) <= 5;
    parts.push(`<aside class="pm-policy pm-safeguard"><strong>${first ? "首单验证" : "常规上限"} · 单笔成本上限 ${escapeHtml(predictionMoney(policy.max_normal_cost))}</strong><p>上限只限制本次跨所订单，不改变未结算资金上限。</p></aside>`);
  }
  const signer = payload?.privy_signer || payload?.signer;
  const bnb = signer?.bnb && typeof signer.bnb === "object" ? signer.bnb : {};
  if (signer && String(signer.mode || "") === "只读") {
    const links = Array.isArray(signer.official_links)
      ? signer.official_links.map((link) => `<a href="${escapeHtml(predictionValue(link?.url, "#"))}" rel="noreferrer" target="_blank">${escapeHtml(predictionValue(link?.label, "官方链接"))}</a>`).join(" · ")
      : "";
    parts.push(`<section class="pm-alert warning pm-safeguard" role="status"><div class="pm-alert-body"><strong>Privy signer BNB 不足，只读</strong><p>当前 ${escapeHtml(predictionValue(bnb.current, "-"))} BNB · 需要 ${escapeHtml(predictionValue(bnb.required, "-"))} BNB · 最低保留 ${escapeHtml(predictionValue(bnb.minimum, "-"))} BNB</p><code class="pm-copy-text">${escapeHtml(predictionValue(signer.copy_text || signer.address, "-"))}</code>${links ? `<small>官方链接：${links}</small>` : ""}</div></section>`);
  }
  const cleanup = payload?.predict_allowance_cleanup;
  if (cleanup && typeof cleanup === "object") {
    parts.push(`<section class="pm-alert danger pm-safeguard" role="alert"><div class="pm-alert-body"><strong>Predict Account 残余授权</strong><p>残余授权 ${escapeHtml(predictionMoney(cleanup.before_allowance))} USDT；清零会消耗 Privy signer BNB，不转移 USDT。</p></div><button class="pm-button danger" type="button" data-action="open-allowance-cleanup">清理残余授权</button></section>`);
  }
  return parts.join("");
}

function predictionCrossVenueFunnel(payload) {
  const crossVenue = payload?.cross_venue && typeof payload.cross_venue === "object" ? payload.cross_venue : {};
  const funnel = crossVenue.funnel && typeof crossVenue.funnel === "object" ? crossVenue.funnel : {};
  const executed = predictionIsCrossVenue(payload?.current_execution) ? 1 : 0;
  const degraded = String(crossVenue.status || "").toLowerCase() !== "ready"
    && typeof crossVenue.discovery_error === "string"
    && crossVenue.discovery_error !== "";
  const stageNote = degraded ? "上次成功快照" : "";
  const warning = degraded
    ? `<div class="pm-funnel-empty pm-funnel-warning" role="alert"><strong>跨所发现链路失败</strong><p>${escapeHtml(crossVenue.discovery_error)} · 降级于 ${escapeHtml(predictionValue(crossVenue.stale_at))} · 保留上次成功快照</p></div>`
    : "";
  const empty = warning
    || (Number(funnel.monitored_pairs || 0) === 0
      ? `<div class="pm-funnel-empty"><strong>当前没有合格跨所市场</strong><p>扫描正常，没有失败；出现 stage-5 明确信号前不会开放按钮。</p></div>`
      : "");
  const statusPill = degraded ? `<span class="pm-pill watch">降级</span>` : "";
  return `<section class="pm-panel pm-relation-funnel pm-cross-venue-funnel" aria-label="跨所 YES/NO 漏斗"><header class="pm-funnel-header"><div><h2>跨所 YES/NO 漏斗</h2><p>只展示明确映射的两所标的；文字一致候选自动实时监控；确认前始终重新读取两所 REST 与账户事实。</p></div>${statusPill}</header><div class="pm-funnel-lane"><div class="pm-funnel-grid pm-funnel-grid-catalog">${predictionFunnelStage("正在监视", funnel.monitored_pairs, stageNote || "对应标的 " + predictionNumber(funnel.matched_pairs, "0") + " · 全部实时订阅", "live")}${predictionFunnelStage("正收益", funnel.arbitrage_space_pairs, stageNote || "实时盘口价差为正", "good")}${predictionFunnelStage("年化达标", funnel.clear_signal_pairs, stageNote || "≥ 15% · 可自动 / 可人工", "live")}${predictionFunnelStage("已提交", executed, stageNote || "自动执行 / 手动确认后", "good")}</div></div><div class="pm-funnel-meta"><span>对应标的 ${escapeHtml(predictionNumber(funnel.matched_pairs, "0"))}</span><span>准入来源（并行，非漏斗阶段）</span><span class="pm-funnel-chip">LLM 认为可以 ${escapeHtml(predictionNumber(funnel.codex_approved_pairs, "0"))} · 自动下单</span><span class="pm-funnel-chip">文字一致 ${escapeHtml(predictionNumber(funnel.manual_eligible_pairs, "0"))} · 人工下单</span>${funnel.retained_at ? `<span>保留时间 ${escapeHtml(predictionValue(funnel.retained_at))}</span>` : ""}</div>${empty}</section>`;
}

function predictionCrossVenueCandidates(payload) {
  const crossVenue = payload?.cross_venue && typeof payload.cross_venue === "object" ? payload.cross_venue : {};
  const crossAuto = payload?.cross_auto && typeof payload.cross_auto === "object" ? payload.cross_auto : {};
  const automaticMode = crossAuto.configured_mode === "auto_submit";
  const opportunities = Array.isArray(crossVenue.opportunities)
    ? crossVenue.opportunities
    : (Array.isArray(payload?.opportunities) ? payload.opportunities : []);
  const candidates = opportunities.filter((item) => (
    item && typeof item === "object"
    && item.actionable === true
    && predictionOpportunityIsComplete(item)
  ));
  const manual = candidates.filter((item) => (
    predictionCrossExecutionMode(item) === "manual_confirm" && item.manual_only === true
  ));
  const auto = candidates.filter((item) => predictionCrossExecutionMode(item) === "auto_submit");
  const card = (item, manualOnly) => {
    const approval = item.codex_approval && typeof item.codex_approval === "object" ? item.codex_approval : {};
    const reason = manualOnly
      ? `<div class="pm-alert warning"><div class="pm-alert-body"><strong>结算规则可能不一致</strong><p>${escapeHtml(predictionValue(item.manual_reason || approval.summary, "结构化理由未返回"))}</p></div></div>`
      : "";
    const action = manualOnly
      ? automaticMode
        ? `<span class="pm-relation-summary">需人工审查，自动模式不执行</span>`
        : `<button class="pm-button primary pm-participate" type="button" data-action="participate" data-opportunity-id="${escapeHtml(predictionValue(item.opportunity_id, ""))}">人工下单</button>`
      : `<span class="pm-relation-summary">系统判定文字与规则等价 · 无需批准，条件满足后自动执行</span>`;
    return `<article class="pm-manual-card"><div class="pm-manual-card-head"><div><div class="pm-manual-title">${escapeHtml(predictionValue(item.title || item.question, "数据未返回"))}</div><div class="pm-relation-summary"><span>Predict.fun × Polymarket</span><span>数据时间 ${escapeHtml(predictionValue(item.confirmed_at, "-"))}</span></div></div><span class="pm-pill ${manualOnly ? "watch" : "pm-tone-ok"}">${manualOnly ? "人工下单" : "自动下单"}</span></div><div class="pm-relation-summary"><span>年化 <strong>${escapeHtml(predictionAnnualizedPercent(item.annualized_yield, 2))}</strong></span><span>最小利润 <strong>${escapeHtml(predictionSignedMoney(item.profit))}</strong></span><span>总成本 <strong>${escapeHtml(predictionMoney(item.total_max_cost))}</strong></span><span>最坏损失 <strong>${escapeHtml(predictionMoney(item.total_max_cost))}</strong></span></div>${predictionNLegShadowHtml(item)}${reason}<div style="display:flex;justify-content:flex-end">${action}</div></article>`;
  };
  return `<section class="pm-panel"><div class="pm-panel-heading"><div><h2>可下单候选</h2><p>只分两类：人工下单（文字一致 · 规则模糊）与自动下单（文字与规则系统判定）；其余候选留在漏斗计数中。</p></div></div><div style="margin-bottom:14px"><h3 style="margin:0 0 8px">人工下单 · 文字一致 / 规则模糊</h3><div style="display:grid;gap:10px">${manual.map((item) => card(item, true)).join("") || '<p class="pm-relation-summary">当前无</p>'}</div></div><div><h3 style="margin:0 0 8px">自动下单 · 文字与规则系统判定</h3><div style="display:grid;gap:10px">${auto.map((item) => card(item, false)).join("") || '<p class="pm-relation-summary">当前无</p>'}</div></div></section>`;
}

function predictionExecutionProgress(execution) {
  const status = String(execution?.status || execution?.state || "").toLowerCase();
  const crossVenue = predictionIsCrossVenue(execution);
  const reached = status.includes("merg") ? 4
    : status.includes("reconcil") ? 3
      : status.includes("submit") ? 2
        : status.includes("valid") ? 1
          : 0;
  const steps = [
    ["最终检查", reached > 1 ? "后台检查已完成" : reached === 1 ? "正在检查" : "等待后台状态"],
    ["双腿提交", reached > 2 ? "批次已提交" : reached === 2 ? "正在提交" : "等待最终检查"],
    ["成交核对", reached > 3 ? "成交结果已确认" : reached === 3 ? "正在读取两腿结果" : "等待批次提交"],
    crossVenue
      ? ["分别结算/自动兑付", reached === 4 ? "等待两所结算与兑付" : "等待成交确认"]
      : ["自动合并", reached === 4 ? "正在合并完整代币组" : "等待成交确认"],
  ];
  return `<div class="pm-progress" aria-label="订单执行进度">${steps.map(([label, detail], index) => {
    const step = index + 1;
    const className = reached > step ? "done" : reached === step ? "current" : "";
    return `<div class="pm-progress-step ${className}"><span>${step} · ${label}</span><strong>${detail}</strong></div>`;
  }).join("")}</div>`;
}

function predictionExecutionUpdatedRecently(value, maxAgeSeconds, now = Date.now()) {
  const timestamp = new Date(value).getTime();
  if (!Number.isFinite(timestamp)) return false;
  const ageMs = Number(now) - timestamp;
  if (!Number.isFinite(ageMs) || ageMs < 0) return false;
  return ageMs <= maxAgeSeconds * 1000;
}

function predictionExecutionAlert(payload, strategy = "yes_no") {
  const execution = payload?.current_execution;
  const incident = payload?.breaker?.incident;
  const status = String(execution?.status || execution?.state || payload?.status || "").toLowerCase();
  if (incident || payload?.breaker?.open && status.includes("incident")) {
    const incidentId = incident?.incident_id || incident?.id || "";
    const happenedAt = incident?.happened_at || incident?.created_at || incident?.updated_at;
    const reason = incident?.reason || incident?.message;
    return `<section class="pm-alert danger" role="alert"><div class="pm-alert-body"><strong>交易已熔断</strong><p>${escapeHtml(reason ? predictionIncidentReasonLabel(reason) : "事故详情未返回")}</p><small>发生时间：${escapeHtml(predictionValue(happenedAt, "-"))}</small></div><button class="pm-button danger" type="button" data-action="open-reset" data-incident-id="${escapeHtml(incidentId)}"${incidentId ? "" : " disabled"}>查看事故并处理</button></section>`;
  }
  if (execution && ["running", "executing", "pending", "submitted", "reconciling", "validating", "final_validating", "submitting", "merging"].some((value) => status.includes(value))) {
    return `<section class="pm-alert info" role="status" aria-live="polite"><div class="pm-alert-body"><strong>正在执行：${escapeHtml(predictionValue(execution.event_title || execution.market_title || execution.question, "数据未返回"))}</strong><p>本笔完成前，其他机会暂时不可参与。</p>${predictionExecutionProgress(execution)}</div><span class="pm-pill watch">执行中</span></section>`;
  }
  if (execution && ["confirmed", "completed", "merged", "success"].some((value) => status.includes(value))) {
    const profit = execution.realized_profit ?? execution.profit ?? execution.net_profit;
    const complete = [
      execution.event_title || execution.market_title || execution.question,
      execution.quantity,
      execution.actual_cost,
      execution.merge_value,
      profit,
      execution.completed_at,
    ].every(predictionHasValue);
    if (!complete) {
      return `<section class="pm-alert success" role="status" aria-live="polite"><div class="pm-alert-body"><strong>交易已完成，详情数据未返回</strong><p>请在“交易与合并”历史中查看后台保存的最终记录。</p></div></section>`;
    }
    return `<section class="pm-alert success" role="status" aria-live="polite"><div class="pm-alert-body"><strong>两腿已成交并自动合并</strong><p>买入 ${escapeHtml(predictionValue(execution.quantity))} 组实际成本 ${escapeHtml(predictionMoney(execution.actual_cost))}，合并收回 ${escapeHtml(predictionMoney(execution.merge_value))}，本次已实现净利润 <b>${escapeHtml(predictionSignedMoney(profit))}</b>。</p></div><span class="pm-pill action">已完成 · ${escapeHtml(predictionValue(execution.completed_at))}</span></section>`;
  }
  const lastExecution = payload?.last_execution;
  if (
    lastExecution
    && String(lastExecution.state || "").trim() === "submit_failed_cleared"
    && predictionExecutionUpdatedRecently(lastExecution.updated_at, 600)
  ) {
    const zero = lastExecution.zero_landing && typeof lastExecution.zero_landing === "object"
      ? lastExecution.zero_landing
      : {};
    const reason = [
      [lastExecution.post_error_code, lastExecution.post_error_type]
        .filter((value) => predictionHasValue(value))
        .join("｜"),
      lastExecution.post_error_message,
    ].filter((value) => predictionHasValue(value)).join("：");
    const balanceProven = predictionHasValue(zero.balance_before)
      && predictionHasValue(zero.balance_after);
    const proofLine = balanceProven
      ? `自证依据：挂单空 · 两腿无持仓 · 余额未变（${zero.balance_before} → ${zero.balance_after}）`
      : "自证依据：挂单空 · 两腿无持仓";
    const body = [
      reason ? `<p>原因 ${escapeHtml(reason)}</p>` : "",
      `<small>${escapeHtml(proofLine)}</small>`,
      "<small>系统已自动恢复，下一个机会照常参与，无需处理。</small>",
    ].join("");
    return `<section class="pm-alert info" role="status" aria-live="polite"><div class="pm-alert-body"><strong>上一笔下单失败 · 已核实无成交</strong>${body}</div><span class="pm-pill watch">已自动恢复</span></section>`;
  }
  if (execution && status === "holding_to_resolution") {
    const cross = predictionIsCrossVenue(execution);
    return `<section class="pm-alert success" role="status" aria-live="polite"><div class="pm-alert-body"><strong>两腿已成交，${cross ? "待兑付" : "待结算"}</strong><p>${cross ? "两所分别结算后自动兑付；不会 merge，结算前允许继续持有其他已确认组合。" : "这是两个独立 condition 的阈值关系组合；不会 merge，结算前允许继续持有其他已确认组合。"}</p></div><span class="pm-pill action">${cross ? "待兑付" : "待结算"}</span></section>`;
  }
  if (payload?.stale && !(strategy === "llm_hedge" && predictionTradingAvailable(payload, strategy))) {
    const health = payload?.health || {};
    const degradedReasons = Array.isArray(health.degraded_reasons)
      ? health.degraded_reasons.map((reason) => String(reason || ""))
      : [];
    const universeAttempts = Number(health.universe_refresh_attempts || 0);
    const universeExhausted = health.universe_retry_exhausted === true
      || degradedReasons.includes("universe_retry_exhausted");
    if (strategy !== "llm_hedge" && universeExhausted) {
      const recovery = health.universe_retry_pending === true
        ? "暂时超时，每 5 分钟自动探测恢复"
        : "已停止自动重试";
      return `<section class="pm-alert danger" role="alert"><div class="pm-alert-body"><strong>监控市场连续 5 次刷新失败</strong><p>监控市场连续 5 次刷新失败，${recovery}；请检查 Prediction Service 的刷新阶段日志及 Polymarket 连接。</p></div><span class="pm-pill watch">失败关闭</span></section>`;
    }
    if (
      strategy !== "llm_hedge"
      && universeAttempts >= 1
      && universeAttempts < 5
      && degradedReasons.includes("universe_refresh_failed")
    ) {
      return `<section class="pm-alert danger" role="alert"><div class="pm-alert-body"><strong>监控市场刷新失败</strong><p>监控市场刷新失败，正在自动重试（${universeAttempts}/5）</p></div><span class="pm-pill watch">失败关闭</span></section>`;
    }
    if (predictionWatcherIsConnected(payload)) {
      return `<section class="pm-alert danger" role="alert"><div class="pm-alert-body"><strong>当前盘口暂不可交易</strong><p>盘口数据已过期，当前不会开放下单；保留最后一次监控结果，仅供查看。</p></div><span class="pm-pill watch">失败关闭</span></section>`;
    }
    return `<section class="pm-alert danger" role="alert"><div class="pm-alert-body"><strong>Polymarket 数据连接异常</strong><p>当前不会开放下单；保留最后一次监控结果，仅供查看。</p></div><span class="pm-pill watch">失败关闭</span></section>`;
  }
  return "";
}

function predictionErrorAlert() {
  const message = String(state.predictionMarket.error || "").trim();
  if (!message) return "";
  return `<section class="pm-alert danger" role="alert"><div class="pm-alert-body"><strong>本次操作未提交</strong><p>${escapeHtml(message)}</p></div><span class="pm-pill watch">失败关闭</span></section>`;
}

function predictionMetricStrip(payload) {
  const labels = ["当前可参与", "监控事件", "市场 / 实时 Token", "过去 24 小时信号"];
  if (!predictionHealthIsNormal(payload)) {
    return `<section class="pm-metrics" aria-label="监控摘要不可用">${labels.map((label) => `<article class="pm-metric"><span>${label}</span><strong>-</strong><small>数据未返回</small></article>`).join("")}</section>`;
  }
  const events = predictionEvents(payload);
  const opportunities = predictionOpportunities(payload);
  const executionBlocked = predictionExecutionIsActive(payload);
  const actionable = payload?.breaker?.open || executionBlocked
    ? 0
    : Array.isArray(payload?.opportunities)
      ? opportunities.filter((item) => item.actionable === true
        && predictionOpportunityIsComplete(item)
        && (!predictionIsCrossVenue(item) || predictionCrossExecutionMode(item) === "manual_confirm")).length
      : "-";
  const eventCount = predictionHasValue(payload?.event_count) ? predictionNumber(payload.event_count) : "-";
  const marketCount = predictionHasValue(payload?.market_count) ? predictionNumber(payload.market_count) : "-";
  const standardTokenCount = payload?.relation_discovery?.websocket?.standard_subscribed_tokens;
  const tokenCount = predictionHasValue(standardTokenCount) ? predictionNumber(standardTokenCount) : "-";
  const signals = predictionHasValue(payload?.signals_24h ?? payload?.history_count_24h)
    ? predictionNumber(payload.signals_24h ?? payload.history_count_24h)
    : "-";
  return `<section class="pm-metrics" aria-label="监控摘要"><article class="pm-metric primary"><span>当前可参与</span><strong>${actionable}</strong><small>后台检查全部通过后才显示</small></article><article class="pm-metric"><span>监控事件</span><strong>${eventCount}</strong><small>按 24h 成交量动态筛选</small></article><article class="pm-metric"><span>市场 / 实时 Token</span><strong>${escapeHtml(`${marketCount} / ${tokenCount}`)}</strong><small>不可参与市场定时刷新</small></article><article class="pm-metric"><span>过去 24 小时信号</span><strong>${signals}</strong><small>曾达到可参与条件</small></article></section>`;
}

function predictionNLegOverview(payload) {
  const shadow = payload?.n_leg_shadow && typeof payload.n_leg_shadow === "object" ? payload.n_leg_shadow : {};
  const count = (name) => Number.isFinite(Number(shadow[name])) ? predictionNumber(shadow[name], "0") : "0";
  const last = predictionHasValue(shadow.last_completed_at)
    ? predictionHktTimestamp(shadow.last_completed_at)
    : "等待";
  return `<section class="pm-metrics pm-n-leg-overview" aria-label="N_LEG Shadow 总览"><article class="pm-metric"><span>监控</span><strong>${escapeHtml(count("monitoring"))}</strong><small>持续监听 Episode</small></article><article class="pm-metric"><span>旧系统合格</span><strong>${escapeHtml(count("legacy_qualified"))}</strong><small>仍由旧系统负责</small></article><article class="pm-metric"><span>N_LEG 完成</span><strong>${escapeHtml(count("completed"))}</strong><small>异步校验完成</small></article><article class="pm-metric"><span>差异</span><strong>${escapeHtml(count("differences"))}</strong><small>需要关注</small></article><article class="pm-metric"><span>失败</span><strong>${escapeHtml(count("failures"))}</strong><small>运行期错误</small></article><article class="pm-metric"><span>最近完成</span><strong>${escapeHtml(last)}</strong><small>只读 Shadow</small></article></section>`;
}

function predictionNLegShadowHtml(value) {
  const shadow = value?.n_leg_shadow && typeof value.n_leg_shadow === "object" ? value.n_leg_shadow : null;
  const latest = shadow?.latest_result && typeof shadow.latest_result === "object" ? shadow.latest_result : null;
  if (!latest) return "";
  const comparison = String(latest.comparison || "").toUpperCase();
  const failure = comparison === "FAILURE";
  const different = comparison === "DIFFERENCE";
  const notEvaluated = comparison === "NOT_EVALUATED";
  const tone = failure ? "danger" : different ? "warning" : notEvaluated ? "" : "pm-tone-ok";
  const label = failure ? "N_LEG 运行失败" : different ? "N_LEG 与旧系统有差异" : notEvaluated ? "N_LEG 未评估（缺少结算证据）" : "N_LEG 与旧系统一致";
  const differences = shadow.current_differences && typeof shadow.current_differences === "object"
    ? Object.entries(shadow.current_differences)
    : [];
  const rows = differences.map(([name, difference]) => {
    const item = difference && typeof difference === "object" ? difference : {};
    return `<li><strong>${escapeHtml(predictionValue(name))}</strong><span>旧 ${escapeHtml(predictionValue(item.legacy, "-"))} · N_LEG ${escapeHtml(predictionValue(item.n_leg, "-"))}${predictionHasValue(item.absolute) ? ` · 差 ${escapeHtml(predictionValue(item.absolute))}` : ""}</span></li>`;
  }).join("");
  const detail = failure
    ? `<p>${escapeHtml(predictionValue(latest.reason, "未返回运行期原因"))}</p>`
    : rows
      ? `<ul class="pm-n-leg-differences">${rows}</ul>`
      : `<p>数量、最大成本、最低利润与资金释放时间均已通过独立验证。</p>`;
  return `<details class="pm-n-leg-shadow ${tone}"${failure || different ? " open" : ""}><summary><span>${escapeHtml(label)}</span><small>${escapeHtml(predictionValue(latest.decision, "UNKNOWN"))}</small></summary>${detail}</details>`;
}

function predictionReplacePositiveActionLabel(value, replacement) {
  const raw = String(value || "");
  if (raw === "可参与") return replacement;
  if (raw.endsWith(" · 可参与")) return `${raw.slice(0, -3)}${replacement}`;
  return value;
}

function predictionVenueLegLabels(value) {
  const legs = Array.isArray(value) ? value : [];
  return legs.map((leg) => {
    const exchange = String(leg?.exchange || leg?.venue || "").toLowerCase();
    const venue = exchange === "predict.fun" ? "Predict.fun" : exchange === "polymarket" ? "Polymarket" : "场所未返回";
    const outcome = predictionValue(leg?.outcome, "结果未返回");
    return `${venue} · ${outcome}`;
  }).join(" / ");
}

function predictionIsCrossVenue(value) {
  return String(value?.market_type || "").toLowerCase() === "cross_venue_yes_no";
}

function predictionCrossExecutionMode(value) {
  const mode = value?.execution_mode;
  return typeof mode === "string" ? mode : "";
}

function predictionCrossExecutionModeReason(value) {
  const mode = predictionCrossExecutionMode(value);
  if (mode === "observe_only") return "当前为只观察模式，不开放下单。";
  if (!mode) return "执行模式未返回，当前不会开放下单。";
  if (mode === "blocked") return "当前执行模式已阻断，不开放下单。";
  return "执行模式未知，当前不会开放下单。";
}

function predictionCrossVenueTradingAvailable(payload) {
  const venues = Array.isArray(payload?.venues) ? payload.venues : [];
  const required = ["predict.fun", "polymarket"];
  const venuesReady = required.every((exchange) => venues.some((venue) => (
    String(venue?.venue || "").toLowerCase() === exchange
      && String(venue?.rest || "").toLowerCase() === "ready"
      && String(venue?.ws || "").toLowerCase() === "ready"
      && String(venue?.mode || "") === "可以交易"
      && predictionHasValue(venue?.balance?.value)
  )));
  return predictionTradingAvailable(payload)
    && venuesReady
    && payload?.cross_venue?.breaker?.open === false;
}

function predictionCrossVenueCandidateHtml(value, payload) {
  const opportunity = predictionOpportunityDisplay(value);
  const legs = Array.isArray(opportunity.legs) ? opportunity.legs : [];
  const titleZh = opportunity.title_zh || opportunity.title;
  const titleEn = opportunity.title_zh ? `<span class="pm-title-en">${escapeHtml(predictionValue(opportunity.title, "数据未返回"))}</span>` : "";
  const complete = predictionOpportunityIsComplete(opportunity);
  const executionMode = predictionCrossExecutionMode(opportunity);
  const executionModeAllowsAction = executionMode === "manual_confirm";
  const observeOnlyStage5 = executionMode === "observe_only" && Number(opportunity.funnel_stage) === 5;
  const actionable = executionModeAllowsAction && complete
    && opportunity.actionable === true
    && opportunity.clear_signal === true
    && predictionCrossVenueTradingAvailable(payload);
  const status = actionable ? "可下单明确信号" : "仅观察";
  const reason = (!executionModeAllowsAction && (executionMode !== "observe_only" || observeOnlyStage5))
    ? predictionCrossExecutionModeReason(opportunity)
    : actionable
      ? "确认时会重新读取两所 REST、盘口、余额和未结算额度。"
      : predictionReasonLabel(opportunity.eligibility_reason || opportunity.reason || "opportunity_unavailable");
  const legRows = legs.map((leg, index) => {
    const ids = [leg.market_id, leg.condition_id, leg.token_id].filter(predictionHasValue).join(" · ");
    const link = leg.official_url ? `<a href="${escapeHtml(leg.official_url)}" target="_blank" rel="noreferrer">官方链接</a>` : "";
    return `<article class="pm-order-leg"><span>第 ${index + 1} 腿 · ${escapeHtml(predictionVenueLegLabels([leg]).replace(" · ", " · BUY "))} · FOK</span><strong>冻结数量 ${escapeHtml(predictionValue(leg.net_quantity ?? opportunity.net_quantity, "-"))} 份 · 最高价冻结 ${escapeHtml(predictionPrice(leg.max_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(leg.max_cost))} · ${escapeHtml(predictionValue(leg.settlement_asset, "资产未返回"))}</small>${ids ? `<small>Native IDs ${escapeHtml(ids)}</small>` : ""}${link ? `<small>${link}</small>` : ""}</article>`;
  }).join("");
  return `<article class="pm-opportunity pm-cross-candidate ${actionable ? "" : "disabled"}" data-cross-opportunity-id="${escapeHtml(predictionValue(opportunity.opportunity_id, ""))}"><div class="pm-opportunity-title"><div><h3 class="pm-event-title"><span class="pm-title-zh">${escapeHtml(predictionValue(titleZh, "数据未返回"))}</span>${titleEn}</h3><p>Predict.fun × Polymarket · 跨所 YES/NO · ${escapeHtml(predictionValue(opportunity.canonical_cutoff ?? opportunity.resolution_at, "截止时间未返回"))}</p></div><span class="pm-pill ${actionable ? "action" : "watch"}">${status}</span></div><div class="pm-order-legs">${legRows || "<div class=\"pm-empty compact\">两条跨所腿数据未返回</div>"}</div><dl class="pm-cross-metrics"><div><dt>净可兑付份额</dt><dd>${escapeHtml(predictionValue(opportunity.net_quantity, "-"))}</dd></div><div><dt>含费最大成本</dt><dd>${escapeHtml(predictionMoney(opportunity.max_cost))}</dd></div><div><dt>最低赔付</dt><dd>${escapeHtml(predictionMoney(opportunity.minimum_payout))}</dd></div><div><dt>最低净利润</dt><dd class="pm-positive">${escapeHtml(predictionSignedMoney(opportunity.profit))}</dd></div><div><dt>简单年化</dt><dd>${escapeHtml(predictionAnnualizedPercent(opportunity.annualized_yield, 2))}</dd></div></dl>${predictionNLegShadowHtml(opportunity)}<div class="pm-opportunity-action"><p>${escapeHtml(reason)}</p>${actionable ? `<button class="pm-button primary pm-participate" type="button" data-action="participate" data-opportunity-id="${escapeHtml(predictionValue(opportunity.opportunity_id, ""))}">查看并确认跨所订单</button>` : ""}</div></article>`;
}

function predictionConditionLabel(value) {
  const raw = String(value || "").trim();
  if (!raw) return "-";
  return raw.length > 18 ? `${raw.slice(0, 8)}…${raw.slice(-6)}` : raw;
}

function predictionLlmDecisionLabel(opportunity) {
  const decision = String(opportunity?.llm_decision || "").trim().toUpperCase();
  const status = String(opportunity?.llm_status || "").trim().toLowerCase();
  const modelText = String(opportunity?.codex_model || "").toLowerCase();
  const provider = modelText.includes("glm")
    ? "智谱 GLM"
    : modelText.includes("deepseek")
      ? "DeepSeek"
      : modelText
        ? "Codex"
        : "LLM";
  if (decision === "APPROVE" || status === "approved") return `${provider} APPROVE`;
  if (decision === "REJECT" || status === "llm_rejected") return `${provider} REJECT`;
  if (status === "llm_unavailable") return `${provider} 不可用`;
  return `${provider} 未校验`;
}

function predictionLlmReasonHtml(opportunity) {
  const reasons = Array.isArray(opportunity?.llm_reason_codes) ? opportunity.llm_reason_codes : [];
  const uncertainties = Array.isArray(opportunity?.llm_uncertainties) ? opportunity.llm_uncertainties : [];
  const evidence = Array.isArray(opportunity?.llm_evidence) ? opportunity.llm_evidence : [];
  const reasonText = [...reasons, ...uncertainties].filter(predictionHasValue).map(escapeHtml).join(" · ");
  const evidenceText = evidence.map((item) => {
    if (!item || typeof item !== "object") return String(item || "");
    return Object.entries(item).map(([key, value]) => `${key}: ${value}`).join(" · ");
  }).filter(predictionHasValue).map(escapeHtml).join("<br>");
  return `${opportunity?.llm_summary ? `<p>${escapeHtml(opportunity.llm_summary)}</p>` : ""}${reasonText ? `<small>原因：${reasonText}</small>` : ""}${evidenceText ? `<small>证据：${evidenceText}</small>` : ""}`;
}

function predictionThresholdDistributionHtml(payload) {
  const distribution = payload?.relation_discovery?.annualized_distribution || {};
  return `<section class="pm-threshold-history" aria-label="历史同类年化参考">${[
    ["current", "当前"],
    ["7d", "7 天"],
    ["30d", "30 天"],
  ].map(([key, label]) => {
    const item = distribution[key] && typeof distribution[key] === "object" ? distribution[key] : {};
    return `<div><span>${label}</span><strong>P50 ${escapeHtml(predictionAnnualizedPercent(item.median))}</strong><small>P90 ${escapeHtml(predictionAnnualizedPercent(item.p90))} · n=${escapeHtml(predictionValue(item.count, "0"))}</small></div>`;
  }).join("")}</section>`;
}

function predictionThresholdCanPreview(opportunity, payload) {
  const legs = Array.isArray(opportunity.buy_legs) ? opportunity.buy_legs : [];
  const quantity = Number(opportunity.quantity);
  const conditions = [String(opportunity.condition_id_a || ""), String(opportunity.condition_id_b || "")];
  const legByLabel = Object.fromEntries(legs.map((leg) => [String(leg?.label || "").toUpperCase(), leg]));
  const tokens = legs.map((leg) => String(leg?.token_id || ""));
  const relation = String(opportunity.relation || "").toUpperCase();
  const outcomesMatchRelation = relation === "A_IMPLIES_B"
    ? String(legByLabel.A?.outcome || "").toUpperCase() === "NO"
      && String(legByLabel.B?.outcome || "").toUpperCase() === "YES"
    : relation === "B_IMPLIES_A"
      ? String(legByLabel.A?.outcome || "").toUpperCase() === "YES"
        && String(legByLabel.B?.outcome || "").toUpperCase() === "NO"
      : false;
  const positiveNumber = (value) => predictionHasValue(value)
    && Number.isFinite(Number(value))
    && Number(value) > 0;
  return predictionOpportunityIsComplete(opportunity)
    && (opportunity.actionable === true || String(opportunity.eligibility_reason || "") === "book_stale")
    && String(opportunity.llm_status || "").toLowerCase() === "approved"
    && String(opportunity.llm_decision || "").toUpperCase() === "APPROVE"
    && conditions[0] !== conditions[1]
    && legByLabel.A?.condition_id === conditions[0]
    && legByLabel.B?.condition_id === conditions[1]
    && outcomesMatchRelation
    && tokens.length === 2
    && tokens.every(Boolean)
    && tokens[0] !== tokens[1]
    && positiveNumber(quantity)
    && legs.every((leg) => Number(leg.quantity) === quantity)
    && positiveNumber(opportunity.max_cost ?? opportunity.total_max_cost)
    && positiveNumber(opportunity.profit ?? opportunity.minimum_profit)
    && positiveNumber(opportunity.minimum_payout)
    && positiveNumber(opportunity.annualized_yield)
    && positiveNumber(opportunity.remaining_days)
    && predictionHasValue(opportunity.resolution_at)
    && predictionTradingAvailable(payload, "llm_hedge");
}

function predictionThresholdCandidateHtml(value, payload, expandedRelationKeys = new Set()) {
  const opportunity = predictionOpportunityDisplay(value);
  const relationKey = predictionValue(
    opportunity.relation_id || opportunity.opportunity_id || opportunity.id,
    ""
  );
  const previewable = predictionThresholdCanPreview(opportunity, payload);
  const actionable = opportunity.actionable === true && previewable;
  const legs = Array.isArray(opportunity.buy_legs) ? opportunity.buy_legs : [];
  const llm = predictionLlmDecisionLabel(opportunity);
  const profit = Number(opportunity.profit ?? opportunity.minimum_profit);
  const cost = Number(opportunity.max_cost ?? opportunity.total_max_cost);
  const simpleReturn = Number.isFinite(profit) && Number.isFinite(cost) && cost > 0
    ? `${(profit / cost * 100).toFixed(2)}%`
    : "-";
  const remaining = Number(opportunity.remaining_days);
  const remainingLabel = Number.isFinite(remaining) && remaining > 0
    ? `${Number.isInteger(remaining) ? remaining : remaining.toFixed(1)} 天`
    : "不可计算";
  const annualized = predictionAnnualizedPercent(opportunity.annualized_yield);
  const annualizedDetail = predictionAnnualizedPercent(opportunity.annualized_yield, 2);
  const title = opportunity.event_title
    || (opportunity.title !== "数据未返回" ? opportunity.title : "")
    || `阈值关系候选 · ${predictionValue(opportunity.relation, "关系未返回")}`;
  const open = relationKey && expandedRelationKeys.has(relationKey);
  const statusClass = llm.includes("APPROVE") ? "action" : "watch";
  const legRows = legs.length
    ? legs.map((leg) => `<article class="pm-order-leg"><span>${escapeHtml(predictionValue(leg.label))} · BUY ${escapeHtml(predictionValue(leg.outcome))} · FOK · ${escapeHtml(predictionConditionLabel(leg.condition_id))}</span><strong>${escapeHtml(predictionValue(leg.quantity, "-"))} 份 @ 最高 ${escapeHtml(predictionPrice(leg.max_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(leg.max_cost))}</small></article>`).join("")
    : `<div class="pm-empty compact">两条 BUY 腿数据未返回</div>`;
  const action = previewable
    ? `<div class="pm-opportunity-action"><p>${actionable ? "两笔订单非原子、不同 condition，不会 merge；确认时重新读取规则、盘口、费用和账户。" : "当前盘口已过期；点击后只刷新这两腿，仍为正收益才生成确认单。"}</p><button class="pm-button primary pm-participate" type="button" data-action="participate" data-opportunity-id="${escapeHtml(relationKey)}">${actionable ? "查看并确认两腿订单" : "刷新盘口并确认"}</button></div>`
    : "";
  const blockedReason = actionable
    ? ""
    : predictionReasonLabel(
      opportunity.eligibility_reason
        || (opportunity.llm_status === "approved" ? "opportunity_unavailable" : opportunity.llm_status)
    );
  const proof = opportunity.llm_proof && typeof opportunity.llm_proof === "object"
    ? Object.entries(opportunity.llm_proof).map(([key, item]) => `${key}: ${item}`).join(" · ")
    : "";
  return `<details class="pm-threshold-candidate pm-opportunity ${previewable ? "" : "disabled"}" data-relation-key="${escapeHtml(relationKey)}"${open ? " open" : ""}><summary><div class="pm-threshold-summary-title"><strong>${escapeHtml(title)}</strong><small>${escapeHtml(predictionConditionLabel(opportunity.condition_id_a))} + ${escapeHtml(predictionConditionLabel(opportunity.condition_id_b))}</small></div><span class="pm-pill ${statusClass}">${escapeHtml(llm.replace(/^(Codex|DeepSeek|智谱 GLM|LLM) /, ""))}</span><div><span>24h 成交量</span><strong>${escapeHtml(predictionVolume(opportunity.volume_24h, "-"))}</strong></div><div><span>成本 / 最低赔付</span><strong>${escapeHtml(predictionMoney(opportunity.max_cost ?? opportunity.total_max_cost))} / ${escapeHtml(predictionMoney(opportunity.minimum_payout))}</strong></div><div><span>理论利润</span><strong class="pm-positive">${escapeHtml(predictionSignedMoney(opportunity.profit ?? opportunity.minimum_profit))}</strong></div><div class="pm-threshold-yield"><span>简单年化</span><strong>${escapeHtml(annualized)}</strong><small>查看详情</small></div></summary><div class="pm-threshold-detail"><section><h3>当前年化计算</h3><div class="pm-threshold-formula"><div><span>含费最大成本</span><strong>${escapeHtml(predictionMoney(opportunity.max_cost ?? opportunity.total_max_cost))}</strong></div><div><span>最低赔付</span><strong>${escapeHtml(predictionMoney(opportunity.minimum_payout))}</strong></div><div><span>理论最低利润</span><strong class="pm-positive">${escapeHtml(predictionSignedMoney(opportunity.profit ?? opportunity.minimum_profit))}</strong></div><div><span>预计资金占用</span><strong>${escapeHtml(remainingLabel)}</strong></div><div><span>简单收益率</span><strong>${escapeHtml(predictionMoney(opportunity.profit ?? opportunity.minimum_profit))} / ${escapeHtml(predictionMoney(opportunity.max_cost ?? opportunity.total_max_cost))} = ${escapeHtml(simpleReturn)}</strong></div><div><span>简单年化</span><strong>${escapeHtml(simpleReturn)} × 365 / ${escapeHtml(remainingLabel)} = ${escapeHtml(annualizedDetail)}</strong></div></div><p class="pm-threshold-caveat">按预计结算时间做非复利年化；结算延迟会降低实际年化。两腿成交前，利润尚未锁定。</p>${predictionThresholdDistributionHtml(payload)}</section><section><h3>合约与赔付证明</h3><div class="pm-threshold-questions"><div><span>市场 A</span><strong>${escapeHtml(predictionValue(opportunity.question_a, "数据未返回"))}</strong><small>${escapeHtml(predictionConditionLabel(opportunity.condition_id_a))}</small></div><div><span>市场 B</span><strong>${escapeHtml(predictionValue(opportunity.question_b, "数据未返回"))}</strong><small>${escapeHtml(predictionConditionLabel(opportunity.condition_id_b))}</small></div></div><div class="pm-order-legs">${legRows}</div></section><section><h3>LLM 与确定性校验</h3><div class="pm-threshold-llm"><div class="pm-llm-line"><span class="pm-pill ${statusClass}">${escapeHtml(llm)}</span><button type="button" class="pm-model-tag" aria-describedby="llm-model-tip-${escapeHtml(relationKey)}">${escapeHtml(String(opportunity?.codex_model || "LLM").trim())}<span class="pm-model-tip" id="llm-model-tip-${escapeHtml(relationKey)}" role="tooltip">${predictionLlmReasonHtml(opportunity) || "<small>该模型本次未给出评价。</small>"}</span></button></div>${predictionLlmReasonHtml(opportunity)}${proof ? `<small>证明：${escapeHtml(proof)}</small>` : ""}<small>规则关系复核：${opportunity.llm_status === "approved" ? "通过" : "未通过"}</small>${blockedReason ? `<small>当前不可确认：${escapeHtml(blockedReason)}</small>` : ""}</div></section>${action}</div></details>`;
}

function predictionFunnelStatus(value) {
  const status = String(value || "unavailable").toLowerCase();
  if (status === "healthy" || status === "connected") return "正常";
  if (status === "scanning") return "扫描中";
  if (status === "lagging") return "追赶中";
  if (status === "degraded") return "降级";
  if (status === "stale") return "已过期";
  return "不可用";
}

function predictionFunnelDuration(value) {
  const milliseconds = Number(value);
  if (!Number.isFinite(milliseconds)) return "-";
  if (milliseconds < 1000) return `${Math.round(milliseconds)} ms`;
  return `${(milliseconds / 1000).toFixed(2)} 秒`;
}

function predictionFunnelStage(label, value, note = "", tone = "") {
  const display = predictionNumber(value);
  return `<article class="pm-funnel-stage ${tone}"><span>${escapeHtml(label)}</span><strong>${escapeHtml(display)}</strong>${note ? `<small>${escapeHtml(note)}</small>` : ""}</article>`;
}

function predictionLpFunnelCount(value) {
  if (value === null || value === undefined || String(value).trim() === "") return "UNKNOWN";
  return predictionNumber(value, "UNKNOWN");
}

function predictionLpFunnelCondition(conditions, key) {
  const value = conditions && typeof conditions === "object" ? conditions[key] : undefined;
  if (value === null || value === undefined || String(value).trim() === "") return "规则不可用（UNKNOWN）";
  if (typeof value === "object") {
    const parts = Object.entries(value).map(([name, item]) => `${name}：${item}`);
    return parts.length ? parts.join(" · ") : "规则不可用（UNKNOWN）";
  }
  return String(value);
}

function predictionLpFunnelStage(label, key, value, note, hint, tone = "") {
  const hintNode = `<span class="pm-lp-funnel-hint" tabindex="0" role="note" aria-label="${escapeHtml(hint)}" data-lp-funnel-hint="${escapeHtml(key)}">!<span class="pm-lp-funnel-tip" role="tooltip">${escapeHtml(hint)}</span></span>`;
  return `<article class="pm-funnel-stage pm-lp-funnel-stage ${tone}" data-lp-funnel-stage="${escapeHtml(key)}"><span>${escapeHtml(label)}${hintNode}</span><strong>${escapeHtml(value)}</strong><small>${escapeHtml(note)}</small></article>`;
}

function predictionLpFunnel(payload) {
  const funnel = payload && typeof payload === "object" ? payload : {};
  const conditions = funnel.conditions && typeof funnel.conditions === "object" ? funnel.conditions : {};
  const read = (key) => funnel[key];
  const hasCondition = (key) => Object.prototype.hasOwnProperty.call(conditions, key);
  const conditionText = (key) => hasCondition(key)
    ? predictionLpFunnelCondition(conditions, key)
    : "规则不可用（UNKNOWN）";
  const numeric = (value) => {
    if (value === null || value === undefined || String(value).trim() === "") return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  };
  const excluded = funnel.excluded && typeof funnel.excluded === "object" ? funnel.excluded : {};
  const compared = funnel.compared_range && typeof funnel.compared_range === "object"
    ? funnel.compared_range : {};
  const stale = payload.stale === true || payload.state === "stale";
  const scanning = payload.scanning === true || payload.state === "scanning";
  const incomplete = payload.state === "incomplete" || payload.complete === false;
  const checkedAt = payload.checked_at || funnel.checked_at || payload.last_success_at || payload.candidate_last_success_at;
  const status = stale
    ? `已过期${incomplete ? " · 部分结果" : ""} · 上次筛选条件 ${predictionHasValue(checkedAt) ? predictionHktTimestamp(checkedAt) : "UNKNOWN"}`
    : scanning
      ? "扫描中 · 保留当前已读计数"
      : incomplete
        ? `部分结果 · 检查 ${predictionHasValue(checkedAt) ? predictionHktTimestamp(checkedAt) : "UNKNOWN"}`
        : predictionHasValue(checkedAt)
          ? `检查 ${predictionHktTimestamp(checkedAt)}`
          : "检查时间 UNKNOWN";
  const rawReasons = funnel.reasons && typeof funnel.reasons === "object" ? funnel.reasons : {};
  const reasonLabels = {read: "读取", base: "基础筛选", sort: "排序", trial: "待测候选"};
  const reasonText = (item) => {
    if (!item || typeof item !== "object") return String(item);
    const market = item.market_id || item.condition_id || "UNKNOWN";
    const code = item.reason || item.code || "UNKNOWN";
    return `${market} · ${String(code).replaceAll("_", " ")}`;
  };
  const reasonGroups = ["read", "base", "sort", "trial"].map((key) => {
    const hasReasons = Object.prototype.hasOwnProperty.call(rawReasons, key)
      && Array.isArray(rawReasons[key]);
    const values = hasReasons ? rawReasons[key] : [];
    return `<section data-lp-funnel-reason-stage="${key}"><strong>${reasonLabels[key]}</strong>${values.length ? `<ul>${values.map((item) => `<li>${escapeHtml(reasonText(item))}</li>`).join("")}</ul>` : hasReasons ? "<p>本轮没有淘汰原因</p>" : "<p>原因 UNKNOWN</p>"}</section>`;
  }).join("");
  const reasons = `<details data-lp-funnel-reasons data-lp-details-key="lp-funnel-reasons"><summary>筛选原因</summary><div class="pm-lp-funnel-reasons">${reasonGroups}</div><p class="sub">同一标的可能有多个原因，原因数量不可相加。</p></details>`;
  const stages = [
    predictionLpFunnelStage(
      "读取", "read", predictionLpFunnelCount(read("read")),
      `已比较 ${predictionLpFunnelCount(compared.compared)}/${predictionLpFunnelCount(compared.total)} · 待处理 ${predictionLpFunnelCount(compared.pending)}`,
      conditionText("read"), "live",
    ),
    predictionLpFunnelStage(
      "基础筛选", "base", predictionLpFunnelCount(read("base")),
      "奖励、市场、参与、摘要与事件窗口剔除",
      conditionText("base"), "live",
    ),
    predictionLpFunnelStage(
      "排序", "sort", predictionLpFunnelCount(read("sort")),
      `竞争有效 ${predictionLpFunnelCount(funnel.competition_known)} · 未知 ${predictionLpFunnelCount(funnel.competition_unknown)} · 竞争 0 排除 ${predictionLpFunnelCount(excluded.competition_empty)}`,
      conditionText("sort"), "live",
    ),
    predictionLpFunnelStage(
      "待测候选", "trial", predictionLpFunnelCount(read("trial")),
      `超可用排除 ${predictionLpFunnelCount(excluded.over_available)} · 展示 ${predictionLpFunnelCount(funnel.trial)}`,
      conditionText("trial"),
      (numeric(read("trial")) || 0) > 0 ? "good" : "drop",
    ),
  ].join("");
  return `<section class="pm-panel pm-relation-funnel pm-lp-funnel" aria-label="LP 标的评估"><header class="pm-funnel-header"><div><h2>LP 标的评估</h2><p>读取市场 → 基础筛选 → 排序 → 待测候选</p></div><span class="pm-pill ${stale ? "watch" : scanning ? "watch" : ""}">${escapeHtml(status)}</span></header><div class="pm-funnel-lane"><div class="pm-funnel-grid pm-funnel-grid-catalog pm-lp-funnel-grid">${stages}</div></div><div class="pm-funnel-meta"><span>官方竞争密度分档筛选只留轻中（并列时按值升序）；缺失/重度/过薄/零竞争整行排除，不填 0</span><span>最低占资超过可用资金的候选不展示，计入排除数</span>${reasons}</div></section>`;
}

function predictionLpPreparation(preparation) {
  if (!preparation || typeof preparation !== "object" || Array.isArray(preparation)) return "";
  const rawState = String(preparation.state || "").trim().toLowerCase();
  const rawStage = String(preparation.stage || "").trim().toLowerCase();
  const stateLabels = {idle: "空闲", preparing: "准备中", waiting_retry: "等待自动重试", partial: "部分完成", paused: "已暂停", ready: "已就绪"};
  const stageLabels = {catalog: "目录", metadata: "市场资料", history: "历史", complete: "完成"};
  const stateLabel = stateLabels[rawState] || "UNKNOWN";
  const operatorAttention = rawState === "paused"
    && preparation.last_error_category === "operator_attention";
  const displayedStateLabel = operatorAttention ? "需人工处理" : stateLabel;
  const stageLabel = stageLabels[rawStage] || "UNKNOWN";
  const count = (value) => predictionHasValue(value) ? predictionNumber(value, "UNKNOWN") : "UNKNOWN";
  const timestamp = (label, value) => predictionHasValue(value)
    ? `<span>${label}：${escapeHtml(predictionHktTimestamp(value, "UNKNOWN"))}</span>`
    : "";
  const emptyCatalog = rawState === "ready" && rawStage === "complete"
    && [preparation.completed_count, preparation.total_count,
      preparation.metadata_completed_count, preparation.metadata_total_count]
      .every((value) => predictionHasValue(value)
        && Number.isFinite(Number(value)) && Number(value) === 0);
  const alertProvided = Object.prototype.hasOwnProperty.call(preparation, "alert_attempted")
    || Object.prototype.hasOwnProperty.call(preparation, "alert_state");
  const alertState = predictionHasValue(preparation.alert_state)
    ? String(preparation.alert_state)
    : preparation.alert_attempted === true ? "UNKNOWN" : "未尝试";
  const itemSummaryProvided = [
    "preparation_item_total", "paused_market_count", "waiting_market_count",
    "retrying_market_count", "failed_market_count",
  ].some((key) => Object.prototype.hasOwnProperty.call(preparation, key));
  const completed = Number(preparation.completed_count);
  const total = Number(preparation.total_count);
  const partialCoverage = rawState === "partial"
    || ["paused_market_count", "waiting_market_count", "retrying_market_count", "failed_market_count"]
      .some((key) => Number(preparation[key]) > 0)
    || Number.isFinite(completed) && Number.isFinite(total) && total > completed;
  const itemCoverage = itemSummaryProvided && partialCoverage
    ? `<div class="pm-relation-summary"><span>部分覆盖</span><span>需人工处理 ${escapeHtml(count(preparation.paused_market_count))} 个市场</span><span>待重试 ${escapeHtml(count(preparation.waiting_market_count))} 个市场</span><span>重试中 ${escapeHtml(count(preparation.retrying_market_count))} 个市场</span></div>`
    : "";
  const recoveryBusy = state.predictionMarket.lpDashboardRequestInFlight
    || state.predictionMarket.lpPreparationRecoveryInFlight;
  const recoverablePartial = rawState === "partial"
    && Number(preparation.paused_market_count) > 0;
  const recoveryButton = rawState === "paused" || recoverablePartial
    ? `<button class="pm-button" type="button" data-action="lp-preparation-recovery"${predictionWritesBlocked() || recoveryBusy || !state.predictionMarket.csrfToken ? " disabled" : ""}>${recoverablePartial ? "恢复暂停项" : "恢复准备"}</button>`
    : "";
  const failure = predictionHasValue(preparation.last_error)
    ? `<p class="pm-signal-error" role="${rawState === "paused" ? "alert" : "status"}">最近失败：${escapeHtml(String(preparation.last_error))}</p>`
    : "";
  const automaticRecovery = rawState === "waiting_retry"
    ? "<span>自动恢复中</span>"
    : "";
  const probe = rawState === "waiting_retry"
    ? `<p class="pm-signal-error" role="status">下次探测：${escapeHtml(predictionHktTimestamp(preparation.next_probe_at, "UNKNOWN"))}</p>`
    : "";
  const retry = rawState === "waiting_retry"
    ? `<p class="pm-signal-error" role="status">下次重试：${escapeHtml(predictionHktTimestamp(preparation.next_retry_at, "UNKNOWN"))}</p>`
    : "";
  const alert = alertProvided ? `<span>告警：${escapeHtml(alertState)}</span>` : "";
  const emptyNote = emptyCatalog
    ? "目录已确认为空；暂无候选资料。"
    : "准备状态不等同于候选资格；下单指引仍需独立风控资料。";
  return `<section class="pm-panel pm-lp-preparation" aria-label="LP 准备状态" data-lp-preparation-state="${escapeHtml(rawState || "unknown")}"><header class="pm-panel-heading"><div><h3>LP 准备状态</h3><p>阶段：${escapeHtml(stageLabel)}</p></div><div class="pm-panel-heading-actions"><span class="pm-pill ${rawState === "paused" ? "pm-tone-danger" : rawState === "ready" ? "pm-tone-ok" : "watch"}">${escapeHtml(displayedStateLabel)}</span>${automaticRecovery}${recoveryButton}</div></header><div class="pm-relation-summary"><span>历史方向 ${escapeHtml(count(preparation.completed_count))} / ${escapeHtml(count(preparation.total_count))}</span><span>市场资料 ${escapeHtml(count(preparation.metadata_completed_count))} / ${escapeHtml(count(preparation.metadata_total_count))}</span><span>尝试 ${escapeHtml(count(preparation.attempt))}</span><span>失败 ${escapeHtml(count(preparation.failure_count))}</span>${alert}</div>${itemCoverage}<div class="pm-relation-summary">${timestamp("上次尝试", preparation.last_attempt_at)}${timestamp("最近进展", preparation.last_progress_at)}${timestamp("上次失败", preparation.last_failure_at)}${timestamp("上次成功", preparation.last_success_at)}</div>${failure}${probe}${retry}<p class="sub">${emptyNote}</p></section>`;
}

function predictionFunnelRejections(counts) {
  const values = counts && typeof counts === "object" ? counts : {};
  const labels = {
    book_unavailable: "盘口缺失",
    minimum_depth: "最小深度",
    cost_limit: "成本上限",
    outside_5pct: "距盈亏平衡",
    codex_rejected: "LLM 拒绝",
    codex_unavailable: "LLM 不可用",
    rules_changed: "规则变化",
    readiness_blocked: "准入阻断",
    event_ineligible: "事件不合格",
    market_unparseable: "市场不可解析",
  };
  const rows = Object.entries(values)
    .filter(([, value]) => Number(value) > 0)
    .map(([key, value]) => `${labels[key] || key.replaceAll("_", " ")} ${predictionNumber(value)}`);
  return rows.length ? rows.join(" · ") : "暂无淘汰";
}

function predictionFunnelReasons(activity, payload) {
  const reasons = Array.isArray(activity?.rejection_reasons) ? activity.rejection_reasons : [];
  const fromActivity = reasons.map((item) => {
    const reason = item && typeof item === "object" ? item.eligibility_reason || item.reason : item;
    return predictionReasonLabel(reason);
  }).filter(Boolean);
  if (fromActivity.length) return [...new Set(fromActivity)];
  const opportunities = predictionOpportunities(payload)
    .filter((item) => String(item?.market_type || "") === "threshold_hedge")
    .map((item) => predictionReasonLabel(item.eligibility_reason || item.reason))
    .filter(Boolean);
  return [...new Set(opportunities)];
}

function predictionRelationFunnel(payload) {
  const discovery = payload?.relation_discovery && typeof payload.relation_discovery === "object" ? payload.relation_discovery : {};
  const catalog = discovery.catalog && typeof discovery.catalog === "object" ? discovery.catalog : {};
  const rawActivity = discovery.activity && typeof discovery.activity === "object" ? discovery.activity : {};
  const scanning = ["scanning", "lagging"].includes(String(rawActivity.status || "").toLowerCase());
  const completed = rawActivity.last_completed && typeof rawActivity.last_completed === "object" ? rawActivity.last_completed : {};
  const activity = scanning ? {...rawActivity, ...completed} : rawActivity;
  const websocket = discovery.websocket && typeof discovery.websocket === "object" ? discovery.websocket : {};
  const queue = discovery.codex_queue && typeof discovery.codex_queue === "object" ? discovery.codex_queue : {};
  const usage = discovery.codex_usage_24h && typeof discovery.codex_usage_24h === "object" ? discovery.codex_usage_24h : {};
  const usageByProvider = discovery.llm_usage_24h_by_provider && typeof discovery.llm_usage_24h_by_provider === "object" ? discovery.llm_usage_24h_by_provider : {};
  const codexUsage = usageByProvider.codex && typeof usageByProvider.codex === "object" ? usageByProvider.codex : {};
  const deepseekUsage = usageByProvider.deepseek && typeof usageByProvider.deepseek === "object" ? usageByProvider.deepseek : {};
  const zhipuUsage = usageByProvider.zhipu && typeof usageByProvider.zhipu === "object" ? usageByProvider.zhipu : {};
  const logs = Array.isArray(discovery.scan_logs) ? discovery.scan_logs : [];
  const relationCount = catalog.relations_discovered ?? catalog.relation_count ?? 0;
  const positive = activity.positive_candidates ?? 0;
  const ready = activity.order_ready ?? 0;
  const catalogStatus = predictionFunnelStatus(catalog.status);
  const catalogPillClass = catalogStatus === "正常" ? "action" : "watch";
  const websocketStatus = String(websocket.status || "").toLowerCase() === "connected" ? "WebSocket 正常" : `WebSocket ${predictionFunnelStatus(websocket.status)}`;
  const logRows = logs.length
    ? logs.map((item) => `<li>${escapeHtml(typeof item === "object" ? Object.entries(item).map(([key, value]) => `${key}=${value}`).join(" · ") : String(item))}</li>`).join("")
    : "<li>暂无扫描日志</li>";
  const empty = Number(relationCount) === 0
    ? `<div class="pm-funnel-empty"><strong>本轮未发现可验证关系</strong><p>关系目录完成后，下一轮成交筛选会自动恢复。</p></div>`
    : positive > 0 && Number(ready) === 0
      ? `<div class="pm-funnel-empty pm-funnel-warning"><strong>正收益候选尚未满足下单准入</strong><p>${escapeHtml(predictionFunnelReasons(activity, payload).join(" · ") || "仍在等待实时校验")}</p></div>`
      : positive === 0
        ? `<div class="pm-funnel-empty"><strong>本轮没有正收益候选</strong><p>完整漏斗和淘汰原因仍保留，下一分钟会重新考虑全部关系。</p></div>`
        : "";
  return `<details class="pm-panel pm-relation-funnel" aria-label="实时两层漏斗"><summary class="pm-funnel-header pm-collapse-summary"><div><h2>实时两层漏斗</h2><p>关系目录每日更新；成交候选每分钟重新筛选。</p></div><span class="pm-pill ${catalogPillClass}">${escapeHtml(catalogStatus)}</span></summary><div class="pm-funnel-chips pm-funnel-chips-body"><span class="pm-funnel-chip">关系目录 ${escapeHtml(catalogStatus)}</span><span class="pm-funnel-chip">成交筛选 ${escapeHtml(predictionFunnelStatus(rawActivity.status))}</span><span class="pm-funnel-chip">${escapeHtml(websocketStatus)} · ${escapeHtml(predictionValue(websocket.last_message_age_seconds, "-"))}s</span><span class="pm-funnel-chip">LLM queue · ${escapeHtml(predictionNumber(queue.pending, "0"))} 待审</span></div><div class="pm-funnel-lane"><div class="pm-funnel-lane-title"><strong>第一层 · 关系目录</strong><small>${escapeHtml(catalogStatus)} · ${escapeHtml(predictionFunnelDuration(catalog.duration_ms))}</small></div><div class="pm-funnel-grid pm-funnel-grid-catalog">${predictionFunnelStage("扫描事件", catalog.events_seen, `合格 ${predictionNumber(catalog.events_eligible)}`)}${predictionFunnelStage("阈值市场", catalog.threshold_markets)}${predictionFunnelStage("程序关系", relationCount)}${predictionFunnelStage("持久化目录", relationCount, `唯一 Token ${predictionNumber(catalog.unique_tokens)}`, "good")}</div></div><div class="pm-funnel-lane"><div class="pm-funnel-lane-title"><strong>第二层 · 成交候选</strong><small>${escapeHtml(predictionFunnelStatus(rawActivity.status))} · ${escapeHtml(predictionFunnelDuration(activity.duration_ms))}</small></div><div class="pm-funnel-grid pm-funnel-grid-activity">${predictionFunnelStage("全部关系", activity.relations_considered)}${predictionFunnelStage("盘口可用", activity.relations_with_books, `淘汰 ${predictionNumber(activity.rejection_counts?.book_unavailable, "0")}`)}${predictionFunnelStage("最小深度", activity.relations_with_minimum_depth, `淘汰 ${predictionNumber(activity.rejection_counts?.minimum_depth, "0")}`)}${predictionFunnelStage("5%边界内", activity.relations_within_5pct, `淘汰 ${predictionNumber(activity.rejection_counts?.outside_5pct, "0")}`, "drop")}${predictionFunnelStage("LLM", activity.codex_approved, `${predictionNumber(activity.codex_pending, "0")} 待审 · ${predictionNumber(activity.codex_rejected, "0")} 拒绝`)}${predictionFunnelStage("WebSocket池", activity.subscribed_tokens, `${predictionNumber(activity.subscribed_relations, "0")} 关系`, "live")}${predictionFunnelStage("正收益", positive, `正收益 ${predictionNumber(positive)}`, positive > 0 ? "good" : "")}${predictionFunnelStage("飞书已发", activity.notifications_sent, `飞书 ${predictionNumber(activity.notifications_sent, "0")} · 可下单 ${predictionNumber(ready, "0")}`, "good")}</div></div><div class="pm-funnel-meta"><span>${escapeHtml(websocketStatus)}</span><span>本轮耗时 ${escapeHtml(predictionFunnelDuration(activity.duration_ms))}</span><details class="pm-funnel-rejections"><summary>拒绝原因</summary><p>${escapeHtml(predictionFunnelRejections({...catalog.rejection_counts, ...activity.rejection_counts}))}</p></details><details class="pm-scan-logs"><summary>扫描日志（${logs.length} 条）</summary><ul>${logRows}</ul></details><span class="pm-usage-line"><strong>智谱 24h</strong>：${escapeHtml(predictionNumber(zhipuUsage.calls, "0"))} calls · ${escapeHtml(predictionNumber(zhipuUsage.failures, "0"))} fail · ${escapeHtml(predictionNumber(zhipuUsage.cache_hits, "0"))} cache(本次运行)</span><span class="pm-usage-line"><strong>Codex 24h</strong>：${escapeHtml(predictionNumber(codexUsage.calls ?? usage.calls, "0"))} calls · ${escapeHtml(predictionNumber(codexUsage.failures ?? usage.failures, "0"))} fail · ${escapeHtml(predictionNumber(codexUsage.cache_hits ?? usage.cache_hits, "0"))} cache(本次运行)</span><span class="pm-usage-line"><strong>DeepSeek 24h</strong>：${escapeHtml(predictionNumber(deepseekUsage.calls, "0"))} calls · ${escapeHtml(predictionNumber(deepseekUsage.failures, "0"))} fail · ${escapeHtml(predictionNumber(deepseekUsage.cache_hits, "0"))} cache(本次运行)</span></div>${empty}</details>`;
}

const PREDICTION_LLM_PROVIDERS = [
  {id: "codex", name: "Codex", sub: "CLI"},
  {id: "deepseek", name: "DeepSeek", sub: ""},
  {id: "zhipu", name: "智谱 GLM", sub: ""},
  {id: "zhipu_max", name: "GLM 5.3 Max", sub: ""},
];

const PREDICTION_LLM_CHECK_SVG = "<svg width=\"12\" height=\"12\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\"><path d=\"m3.5 8.5 3 3 6-7\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>";

function predictionLlmEngineHtml(discovery) {
  const engine = discovery?.llm_provider && typeof discovery.llm_provider === "object" ? discovery.llm_provider : {};
  const selected = String(engine.selected || "");
  if (!selected) return "";
  const models = engine.models && typeof engine.models === "object" ? engine.models : {};
  const configuredMap = engine.configured && typeof engine.configured === "object" ? engine.configured : {};
  const usageByProvider = discovery?.llm_usage_24h_by_provider && typeof discovery.llm_usage_24h_by_provider === "object" ? discovery.llm_usage_24h_by_provider : {};
  const switching = String(state.predictionMarket.llmSwitchInFlight || "");
  const buttons = PREDICTION_LLM_PROVIDERS.map((item) => {
    const isCurrent = item.id === selected;
    const configured = configuredMap[item.id] !== false;
    const inFlight = switching === item.id;
    const disabled = isCurrent || !configured || (Boolean(switching) && !inFlight);
    const sub = isCurrent ? "当前" : configured ? item.sub : "未配置 Key";
    return `<button type="button" class="pm-llm-option" data-llm-provider="${item.id}" aria-pressed="${isCurrent}"${disabled ? " disabled" : ""}${!configured ? " title=\"未配置 API Key\"" : ""}>${isCurrent ? PREDICTION_LLM_CHECK_SVG + " " : ""}${escapeHtml(item.name)}${sub ? ` <span class="pm-llm-sub">${escapeHtml(sub)}</span>` : ""}${inFlight ? " 切换中…" : ""}</button>`;
  }).join("");
  const usageChip = (provider, label) => {
    const item = usageByProvider[provider] && typeof usageByProvider[provider] === "object" ? usageByProvider[provider] : {};
    const failing = Number(item.failures) > 0;
    const active = provider === selected;
    return `<span class="pm-funnel-chip${active ? " active" : failing ? " failing" : ""}">${label} 24h ${escapeHtml(predictionNumber(item.calls, "0"))} calls · ${escapeHtml(predictionNumber(item.failures, "0"))} fail · ${escapeHtml(predictionNumber(item.cache_hits, "0"))} cache</span>`;
  };
  const selectedName = PREDICTION_LLM_PROVIDERS.find((item) => item.id === selected)?.name || selected;
  return `<div class="pm-llm-engine"><div class="pm-llm-engine-label">LLM 校验引擎</div><div class="pm-llm-segment" role="group" aria-label="选择 LLM 校验引擎">${buttons}</div><div class="pm-llm-status"><div class="pm-llm-current">当前 ${escapeHtml(selectedName)} · ${escapeHtml(String(models[selected] || ""))} <small>· 选中失败即停止新下单（不降级），恢复后自动重审</small></div></div><div class="pm-llm-usage">${usageChip("zhipu", "智谱")}${usageChip("zhipu_max", "GLM 5.3 Max")}${usageChip("codex", "Codex")}${usageChip("deepseek", "DeepSeek")}</div><p class="pm-llm-hint">切换立即生效：下一次校验走新引擎；已批准/已拒绝的缓存结论跨引擎复用，不重审。</p></div>`;
}

async function switchPredictionLlmProvider(provider) {
  if (!provider || state.predictionMarket.llmSwitchInFlight) return;
  state.predictionMarket.llmSwitchInFlight = provider;
  renderPredictionMarket();
  try {
    await predictionPost("/api/prediction-arbitrage/llm-provider", {provider});
  } catch (error) {
    state.predictionMarket.error = error instanceof Error ? error.message : String(error);
  } finally {
    state.predictionMarket.llmSwitchInFlight = "";
  }
  await fetchPredictionState();
}

function predictionRelationDiscoveryPanel(payload) {
  const discovery = payload?.relation_discovery && typeof payload.relation_discovery === "object" ? payload.relation_discovery : {};
  const catalog = discovery.catalog && typeof discovery.catalog === "object" ? discovery.catalog : {};
  const activity = discovery.activity && typeof discovery.activity === "object" ? discovery.activity : {};
  const usage = discovery.codex_usage_24h && typeof discovery.codex_usage_24h === "object" ? discovery.codex_usage_24h : {};
  const usageByProvider = discovery.llm_usage_24h_by_provider && typeof discovery.llm_usage_24h_by_provider === "object" ? discovery.llm_usage_24h_by_provider : {};
  const logs = Array.isArray(discovery.scan_logs) ? discovery.scan_logs : [];
  const logRows = logs.length ? logs.map((item) => `<li>${escapeHtml(typeof item === "object" ? Object.entries(item).map(([key, value]) => `${key}=${value}`).join(" · ") : String(item))}</li>`).join("") : "<li>暂无扫描日志</li>";
  const duration = predictionFunnelDuration(catalog.duration_ms);
  const next = predictionValue(activity.next_scan_at, "按计划");
  const catalogStatus = predictionFunnelStatus(catalog.status);
  const catalogPillClass = catalogStatus === "正常" ? "action" : "watch";
  const usageLine = (provider, label) => {
    const item = usageByProvider[provider] && typeof usageByProvider[provider] === "object" ? usageByProvider[provider] : {};
    return `${label} ${predictionNumber(item.calls ?? (provider === "codex" ? usage.calls : undefined), "0")} calls · ${predictionNumber(item.failures ?? (provider === "codex" ? usage.failures : undefined), "0")} fail · ${predictionNumber(item.cache_hits ?? (provider === "codex" ? usage.cache_hits : undefined), "0")} cache(本次运行)`;
  };
  return `<details class="pm-panel pm-relation-discovery" aria-label="关联合约扫描"><summary class="pm-panel-heading pm-collapse-summary"><div><h2>关联合约扫描</h2><p>关系目录持久化，成交筛选每分钟刷新。</p></div><span class="pm-pill ${catalogPillClass}">${escapeHtml(catalogStatus)}</span></summary><div class="pm-relation-summary pm-relation-summary-grid"><span>最近全量扫描<strong>${escapeHtml(predictionValue(catalog.completed_at, "未完成"))}</strong></span><span>扫描耗时<strong>${escapeHtml(duration)}</strong></span><span>下次计划<strong>${escapeHtml(next)}</strong></span><span>LLM 24h<strong>${escapeHtml(usageLine("zhipu", "智谱"))}<br>${escapeHtml(usageLine("codex", "Codex"))}<br>${escapeHtml(usageLine("deepseek", "DeepSeek"))}</strong></span></div>${predictionLlmEngineHtml(discovery)}<details class="pm-scan-logs"><summary>扫描日志（${logs.length} 条）</summary><ul>${logRows}</ul></details></details>`;
}

function predictionOpportunityPanel(payload) {
  const opportunities = predictionOpportunities(payload);
  const opportunity = opportunities[0];
  if (!opportunity) {
    return predictionHealthIsNormal(payload)
      ? `<div class="pm-empty"><strong>当前没有可参与机会</strong><p>Watcher 正常运行。历史信号仍可在下方查看。</p></div>`
      : `<div class="pm-empty"><strong>预测市场暂不可用</strong><p>${escapeHtml(predictionFailureReasonLabel(payload))}</p></div>`;
  }
  const complete = predictionOpportunityIsComplete(opportunity);
  const executionBlocked = predictionExecutionIsActive(payload);
  const actionable = complete && opportunity.actionable === true && predictionTradingAvailable(payload);
  if (predictionIsCrossVenue(opportunity)) {
    return predictionCrossVenueCandidateHtml(opportunity, payload);
  }
  if (String(opportunity.market_type || "") === "threshold_hedge") {
    return predictionThresholdCandidateHtml(opportunity, payload);
  }
  const title = opportunity.title || opportunity.market_title || opportunity.event_title || "数据未返回";
  const status = !complete ? "数据不完整" : actionable ? "可参与" : "暂不可参与";
  const buttonText = !complete ? "数据不完整"
    : executionBlocked ? "另一笔正在执行"
      : !predictionHealthIsNormal(payload) ? "不可用"
        : payload?.breaker?.open ? "熔断中"
          : actionable ? `参与 · 预计 ${predictionSignedMoney(opportunity.profit ?? opportunity.minimum_profit)}`
            : "暂不可参与";
  const quantity = predictionValue(opportunity.quantity ?? opportunity.size, "-");
  const threshold = payload?.policy_limits?.min_estimated_profit;
  const actionNote = predictionHasValue(threshold)
    ? `确认时会重新检查价格；净利润低于 ${predictionMoney(threshold)} 就拒绝下单。`
    : "策略参数未返回，不能下单。";
  return `<article class="pm-opportunity ${actionable ? "" : "disabled"}"><div class="pm-opportunity-title"><div><h3>${escapeHtml(title)}</h3><p>Polymarket · ${escapeHtml(predictionMarketTypeLabel(opportunity.market_type))} · ${escapeHtml(predictionFeeStatusLabel(opportunity.fee_status))} · ${escapeHtml(predictionValue(opportunity.updated_at, "-"))}</p></div><span class="pm-pill ${actionable ? "action" : "watch"}">${status}</span></div><dl class="pm-opportunity-metrics"><div><dt>YES 最高买价</dt><dd>${escapeHtml(predictionPrice(opportunity.yes_price ?? opportunity.yes_best_bid))}</dd></div><div><dt>NO 最高买价</dt><dd>${escapeHtml(predictionPrice(opportunity.no_price ?? opportunity.no_best_bid))}</dd></div><div><dt>自动数量</dt><dd>${escapeHtml(quantity === "-" ? quantity : `${quantity} 组`)}</dd></div><div><dt>最大成本</dt><dd>${escapeHtml(predictionMoney(opportunity.max_cost ?? opportunity.cost))}</dd></div><div><dt>最低净利润</dt><dd class="pm-positive">${escapeHtml(predictionSignedMoney(opportunity.profit ?? opportunity.minimum_profit))}</dd></div></dl><div class="pm-opportunity-action"><p>${escapeHtml(actionNote)}</p><button class="pm-button primary pm-participate" type="button" data-action="participate" data-opportunity-id="${escapeHtml(predictionValue(opportunity.opportunity_id || opportunity.id, ""))}"${actionable ? "" : " disabled"}>${escapeHtml(buttonText)}</button></div></article>`;
}

function predictionHistoryContent(payload, kind) {
  const rows = payload?.histories?.[kind];
  const displayRows = (Array.isArray(rows) ? rows : [])
    .map((row) => predictionHistoryDisplay(kind, row))
    .filter((row) => kind !== "executions" || row.phase !== "startup_unknown_state");
  if (!displayRows.length) return `<div class="pm-empty compact"><strong>${kind === "signals" ? "还没有历史信号" : kind === "executions" ? "还没有真实交易" : "没有交易事故"}</strong><p>${kind === "signals" ? "后台达到正式信号门槛后会保留出现时间、成交量和利润。" : kind === "executions" ? "第一笔真实机会完成后，这里会记录两腿订单、合并交易和已实现利润。" : "单腿成交、自动处置失败和合并失败会永久保留在这里。"}</p></div>`;
  if (kind === "signals") {
    const notificationLabel = (value) => {
      const stateValue = String(value || "").toLowerCase();
      if (stateValue === "sent") return "飞书已发";
      if (stateValue === "failed") return "发送失败";
      return "未发送";
    };
    const durationLabel = (row) => {
      const observed = Number(row.observed_duration_ms);
      return Number.isFinite(observed) ? `${Math.round(observed)} ms` : predictionValue(row.duration);
    };
    const closed = (row) => row.closed === true
      || ["closed", "ended", "expired"].includes(String(row.status || "").toLowerCase())
      || predictionHasValue(row.ended_at)
      || predictionHasValue(row.closed_at);
    const title = (row) => {
      const english = predictionValue(row.event_title, "-");
      const chinese = String(row.event_title_zh || row.title_zh || "").trim();
      const secondary = chinese || "中文翻译生成中";
      const legs = predictionVenueLegLabels(row.legs);
      return `<span class="pm-title-en">${escapeHtml(english)}</span><span class="pm-title-zh">${escapeHtml(secondary)}</span>${legs ? `<small class="pm-signal-legs">${escapeHtml(legs)}</small>` : ""}${predictionNLegShadowHtml(row)}`;
    };
    const liveProfit = (row) => closed(row) ? "—" : predictionSignedMoney(row.live_profit ?? row.estimated_profit, "—");
    const threshold = (row) => String(row.market_type || "") === "threshold_hedge";
    const cross = (row) => predictionIsCrossVenue(row);
    const capitalUsage = (row) => {
      if (cross(row)) return `<strong>净可兑付 ${escapeHtml(predictionValue(row.net_quantity ?? row.quantity, "-"))} 份</strong><small>两所待兑付</small>`;
      if (!threshold(row)) return `<strong>${escapeHtml(durationLabel(row))}</strong>`;
      const remaining = Number(row.remaining_days);
      const remainingText = Number.isFinite(remaining) && remaining > 0
        ? `${Number.isInteger(remaining) ? remaining : remaining.toFixed(1)} 天`
        : "不可计算";
      const resolution = predictionHktTimestamp(row.resolution_at, "结算时间未返回");
      return `<strong>${escapeHtml(remainingText)}</strong><small>结算 ${escapeHtml(resolution)}</small>`;
    };
    const netReturn = (row) => {
      if (cross(row)) return `<strong class="pm-positive">${escapeHtml(predictionSignedMoney(row.minimum_profit ?? row.initial_profit))}</strong><small>年化 ${escapeHtml(predictionAnnualizedPercent(row.annualized_yield, 2))}</small>`;
      if (!threshold(row)) {
        return `<strong>${escapeHtml(predictionSignedMoney(row.initial_profit))}</strong><small>实时 ${escapeHtml(liveProfit(row))}</small>`;
      }
      const profit = predictionSignedMoney(row.minimum_profit ?? row.profit ?? row.estimated_profit);
      const annualized = predictionAnnualizedPercent(row.annualized_yield, 2);
      const cost = predictionMoney(row.total_max_cost ?? row.max_cost);
      const fee = predictionHasValue(row.maximum_fee) ? ` ${predictionMoney(row.maximum_fee)}` : "";
      return `<strong class="pm-positive">${escapeHtml(profit)}</strong><small>年化 ${escapeHtml(annualized)}</small><small>最多占用 ${escapeHtml(cost)} · 含模型手续费${escapeHtml(fee)}</small>`;
    };
    const operation = (row) => {
      const currentState = state.predictionMarket.payload || payload;
      const automaticCrossMode = currentState?.cross_auto?.configured_mode === "auto_submit";
      const healthy = !String(state.predictionMarket.signalError || "").trim()
        && predictionTradingAvailable(currentState);
      const liveCrossOpportunity = cross(row) && Array.isArray(currentState?.opportunities)
        ? currentState.opportunities.find((candidate) => (
          predictionIsCrossVenue(candidate)
          && String(candidate?.opportunity_id ?? candidate?.id ?? "") === String(row.opportunity_id ?? "")
        ))
        : null;
      const effectiveCrossRow = cross(row)
        ? liveCrossOpportunity
          ? {...row, execution_mode: liveCrossOpportunity.execution_mode}
          : {...row, execution_mode: undefined}
        : row;
      const crossModeAllowsAction = !cross(row) || predictionCrossExecutionMode(effectiveCrossRow) === "manual_confirm";
      const actionable = !automaticCrossMode && row.actionable_now === true && !closed(row) && predictionHasValue(row.opportunity_id) && healthy && crossModeAllowsAction;
      const button = `<button class="pm-button primary pm-signal-action" type="button" data-action="participate" data-opportunity-id="${escapeHtml(String(row.opportunity_id))}">重新检查</button>`;
      if (cross(row)) {
        if (String(row.status || "").includes("授权已清零")) {
          return `<span class="pm-observe">${escapeHtml(predictionValue(row.status))}</span>`;
        }
        return actionable && predictionCrossVenueTradingAvailable(currentState)
          ? button
          : `<span class="pm-observe">仅观察</span><small>${escapeHtml(!crossModeAllowsAction ? predictionCrossExecutionModeReason(effectiveCrossRow) : predictionReasonLabel(row.eligibility_reason || "opportunity_unavailable"))}</small>`;
      }
      if (threshold(row)) {
        return actionable
          ? button
          : `<span class="pm-observe">仅观察</span><small>${escapeHtml(predictionReasonLabel(row.eligibility_reason || (row.actionable_now ? "opportunity_unavailable" : "annualized_yield_unavailable")))}</small>`;
      }
      const notice = notificationLabel(row.notification_state);
      return `${escapeHtml(notice)}${actionable ? button : ""}`;
    };
    return `<table class="pm-table pm-signal-table"><thead><tr><th>出现时间（HKT）</th><th>标的</th><th>24h 成交量</th><th>资金占用</th><th>净回报</th><th>操作</th></tr></thead><tbody>${displayRows.map((row) => `<tr class="${row.actionable_now === true && !closed(row) ? "pm-signal-live" : ""}"><td data-label="出现时间（HKT）">${escapeHtml(predictionHktTimestamp(row.occurred_at))}<small class="pm-relative-age">${escapeHtml(predictionRelativeAge(row.occurred_at))}</small></td><td data-label="标的" class="pm-title-cell">${title(row)}</td><td data-label="24h 成交量">${escapeHtml(predictionVolume(row.volume_24h, "-"))}</td><td data-label="资金占用">${capitalUsage(row)}</td><td data-label="净回报">${netReturn(row)}</td><td data-label="操作" class="pm-signal-operation">${operation(row)}</td></tr>`).join("")}</tbody></table>`;
  }
  if (kind === "executions") {
    return `<table class="pm-table"><thead><tr><th>完成时间</th><th>市场</th><th>数量</th><th>实际成本</th><th>合并收回</th><th>已实现</th></tr></thead><tbody>${displayRows.map((row) => { const quantity = predictionValue(row.quantity); const quantityLabel = quantity === "-" || quantity.includes("组") ? quantity : `${quantity} 组`; const holding = row.state === "holding_to_resolution"; const legs = predictionVenueLegLabels(row.legs); const state = predictionValue(row.status ?? row.state, "-"); const lifecycle = Array.isArray(row.lifecycle) ? `<details class="pm-lifecycle"><summary>生命周期回执</summary>${row.lifecycle.map((item) => `<div><span>${escapeHtml(predictionValue(item.phase, "阶段"))}</span><strong>${escapeHtml(predictionValue(item.receipt, "-"))}</strong><small>${escapeHtml(predictionValue(item.status, "-"))}</small></div>`).join("")}</details>` : ""; return `<tr><td data-label="完成时间">${escapeHtml(predictionValue(row.completed_at))}</td><td data-label="市场">${escapeHtml(predictionValue(row.event_title))}${legs ? `<small class="pm-signal-legs">${escapeHtml(legs)}</small>` : ""}<small>状态 ${escapeHtml(predictionExecutionStatusLabel(state))}</small>${lifecycle}</td><td data-label="数量">${escapeHtml(quantityLabel)}</td><td data-label="实际成本">${escapeHtml(predictionMoney(row.actual_cost))}</td><td data-label="合并收回">${holding ? "待兑付（不 merge）" : escapeHtml(predictionMoney(row.merge_value))}</td><td data-label="已实现" class="pm-positive"><strong>${holding ? "待兑付" : escapeHtml(predictionSignedMoney(row.realized_profit))}</strong></td></tr>`; }).join("")}</tbody></table>`;
  }
  return `<table class="pm-table"><thead><tr><th>发生时间</th><th>市场</th><th>原因</th><th>自动处置</th><th>损失</th><th>状态</th></tr></thead><tbody>${displayRows.map((row) => { const legs = predictionVenueLegLabels(row.legs); return `<tr><td data-label="发生时间">${escapeHtml(predictionValue(row.happened_at))}</td><td data-label="市场">${escapeHtml(predictionValue(row.event_title))}${legs ? `<small class="pm-signal-legs">${escapeHtml(legs)}</small>` : ""}</td><td data-label="原因">${escapeHtml(predictionIncidentReasonLabel(row.reason))}</td><td data-label="自动处置">${escapeHtml(predictionValue(row.remediation))}</td><td data-label="损失" class="pm-tone-danger"><strong>${escapeHtml(predictionSignedMoney(row.loss))}</strong></td><td data-label="状态">${escapeHtml(predictionIncidentStatusLabel(row.status))}</td></tr>`; }).join("")}</tbody></table>`;
}

function predictionHistoryDisplay(kind, value) {
  const row = value && typeof value === "object" ? value : {};
  const evidence = row.evidence && typeof row.evidence === "object" ? row.evidence : {};
  if (kind === "signals") {
    return {
      ...row,
      occurred_at: row.occurred_at ?? row.started_at ?? row.created_at,
      event_title: row.event_title ?? row.question ?? row.title,
      event_title_zh: row.event_title_zh ?? row.title_zh,
      duration: row.duration ?? "-",
      observed_duration_ms: row.observed_duration_ms,
      initial_profit: row.initial_profit,
      peak_profit: row.peak_profit,
      final_profit: row.final_profit,
      ended_reason: row.ended_reason,
      ended_at: row.ended_at ?? row.closed_at,
      closed: row.closed,
      opportunity_id: row.opportunity_id ?? row.id,
      actionable_now: row.actionable_now === true,
      live_profit: row.live_profit ?? row.estimated_profit,
      notification_state: row.notification_state ?? row.notification_status,
      peak_edge: row.peak_edge ?? row.peak_net_edge ?? row.net_edge,
      quantity: row.quantity ?? row.peak_quantity,
      profit: row.profit ?? row.peak_estimated_profit ?? row.estimated_profit ?? row.minimum_profit,
    };
  }
  if (kind === "executions") {
    return {
      ...row,
      completed_at: row.completed_at ?? row.updated_at ?? row.created_at,
      event_title: row.event_title ?? row.question ?? row.title,
      quantity: row.quantity ?? row.peak_quantity,
      actual_cost: row.actual_cost ?? row.total_actual_cost,
      merge_value: row.merge_value ?? row.merged_value ?? row.payout ?? row.merge_amount,
      realized_profit: row.realized_profit ?? row.net_profit ?? row.actual_profit,
    };
  }
  return {
    ...row,
    happened_at: row.happened_at ?? row.created_at ?? row.updated_at,
    event_title: row.event_title ?? row.question ?? row.title,
    reason: row.reason ?? evidence.reason,
    remediation: row.remediation ?? evidence.remediation,
    loss: row.loss ?? evidence.loss ?? evidence.actual_loss,
    status: row.acknowledged && row.acknowledgement?.reconciliation === "fresh_clean"
      ? "resolved_clean"
      : row.status ?? row.state,
  };
}

function predictionHistoryPanel(payload) {
  const kind = state.predictionMarket.historyKind;
  const title = kind === "signals" ? "套利信号" : kind === "executions" ? "交易与合并" : "事故";
  const description = kind === "signals"
    ? "达到套利门槛的信号会保留；有按钮才代表当前可操作。"
    : kind === "executions"
      ? "真实交易和已实现利润单独保存。"
      : "单腿成交、自动处置失败和合并失败永久保留。";
  const signalClock = kind === "signals"
    ? predictionClock("信号刷新时间", state.predictionMarket.signalLastSuccessAt, {danger: Boolean(String(state.predictionMarket.signalError || "").trim())})
    : "";
  const signalError = kind === "signals" && state.predictionMarket.signalError
    ? `<p class="pm-signal-error" role="alert">${escapeHtml(state.predictionMarket.signalError)}；已冻结上次结果，恢复后继续刷新。</p>`
    : "";
  return `<section class="pm-panel" data-prediction-history-panel><header class="pm-panel-heading"><div><h2>${title}</h2><p>${description}</p>${signalError}</div><div class="pm-panel-heading-actions">${signalClock}<div class="pm-history-tabs" aria-label="套利历史类型"><button class="pm-history-tab" type="button" data-history="signals" aria-pressed="${kind === "signals"}">套利信号</button><button class="pm-history-tab" type="button" data-history="executions" aria-pressed="${kind === "executions"}">交易与合并</button><button class="pm-history-tab" type="button" data-history="incidents" aria-pressed="${kind === "incidents"}">事故</button></div></div></header>${predictionHistoryContent(payload, kind)}</section>`;
}

function predictionYesNoWorkspace(payload) {
  const opportunities = (Array.isArray(payload?.opportunities) ? payload.opportunities : [])
    .filter((item) => String(item?.market_type || "") !== "threshold_hedge");
  const viewPayload = {...payload, opportunities};
  const waiting = opportunities.length
    ? ""
    : `<section class="pm-panel"><div class="pm-empty"><strong>等待旧 YES/NO 合格机会</strong><p>出现真实合格机会后，旧系统保持原有通知和执行；N_LEG 将异步显示只读对比。</p></div></section>`;
  return `${predictionNLegOverview(viewPayload)}${waiting}${predictionCrossVenueFunnel(viewPayload)}${predictionCrossVenueCandidates(viewPayload)}<aside class="pm-policy"><strong>V1 仅对普通二元、免手续费市场开放实盘</strong><p>收费市场和 Negative Risk 市场仍监控，但不会出现“参与”按钮。</p></aside>${predictionHistoryPanel(viewPayload)}`;
}

function predictionCandidateTable(opportunities) {
  const rows = (Array.isArray(opportunities) ? opportunities : []).map((raw) => {
    const opportunity = predictionOpportunityDisplay(raw);
    const actionable = opportunity.actionable === true;
    const cross = predictionIsCrossVenue(opportunity);
    const combinedQuestions = opportunity.question_a && opportunity.question_b
      ? `${opportunity.question_a} / ${opportunity.question_b}`
      : "";
    const title = predictionValue(
      opportunity.title_zh || opportunity.title || opportunity.question || combinedQuestions,
      "数据未返回"
    );
    const sub = cross ? "Predict × Polymarket" : "Polymarket 阈值对冲";
    const annualized = predictionAnnualizedPercent(opportunity.annualized_yield, 2);
    const remaining = Number(opportunity.remaining_days);
    const settlement = Number.isFinite(remaining) && remaining > 0
      ? `${Number.isInteger(remaining) ? remaining : remaining.toFixed(1)} 天`
      : "不可计算";
    const resolution = predictionHktTimestamp(
      opportunity.resolution_at ?? opportunity.canonical_cutoff,
      "—"
    );
    const depthOk = String(opportunity.depth_status || "") === "pass";
    const depth = depthOk
      ? `${escapeHtml(predictionValue(opportunity.max_executable_quantity, "-"))} 份 / ${escapeHtml(predictionMoney(opportunity.max_executable_cost))}`
      : `<span class="pm-tone-danger">深度不足</span>`;
    const policy = depthOk
      ? `${escapeHtml(predictionValue(opportunity.policy_quantity, "-"))} 份 / ${escapeHtml(predictionMoney(opportunity.policy_cost))}`
      : "—";
    const status = actionable
      ? `<span class="pm-pill action">可参与</span>`
      : `<span class="pm-pill watch">仅观察</span><small>${escapeHtml(predictionReasonLabel(opportunity.eligibility_reason || "opportunity_unavailable"))}</small>${Array.isArray(opportunity.llm_reason_codes) && opportunity.llm_reason_codes[0] ? `<small>${escapeHtml(String(opportunity.llm_reason_codes[0]))}</small>` : ""}`;
    const action = actionable
      ? `<button class="pm-button primary pm-participate" type="button" data-action="participate" data-opportunity-id="${escapeHtml(predictionValue(opportunity.opportunity_id || opportunity.id, ""))}">确认</button>`
      : "—";
    return `<tr data-relation-key="${escapeHtml(predictionValue(opportunity.relation_id || opportunity.opportunity_id || opportunity.id, ""))}"><td><strong>${escapeHtml(title)}</strong><span class="sub">${escapeHtml(sub)}</span></td><td class="num"><strong>${escapeHtml(annualized)}</strong></td><td class="num"><strong>${escapeHtml(settlement)}</strong><span class="sub">${escapeHtml(resolution)}</span></td><td class="num">${depth}</td><td class="num">${escapeHtml(policy)}</td><td>${status}</td><td>${action}</td></tr>`;
  }).join("");
  return `<div class="pm-table-wrap"><table class="pm-table pm-candidate-table"><thead><tr><th>标的</th><th class="num">年化</th><th class="num">结算期</th><th class="num">理论深度</th><th class="num">政策下单量</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function predictionLlmHedgeWorkspace(payload, expandedRelationKeys) {
  const opportunities = predictionOpportunities(payload)
    .filter((item) => String(item.market_type || "") === "threshold_hedge");
  const candidates = opportunities.length
    ? predictionCandidateTable(opportunities)
    : `<div class="pm-empty"><strong>当前没有正收益候选</strong><p>关联合约扫描仍在运行；出现候选后会在这里展示校验状态和年化计算。</p></div>`;
  return `${predictionRelationFunnel(payload)}<aside class="pm-policy"><strong>所有正收益候选都会展示</strong><p>低于 15% 年化的信号不展示；LLM 结论和程序复核全部通过后才出现人工确认入口；两腿属于不同 condition，不会 merge。</p></aside><section class="pm-panel"><header class="pm-panel-heading"><div><h2>候选标的</h2><p>按可参与 → 年化 → 结算期 → 利润排序；点击确认前会重新检查价格。</p></div><span class="pm-pill">显示 ${opportunities.length}</span></header>${candidates}</section>`;
}

function predictionLegacyControlsRetired(payload) {
  // Issue #60: once the N_LEG contract reaches generation 2 the legacy
  // strategy controls (validation mode, cross-auto, legacy preview/confirm)
  // are retired; the backend answers 410 to their endpoints.
  const generation = payload?.n_leg?.contract_generation ?? payload?.contract_generation ?? 1;
  return Number(generation) >= 2;
}

function predictionModeBar(payload) {
  if (state.predictionMarket.nLegStatus === "paused") return "";
  if (predictionWritesBlocked()) return `<div class="pm-mode-bar" aria-label="执行模式"><span class="pm-mode-stats">${escapeHtml(predictionServiceIdentity().label)} · 写操作不可用</span></div>`;
  const nleg = payload?.n_leg && typeof payload.n_leg === "object" ? payload.n_leg : {};
  const gates = nleg.execution_gates && typeof nleg.execution_gates === "object" ? nleg.execution_gates : {};
  const contractMode = String(nleg.mode || "");
  const effective = contractMode || payload.validation_mode || "observe_only";
  const active = effective === "AUTO" || effective === "auto" ? "AUTO" : "MANUAL";
  const breakerOpen = gates.breaker_open === true || payload?.breaker?.open === true;
  const breaker = breakerOpen ? "全局熔断开启" : "全局熔断关闭";
  const scopeCount = Array.isArray(nleg.enabled_execution_scope_version) ? nleg.enabled_execution_scope_version.length : 0;
  const scopeText = scopeCount > 0 ? `enabled scope ${scopeCount} 个` : "enabled scope 空";
  const buttons = predictionLegacyControlsRetired(payload) ? "" : [["manual", "MANUAL"], ["auto", "AUTO"]].map(([value, label]) =>
    `<button type="button" class="pm-mode-button${active === label ? " active" : ""}" data-action="set-mode" data-mode="${value}">${label}</button>`
  ).join("");
  return `<div class="pm-mode-bar" aria-label="执行模式">${buttons}<span class="pm-mode-stats">#60 前只读预览 · ${breaker} · ${scopeText}</span></div>`;
}

function predictionCrossAutoStatus(payload) {
  if (predictionWritesBlocked()) return `<span class="pm-mode-stats">${escapeHtml(predictionServiceIdentity().label)} · 写操作不可用</span>`;
  if (predictionLegacyControlsRetired(payload)) return "";
  const auto = payload?.cross_auto && typeof payload.cross_auto === "object" ? payload.cross_auto : {};
  if (auto.configured_mode !== "auto_submit") return "";
  const daily = auto.daily_principal && typeof auto.daily_principal === "object" ? auto.daily_principal : {};
  const attempt = auto.latest_attempt && typeof auto.latest_attempt === "object" ? auto.latest_attempt : null;
  const active = auto.armed === true && auto.effective_mode === "auto_submit";
  const pauseReason = !active && auto.pause_reason
    ? ` · ${escapeHtml(predictionReasonLabel(auto.pause_reason))} · 需要操作员处理`
    : "";
  const attemptedAt = attempt?.updated_at || attempt?.created_at;
  const attemptStatus = attempt?.decision === "rejected"
    ? `<span class="pm-mode-stats">拒绝 ${escapeHtml(predictionValue(attempt.reason_code))} · ${escapeHtml(predictionValue(attempt.reason_zh))} · 当前 ${escapeHtml(predictionValue(attempt.current))} · 上限 ${escapeHtml(predictionValue(attempt.limit))} · 场所 ${escapeHtml(predictionValue(attempt.venue))} · ${escapeHtml(predictionHktTimestamp(attemptedAt))} · ${attempt.operator_action_required === true ? "需要操作员处理" : "无需操作员处理"}${attempt.operator_action ? ` · 操作 ${escapeHtml(predictionValue(attempt.operator_action))}` : ""}</span>`
    : attempt?.decision === "submitted"
      ? `<span class="pm-mode-stats">已提交双边订单 · ${escapeHtml(predictionValue(attempt.reason_zh))} · ${escapeHtml(predictionHktTimestamp(attemptedAt))}</span>`
      : "";
  const pause = active
    ? predictionWritesBlocked() ? "" : `<button class="pm-button danger" type="button" data-action="pause-cross-auto">紧急暂停自动下单</button>`
    : "";
  return `<span class="pm-mode-stats" data-cross-auto-status>跨所自动下单 · ${active ? "已启用" : "已暂停"} · 当日新本金 ${escapeHtml(predictionMoney(daily.current))} / ${escapeHtml(predictionMoney(daily.limit))}${pauseReason}</span>${attemptStatus}${pause}`;
}

function relationDecisionSnapshot(root) {
  const reason = root?.querySelector?.("[data-relation-reason]");
  const note = root?.querySelector?.("[data-relation-note]");
  return {
    reason: reason ? String(reason.value || "") : "",
    note: note ? String(note.value || "") : "",
  };
}

function restoreRelationDecision(root, snapshot) {
  if (!root || !snapshot) return;
  const reason = root.querySelector?.("[data-relation-reason]");
  if (reason && snapshot.reason) {
    const options = Array.from(reason.options || []);
    if (options.some((option) => option.value === snapshot.reason)) reason.value = snapshot.reason;
  }
  const note = root.querySelector?.("[data-relation-note]");
  if (note && snapshot.note) note.value = snapshot.note;
}

function renderPredictionMarket() {
  const root = elements["prediction-market-root"];
  if (!root) return;
  // Polling re-renders the whole page every 5s; snapshot the open relation
  // drawer's decision form first and refill it after so an operator's picked
  // reason/typed note survives instead of silently resetting.
  const decision = relationDecisionSnapshot(root);
  const lpSnapshot = lpRenderFidelitySnapshot(root);
  const cancelFeedbackFocused = document.activeElement?.matches?.(".lp-cancel-feedback");
  root.innerHTML = predictionWorkspacePage();
  restoreRelationDecision(root, decision);
  lpRenderFidelityRestore(root, lpSnapshot);
  if (cancelFeedbackFocused) root.querySelector(".lp-cancel-feedback")?.focus({preventScroll: true});
}

function lpRenderFidelitySnapshot(root) {
  const open = new Set();
  if (typeof root.querySelectorAll === "function") {
    root.querySelectorAll("details[data-lp-details-key][open]").forEach((element) => {
      const key = element.getAttribute("data-lp-details-key");
      if (key) open.add(key);
    });
  }
  const anchor = typeof window !== "undefined" && Number.isFinite(window.scrollY)
    ? window.scrollY : 0;
  const autoField = typeof document !== "undefined" ? document.activeElement?.dataset?.lpAutoField : null;
  return {open, anchor, autoField};
}

function lpRenderFidelityRestore(root, snapshot) {
  if (!snapshot
    || !(snapshot.open instanceof Set)
    || typeof root.querySelectorAll !== "function") {
    return;
  }
  root.querySelectorAll("details[data-lp-details-key]").forEach((element) => {
    if (snapshot.open.has(element.getAttribute("data-lp-details-key"))) {
      element.open = true;
    }
  });
  if (["budget_usd", "target_buy_count"].includes(snapshot.autoField)) {
    root.querySelector(`[data-lp-auto-field="${snapshot.autoField}"]`)?.focus({preventScroll: true});
  }
  if (snapshot.anchor > 0 && typeof window !== "undefined"
    && Number.isFinite(window.scrollY) && typeof window.scrollTo === "function") {
    window.scrollTo(0, snapshot.anchor);
  }
}

function selectPredictionTab(tab) {
  const active = tab === "multi_leg" ? "multi_leg" : "lp";
  if (state.predictionMarket.activeTab === active) return;
  if (active !== "multi_leg") {
    // 离开 multi_leg：维持现状——失效 N_LEG 读 + 关闭 N_LEG 域弹窗。
    invalidatePredictionNLegReads();
    closeNLegDomainPredictionModal();
  } else if (LP_MODAL_KINDS.has(predictionModal?.kind || "")) {
    // Issue 162（定案 2）：离开 lp 标签时显式关闭 LP 三类弹窗。
    closePredictionModal();
  }
  state.predictionMarket.activeTab = active;
  renderPredictionMarket();
  fetchPredictionVenues();
  fetchCurrentPredictionPane();
}

function handlePredictionTabKeydown(event) {
  const button = event.target.closest?.("[data-prediction-tab]");
  if (!button || !["ArrowLeft", "ArrowRight"].includes(event.key)) return;
  event.preventDefault();
  const next = button.dataset.predictionTab === "lp" ? "multi_leg" : "lp";
  selectPredictionTab(next);
  elements["prediction-market-root"]?.querySelector?.(`[data-prediction-tab="${next}"]`)?.focus?.();
}

function fetchCurrentPredictionPane() {
  return state.predictionMarket.activeTab === "multi_leg"
    ? fetchPredictionState()
    : fetchPredictionLpDashboard();
}

function startPredictionPolling() {
  stopPredictionPolling();
  if (state.workspaceView !== "prediction_market") return;
  state.predictionMarket.pollId = window.setInterval(async () => {
    renderPredictionMarket();
    await Promise.all([fetchPredictionVenues(), fetchCurrentPredictionPane()]);
  }, 5000);
}

function stopPredictionPolling() {
  if (state.predictionMarket.pollId !== null) {
    window.clearInterval(state.predictionMarket.pollId);
    state.predictionMarket.pollId = null;
  }
}

function startPredictionSignalPolling() {
  stopPredictionSignalPolling();
  if (!predictionNLegReadAllowed() || state.predictionMarket.strategy !== "yes_no") return;
  loadPredictionHistory("signals", {panelOnly: true});
  state.predictionMarket.signalPollId = window.setInterval(() => {
    loadPredictionHistory("signals", {panelOnly: true});
  }, 5000);
}

function stopPredictionSignalPolling() {
  state.predictionMarket.signalPollEpoch += 1;
  if (state.predictionMarket.signalPollId !== null) {
    window.clearInterval(state.predictionMarket.signalPollId);
    state.predictionMarket.signalPollId = null;
  }
}

function predictionRequestUrl(path) {
  if (typeof window === "undefined" || !window.location) return path;
  const scenario = new URLSearchParams(window.location.search || "").get("prediction_state");
  return scenario ? `${path}${path.includes("?") ? "&" : "?"}scenario=${encodeURIComponent(scenario)}` : path;
}

function predictionNLegStatus(payload) {
  const status = String(payload?.n_leg?.status || "").trim().toLowerCase();
  return status === "paused" ? "paused" : status === "running" ? "running" : "unknown";
}

function predictionServiceReadOnly() {
  return predictionServiceIdentity().state === "shadow";
}

function predictionSplit() {
  return document.body?.dataset?.predictionSplit === "true";
}

function predictionLpDisplayBusy() {
  return !predictionSplit() && state.predictionMarket.lpDashboardRequestInFlight;
}

function predictionLpAutoState() {
  return predictionSplit() ? state.predictionMarket.lpAutoPayload : state.predictionMarket.lpDashboard?.auto;
}

function predictionServiceIdentity() {
  const payload = predictionSplit() ? state.predictionMarket.executionPayload : state.predictionMarket.venuesPayload;
  if (String(payload?.mode || "") === "shadow" && String(payload?.mutations || "") === "prohibited") {
    return {state: "shadow", label: "Shadow 只读"};
  }
  if (String(payload?.mode || "") === "production" && String(payload?.mutations || "") === "enabled") {
    return {state: "production", label: "Production"};
  }
  // Cloud/Prediction-only views must fail closed. A normal legacy route with
  // no service identity fields retains its existing compatibility behavior.
  if (predictionSplit() || predictionOnly() || payload?.mode !== undefined || payload?.mutations !== undefined) {
    return {state: "unknown", label: "服务身份 UNKNOWN"};
  }
  return {state: "legacy", label: ""};
}

function predictionWritesBlocked() {
  return ["shadow", "unknown"].includes(predictionServiceIdentity().state);
}

function predictionNLegReadAllowed() {
  return state.workspaceView === "prediction_market"
    && state.predictionMarket.activeTab === "multi_leg"
    && state.predictionMarket.nLegStatus === "running";
}

function predictionNLegPath(path) {
  const value = String(path || "").split("?", 1)[0];
  return value.includes("/prediction-arbitrage/state")
    || value.includes("/prediction-arbitrage/history")
    || value.includes("/prediction-arbitrage/n-leg/")
    || value.includes("/prediction-arbitrage/relations")
    || value.endsWith("/prediction-arbitrage/llm-provider")
    || value.endsWith("/prediction-arbitrage/mode")
    || value.endsWith("/prediction-arbitrage/preview")
    || value.endsWith("/prediction-arbitrage/executions")
    || value.endsWith("/prediction-arbitrage/circuit-breaker/reset")
    || value.endsWith("/prediction-arbitrage/predict-allowance/cleanup")
    || value.endsWith("/prediction-arbitrage/cross-auto/pause");
}

function predictionNLegReadCurrent(generation, controller) {
  const signal = controller?.signal;
  return state.predictionMarket.nLegReadGeneration === generation
    && predictionNLegReadAllowed()
    && signal?.aborted !== true;
}

// Issue 162（定案 1）：LP 三类弹窗豁免后台轮询关闭——5 秒场所摘要轮询在
// N_LEG 暂停或失败时不得清掉操作者正在填写的下单/加量/撤单表单。
const LP_MODAL_KINDS = new Set(["lp_order", "lp_augment", "lp_cancel"]);

// 定案 1：N_LEG 域失效路径只关闭非 LP、非 order 的弹窗
// （nleg_order/nleg_incident/reset/allowance_cleanup，与既有逐 kind 行为一致；
// order 维持现状豁免）。order 弹窗由 setWorkspaceView 的全量关闭负责。
function closeNLegDomainPredictionModal() {
  const kind = predictionModal?.kind || "";
  if (kind && !LP_MODAL_KINDS.has(kind) && kind !== "order") closePredictionModal();
}

function invalidatePredictionNLegReads() {
  const prediction = state.predictionMarket;
  prediction.nLegReadGeneration += 1;
  for (const key of [
    "stateRequestController",
    "historyRequestController",
    "nlegReportRequestController",
    "relationReviewRequestController",
    "relationDetailRequestController",
  ]) {
    const controller = prediction[key];
    controller?.abort?.();
    prediction[key] = null;
  }
  prediction.stateRequestInFlight = false;
  prediction.signalRequestInFlight = false;
  prediction.signalPollEpoch += 1;
  prediction.relationReview.loading = false;
  if (prediction.nlegReport) {
    prediction.nlegReport.open = false;
    prediction.nlegReport.data = null;
    prediction.nlegReport.error = null;
  }
  prediction.relationReview.open = false;
  prediction.relationReview.detail = null;
  // Issue 162（定案 1）：本函数不再关闭任何弹窗；关闭策略由调用方决定
  // （轮询路径走 closeNLegDomainPredictionModal，离开视图走全量关闭）。
}

async function fetchPredictionLpDashboard({force = false} = {}) {
  if (predictionSplit()) fetchPredictionLpAutoState();
  if (state.workspaceView !== "prediction_market" || state.predictionMarket.activeTab !== "lp"
    || (!force && (state.predictionMarket.lpDashboardRequestInFlight || state.predictionMarket.lpAutoBusy))) return;
  const requestSeq = (state.predictionMarket.lpDashboardRequestSeq || 0) + 1;
  state.predictionMarket.lpDashboardRequestSeq = requestSeq;
  state.predictionMarket.lpDashboardRequestInFlight = true;
  state.predictionMarket.lpDashboardPendingSeq = requestSeq;
  try {
    const response = await fetch(predictionRequestUrl("/api/prediction-arbitrage/lp/dashboard"), {
      cache: "no-store",
      credentials: "same-origin",
    });
    if (!response.ok) throw new Error("LP dashboard " + response.status);
    const dashboard = await response.json();
    if (requestSeq !== state.predictionMarket.lpDashboardRequestSeq) return;
    state.predictionMarket.lpDashboard = {...dashboard};
    state.predictionMarket.lpDashboardError = "";
  } catch (error) {
    if (requestSeq !== state.predictionMarket.lpDashboardRequestSeq) return;
    const previous = state.predictionMarket.lpDashboard && typeof state.predictionMarket.lpDashboard === "object"
      ? state.predictionMarket.lpDashboard
      : {};
    state.predictionMarket.lpDashboardError = error instanceof Error ? error.message : String(error);
    state.predictionMarket.lpDashboard = {
      ...previous,
      stale: true,
      last_success_at: previous.last_success_at || previous.checked_at || null,
      error: state.predictionMarket.lpDashboardError,
    };
  } finally {
    if (state.predictionMarket.lpDashboardPendingSeq !== requestSeq) return;
    state.predictionMarket.lpDashboardRequestInFlight = false;
    if (state.workspaceView === "prediction_market" && state.predictionMarket.activeTab === "lp") {
      renderPredictionMarket();
    }
  }
}

function updatePredictionNLegStatus(payload) {
  const nLegStatus = predictionNLegStatus(payload);
  state.predictionMarket.nLegStatus = nLegStatus;
  if (nLegStatus !== "running") {
    invalidatePredictionNLegReads();
    closeNLegDomainPredictionModal();
  } else if (state.predictionMarket.activeTab === "multi_leg") fetchPredictionState();
}

async function fetchPredictionExecutionIdentity() {
  const prediction = state.predictionMarket;
  if (prediction.executionRequestInFlight) return;
  prediction.executionRequestInFlight = true;
  try {
    const response = await fetch(predictionRequestUrl("/api/prediction-arbitrage/execution/identity"), {cache: "no-store", credentials: "same-origin"});
    if (!response.ok) throw new Error("Air execution " + response.status);
    prediction.executionPayload = await response.json();
    prediction.csrfToken = prediction.executionPayload.csrf_token || "";
    updatePredictionNLegStatus(prediction.executionPayload);
  } catch (error) {
    prediction.executionPayload = {mode: "unknown", mutations: "unknown"};
    prediction.csrfToken = "";
    updatePredictionNLegStatus({});
  } finally {
    prediction.executionRequestInFlight = false;
    if (state.workspaceView === "prediction_market") renderPredictionMarket();
  }
}

async function fetchPredictionLpAutoState() {
  const prediction = state.predictionMarket;
  if (state.workspaceView !== "prediction_market" || prediction.lpAutoRequestInFlight || prediction.lpAutoBusy) return;
  const requestSeq = (prediction.lpAutoRequestSeq || 0) + 1;
  prediction.lpAutoRequestSeq = requestSeq;
  prediction.lpAutoRequestInFlight = true;
  try {
    const response = await fetch(predictionRequestUrl("/api/prediction-arbitrage/lp/auto/state"), {cache: "no-store", credentials: "same-origin"});
    if (!response.ok) throw new Error("Air auto state " + response.status);
    const payload = await response.json();
    if (requestSeq !== prediction.lpAutoRequestSeq) return;
    prediction.lpAutoPayload = payload;
    prediction.lpAutoError = "";
  } catch (error) {
    if (requestSeq !== prediction.lpAutoRequestSeq) return;
    prediction.lpAutoPayload = null;
    prediction.lpAutoError = error instanceof Error ? error.message : String(error);
  } finally {
    prediction.lpAutoRequestInFlight = false;
    if (state.workspaceView === "prediction_market" && prediction.activeTab === "lp") renderPredictionMarket();
  }
}

async function fetchPredictionVenues() {
  if (predictionSplit()) fetchPredictionExecutionIdentity();
  if (state.workspaceView !== "prediction_market" || state.predictionMarket.venuesRequestInFlight) return;
  const previousPayload = state.predictionMarket.venuesPayload;
  state.predictionMarket.venuesRequestInFlight = true;
  try {
    const response = await fetch(predictionRequestUrl("/api/prediction-arbitrage/venues"), {
      cache: "no-store",
      credentials: "same-origin",
    });
    if (!response.ok) throw new Error("Venue summary " + response.status);
    const payload = await response.json();
    state.predictionMarket.venuesPayload = {...payload};
    state.predictionMarket.venuesError = "";
    if (!predictionSplit()) state.predictionMarket.csrfToken = payload.csrf_token || state.predictionMarket.csrfToken;
    if (!predictionSplit()) updatePredictionNLegStatus(payload);
  } catch (error) {
    if (!predictionSplit() && (predictionOnly() || previousPayload?.mode !== undefined || previousPayload?.mutations !== undefined)) {
      state.predictionMarket.venuesPayload = {mode: "unknown", mutations: "unknown"};
    }
    state.predictionMarket.venuesError = error instanceof Error ? error.message : String(error);
    if (!predictionSplit()) updatePredictionNLegStatus({});
  } finally {
    state.predictionMarket.venuesRequestInFlight = false;
    if (state.workspaceView === "prediction_market") renderPredictionMarket();
  }
}

async function fetchPredictionState() {
  const prediction = state.predictionMarket;
  if (!predictionNLegReadAllowed() || prediction.stateRequestInFlight) return;
  prediction.stateRequestInFlight = true;
  const generation = prediction.nLegReadGeneration;
  const controller = new AbortController();
  prediction.stateRequestController = controller;
  const signalHistoryGeneration = state.predictionMarket.signalHistoryGeneration;
  try {
    const response = await fetch(predictionRequestUrl("/api/prediction-arbitrage/state"), {cache: "no-store", credentials: "same-origin", signal: controller.signal});
    if (!predictionNLegReadCurrent(generation, controller)) return;
    if (!response.ok) throw new Error(`prediction state ${response.status}`);
    const payload = await response.json();
    if (!predictionNLegReadCurrent(generation, controller)) return;
    const previousHistories = state.predictionMarket.payload?.histories || {};
    const histories = {...previousHistories, ...(payload.histories || {})};
    if (state.predictionMarket.signalHistoryGeneration !== signalHistoryGeneration && Array.isArray(previousHistories.signals)) {
      histories.signals = previousHistories.signals;
    }
    state.predictionMarket.payload = {
      ...payload,
      histories,
    };
    state.predictionMarket.relationReview.pendingCount = Number(payload?.relation_review?.pending_count || 0);
    state.predictionMarket.error = "";
    if (!predictionSplit()) state.predictionMarket.csrfToken = payload.csrf_token || state.predictionMarket.csrfToken;
    if (!["signals", "executions", "incidents"].includes(state.predictionMarket.historyKind)) {
      state.predictionMarket.historyKind = "signals";
    }
  } catch (error) {
    if (!predictionNLegReadCurrent(generation, controller)) return;
    state.predictionMarket.error = error instanceof Error ? error.message : String(error);
    if (state.predictionMarket.payload) {
      const payload = state.predictionMarket.payload;
      const observation = payload.n_leg_observation && typeof payload.n_leg_observation === "object"
        ? payload.n_leg_observation
        : {};
      const markStale = (row) => {
        if (!row || typeof row !== "object") return row;
        const result = row.result && typeof row.result === "object" ? row.result : null;
        if (!result) return row;
        return {
          ...row,
          result: {
            ...result,
            status: result.status === "PASS" ? "BLOCKED" : result.status,
            current: false,
            reason: "STATE_FETCH_FAILED",
          },
        };
      };
      const staleLatest = Array.isArray(observation.latest)
        ? observation.latest.map(markStale)
        : observation.latest;
      const staleResults = Array.isArray(observation.results)
        ? observation.results.map(markStale)
        : observation.results;
      const oldCoverage = payload.n_leg_coverage && typeof payload.n_leg_coverage === "object"
        ? payload.n_leg_coverage
        : {};
      const staleResultCount = Array.isArray(staleResults)
        ? staleResults.filter((row) => row && typeof row.result === "object").length
        : 0;
      state.predictionMarket.payload = {
        ...payload,
        stale: true,
        n_leg_coverage: {
          ...oldCoverage,
          status: "ERROR",
          status_reason: "STATE_FETCH_FAILED",
          fresh: 0,
          fresh_count: 0,
          positive: 0,
          positive_count: 0,
          non_positive: 0,
          non_positive_count: 0,
          blocked_count: staleResultCount,
        },
        n_leg_observation: {
          ...observation,
          status: "ERROR",
          status_reason: "STATE_FETCH_FAILED",
          latest: staleLatest,
          results: staleResults,
        },
      };
    } else {
      state.predictionMarket.payload = {status: "unavailable", stale: true, readiness: {status: "unavailable"}, events: [], opportunities: [], breaker: {open: true}};
    }
  } finally {
    if (prediction.stateRequestController === controller) prediction.stateRequestController = null;
    if (prediction.nLegReadGeneration === generation) prediction.stateRequestInFlight = false;
  }
  if (predictionNLegReadCurrent(generation, controller)) {
    renderPredictionMarket();
  }
}

async function loadPredictionHistory(kind, options = {}) {
  const panelOnly = options.panelOnly === true;
  if (!predictionNLegReadAllowed()) return;
  if (panelOnly && state.predictionMarket.signalRequestInFlight) return;
  const requestEpoch = panelOnly ? state.predictionMarket.signalPollEpoch : null;
  const prediction = state.predictionMarket;
  const generation = prediction.nLegReadGeneration;
  prediction.historyRequestController?.abort?.();
  const controller = new AbortController();
  prediction.historyRequestController = controller;
  if (panelOnly) prediction.signalRequestInFlight = true;
  try {
    const response = await fetch(predictionRequestUrl(`/api/prediction-arbitrage/history?kind=${encodeURIComponent(kind)}&limit=100`), {cache: "no-store", credentials: "same-origin", signal: controller.signal});
    if (!predictionNLegReadCurrent(generation, controller)) return;
    if (!response.ok) throw new Error(`prediction history ${response.status}`);
    const result = await response.json();
    if (!predictionNLegReadCurrent(generation, controller)) return;
    const payload = state.predictionMarket.payload || {};
    state.predictionMarket.payload = {...payload, histories: {...(payload.histories || {}), [kind]: Array.isArray(result.items) ? result.items : []}};
    if (!panelOnly) state.predictionMarket.error = "";
    if (kind === "signals") {
      state.predictionMarket.signalHistoryGeneration += 1;
      state.predictionMarket.signalLastSuccessAt = new Date().toISOString();
      state.predictionMarket.signalError = "";
    }
  } catch (error) {
    if (!predictionNLegReadCurrent(generation, controller)) return;
    const message = error instanceof Error ? error.message : String(error);
    if (kind === "signals" && panelOnly) {
      state.predictionMarket.signalError = message;
    } else {
      state.predictionMarket.error = message;
    }
  } finally {
    if (prediction.historyRequestController === controller) prediction.historyRequestController = null;
    if (panelOnly && prediction.nLegReadGeneration === generation) prediction.signalRequestInFlight = false;
  }
  if (!predictionNLegReadCurrent(generation, controller)) return;
  if (panelOnly && requestEpoch === state.predictionMarket.signalPollEpoch) {
    renderPredictionSignalPanel();
  } else if (kind === state.predictionMarket.historyKind) {
    const panel = elements["prediction-market-root"]?.querySelector("[data-prediction-history-panel]");
    if (panel) {
      panel.outerHTML = predictionHistoryPanel(state.predictionMarket.payload || {});
    } else {
      renderPredictionMarket();
    }
  }
}

function renderPredictionSignalPanel() {
  if (state.workspaceView !== "prediction_market" || state.predictionMarket.strategy !== "yes_no") return;
  if (state.predictionMarket.historyKind !== "signals") return;
  const panel = elements["prediction-market-root"]?.querySelector("[data-prediction-history-panel]");
  if (!panel) return;
  panel.outerHTML = predictionHistoryPanel(state.predictionMarket.payload || {});
}

async function predictionPost(path, body) {
  if (predictionServiceIdentity().state === "unknown") throw new Error("prediction service identity UNKNOWN，写操作不可用");
  if (predictionServiceReadOnly()) throw new Error("Shadow 只读，写操作不可用");
  if (predictionNLegPath(path) && !predictionNLegReadAllowed()) throw new Error("N_LEG_PAUSED");
  const response = await fetch(predictionRequestUrl(path), {method: "POST", credentials: "same-origin", headers: {"Content-Type": "application/json", "X-CSRF-Token": state.predictionMarket.csrfToken}, body: JSON.stringify(body)});
  if (!response.ok) {
    let message = `prediction mutation ${response.status}`;
    try { message = (await response.json()).message || message; } catch (_) { /* keep status */ }
    throw new Error(message);
  }
  return response.json();
}

function predictionIdempotencyKey() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `prediction-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function predictionMaskedWallet(value) {
  const wallet = String(value || "").trim();
  if (!wallet || wallet.includes("…")) return wallet;
  return wallet.length >= 10 ? `${wallet.slice(0, 6)}…${wallet.slice(-4)}` : wallet;
}

function predictionPreviewDisplay(value) {
  const source = value && typeof value === "object" ? value : {};
  const result = {
    ...predictionOpportunityDisplay(source),
    preview_id: source.preview_id ?? source.id,
    title: source.title ?? source.question ?? source.market_title ?? source.event_title,
    market_type: source.market_type,
    fee_status: source.fee_status,
    merge_value: source.merge_value,
    available_balance: source.available_balance,
    wallet: source.masked_wallet ?? source.wallet_address,
    policy_limits: source.policy_limits,
  };
  if (String(result.market_type || "") === "threshold_hedge") {
    result.question_a = source.question_a;
    result.question_b = source.question_b;
    result.relation = source.relation;
    result.condition_id_a = source.condition_id_a;
    result.condition_id_b = source.condition_id_b;
    result.buy_legs = Array.isArray(source.buy_legs) ? source.buy_legs : [];
    result.maximum_fee = source.maximum_fee;
    result.minimum_payout = source.minimum_payout;
    result.rules_hash_a = source.rules_hash_a;
    result.rules_hash_b = source.rules_hash_b;
    result.cache_key = source.cache_key;
  }
  if (predictionIsCrossVenue(result)) {
    result.buy_legs = Array.isArray(source.buy_legs) ? source.buy_legs : [];
    result.net_quantity = source.net_quantity;
    result.minimum_payout = source.minimum_payout;
    result.annualized_yield = source.annualized_yield;
    result.canonical_cutoff = source.canonical_cutoff;
    result.codex_approval = source.codex_approval;
    result.balances = source.balances && typeof source.balances === "object" && !Array.isArray(source.balances) ? source.balances : {};
    result.unsettled = source.unsettled;
  }
  return result;
}

function predictionPreviewIsComplete(value) {
  const preview = predictionPreviewDisplay(value);
  if (predictionIsCrossVenue(preview)) {
    const legs = Array.isArray(preview.buy_legs) ? preview.buy_legs : [];
    const balances = preview.balances && typeof preview.balances === "object" && !Array.isArray(preview.balances) ? preview.balances : {};
    const evidence = Array.isArray(preview.codex_approval?.evidence) ? preview.codex_approval.evidence : [];
    const exchanges = new Set(legs.map((leg) => String(leg?.exchange || "").toLowerCase()));
    const tokenIds = new Set(legs.map((leg) => leg?.token_id));
    const policy = preview.policy_limits || {};
    const finitePositive = (item, maximum) => {
      const number = Number(item);
      return predictionHasValue(item)
        && Number.isFinite(number)
        && number > 0
        && (maximum === undefined || number <= maximum);
    };
    const finiteNonNegative = (item) => {
      const number = Number(item);
      return predictionHasValue(item) && Number.isFinite(number) && number >= 0;
    };
    const identity = (item) => typeof item === "string" && item.trim().length > 0;
    const cutoffTimestamp = predictionCanonicalUtcCutoff(preview.canonical_cutoff);
    const expectedMapping = {
      predict_yes: "YES",
      predict_no: "NO",
      polymarket_yes: "YES",
      polymarket_no: "NO",
    };
    const mapping = preview.codex_approval?.direct_outcome_mapping;
    const mappingValid = mapping
      && typeof mapping === "object"
      && !Array.isArray(mapping)
      && Object.keys(mapping).length === Object.keys(expectedMapping).length
      && Object.entries(expectedMapping).every(([key, expected]) => mapping[key] === expected);
    const expectedOutcomes = {
      PREDICT_YES_POLYMARKET_NO: {"predict.fun": "YES", polymarket: "NO"},
      POLYMARKET_YES_PREDICT_NO: {"predict.fun": "NO", polymarket: "YES"},
    }[String(preview.direction || "").trim().toUpperCase()];
    const identitiesValid = legs.length === 2
      && exchanges.size === 2
      && exchanges.has("predict.fun")
      && exchanges.has("polymarket")
      && tokenIds.size === 2
      && expectedOutcomes
      && legs.every((leg) => (
        expectedOutcomes[leg?.exchange]
        && leg?.outcome === expectedOutcomes[leg?.exchange]
        && [leg?.exchange, leg?.market_id, leg?.condition_id, leg?.token_id, leg?.settlement_asset, leg?.fee_asset]
          .every(identity)
      ));
    const economicsValid = legs.every((leg) => (
      finitePositive(leg?.net_quantity)
      && finitePositive(leg?.max_price, 1)
      && finitePositive(leg?.max_cost)
      && finiteNonNegative(leg?.maximum_fee)
    ));
    const numericFieldsValid = [
      preview.net_quantity, preview.max_cost, preview.minimum_payout, preview.profit, preview.annualized_yield,
      policy.max_normal_cost, policy.max_emergency_loss,
    ].every((item) => finitePositive(item));
    const unsettledValid = [preview.unsettled?.current, preview.unsettled?.after, preview.unsettled?.limit]
      .every(finiteNonNegative);
    return [preview.preview_id, preview.title, preview.market_type, preview.canonical_cutoff, preview.codex_approval?.summary]
      .every(predictionHasValue)
      && preview.codex_approval?.decision === "APPROVE"
      && cutoffTimestamp !== null
      && cutoffTimestamp > Date.now()
      && mappingValid
      && identitiesValid
      && economicsValid
      && numericFieldsValid
      && unsettledValid
      && ["predict.fun", "polymarket"].every((exchange) => {
        const balance = balances[exchange];
        return balance
          && [balance.wallet_address, balance.asset, balance.available_balance].every(predictionHasValue)
          && Number.isFinite(Number(balance.available_balance));
      })
      && evidence.length >= 2
      && evidence.every((item) => [item?.exchange, item?.field, item?.quote].every(predictionHasValue));
  }
  if (String(preview.market_type || "") === "threshold_hedge") {
    const legs = Array.isArray(preview.buy_legs) ? preview.buy_legs : [];
    return [preview.preview_id, preview.question_a, preview.question_b, preview.relation, preview.condition_id_a, preview.condition_id_b, preview.wallet]
      .every(predictionHasValue)
      && predictionHasValue(preview.quantity)
      && predictionHasValue(preview.max_cost)
      && predictionHasValue(preview.profit)
      && predictionHasValue(preview.available_balance)
      && predictionPolicyIsComplete(preview.policy_limits)
      && legs.length === 2
      && legs.every((leg) => [leg?.label, leg?.outcome, leg?.condition_id, leg?.quantity, leg?.max_price, leg?.max_cost].every(predictionHasValue));
  }
  const policy = preview.policy_limits;
  const textFields = [
    preview.preview_id,
    preview.title,
    preview.market_type,
    preview.fee_status,
    preview.wallet,
  ];
  const numericFields = [
    preview.quantity,
    preview.yes_price,
    preview.no_price,
    preview.yes_cost,
    preview.no_cost,
    preview.max_cost,
    preview.merge_value,
    preview.profit,
    preview.available_balance,
  ];
  return textFields.every(predictionHasValue)
    && numericFields.every((item) => predictionHasValue(item) && Number.isFinite(Number(item)))
    && predictionPolicyIsComplete(policy);
}

// ===== Issue 158: LP 手动下单（lp_order）与委托加量（lp_augment）模态 =====

// Issue 163：动作→所需 kind 映射。click 处理器在发请求前校验
// 当前弹窗 kind 匹配，不匹配（含未知动作）直接 return，不发任何请求。
// 单次确认提交后不再有预检/重预检动作。
const PREDICTION_MODAL_ACTION_KINDS = {
  "lp-order-confirm": "lp_order",
  "lp-augment-confirm": "lp_augment",
  "lp-cancel-confirm": "lp_cancel",
  "nleg-confirm": "nleg_order",
  "nleg-incident-unlock": "nleg_incident",
  "confirm": "order",
  "cleanup": "allowance_cleanup",
  "arm-cleanup": "allowance_cleanup",
  "reset": "reset",
};

function lpShortSessionId(value) {
  const text = String(value || "").trim();
  return text ? text.slice(0, 6) : "-";
}

// 定案 10: response-state branch texts (all LP submit responses are HTTP 200).
// Issue 163: single-shot world — there is no preview to re-run, so every
// text names what happened and points at a fresh confirmation (新意图新键).
function lpSubmitStateMessage(result) {
  const resultState = String(result?.state || "").toLowerCase();
  const reason = String(result?.reason || "");
  if (resultState === "locked") {
    if (reason === "circuit_breaker_open") return "交易熔断开启中，禁止新下单；界面保持只读。";
    if (reason === "mutation_blocked") return "系统当前处于只读保护，禁止提交变更；请稍后重试。";
    return `当前状态不允许提交（${reason || "locked"}）。`;
  }
  if (resultState === "busy") {
    if (reason === "lp_session_market_active") return "该标的已有活动组，本单未提交；换一个标的即可开仓。";
    if (reason === "active_execution") return "已有另一笔交易正在执行，本单未提交。";
    if (reason === "execution_lock") return "已有另一笔操作正在确认，请稍后重新确认。";
    return `系统忙，暂不能提交（${reason || "busy"}）。`;
  }
  if (resultState === "rejected") {
    if (reason === "history_amplitude_exceeded") {
      return "未提交：该方向历史波动不符合要求";
    }
    if (reason === "history_latest_refresh_failed") {
      return "未提交：该方向历史数据刷新失败";
    }
    if (reason === "history_summary_expired") {
      return "未提交：该方向历史数据已失效";
    }
    if (reason.startsWith("history_")) {
      return "未提交：该方向历史数据不可用";
    }
    if (reason === "best_bid_changed") return "确认价与提交时买一不一致。";
    if (reason === "session_not_active" || reason === "session_not_found") {
      return "该标的当前无活动系统会话——请先从候选列表经系统入口下第一单。";
    }
    if (reason === "session_review_exit") return "目标会话正在退出收尾，不能再加量。";
    if (reason === "session_stop_loss_exit") return "目标会话已触发止损退出，不能再加量。";
    if (reason === "session_needs_attention") return "目标会话待人工核对，不能再加量。";
    if (reason === "quantity_invalid") return "数量不是有效正数。";
    if (reason === "price_invalid") return "价格不是有效正数。";
    if (reason === "price_level_active") return "该价位已有挂单，请先撤该价位再追加。";
    if (reason === "price_above_best_bid") return "价格不能高于当前买一。";
    return reason ? `未下单：${reason}` : "未下单。";
  }
  if (resultState === "entry_rejected") {
    return "交易所拒绝了订单，未产生委托。";
  }
  if (resultState === "needs_attention") {
    return "提交回执未确认。";
  }
  return "";
}

// ===== Issue 163：单次确认提交的结果 toast 栈与 10 秒共享锁 =====
// toast 一律挂在 LP 卡片内（≤3 条、新的在前），按幂等键归属：无论回执多迟，
// 只更新自己那条，绝不触碰其它意图的 toast 或任何当前弹窗。四色语义：
// submitting=黄 / success=绿 / danger=红 / unknown=蓝（对齐 mock）。

function lpSubmitToastPush(entry) {
  const toasts = Array.isArray(state.predictionMarket.lpSubmitToasts)
    ? state.predictionMarket.lpSubmitToasts.slice() : [];
  if (entry.kind !== "submitting") entry.doneAt = Date.now() + 30000;
  toasts.unshift(entry);
  state.predictionMarket.lpSubmitToasts = toasts.slice(0, 3);
}

function lpSubmitToastUpdate(key, patch) {
  const toast = (state.predictionMarket.lpSubmitToasts || [])
    .find((item) => item.id === key);
  if (!toast) return; // 迟到回执只更新自己那条；找不到就静默丢弃。
  Object.assign(toast, patch);
  if (patch.kind && patch.kind !== "submitting") toast.doneAt = Date.now() + 30000;
}

// Map one submit response onto the intent's own toast.  Returns true when
// the response is a registered session the operator should hear about.
function lpSubmitToastResult(key, result, role) {
  const resultState = String(result?.state || "").toLowerCase();
  const hasSession = Boolean(String(result?.session_id || "").trim());
  const sessionShort = lpShortSessionId(result?.session_id);
  if (resultState === "entry_open" && hasSession) {
    const orderId = String(
      (role === "augment" ? result?.augment_order_id : result?.entry_order_id) || "",
    );
    if (role === "augment") {
      lpSubmitToastUpdate(key, {
        kind: "success",
        main: `已追加 · 订单 ${orderId || "UNKNOWN"} 并入会话 ${sessionShort}`,
        sub: "新增价位独立位置保护 · 复核截止沿用首单 · 看板稍后刷新",
      });
    } else {
      lpSubmitToastUpdate(key, {
        kind: "success",
        main: `已提交 · 订单 ${orderId || "UNKNOWN"} 已登记`,
        sub: `会话 ${sessionShort} · #152 位置保护已带基线 · 看板稍后刷新`,
      });
    }
    return true;
  }
  if (hasSession && !["busy", "locked", "rejected", "entry_rejected", "needs_attention"].includes(resultState)) {
    // 幂等重放命中的既有会话已不在 entry_open（如复核中）——如实报「已登记」。
    lpSubmitToastUpdate(key, {
      kind: "success",
      main: `已登记 · 返既有会话 ${sessionShort}（${predictionValue(resultState, "状态未知")}）`,
      sub: "以看板与会话状态为准",
    });
    return true;
  }
  lpSubmitToastUpdate(key, lpSubmitToastCopy(result));
  return false;
}

function lpSubmitToastCopy(result) {
  const resultState = String(result?.state || "").toLowerCase();
  if (resultState === "entry_rejected") {
    return {
      kind: "danger",
      main: "未登记：交易所拒绝了订单，未产生委托",
      sub: "请重新发起下单（新确认 = 新意图）",
    };
  }
  if (resultState === "needs_attention") {
    return {
      kind: "unknown",
      main: "结果未知：提交回执未确认",
      sub: "系统不会自动重试 · 请以看板与会话状态为准",
    };
  }
  if (resultState === "busy") {
    // Issue 166: 同标的已有活动组的拒绝文案点名换标的；Issue 178: 其余 busy
    // 理由复用 lpSubmitStateMessage 的准确句子，不再笼统误报「已有活动 LP 会话」。
    if (String(result?.reason || "") === "lp_session_market_active") {
      return {
        kind: "danger",
        main: "业务忙：该标的已有活动组，本单未提交",
        sub: "换一个标的即可开仓 · 本单未发出",
      };
    }
    const reason = String(result?.reason || "");
    const stateMessage = lpSubmitStateMessage(result);
    return {
      kind: "danger",
      main: stateMessage || `业务忙（${reason || "busy"}）`,
      sub: "稍后再次确认即可 · 本单未发出",
    };
  }
  if (resultState === "locked") {
    return {
      kind: "danger",
      main: "系统锁定（熔断/维护中），本单未提交",
      sub: "解除后需重新确认；系统不会自动重试",
    };
  }
  if (resultState === "rejected") {
    const reason = String(result?.reason || "");
    if (reason === "best_bid_changed") {
      return {
        kind: "danger",
        main: "未提交：确认价与提交时买一不一致",
        sub: "不改价、不改量、不追价 · 请核对最新买一后重新确认",
      };
    }
    // 评审修复 P3：lpSubmitStateMessage 对未特判原因已产出「未下单：<reason>」
    // 完整句，直接采用；只有它给不出句子时才用「未提交：<reason>」兜底——
    // 任何情况下主行只出现一个前缀，绝不拼出「未提交：未下单：…」。
    const stateMessage = lpSubmitStateMessage(result);
    return {
      kind: "danger",
      main: stateMessage || `未提交：${reason || "条件不满足"}`,
      sub: "请核对后重新发起下单（新确认 = 新意图）",
    };
  }
  return {
    kind: "unknown",
    main: "结果未知：响应状态未识别",
    sub: "系统不会自动重试 · 请以看板与会话状态为准",
  };
}

function lpSubmitCooldownActive() {
  const cooldown = state.predictionMarket.lpSubmitCooldown;
  return Boolean(cooldown && Number(cooldown.until) > Date.now());
}

// 定案 7：锁固定 10 秒；提前回执只更新 toast、不提前解锁；到点若该意图仍
// submitting 则改报「结果未知」（不出现 失败/成功/已撤销 字样），随后解锁。
function lpSubmitStartCooldown(toastKey) {
  const previous = state.predictionMarket.lpSubmitCooldown;
  if (previous && previous.timer) window.clearTimeout(previous.timer);
  const timer = window.setTimeout(() => {
    state.predictionMarket.lpSubmitCooldown = null;
    const toast = (state.predictionMarket.lpSubmitToasts || [])
      .find((item) => item.id === toastKey);
    if (toast && toast.kind === "submitting") {
      lpSubmitToastUpdate(toastKey, {
        kind: "unknown",
        main: "结果未知：提交 10 秒未收到回执",
        sub: "订单可能已挂出 · 系统不会自动重试 · 请以看板与会话状态为准",
      });
    }
    renderPredictionMarket();
  }, 10000);
  state.predictionMarket.lpSubmitCooldown = {
    until: Date.now() + 10000, timer, toastKey,
  };
}

// 渲染时顺带清理：完成/失败 toast 满 30 秒后淡出（复用轮询渲染周期）。
function lpSubmitToastsMarkup() {
  const toasts = state.predictionMarket.lpSubmitToasts;
  if (!Array.isArray(toasts) || !toasts.length) return "";
  const now = Date.now();
  const live = toasts.filter((item) =>
    item.kind === "submitting" || Number(item.doneAt || 0) > now);
  state.predictionMarket.lpSubmitToasts = live;
  if (!live.length) return "";
  return `<div class="lp-submit-toasts" aria-live="polite">` + live.map((item) =>
    `<div class="lp-toast ${item.kind}" role="status" data-lp-toast-key="${escapeHtml(String(item.id || ""))}">`
    + `<div><strong>${escapeHtml(String(item.main || ""))}`
    + (item.kind === "submitting" ? `<span class="lp-toast-dots"></span>` : "")
    + `</strong><p>${escapeHtml(String(item.sub || ""))}</p></div>`
    + `</div>`
  ).join("") + `</div>`;
}

function lpOrderCaseLine(mode, currentMode, label, disabled) {
  const checked = currentMode === mode;
  return `<label class="radio-line${disabled ? " is-disabled" : ""}">`
    + `<input type="radio" name="lp-order-case" value="${mode}"${checked ? " checked" : ""}${disabled ? " disabled" : ""}`
    + ` data-modal-action="lp-order-case" data-case-mode="${mode}"> ${label}</label>`;
}

// Issue 162（定案 5/7）：预计占用是弹窗内唯一计算值——$ + (price*qty).toFixed(2)；
// 数量/价格一律原样字符串，空缺或非数值显示 "-"。
function lpOrderCostText(price, quantity) {
  const priceText = String(price ?? "").trim();
  const qtyText = String(quantity ?? "").trim();
  if (!priceText || !qtyText) return "-";
  const cost = Number(priceText) * Number(qtyText);
  return Number.isFinite(cost) ? `$${cost.toFixed(2)}` : "-";
}

function lpOrderModalHtml(data = {}) {
  // Issue 163 定案：单相弹窗——填写与查看零服务端调用；「确认提交」一次
  // 最终确认即关窗、弹 toast、锁入口 10 秒，服务端恰读一次新鲜事实做一次
  // 完整校验后挂单，结果以 toast 返回。
  const row = data.row && typeof data.row === "object" ? data.row : {};
  const mode = ["trial", "five", "custom"].includes(data.mode) ? data.mode : "trial";
  const title = escapeHtml(lpMarketTitle(row));
  const sub = `Polymarket · ${escapeHtml(predictionValue(row.condition_id, "UNKNOWN"))} · 买 ${escapeHtml(predictionValue(data.outcome, "UNKNOWN"))}`;
  const header = `<header class="pm-modal-header"><h2 id="pm-dialog-title">确认 LP 试挂（BUY · post-only）</h2><p>一次确认即提交：填写与查看不发起预检；服务端按提交时最新事实校验后挂单，结果以提示返回。</p></header>`
    + `<div class="pm-order-market"><span>${sub}</span><strong>${title}</strong></div>`;
  const fiveLabel = data.fiveQuantity
    ? `5% 单 · ${escapeHtml(String(data.trialPrice ?? ""))} × ${escapeHtml(data.fiveQuantity)} 份`
    : "5% 单 · 目标量 UNKNOWN（本行估算未出）";
  const cases = lpOrderCaseLine("trial", mode, `试挂单 · ${escapeHtml(String(data.trialPrice ?? ""))} × ${escapeHtml(data.trialQuantity)} 份`, false)
    + lpOrderCaseLine("five", mode, fiveLabel, !data.fiveQuantity)
    + lpOrderCaseLine("custom", mode, "自定义份额下单（可改价改量，继承当前值）", false);
  const locked = mode !== "custom";
  const hint = mode === "trial" ? "计划口径，锁定" : mode === "five" ? "5% 目标量，锁定" : "自定义：可改";
  const body = `<p class="sub">下单情形（单选 · 默认试挂单）</p><div style="margin-bottom:10px">${cases}</div>`
    + `<div class="pm-check-list">`
    + `<div class="pm-check"><span>挂单价 USDC</span><input class="lp-order-input" id="lp-order-price" type="number" step="0.01" min="0.01" max="0.99" value="${escapeHtml(String(data.price ?? ""))}"${locked ? " readonly" : ""}></div>`
    + `<div class="pm-check"><span>数量（份）</span><span><input class="lp-order-input" id="lp-order-quantity" type="number" step="1" min="1" value="${escapeHtml(String(data.quantity ?? ""))}"${locked ? " readonly" : ""}> <span class="sub">${hint}</span></span></div>`
    + `<div class="pm-check"><span>预计占用</span><strong id="lp-order-cost">${lpOrderCostText(data.price, data.quantity)}</strong></div>`
    + `</div>`
    + `<div class="lp-submit-note" role="note"><strong>提交时校验（一次新鲜事实）</strong>账户 · 余额/授权 · 标的身份 · 价位/数量 · 盘口新鲜度 · 奖励资格 · 退出深度 · 复核时间；默认试挂单确认价与提交时所选买档不一致将直接拒绝。</div>`
    + `<div class="pm-risk-note" role="note"><strong>提交即登记 #152 位置保护</strong><p>经系统入口提交的单自动带基线：初始 A = 前方份额 ÷ 同价位总量，A ≤ 50% 时自动撤掉该价位全部自己 BUY。网页手动单显示与行为不变。</p></div>`;
  const footer = `<footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">取消</button>`
    + `<button class="pm-button primary" type="button" data-modal-action="lp-order-confirm">确认提交 · 登记受保护</button></footer>`;
  return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1">${header}${body}${footer}</section>`;
}

// Issue 167 D1: the augment modal unlocks the price level (default = the
// group price); the retired same-price merged estimate makes way for the
// level rules hint.
const LP_AUGMENT_PRICE_HINT =
  "价位须为本组还没有在挂的价格（不高于当前买一）；同价补量请先撤该价位再追加。每个价位至多一张在挂单，各自独立位置保护。";

function lpAugmentModalHtml(data = {}) {
  // Issue 163 定案：追加同样单相化——删预检/复核相，确认即一次提交。
  const session = data.session && typeof data.session === "object" ? data.session : {};
  const sessionPrice = String(session.price ?? "");
  const mode = ["five", "custom"].includes(data.mode) ? data.mode : (data.fiveQuantity ? "five" : "custom");
  const title = escapeHtml(session.market_title || "标的未返回");
  const header = `<header class="pm-modal-header"><h2 id="pm-dialog-title">追加 · 解锁价位</h2><p>一次确认即提交：在现有组内追加一张 post-only BUY；每个价位至多一张在挂单，各自独立位置保护。</p></header>`
    + `<div class="pm-order-market"><span>Polymarket · 同所 · 会话 ${escapeHtml(lpShortSessionId(session.session_id))}</span><strong>${title}</strong></div>`;
  const existingText = `试挂单 ${escapeHtml(predictionValue(session.quantity, "UNKNOWN"))} 份 @ ${escapeHtml(sessionPrice)}（首单价）`;
  const fiveLabel = data.fiveQuantity
    ? `加 5% 单 · ${escapeHtml(sessionPrice)} × ${escapeHtml(data.fiveQuantity)} 份`
    : "加 5% 单 · 目标量 UNKNOWN";
  const caseLine = (value, label, disabled) => `<label class="radio-line${disabled ? " is-disabled" : ""}">`
    + `<input type="radio" name="lp-augment-case" value="${value}"${mode === value ? " checked" : ""}${disabled ? " disabled" : ""}`
    + ` data-modal-action="lp-augment-case" data-case-mode="${value}"> ${label}</label>`;
  const cases = caseLine("five", fiveLabel, !data.fiveQuantity)
    + caseLine("custom", `自定义数量 <input class="lp-order-input" id="lp-augment-quantity" type="number" step="1" min="1" value="${escapeHtml(String(data.quantity || ""))}"> 份`, false);
  const body = `<div class="pm-check-list">`
    + `<div class="pm-check"><span>现有委托</span><strong>${existingText}</strong></div>`
    + `<div class="pm-check"><span>追加价位 USDC</span><span><input class="lp-order-input" id="lp-augment-price" type="number" step="0.01" min="0.01" max="0.99" value="${escapeHtml(String(data.price ?? sessionPrice))}"> <span class="sub">默认组价，可改</span></span></div>`
    + `<div class="pm-check"><span>加量方式</span><span style="display:block">${cases}</span></div>`
    + `</div>`
    + `<p class="sub">${escapeHtml(LP_AUGMENT_PRICE_HINT)}</p>`
    + `<p class="sub">服务端按提交时最新事实校验（会话仍活动、盘口新鲜、价位不高于当前买一）；成功后新价位独立建档保护、复核截止沿用首单。</p>`;
  const footer = `<footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">取消</button>`
    + `<button class="pm-button primary" type="button" data-modal-action="lp-augment-confirm">确认提交</button></footer>`;
  return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1">${header}${body}${footer}</section>`;
}

function lpOrderIntent(row) {
  const selected = row?.selected_direction && typeof row.selected_direction === "object"
    ? row.selected_direction : {};
  const target = Number(row?.estimated_target_quantity);
  // The raw price string feeds the number input and the case labels; the
  // display-only cent formatting of lpDashboardPrice would corrupt inputs.
  const price = predictionHasValue(selected.price) ? String(selected.price) : "";
  const quantity = String(predictionHasValue(selected.quantity) ? selected.quantity : "");
  return {
    row,
    mode: "trial",
    trialPrice: price,
    trialQuantity: quantity,
    trialBidLevel: row?.estimate_buy_price_level,
    price,
    quantity,
    // Issue 162: 数量一律原样字符串——formatDisplayNumber 的千位逗号/两位舍入
    // 是展示口径，进入输入框与请求体会令 Number() 解析 NaN。
    fiveQuantity: Number.isFinite(target) && target > 0 ? String(target) : "",
    // Issue 174: 提交体身份同源——token 与 outcome 同取弹窗捕获的 selected_direction，
    // 不取行顶层（行顶层是入队评估腿，可与展示所选腿不同）。
    token: String(selected.token_id || ""),
    outcome: String(selected.outcome || ""),
    reviewAtText: String(row?.review_at ?? ""),
  };
}

function lpAugmentIntent(orders, session) {
  // Issue 167: price is unlocked — the group price only pre-fills the input.
  const conditionId = String(session?.condition_id || "");
  // Issue 158: the candidate funnel marks the session's market
  // known_participation and excludes it from the pool, so the 加 5% default
  // first reads the informational-only estimated_target_quantity projected on
  // the session, then falls back to the candidate pool; when neither has a
  // value the option renders disabled with the UNKNOWN label.  This value
  // only pre-fills the modal — every augment quantity is still validated by
  // the augment preview/confirm endpoints.
  const sessionTarget = Number(session?.estimated_target_quantity);
  let targetRow = null;
  if (!(Number.isFinite(sessionTarget) && sessionTarget > 0)) {
    const dashboard = state.predictionMarket.lpDashboard;
    for (const list of [dashboard?.recommendations, dashboard?.candidates]) {
      if (!Array.isArray(list)) continue;
      targetRow = list.find((item) => String(item?.condition_id || "") === conditionId) || null;
      if (targetRow) break;
    }
  }
  const target = targetRow ? Number(targetRow?.estimated_target_quantity) : sessionTarget;
  // Issue 162: 同 lpOrderIntent——5% 默认量原样字符串，不套展示格式。
  const fiveQuantity = Number.isFinite(target) && target > 0 ? String(target) : "";
  return {
    session: {
      session_id: String(session?.session_id || ""),
      condition_id: conditionId,
      price: String(session?.price ?? ""),
      quantity: String(session?.quantity ?? ""),
      market_title: lpMarketTitle(session || {}),
    },
    price: String(session?.price ?? ""),
    fiveQuantity,
    mode: fiveQuantity ? "five" : "custom",
    quantity: fiveQuantity || "",
  };
}

function renderPredictionModal() {
  const root = elements["prediction-market-modal-root"];
  root.innerHTML = predictionModalHtml(predictionModal.kind, predictionModal.data);
  root.querySelector(".pm-modal")?.focus();
}

function lpOrderSwitchCase(mode) {
  const data = predictionModal.data;
  if (!data || !["trial", "five", "custom"].includes(mode)) return;
  const root = elements["prediction-market-modal-root"];
  const priceInput = root.querySelector("#lp-order-price");
  const qtyInput = root.querySelector("#lp-order-quantity");
  if (data.mode === "custom" && priceInput && qtyInput) {
    data.price = priceInput.value;
    data.quantity = qtyInput.value;
  }
  data.mode = mode;
  if (mode === "trial") {
    data.price = data.trialPrice;
    data.quantity = data.trialQuantity;
  } else if (mode === "five" && data.fiveQuantity) {
    data.price = data.trialPrice;
    data.quantity = data.fiveQuantity;
  }
  renderPredictionModal();
}

function lpAugmentSwitchCase(mode) {
  const data = predictionModal.data;
  if (!data || !["five", "custom"].includes(mode)) return;
  const qtyInput = elements["prediction-market-modal-root"].querySelector("#lp-augment-quantity");
  if (data.mode === "custom" && qtyInput) data.quantity = qtyInput.value;
  data.mode = mode;
  if (mode === "five" && data.fiveQuantity) data.quantity = data.fiveQuantity;
  renderPredictionModal();
}

function predictionModalHtml(kind, data = {}) {
  if (kind === "lp_order") return lpOrderModalHtml(data);
  if (kind === "lp_augment") return lpAugmentModalHtml(data);
  if (kind === "nleg_incident") {
    // #64 (Q6=A): incident-gate unlock. Server re-checks batch receipts and
    // ledger consistency before actually releasing; the modal only asks.
    const incident = data && typeof data === "object" ? data : {};
    const legs = Array.isArray(incident.legs) ? incident.legs : [];
    const legRows = legs.map((leg) => `<div class="pm-check"><span>第 ${Number(leg.index)} 腿 · ${leg.direction === "BUY_YES" ? "买 YES" : "买 NO"}</span><strong>${leg.state === "FILLED" ? `已成交 ${escapeHtml(String(leg.filled_quantity))}/${escapeHtml(String(leg.quantity))} 份 · ${escapeHtml(predictionNLegUnitsMoney(leg.cost_units))}` : "未成交（FOK 全撤）"}</strong></div>`).join("");
    return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1"><header class="pm-modal-header"><h2 id="pm-dialog-title">解除 N_LEG 事故门</h2><p>仅在你已在系统外完成仓位处置并对账一致后使用；点击后服务端会重新核对批次回执与账本，任何不一致都会保持事故态。</p></header><div class="pm-check-list"><div class="pm-check"><span>事故原因</span><strong>${incident.reason === "PARTIAL_FILL" ? "部分成交" : escapeHtml(String(incident.reason ?? "-"))}</strong></div><div class="pm-check"><span>批次</span><strong>${escapeHtml(predictionValue(incident.execution_batch_id))}</strong></div>${legRows}<div class="pm-check"><span>已付现金</span><strong>${escapeHtml(predictionNLegUnitsMoney(incident.paid_cash_units))}</strong></div><div class="pm-check"><span>谱系执行锁</span><strong>保留（该机会族不会再有第二笔真实批次）</strong></div></div><div class="pm-risk-note" role="note"><strong>解除不会恢复自动交易</strong><p>解除只重新开放人工确认下单；若全局熔断已打开需另行解除。事故记录永久保留，供审计。</p></div><footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">保持事故态</button><button class="pm-button danger" type="button" data-modal-action="nleg-incident-unlock">对账完成，解除事故门</button></footer></section>`;
  }
  if (kind === "nleg_order") {
    // #64: manual confirmation of one frozen N-leg ExecutionSolution. The
    // displayed facts come from the server's frozen projection only.
    const solution = data.n_leg_solution && typeof data.n_leg_solution === "object" ? data.n_leg_solution : {};
    const market = solution.market && typeof solution.market === "object" ? solution.market : {};
    const execution = solution.execution && typeof solution.execution === "object" ? solution.execution : {};
    const fee = market.fee && typeof market.fee === "object" ? market.fee : {};
    const legs = Array.isArray(execution.leg_details) ? execution.leg_details : [];
    const caps = data.n_leg_caps && typeof data.n_leg_caps === "object" ? data.n_leg_caps : {};
    const capValues = caps.values && typeof caps.values === "object" ? caps.values : {};
    const maxCost = market.maximum_cost ?? predictionNLegUnitsMoney(execution.projected_total_units);
    const fingerprint = String(execution.execution_solution_fingerprint || "");
    const feeLabel = fee.status === "fee_charging"
      ? `收费 ${Number(fee.taker_fee_rate_bps) / 100}% · 已建模`
      : fee.status === "fee_free" ? "免费市场" : "未知";
    const maxCostMoney = predictionMoney(Number(maxCost), String(maxCost));
    const payoutMoney = predictionMoney(Number(market.maximum_payout), String(market.maximum_payout ?? "-"));
    const profitMoney = predictionSignedMoney(Number(market.minimum_profit), String(market.minimum_profit ?? "-"));
    return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1"><header class="pm-modal-header"><h2 id="pm-dialog-title">确认 N 腿真实订单</h2><p>确认后进入统一 FIFO 队列；确认与发单前都会取最新盘口复核——方案随行情轮转时，只要仍满足利润门槛与全部安全闸，就按最新合格方案入队并执行（上方数字为点开时参考）；价格超出已证明边界则自动作废退回监控，不会临时改方向或数量。</p></header><div class="pm-order-market"><span>Polymarket · 同所 · 同事件 · 资格 ${escapeHtml(predictionValue(data.qualification_policy_version, "v1"))} · 方案指纹 ${escapeHtml(fingerprint.slice(0, 14) || "-")}</span><strong>${escapeHtml(predictionValue(data.title, "数据未返回"))}</strong></div><div class="pm-order-legs">${legs.map((leg, index) => `<article class="pm-order-leg"><span>第 ${index + 1} 腿 · ${escapeHtml(predictionValue(leg.title, "市场未返回"))} · ${escapeHtml(predictionValue(leg.direction, "BUY"))} · FOK</span><strong>${escapeHtml(String(leg.quantity ?? "-"))} 份 @ 成本上限 ${escapeHtml(predictionPrice(leg.max_price))}</strong><small>最大成本 ${escapeHtml(predictionNLegUnitsMoney(leg.max_cost_units))} · taker 费 ${escapeHtml(predictionNLegUnitsMoney(leg.taker_fee_units))}</small></article>`).join("") || "<div class=\"pm-empty compact\">腿数据未返回</div>"}</div><div class="pm-order-summary"><div><span>含费最大成本</span><strong>${escapeHtml(maxCostMoney)}</strong></div><div><span>最低赔付</span><strong>${escapeHtml(payoutMoney)}</strong></div><div><span>保证最低利润（扣费后）</span><strong class="pm-positive">${escapeHtml(profitMoney)}</strong></div><div><span>资本释放</span><strong>${escapeHtml(String(market.capital_release_at || "-").slice(0, 10))}</strong></div></div><div class="pm-check-list"><div class="pm-check"><span>单笔资金上限</span><strong>${escapeHtml(predictionNLegUnitsMoney(capValues.max_per_trade_cost_units))} · 本次 ${escapeHtml(maxCostMoney)}</strong></div><div class="pm-check"><span>未清资本上限</span><strong>${escapeHtml(predictionNLegUnitsMoney(capValues.max_total_unsettled_capital_units))} · 预留后 ${escapeHtml(predictionNLegUnitsMoney(execution.projected_total_units))}</strong></div><div class="pm-check"><span>部分成交损失上限</span><strong>${escapeHtml(predictionNLegUnitsMoney(capValues.max_partial_fill_loss_units))}</strong></div><div class="pm-check"><span>自动修复损失上限</span><strong>${escapeHtml(predictionNLegUnitsMoney(capValues.max_auto_repair_loss_units))} · 上限确认 v${escapeHtml(predictionValue(caps.acknowledged_version, "-"))}</strong></div><div class="pm-check"><span>成交证明</span><strong>${escapeHtml(predictionValue(execution.partial_fill_proof, "-"))}</strong></div><div class="pm-check"><span>费用状态</span><strong>${escapeHtml(feeLabel)}</strong></div></div><div class="pm-risk-note" role="note"><strong>部分成交会立即触发事故</strong><p>各腿并发提交但不跨交易所原子；任一腿部分成交或回执未知时，全线停止新订单、保持事故态并转为人工处置（自动修复未启用），最坏损失由部分成交损失上限约束。重复点击不会生成第二组订单。</p></div><footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">取消</button><button class="pm-button primary" type="button" data-modal-action="nleg-confirm">确认入队 · 单笔上限 ${escapeHtml(predictionNLegUnitsMoney(capValues.max_per_trade_cost_units))}</button></footer></section>`;
  }
  if (kind === "lp_cancel") {
    // Manual LP cancel: displayed facts come from the current dashboard
    // snapshot rows; the server re-resolves every target against a fresh
    // account read before actually cancelling.
    const scope = String(data.scope || "");
    const orders = Array.isArray(data.orders) ? data.orders : [];
    const orderRows = orders.map((row) => {
      const quantity = lpDashboardTodayOrderQuantity(row);
      const shares = Number.isFinite(quantity) ? formatDisplayNumber(String(quantity)) : "-";
      const filled = Number(row.filled_quantity);
      const filledNote = Number.isFinite(filled) && filled > 0
        ? ` · 已成交 ${escapeHtml(formatDisplayNumber(String(filled)))}` : "";
      return `<div class="pm-check"><span>${escapeHtml(predictionValue(row.market_title, "市场未返回"))}</span><strong>${escapeHtml(predictionValue(row.side, "-"))} · ${shares} 份${filledNote} · 剩余 ${escapeHtml(predictionValue(row.remaining_quantity, "-"))}</strong></div>`;
    }).join("");
    const scopeLabel = scope === "all"
      ? "当天 LP 委托全部"
      : scope === "market" ? "该标的全部可撤委托" : "所选委托";
    const totalShares = orders.reduce((sum, row) => {
      const quantity = lpDashboardTodayOrderQuantity(row);
      return sum + (Number.isFinite(quantity) ? quantity : 0);
    }, 0);
    return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1"><header class="pm-modal-header"><h2 id="pm-dialog-title">确认撤单</h2><p>${escapeHtml(scopeLabel)} · ${orders.length} 笔 · 合计 ${escapeHtml(formatDisplayNumber(String(totalShares)))} 份。撤单即时生效;已成交部分不可撤。</p></header><div class="pm-check-list">${orderRows || "<div class=\"pm-check\"><span>没有可撤委托</span><strong>-</strong></div>"}</div><div class="pm-risk-note" role="note"><strong>撤单即时生效</strong><p>撤单后该委托不再参与计分；已成交部分不可撤；确认时服务端会用最新账户数据重新核对每一笔。请求发送后，关闭弹窗不会中止撤单。</p></div><footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">取消</button><button class="pm-button danger" type="button" data-modal-action="lp-cancel-confirm"${state.predictionMarket.lpCancelInFlight ? " disabled" : ""}>确认撤单 · ${orders.length} 笔</button></footer></section>`;
  }
  const reset = kind === "reset";
  const cleanup = kind === "allowance_cleanup";
  const title = cleanup ? "确认清理 Predict 残余授权" : reset ? "确认解除交易熔断" : "确认真实下单";
  const description = reset ? "事故记录会永久保留；解除后系统才重新开放“参与”按钮。" : "确认后由 Open Trader 使用独立钱包直接签名并执行，不跳转 Polymarket。";
  if (reset) {
    const incidentId = data.incident_id || data.id || "";
    const happenedAt = data.happened_at || data.created_at || data.updated_at;
    const market = data.event_title || data.question || data.title;
    const reason = data.reason || data.message;
    const loss = data.loss ?? data.actual_loss;
    return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1"><header class="pm-modal-header"><h2 id="pm-dialog-title">${title}</h2><p>${description}</p></header><div class="pm-check-list"><div class="pm-check"><span>事故时间</span><strong>${escapeHtml(predictionValue(happenedAt, "-"))}</strong></div><div class="pm-check"><span>市场</span><strong>${escapeHtml(predictionValue(market, "-"))}</strong></div><div class="pm-check"><span>原因</span><strong>${escapeHtml(reason ? predictionIncidentReasonLabel(reason) : "事故详情未返回")}</strong></div><div class="pm-check"><span>实际损失</span><strong class="pm-tone-danger">${escapeHtml(predictionSignedMoney(loss))}</strong></div></div><div class="pm-risk-note"><strong>点击后会重新读取真实账户状态</strong><p>系统将检查未完成订单、方向性敞口、待合并头寸、账户数据新鲜度，以及 relayer 和通知通道；任何一项失败都会继续保持熔断并显示后台原因。</p></div><footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">保持熔断</button><button class="pm-button danger" type="button" data-modal-action="reset"${incidentId ? "" : " disabled"}>重新检查并解除</button></footer></section>`;
  }
  if (cleanup) {
    const armed = data.armed === true;
    return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1"><header class="pm-modal-header"><h2 id="pm-dialog-title">${title}</h2><p>只把 Predict Account 对 spender 的 USDT allowance 清零；不会发起转入、转出、下单或兑付。</p></header><div class="pm-check-list"><div class="pm-check"><span>owner</span><strong>${escapeHtml(predictionValue(data.owner, "-"))}</strong></div><div class="pm-check"><span>spender</span><strong>${escapeHtml(predictionValue(data.spender, "-"))}</strong></div><div class="pm-check"><span>allowance</span><strong>${escapeHtml(predictionMoney(data.before_allowance))} → ${escapeHtml(predictionMoney(data.after_allowance))}</strong></div><div class="pm-check"><span>gas effect</span><strong>${escapeHtml(predictionValue(data.gas_effect, "消耗 Privy signer BNB"))}</strong></div></div><div class="pm-risk-note" role="note"><strong>不转移 USDT</strong><p>这是授权清零交易，不是资金划转；需要二次确认后才会向本地受保护端点发送 {"confirm":true}。</p></div><footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">取消</button>${armed ? `<button class="pm-button danger" type="button" data-modal-action="cleanup">二次确认 · 授权清零</button>` : `<button class="pm-button danger" type="button" data-modal-action="arm-cleanup">我知道这会消耗 BNB</button>`}</footer></section>`;
  }
  // Issue 162（定案 6）：兜底 order 模板只对 kind === "order" 渲染；未知/空
  // kind（含迟到响应里的 ""）一律返回空串，绝不渲染「确认真实下单」空白框。
  if (kind !== "order") return "";
  const opportunity = predictionPreviewDisplay(data);
  const policy = opportunity.policy_limits || {};
  const walletCap = predictionMoney(policy.max_wallet_balance);
  const normalCap = predictionMoney(policy.max_normal_cost);
  const emergencyCap = predictionMoney(policy.max_emergency_loss);
  const minimumProfit = predictionMoney(policy.min_estimated_profit);
  if (predictionIsCrossVenue(opportunity)) {
    const legs = Array.isArray(opportunity.buy_legs) ? opportunity.buy_legs : [];
    const balances = opportunity.balances && typeof opportunity.balances === "object" && !Array.isArray(opportunity.balances) ? opportunity.balances : {};
    const approval = opportunity.codex_approval && typeof opportunity.codex_approval === "object" ? opportunity.codex_approval : {};
    const evidence = Array.isArray(approval.evidence) ? approval.evidence : [];
    const unsettled = opportunity.unsettled && typeof opportunity.unsettled === "object" ? opportunity.unsettled : {};
    const balanceSummary = ["predict.fun", "polymarket"].map((exchange) => {
      const balance = balances[exchange];
      if (!balance) return "";
      const venue = exchange === "predict.fun" ? "Predict.fun" : "Polymarket";
      return `${venue} ${predictionMoney(balance.available_balance)} ${predictionValue(balance.asset, "-")}`;
    }).filter(Boolean).join(" · ");
    const capLabel = Number(policy.max_normal_cost) <= 5 ? "首单验证" : "常规上限";
    const manualOnly = opportunity.manual_only === true;
    const manualWarning = manualOnly
      ? `<div class="pm-alert warning"><div class="pm-alert-body"><strong>结算规则可能不一致</strong><p>两所对规则有独立解释权，文字一致不保证同向结算。若两所分歧且押错方向，两腿皆输，损失 = 总成本（含手续费和 gas）。</p></div></div>`
      : "";
    const manualWorstRow = manualOnly
      ? `<div class="pm-check"><span>最坏损失（分歧）</span><strong>${escapeHtml(predictionMoney(opportunity.total_max_cost))}</strong></div>`
      : "";
    return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1"><header class="pm-modal-header"><h2 id="pm-dialog-title">${title}</h2><p>确认后分别向 Predict.fun 与 Polymarket 提交受限 FOK 订单；确认前不会提交任何订单。</p></header>${manualWarning}<div class="pm-order-market"><span>Predict.fun × Polymarket · 跨所 YES/NO · 统一结算截止 ${escapeHtml(predictionValue(opportunity.canonical_cutoff, "未返回"))} · 统一截止</span><strong>${escapeHtml(predictionValue(opportunity.title, "数据未返回"))}</strong></div><div class="pm-order-legs">${legs.map((leg, index) => { const ids = [leg.market_id, leg.condition_id, leg.token_id].filter(predictionHasValue).join(" · "); const link = leg.official_url ? `<a href="${escapeHtml(leg.official_url)}" target="_blank" rel="noreferrer">${escapeHtml(leg.official_url)}</a>` : ""; return `<article class="pm-order-leg"><span>第 ${index + 1} 腿 · ${escapeHtml(predictionVenueLegLabels([leg]).replace(" · ", " · BUY "))} · FOK · ${escapeHtml(predictionValue(leg.settlement_asset, "资产未返回"))}</span><strong>冻结数量 ${escapeHtml(predictionValue(leg.net_quantity, "-"))} 净份 · 最高 ${escapeHtml(predictionPrice(leg.max_price))} · 最高价冻结</strong><small>最大成本 ${escapeHtml(predictionMoney(leg.max_cost))} · 手续费 ${escapeHtml(predictionMoney(leg.maximum_fee))} ${escapeHtml(predictionValue(leg.fee_asset, "费用资产未返回"))}</small>${ids ? `<small>Native IDs ${escapeHtml(ids)}</small>` : ""}${link ? `<small>官方链接 ${link}</small>` : ""}${leg.quote_at ? `<small>数据时间 ${escapeHtml(predictionValue(leg.quote_at))}</small>` : ""}</article>`; }).join("")}</div><div class="pm-order-summary"><div><span>净可兑付份额</span><strong>${escapeHtml(predictionValue(opportunity.net_quantity, "-"))}</strong></div><div><span>含费最大成本</span><strong>${escapeHtml(predictionMoney(opportunity.max_cost))}</strong></div><div><span>最低赔付</span><strong>${escapeHtml(predictionMoney(opportunity.minimum_payout))}</strong></div><div><span>最低净利润</span><strong class="pm-positive">${escapeHtml(predictionSignedMoney(opportunity.profit))}</strong></div><div><span>简单年化</span><strong>${escapeHtml(predictionAnnualizedPercent(opportunity.annualized_yield, 2))}</strong></div></div><div class="pm-risk-note" role="note"><strong>两笔订单不是原子交易</strong><p>可能只成交一腿。你授权系统最多承担 ${escapeHtml(emergencyCap)} 预计损失进行补腿或平仓；两所分别结算后自动兑付，异常会熔断。</p></div><div class="pm-check-list"><div class="pm-check"><span>${capLabel} · 单笔成本上限</span><strong>${escapeHtml(normalCap)}</strong></div><div class="pm-check"><span>应急损失上限</span><strong>${escapeHtml(emergencyCap)}</strong></div><div class="pm-check"><span>LLM ${escapeHtml(predictionValue(approval.decision, "未返回"))}</span><strong>LLM ${escapeHtml(predictionValue(approval.reviewed_at || approval.review_time || approval.updated_at, predictionValue(approval.decision, "未返回")))} · ${escapeHtml(predictionValue(approval.summary, "结构化理由未返回"))}</strong></div>${evidence.map((item) => `<div class="pm-check"><span>${escapeHtml(predictionValue(item.exchange, "交易所"))} · ${escapeHtml(predictionValue(item.field, "证据"))}</span><strong>${escapeHtml(predictionValue(item.quote, "证据未返回"))}</strong></div>`).join("")}<div class="pm-check"><span>可用余额</span><strong>${escapeHtml(balanceSummary || "余额数据未返回")}</strong></div><div class="pm-check"><span>待结算占用</span><strong>${escapeHtml(`${predictionMoney(unsettled.current)} → ${predictionMoney(unsettled.after)} / ${predictionMoney(unsettled.limit)}`)}</strong></div><div class="pm-check"><span>未结算上限</span><strong>${escapeHtml(predictionMoney(policy.max_cross_unsettled_principal ?? unsettled.limit))}</strong></div><div class="pm-check"><span>自动兑付</span><strong>两所分别完成结算后读取余额和回执</strong></div><div class="pm-check"><span>确认时处理</span><strong>重新读取两所 REST、盘口、余额和未结算额度</strong></div>${manualWorstRow}</div><footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">取消</button><button class="pm-button primary" type="button" data-modal-action="confirm">确认下单 · 最多 ${escapeHtml(normalCap)}</button></footer></section>`;
  }
  if (String(opportunity.market_type || "") === "threshold_hedge") {
    const legs = Array.isArray(opportunity.buy_legs) ? opportunity.buy_legs : [];
    return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1"><header class="pm-modal-header"><h2 id="pm-dialog-title">${title}</h2><p>${description}</p></header><div class="pm-order-market"><span>Polymarket · 阈值关系套利 · ${escapeHtml(predictionValue(opportunity.relation, "关系未返回"))}</span><strong>${escapeHtml(predictionValue(opportunity.question_a, "数据未返回"))}<br>${escapeHtml(predictionValue(opportunity.question_b, "数据未返回"))}</strong></div><div class="pm-order-legs">${legs.map((leg) => `<article class="pm-order-leg"><span>${escapeHtml(predictionValue(leg.label))} · BUY ${escapeHtml(predictionValue(leg.outcome))} · FOK · ${escapeHtml(predictionConditionLabel(leg.condition_id))}</span><strong>${escapeHtml(predictionValue(leg.quantity, "-"))} 份 @ 最高 ${escapeHtml(predictionPrice(leg.max_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(leg.max_cost))} · 全成或全撤</small></article>`).join("")}</div><div class="pm-order-summary"><div><span>含费最大成本</span><strong>${escapeHtml(predictionMoney(opportunity.max_cost))}</strong></div><div><span>最低收回</span><strong>${escapeHtml(predictionMoney(opportunity.minimum_payout))}</strong></div><div><span>最低净利润</span><strong class="pm-positive">${escapeHtml(predictionSignedMoney(opportunity.profit))}</strong></div></div><div class="pm-risk-note" role="note"><strong>两笔订单不是原子交易，也不会 merge</strong><p>两个 condition 必须分别成交和核对；若只成交一腿，系统最多按 ${escapeHtml(emergencyCap)} 预计补腿或平仓，超过上限就熔断并通知。</p></div><div class="pm-check-list"><div class="pm-check"><span>规则校验</span><strong>${escapeHtml(predictionLlmDecisionLabel(opportunity))} · ${escapeHtml(predictionValue(opportunity.llm_summary, "结构化理由未返回"))}</strong></div><div class="pm-check"><span>独立钱包</span><strong>${escapeHtml(predictionMaskedWallet(opportunity.wallet))} · 可用 ${escapeHtml(predictionMoney(opportunity.available_balance))} pUSD</strong></div><div class="pm-check"><span>确认时处理</span><strong>重新检查两条规则、两个盘口、费用、余额和地区</strong></div></div><footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">取消</button><button class="pm-button primary" type="button" data-modal-action="confirm">确认下单 · 最多 ${escapeHtml(normalCap)}</button></footer></section>`;
  }
  return `<section class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="pm-dialog-title" tabindex="-1"><header class="pm-modal-header"><h2 id="pm-dialog-title">${title}</h2><p>${description}</p></header><div class="pm-order-market"><span>Polymarket · ${escapeHtml(predictionMarketTypeLabel(opportunity.market_type))} · ${escapeHtml(predictionFeeStatusLabel(opportunity.fee_status))}</span><strong>${escapeHtml(predictionValue(opportunity.title, "-"))}</strong></div><div class="pm-order-legs"><article class="pm-order-leg"><span>第一腿 · BUY YES · FOK</span><strong>${escapeHtml(predictionValue(opportunity.quantity, "-"))} 份 @ 最高 ${escapeHtml(predictionPrice(opportunity.yes_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(opportunity.yes_cost))} · 全成或全撤</small></article><article class="pm-order-leg"><span>第二腿 · BUY NO · FOK</span><strong>${escapeHtml(predictionValue(opportunity.quantity, "-"))} 份 @ 最高 ${escapeHtml(predictionPrice(opportunity.no_price))}</strong><small>最大成本 ${escapeHtml(predictionMoney(opportunity.no_cost))} · 全成或全撤</small></article></div><div class="pm-order-summary"><div><span>正常最大成本</span><strong>${escapeHtml(predictionMoney(opportunity.max_cost))}</strong></div><div><span>合并收回</span><strong>${escapeHtml(predictionMoney(opportunity.merge_value))}</strong></div><div><span>最低净利润</span><strong class="pm-positive">${escapeHtml(predictionSignedMoney(opportunity.profit))}</strong></div></div><div class="pm-risk-note" role="note"><strong>两笔订单不是原子交易</strong><p>可能只成交一腿。你授权系统最多承担 ${escapeHtml(emergencyCap)} 预计损失进行补腿或平仓；随后会熔断并通知。</p></div><div class="pm-check-list"><div class="pm-check"><span>独立钱包</span><strong>${escapeHtml(predictionMaskedWallet(opportunity.wallet))} · 可用 ${escapeHtml(predictionMoney(opportunity.available_balance))} pUSD</strong></div><div class="pm-check"><span>钱包余额上限</span><strong>${escapeHtml(walletCap)} pUSD</strong></div><div class="pm-check"><span>确认时处理</span><strong>重新检查价格、费用、余额和地区</strong></div><div class="pm-check"><span>失败规则</span><strong>净利润低于 ${escapeHtml(minimumProfit)} 就拒绝，不追价</strong></div></div><footer class="pm-modal-actions"><button class="pm-button" type="button" data-modal-action="cancel">取消</button><button class="pm-button primary" type="button" data-modal-action="confirm">确认下单 · 最多 ${escapeHtml(normalCap)}</button></footer></section>`;
}

function openPredictionModal(kind, trigger, data) {
  // Issue 162（定案 3）：epoch 是模态世代号——open/close 各递增一次，异步
  // 响应用它识别自己所属的弹窗是否已被关闭/替换（迟到响应隔离）。
  predictionModal = {kind, previousFocus: trigger || document.activeElement, busy: false, epoch: (predictionModal?.epoch || 0) + 1, data: data || {}};
  const root = elements["prediction-market-modal-root"];
  root.innerHTML = predictionModalHtml(kind, data);
  document.body.style.overflow = "hidden";
  requestAnimationFrame(() => root.querySelector(".pm-modal")?.focus());
}

function closePredictionModal() {
  const previous = predictionModal.previousFocus;
  predictionModal = {kind: "", previousFocus: null, busy: false, epoch: (predictionModal?.epoch || 0) + 1, data: null};
  elements["prediction-market-modal-root"].innerHTML = "";
  document.body.style.overflow = "";
  if (previous?.matches?.("[data-action='participate']")) previous.disabled = false;
  previous?.focus?.();
}

function setPredictionModalBusy(busy) {
  predictionModal.busy = busy;
  if (predictionModal.kind === "lp_cancel") {
    const confirm = elements["prediction-market-modal-root"].querySelector("[data-modal-action='lp-cancel-confirm']");
    if (confirm && busy) confirm.textContent = "正在撤单…";
    const cancel = elements["prediction-market-modal-root"].querySelector("[data-modal-action='cancel']");
    if (cancel && busy) cancel.textContent = "关闭";
  }
  // Issue 162（定案 4）：LP 三类弹窗 busy 期间保留「取消」可点——转圈也允许
  // 放弃；关闭即 epoch 递增，迟到响应按过期静默丢弃。
  const keepCancel = busy && LP_MODAL_KINDS.has(predictionModal.kind || "");
  elements["prediction-market-modal-root"].querySelectorAll("button").forEach((button) => {
    button.disabled = busy && !(keepCancel && button.dataset?.modalAction === "cancel");
  });
}

// Issue 158: live cost / merged-A refresh while typing in the LP modals.
function handlePredictionModalInput(event) {
  if (!predictionModal?.kind || predictionModal.busy) return;
  const root = elements["prediction-market-modal-root"];
  const target = event.target;
  if (predictionModal.kind === "lp_order"
    && (target?.id === "lp-order-price" || target?.id === "lp-order-quantity")) {
    // Issue 162（定案 7）：价格与数量两个输入都实时重算预计占用。
    const node = root.querySelector("#lp-order-cost");
    if (node) {
      node.textContent = lpOrderCostText(
        root.querySelector("#lp-order-price")?.value,
        root.querySelector("#lp-order-quantity")?.value,
      );
    }
  }
}

function relationExpected(detail) {
  return {version_id: String(detail?.version_id || "")};
}

function relationReviewStateKey(item) {
  const status = String(item?.status || "");
  const activation = String(item?.activation || "");
  if (status === "PENDING") return "PENDING_APPROVAL";
  if (status !== "APPROVED") return "";
  if (activation === "ACTIVE") return "ACTIVATED";
  if (activation.startsWith("ACTIVATION_BLOCKED") || activation === "UNSUPPORTED_SIZE") return "ACTIVATION_BLOCKED";
  if (activation === "SUPERSEDED") return "SOURCE_CHANGED_REAPPROVAL";
  const compiled = Array.isArray(item?.model?.terminal_states) && item.model.terminal_states.length > 0;
  return compiled ? "COMPILED_PENDING_ACTIVATION" : "APPROVED_MODEL_INCOMPLETE";
}

function relationRoleLetters(item) {
  // Roles come from the row's endpoint.role fields — the same parsed roles the
  // backend used to derive the statement — so the stored endpoint order can
  // never flip the antecedent/consequent labels. Rows without provable roles
  // (legacy payloads) get no letters at all.
  const endpoints = Array.isArray(item?.endpoints) ? item.endpoints : [];
  if (endpoints.length !== 2) return [];
  const roles = endpoints.map((market) => String(market?.role || ""));
  if (!roles.every((role) => role === "A" || role === "B") || roles[0] === roles[1]) return [];
  return roles;
}

function relationAntecedentLetter(directionCode) {
  return ["B_IMPLIES_A", "B_TO_A"].includes(String(directionCode || "")) ? "B" : "A";
}

function relationAbbreviatedId(versionId) {
  const value = String(versionId || "-");
  return value.length > 12 ? `${value.slice(0, 4)}…${value.slice(-2)}` : value;
}

function relationCatalogItem(item, expanded = false) {
  const endpoints = Array.isArray(item?.endpoints) ? item.endpoints : [];
  const directionCode = String(item?.direction_code || "");
  const letters = relationRoleLetters(item);
  const stateMeta = PREDICTION_RELATION_REVIEW_STATES[relationReviewStateKey(item)] || {label: predictionValue(item?.status, "未知状态"), tone: ""};
  const venue = [...new Set(endpoints.map((market) => String(market?.venue || "").trim()).filter(Boolean))].join(" / ");
  const expiryLine = [venue ? escapeHtml(venue) : "", ...endpoints.map((market, index) => `${letters[index] ? `${letters[index]} ` : ""}到期 ${escapeHtml(predictionHktTimestamp(market?.expires_at))}`)]
    .filter(Boolean).join(" · ");
  const tags = `${directionCode ? `<span class="pm-relation-tag">${escapeHtml(directionCode)}</span>` : ""}${item?.discovery_source ? `<span class="pm-relation-tag">${escapeHtml(String(item.discovery_source))}</span>` : ""}`;
  return `<button type="button" class="pm-relation-row${expanded ? " expanded" : ""}" data-relation-version-id="${escapeHtml(predictionValue(item?.version_id, ""))}"><div style="display:flex;justify-content:space-between;align-items:start;gap:10px"><strong>${escapeHtml(predictionValue(item?.statement, "关系表述未返回"))}</strong><span class="pm-relation-badge${stateMeta.tone ? ` ${stateMeta.tone}` : ""}">${escapeHtml(stateMeta.label)}</span></div><div class="pm-relation-market"><small>${expiryLine}</small><small>${tags}版本 ${escapeHtml(relationAbbreviatedId(item?.version_id))} · 发现 ${escapeHtml(predictionHktTimestamp(item?.discovered_at))}</small></div></button>`;
}

const RELATION_REVIEW_PAGE_SIZE = 50;

function relationDetailHtml(detail) {
  if (!detail) return "";
  const endpoints = Array.isArray(detail?.endpoints) ? detail.endpoints : [];
  const letters = relationRoleLetters(detail);
  const antecedentLetter = letters.length === 2 ? relationAntecedentLetter(detail?.direction_code) : "";
  const detailMarkets = `<div class="pm-relation-markets">${endpoints.map((market, index) => `<article class="pm-relation-detail-market"><strong>${escapeHtml(predictionValue(market?.title, "标题未返回"))}</strong>${letters.length === 2 ? `<span class="pm-relation-market-role">市场 ${letters[index]} · ${letters[index] === antecedentLetter ? "前件" : "后件"}</span>` : ""}<dl><div><dt>交易所</dt><dd>${escapeHtml(predictionValue(market?.venue, "-"))}</dd></div><div><dt>Native ID</dt><dd>${escapeHtml(predictionValue(market?.contract_id, "-"))}</dd></div><div><dt>市场日期</dt><dd>${escapeHtml(predictionHktTimestamp(market?.market_date))}</dd></div><div><dt>到期日</dt><dd>${escapeHtml(predictionHktTimestamp(market?.expires_at))}</dd></div><div><dt>结算依据</dt><dd>${escapeHtml(predictionValue(market?.settlement_observation_key, "-"))}</dd></div></dl></article>`).join("")}</div>`;
  const evidence = Array.isArray(detail?.evidence) ? detail.evidence.map((item) => `<li>${escapeHtml(JSON.stringify(item?.source_evidence || item))}</li>`).join("") : "";
  const expected = relationExpected(detail);
  const actions = predictionWritesBlocked() ? "" : detail?.status === "PENDING" && expected ? `<div class="pm-relation-actions"><button class="pm-button" type="button" data-action="reject-relation" data-relation-version-id="${escapeHtml(expected.version_id)}">拒绝</button><button class="pm-button primary" type="button" data-action="approve-relation" data-relation-version-id="${escapeHtml(expected.version_id)}">确认并尝试激活</button></div>` : detail?.activation === "ACTIVE" && expected ? `<div class="pm-relation-actions"><button class="pm-button danger" type="button" data-action="revoke-relation" data-relation-version-id="${escapeHtml(expected.version_id)}">撤销当前关系</button></div>` : "";
  const decision = `<label class="pm-relation-reason">决定原因<select data-relation-reason><option value="source_evidence_insufficient">来源证据不足</option><option value="relation_semantics_wrong">关系语义错误</option><option value="model_incomplete_or_wrong">模型不完整或错误</option><option value="identity_mismatch">身份不匹配</option><option value="rules_changed">规则已变化</option><option value="other">其他</option></select><textarea data-relation-note maxlength="1000" placeholder="备注（可选）"></textarea></label>`;
  return `<section class="pm-relation-detail" data-relation-detail><button type="button" class="pm-relation-back" data-action="relation-back">收起详情</button><h2>${escapeHtml(predictionValue(detail?.statement, "关系表述未返回"))}</h2><p>版本 ${escapeHtml(predictionValue(detail?.version_id, "-"))} · 发现 ${escapeHtml(predictionHktTimestamp(detail?.discovered_at))} · 来源 ${escapeHtml(predictionValue(detail?.discovery_source, "-"))}</p>${detailMarkets}<section><h3>来源证据</h3><ul class="pm-relation-evidence">${evidence}</ul></section>${decision}${actions}</section>`;
}

function relationReviewDrawer() {
  const review = state.predictionMarket.relationReview;
  if (!review.open) return "";
  const counts = state.predictionMarket.payload?.relation_review?.counts && typeof state.predictionMarket.payload.relation_review.counts === "object" ? state.predictionMarket.payload.relation_review.counts : {};
  const tabs = Object.entries(PREDICTION_RELATION_REVIEW_STATES).map(([key, meta]) => {
    const view = key.toLowerCase();
    const count = Number(counts[key] || 0);
    return `<button type="button" data-relation-view="${view}" aria-pressed="${review.view === view}">${meta.short} <span class="pm-relation-tab-count">${Number.isFinite(count) ? count : 0}</span></button>`;
  }).join("");
  const detail = review.detail;
  const list = review.loading ? `<p class="pm-relation-empty">正在加载关系目录…</p>` : review.items.length ? review.items.map((item) => {
    const expanded = Boolean(detail && item.version_id === detail.version_id);
    return relationCatalogItem(item, expanded) + (expanded ? relationDetailHtml(detail) : "");
  }).join("") : `<p class="pm-relation-empty">此视图暂无关系。</p>`;
  const total = Number(review.total || 0);
  const offset = Math.max(0, Number(review.offset) || 0);
  const pages = Math.max(1, Math.ceil(total / RELATION_REVIEW_PAGE_SIZE));
  const page = Math.min(Math.floor(offset / RELATION_REVIEW_PAGE_SIZE) + 1, pages);
  const pager = `<div class="pm-relation-pager"><span>显示 ${total === 0 ? 0 : offset + 1}–${total === 0 ? 0 : Math.min(offset + RELATION_REVIEW_PAGE_SIZE, total)} / ${total}</span><span class="pm-relation-pager-pages"><button type="button" data-action="relation-prev-page" ${offset <= 0 ? "disabled" : ""}>‹ 上一页</button><span>第 ${page} / ${pages} 页</span><button type="button" data-action="relation-next-page" ${offset + RELATION_REVIEW_PAGE_SIZE >= total ? "disabled" : ""}>下一页 ›</button></span></div>`;
  return `<aside class="pm-relation-drawer" aria-label="关系审核" role="dialog" aria-modal="true"><header><div><h2>关系审核</h2><p>只审核系统发现的关系事实；不展示价格、利润或机会排序。</p></div><button type="button" class="pm-relation-close" data-action="close-relation-review" aria-label="关闭关系审核">关闭</button></header><nav class="pm-relation-tabs" aria-label="关系审核视图">${tabs}</nav><div class="pm-relation-drawer-body"><section class="pm-relation-list">${list}</section>${pager}</div></aside>`;
}

const NLEG_REPORT_RECEIPT_LABELS = { FILLED: "已成交", REJECTED: "全拒（FOK 撤销）", UNKNOWN: "未知回执", UNSUBMITTED: "未提交" };
const NLEG_REPORT_BATCH_LABELS = { ACTIVE: "执行中", INCIDENT: "事故中" };
const NLEG_REPORT_REQUEST_LABELS = { PENDING: "等待发单预检", ADMITTED: "已准入", SUBMITTED: "已提交" };
function nlegReportShortId(value, head = 16, tail = 4) {
  const text = String(value ?? "");
  return text.length > head + tail + 1 ? `${text.slice(0, head)}…${text.slice(-tail)}` : text;
}
function nlegReportBatchStateLabel(state) {
  const text = String(state ?? "");
  if (text.startsWith("RECONCILED")) return `已对账（${text}）`;
  return NLEG_REPORT_BATCH_LABELS[text] || text;
}
function nlegReportTriggerLabel(trigger) {
  if (trigger === "MANUAL_CONFIRM") return "人工确认";
  return String(trigger ?? "-");
}
function nlegReportDirectionLabel(leg) {
  const parts = String(leg?.action_id ?? "").split(":");
  const contract = parts[1] || String(leg?.action_id ?? "-");
  const tail = parts.slice(2).join(":");
  const side = String(leg?.side ?? tail ?? "");
  const direction = side === "BUY_YES" ? "买 YES" : side === "BUY_NO" ? "买 NO" : side === "BUY" ? "买入" : side === "SELL" ? "卖出" : "";
  return direction ? `${escapeHtml(contract)} · ${escapeHtml(direction)}` : escapeHtml(contract);
}
function nlegReportBatchArticle(batch) {
  const profit = batch?.profit && typeof batch.profit === "object" ? batch.profit : {};
  const conservation = batch?.conservation && typeof batch.conservation === "object" ? batch.conservation : {};
  const guaranteed = Number(profit.guaranteed_profit_units);
  const guaranteedText = Number.isFinite(guaranteed) ? `${guaranteed > 0 ? "+" : ""}${escapeHtml(predictionNLegUnitsMoney(profit.guaranteed_profit_units))}` : "-";
  const actualText = profit.actual_profit === "UNSETTLED" || profit.actual_profit == null ? "未结算 · 结算后重跑补算" : escapeHtml(predictionNLegUnitsMoney(profit.actual_profit));
  const conservationText = `预留 ${escapeHtml(predictionNLegUnitsMoney(conservation.reserved_units))} = 仓位 ${escapeHtml(predictionNLegUnitsMoney(conservation.position_units))} · ${conservation.equal === true ? "一致" : "不一致"}`;
  const legs = Array.isArray(batch?.legs) ? batch.legs : [];
  const legRows = legs.map((leg) => `<tr><td>${nlegReportDirectionLabel(leg)}</td><td>${Number(leg.filled_quantity)}/${Number(leg.submitted_quantity)} 份</td><td>${escapeHtml(predictionNLegUnitsMoney(leg.paid_cash_units))}</td><td>${escapeHtml(predictionNLegUnitsMoney(leg.paid_fee_units))}</td><td>${escapeHtml(NLEG_REPORT_RECEIPT_LABELS[leg.state] || String(leg.state ?? "-"))}</td></tr>`).join("");
  const incident = batch?.incident && typeof batch.incident === "object" ? batch.incident : null;
  const repair = batch?.repair_authorization && typeof batch.repair_authorization === "object" ? batch.repair_authorization : null;
  const incidentBlock = incident ? `<div class="pm-n-leg-report-incident"><strong>执行事故 ${escapeHtml(predictionValue(incident.reason))}</strong><p>已付现金 ${escapeHtml(predictionNLegUnitsMoney(incident.paid_cash_units))} · 系统外处置后对账解锁</p>${repair ? `<p class="pm-n-leg-report-repair">修复授权基准：部分成交损失上限 ${escapeHtml(predictionNLegUnitsMoney(repair.max_partial_fill_loss_units))} · 自动修复损失上限 ${escapeHtml(predictionNLegUnitsMoney(repair.max_auto_repair_loss_units))} — 上限数字为完整修复终点估算、非最坏界</p>` : ""}</div>` : "";
  return `<article class="pm-n-leg-report-batch"><header><strong>批次 ${escapeHtml(nlegReportShortId(batch?.execution_batch_id))}</strong><span>${escapeHtml(nlegReportBatchStateLabel(batch?.state))} · ${escapeHtml(String(batch?.updated_at ?? "").slice(0, 16).replace("T", " "))}</span></header><div class="pm-check"><span>保证利润（冻结已证下界）</span><strong>${guaranteedText}</strong></div><div class="pm-check"><span>已付现金 / 费用</span><strong>${escapeHtml(predictionNLegUnitsMoney(batch?.paid_cash_units))} / ${escapeHtml(predictionNLegUnitsMoney(batch?.paid_fee_units))}</strong></div><div class="pm-check"><span>实际利润</span><strong>${actualText}</strong></div><div class="pm-check"><span>资金守恒</span><strong>${conservationText}</strong></div><div class="pm-check"><span>触发来源 / Episode</span><strong>${escapeHtml(nlegReportTriggerLabel(batch?.trigger_source))} · ${escapeHtml(nlegReportShortId(batch?.opportunity_episode_id, 10, 4))}</strong></div>${legRows ? `<table class="pm-n-leg-report-legs"><thead><tr><th>腿 · 方向</th><th>成交/委托</th><th>已付现金</th><th>费用</th><th>回执</th></tr></thead><tbody>${legRows}</tbody></table>` : ""}${incidentBlock}</article>`;
}
function nlegReportDrawer() {
  const reportState = state.predictionMarket?.nlegReport;
  if (!reportState || reportState.open !== true) return "";
  const base = `<aside class="pm-relation-drawer pm-n-leg-report-drawer" aria-label="执行报告" role="dialog" aria-modal="true"><header><div><h2>执行报告</h2><p>N_LEG 批次事实 · 只列事实，不含建议 · 实际利润未结算时如实标注</p></div><button type="button" class="pm-relation-close" data-action="close-nleg-report" aria-label="关闭执行报告">关闭</button></header><div class="pm-relation-drawer-body">`;
  if (reportState.error) return `${base}<p class="pm-n-leg-report-error">执行报告加载失败：${escapeHtml(String(reportState.error))}</p></div></aside>`;
  const report = reportState.data;
  if (!report) return `${base}<p class="pm-n-leg-report-loading">正在生成执行报告…</p></div></aside>`;
  const ledger = report.ledger && typeof report.ledger === "object" ? report.ledger : {};
  const batches = Array.isArray(report.batches) ? report.batches : [];
  const requests = report.queue && Array.isArray(report.queue.requests) ? report.queue.requests : [];
  const requestRows = requests.length ? requests.map((row) => {
    const stateText = row.state === "ABANDONED" ? `已离队 · ${escapeHtml(predictionValue(row.abandon_reason))} · 仅监控` : escapeHtml(NLEG_REPORT_REQUEST_LABELS[row.state] || String(row.state ?? "-"));
    return `<p class="pm-n-leg-report-request">#${Number(row.fifo_index)} · ${escapeHtml(String(row.component_id ?? "").replace(/^component:/, ""))} · ${stateText} · ${escapeHtml(String(row.created_at ?? "").slice(0, 16).replace("T", " "))}</p>`;
  }).join("") : `<p class="pm-n-leg-report-request pm-relation-empty">队内请求为空。</p>`;
  return `${base}<div class="pm-n-leg-report-ledger"><span>总未结算资本 <strong>${escapeHtml(predictionNLegUnitsMoney(ledger.total_unsettled_capital_units))}</strong></span><span>活跃批次 <strong>${ledger.active_execution_batch_id ? escapeHtml(nlegReportShortId(ledger.active_execution_batch_id)) : "无"}</strong></span><span>模式 <strong>${escapeHtml(predictionValue(ledger.mode))}</strong></span><span>熔断 <strong>${ledger.breaker_open === true ? "开" : "关"}</strong></span></div><section class="pm-n-leg-report-batches">${batches.length ? batches.map(nlegReportBatchArticle).join("") : `<p class="pm-relation-empty">尚无批次。首笔真实订单确认后，这里逐批列出事实。</p>`}</section><section class="pm-n-leg-report-queue"><h3>队内请求</h3>${requestRows}</section><footer class="pm-n-leg-report-footer">只读事实快照 · 生成时间 ${escapeHtml(String(report.generated_at ?? "").slice(0, 19).replace("T", " "))} · CLI 导出 reports/n_leg_canary/</footer></div></aside>`;
}
async function loadNLegReport() {
  if (!predictionNLegReadAllowed()) return;
  const prediction = state.predictionMarket;
  const generation = prediction.nLegReadGeneration;
  prediction.nlegReportRequestController?.abort?.();
  const controller = new AbortController();
  prediction.nlegReportRequestController = controller;
  if (!state.predictionMarket.nlegReport) state.predictionMarket.nlegReport = { open: false, data: null, error: null };
  state.predictionMarket.nlegReport.open = true;
  state.predictionMarket.nlegReport.data = null;
  state.predictionMarket.nlegReport.error = null;
  renderPredictionMarket();
  try {
    const response = await fetch(predictionRequestUrl("/api/prediction-arbitrage/n-leg/report"), { cache: "no-store", credentials: "same-origin", signal: controller.signal });
    if (!predictionNLegReadCurrent(generation, controller)) return;
    if (!response.ok) throw new Error(`执行报告 ${response.status}`);
    const data = await response.json();
    if (!predictionNLegReadCurrent(generation, controller)) return;
    state.predictionMarket.nlegReport.data = data;
  } catch (error) {
    if (!predictionNLegReadCurrent(generation, controller)) return;
    state.predictionMarket.nlegReport.error = String(error?.message || error);
  } finally {
    if (prediction.nlegReportRequestController === controller) prediction.nlegReportRequestController = null;
  }
  if (predictionNLegReadCurrent(generation, controller)) renderPredictionMarket();
}

async function loadRelationReview(view = state.predictionMarket.relationReview.view, offset = 0) {
  if (!predictionNLegReadAllowed()) return;
  const review = state.predictionMarket.relationReview;
  const prediction = state.predictionMarket;
  const generation = prediction.nLegReadGeneration;
  prediction.relationReviewRequestController?.abort?.();
  const controller = new AbortController();
  prediction.relationReviewRequestController = controller;
  const fetchPage = async (pageOffset) => {
    const response = await fetch(predictionRequestUrl(`/api/prediction-arbitrage/relations?view=${encodeURIComponent(review.view)}&limit=${RELATION_REVIEW_PAGE_SIZE}&offset=${pageOffset}`), {cache: "no-store", credentials: "same-origin", signal: controller.signal});
    if (!predictionNLegReadCurrent(generation, controller)) return null;
    if (!response.ok) throw new Error(`关系目录 ${response.status}`);
    return response.json();
  };
  review.loading = true; review.view = view; review.offset = Math.max(0, Number(offset) || 0); review.detail = null; renderPredictionMarket();
  try {
    const result = await fetchPage(review.offset);
    if (!result || !predictionNLegReadCurrent(generation, controller)) return;
    review.items = Array.isArray(result.items) ? result.items : [];
    review.total = Number(result.total || 0);
    review.pendingCount = Number(result.pending_count || 0);
    const maxOffset = Math.max(0, (Math.ceil(review.total / RELATION_REVIEW_PAGE_SIZE) - 1) * RELATION_REVIEW_PAGE_SIZE);
    if (review.total > 0 && review.offset > maxOffset) {
      review.offset = maxOffset;
      const clamped = await fetchPage(review.offset);
      if (!clamped || !predictionNLegReadCurrent(generation, controller)) return;
      review.items = Array.isArray(clamped.items) ? clamped.items : [];
    }
  } catch (error) {
    if (!predictionNLegReadCurrent(generation, controller)) return;
    state.predictionMarket.error = error instanceof Error ? error.message : String(error); review.items = []; review.total = 0;
  } finally {
    if (prediction.relationReviewRequestController === controller) prediction.relationReviewRequestController = null;
    if (predictionNLegReadCurrent(generation, controller)) { review.loading = false; renderPredictionMarket(); }
  }
}

async function loadRelationDetail(relationVersionId) {
  if (!predictionNLegReadAllowed()) return;
  const prediction = state.predictionMarket;
  const generation = prediction.nLegReadGeneration;
  prediction.relationDetailRequestController?.abort?.();
  const controller = new AbortController();
  prediction.relationDetailRequestController = controller;
  try {
    const response = await fetch(predictionRequestUrl(`/api/prediction-arbitrage/relations/${encodeURIComponent(relationVersionId)}`), {cache: "no-store", credentials: "same-origin", signal: controller.signal});
    if (!predictionNLegReadCurrent(generation, controller)) return;
    if (!response.ok) throw new Error(`关系详情 ${response.status}`);
    const detail = await response.json();
    if (!predictionNLegReadCurrent(generation, controller)) return;
    state.predictionMarket.relationReview.detail = detail;
  } catch (error) {
    if (!predictionNLegReadCurrent(generation, controller)) return;
    state.predictionMarket.error = error instanceof Error ? error.message : String(error);
  } finally {
    if (prediction.relationDetailRequestController === controller) prediction.relationDetailRequestController = null;
  }
  if (!predictionNLegReadCurrent(generation, controller)) return;
  renderPredictionMarket();
  document.querySelector("[data-relation-detail]")?.scrollIntoView?.({block: "nearest", behavior: "smooth"});
}

async function mutateRelation(action, relationVersionId) {
  const expected = relationExpected(state.predictionMarket.relationReview.detail);
  const body = action === "approve" ? {...expected, confirm: true} : {...expected, reason: document.querySelector("[data-relation-reason]")?.value || "other", note: document.querySelector("[data-relation-note]")?.value || "", confirm: true};
  try { await predictionPost(`/api/prediction-arbitrage/relations/${encodeURIComponent(relationVersionId)}/${action}`, body); await loadRelationReview(state.predictionMarket.relationReview.view, state.predictionMarket.relationReview.offset); await fetchPredictionState(); }
  catch (error) { state.predictionMarket.error = error instanceof Error ? error.message : String(error); renderPredictionMarket(); }
}

function handlePredictionMarketChange(event) {
  const directionSelect = event.target.closest?.("[data-lp-direction]");
  if (directionSelect) {
    const conditionId = String(directionSelect.dataset.conditionId || "");
    const outcome = String(directionSelect.value || "");
    if (!conditionId || !outcome) return;
    state.predictionMarket.lpDirectionSelections[conditionId] = outcome;
    renderPredictionMarket();
    return;
  }
  const filter = event.target.closest?.("[data-observation-filter]");
  if (!filter) return;
  state.predictionMarket.observationFilter = String(filter.value || "all");
  renderPredictionMarket();
}

function lpDashboardTodayActiveRows() {
  const dashboard = state.predictionMarket.lpDashboard;
  const rows = dashboard && typeof dashboard === "object"
    && Array.isArray(dashboard.lp_orders_today) ? dashboard.lp_orders_today : [];
  return rows.filter((row) => row && typeof row === "object"
    && lpDashboardTodayHasActiveOrder(row));
}

async function handlePredictionMarketClick(event) {
  const autoAction = event.target.closest("[data-lp-auto-action]");
  if (autoAction && !autoAction.disabled) {
    await controlLpAuto(autoAction.dataset.lpAutoAction);
    return;
  }
  const lpAutoReport = event.target.closest("[data-action='lp-auto-report-load']");
  if (lpAutoReport) { await loadLpAutoReport(lpAutoReport.dataset.reportDate || ""); return; }
  const predictionTab = event.target.closest("[data-prediction-tab]");
  if (predictionTab) {
    selectPredictionTab(predictionTab.dataset.predictionTab || "lp");
    return;
  }
  const lpPreparationRecovery = event.target.closest("[data-action='lp-preparation-recovery']");
  if (lpPreparationRecovery && !lpPreparationRecovery.disabled
    && state.predictionMarket.csrfToken
    && !state.predictionMarket.lpDashboardRequestInFlight
    && !state.predictionMarket.lpPreparationRecoveryInFlight) {
    state.predictionMarket.lpPreparationRecoveryInFlight = true;
    renderPredictionMarket();
    try {
      await predictionPost("/api/prediction-arbitrage/lp/candidates/refresh", {manual_recovery: true});
      await fetchPredictionLpDashboard();
    } catch (error) {
      state.predictionMarket.error = error instanceof Error ? error.message : String(error);
    } finally {
      state.predictionMarket.lpPreparationRecoveryInFlight = false;
      renderPredictionMarket();
    }
    return;
  }
  const lpRefresh = event.target.closest("[data-action='lp-dashboard-refresh']");
  if (lpRefresh && !lpRefresh.disabled && !state.predictionMarket.lpPreparationRecoveryInFlight) {
    try {
      await predictionPost("/api/prediction-arbitrage/lp/candidates/refresh", {});
      await fetchPredictionLpDashboard();
    } catch (error) {
      state.predictionMarket.error = error instanceof Error ? error.message : String(error);
      renderPredictionMarket();
    }
    return;
  }
  const lpCancelOrder = event.target.closest("[data-action='lp-cancel-order']");
  if (lpCancelOrder && !lpCancelOrder.disabled) {
    const orderId = String(lpCancelOrder.dataset.orderId || "");
    const row = lpDashboardTodayActiveRows().find(
      (item) => String(item.order_id || "") === orderId);
    if (row) openPredictionModal("lp_cancel", lpCancelOrder, {scope: "order", orders: [row]});
    return;
  }
  const lpCancelMarket = event.target.closest("[data-action='lp-cancel-market']");
  if (lpCancelMarket && !lpCancelMarket.disabled) {
    const conditionId = String(lpCancelMarket.dataset.conditionId || "");
    const orders = lpDashboardTodayActiveRows().filter(
      (row) => String(row.condition_id || "") === conditionId);
    if (orders.length) {
      openPredictionModal("lp_cancel", lpCancelMarket, {scope: "market", conditionId, orders});
    }
    return;
  }
  const lpCancelAll = event.target.closest("[data-action='lp-cancel-all']");
  if (lpCancelAll && !lpCancelAll.disabled) {
    const orders = lpDashboardTodayActiveRows();
    if (orders.length) openPredictionModal("lp_cancel", lpCancelAll, {scope: "all", orders});
    return;
  }
  // Issue 158: candidate row 挂单 entry — opens the lp_order intent modal.
  const lpOrderEntry = event.target.closest("[data-action='lp-order-entry']");
  if (lpOrderEntry && !lpOrderEntry.disabled) {
    const conditionId = String(lpOrderEntry.dataset.conditionId || "");
    const outcome = String(lpOrderEntry.dataset.outcome || "");
    const dashboard = state.predictionMarket.lpDashboard;
    const row = lpDashboardRows(dashboard?.candidates).find((item) => {
      if (String(item?.condition_id || "") !== conditionId) return false;
      return !outcome || String(item?.selected_direction?.outcome || "") === outcome;
    });
    if (row) openPredictionModal("lp_order", lpOrderEntry, lpOrderIntent(row));
    return;
  }
  // Issue 158: today-table 加量 entry — only rendered on session rows.
  const lpAugmentEntry = event.target.closest("[data-action='lp-augment-entry']");
  if (lpAugmentEntry && !lpAugmentEntry.disabled) {
    const conditionId = String(lpAugmentEntry.dataset.conditionId || "");
    // Issue 165: the button names its owning session; a click whose
    // session_id is empty or no longer matches the served session list is
    // ignored (no modal).  Issue 166: the served list is lp_sessions — the
    // click must land on its own group, not "whatever session is newest".
    const sessionId = String(lpAugmentEntry.dataset.sessionId || "");
    const dashboard = state.predictionMarket.lpDashboard;
    const servedList = Array.isArray(dashboard?.lp_sessions)
      && dashboard.lp_sessions.length
      ? dashboard.lp_sessions
      : (dashboard?.lp_session ? [dashboard.lp_session] : []);
    const session = servedList.find((row) => row && typeof row === "object"
      && String(row.session_id || "") === sessionId) || null;
    if (!sessionId || !session) {
      return;
    }
    const group = lpDashboardTodayGroups(lpDashboardRows(dashboard?.lp_orders_today))
      .find((item) => item.conditionId === conditionId);
    if (group && session) {
      openPredictionModal("lp_augment", lpAugmentEntry, lpAugmentIntent(group.orders, session));
    }
    return;
  }
  const llmProviderButton = event.target.closest("[data-llm-provider]");
  if (llmProviderButton && !llmProviderButton.disabled) {
    await switchPredictionLlmProvider(llmProviderButton.dataset.llmProvider || "");
    return;
  }
  const nlegUnlock = event.target.closest("[data-action='nleg-incident-unlock']");
  if (nlegUnlock && !nlegUnlock.disabled) {
    openPredictionModal("nleg_incident", nlegUnlock, state.predictionMarket.payload?.n_leg_incident || {});
    return;
  }
  const nlegConfirm = event.target.closest("[data-action='nleg-confirm']");
  if (nlegConfirm && !nlegConfirm.disabled) {
    const opportunityId = String(nlegConfirm.dataset.opportunityId || "");
    const row = predictionUnifiedFilteredRows(state.predictionMarket.payload, state.predictionMarket.filter)
      .find((item) => String(predictionOpportunityDisplay(item).opportunity_id || "") === opportunityId);
    if (!row) {
      state.predictionMarket.error = "机会已变化或已失效，请刷新后重新确认。";
      renderPredictionMarket();
      return;
    }
    const opportunity = predictionOpportunityDisplay(row);
    openPredictionModal("nleg_order", nlegConfirm, {
      n_leg_solution: opportunity.n_leg_solution,
      n_leg_caps: state.predictionMarket.payload?.n_leg_orders?.caps,
      title: opportunity.title,
      qualification_policy_version: opportunity.qualification_policy_version,
    });
    return;
  }
  if (event.target.closest("[data-action='open-relation-review']")) { state.predictionMarket.relationReview.open = true; await loadRelationReview("pending_approval", 0); return; }
  if (event.target.closest("[data-action='close-relation-review']")) { state.predictionMarket.relationReview.open = false; state.predictionMarket.relationReview.detail = null; renderPredictionMarket(); return; }
  if (event.target.closest("[data-action='open-nleg-report']")) { await loadNLegReport(); return; }
  if (event.target.closest("[data-action='close-nleg-report']")) { state.predictionMarket.nlegReport = { open: false, data: null, error: null }; renderPredictionMarket(); return; }
  const openRelationView = event.target.closest("[data-open-relation-view]");
  if (openRelationView) { state.predictionMarket.relationReview.open = true; await loadRelationReview(openRelationView.dataset.openRelationView || "pending_approval", 0); return; }
  const relationView = event.target.closest("[data-relation-view]");
  if (relationView) { await loadRelationReview(relationView.dataset.relationView || "pending_approval", 0); return; }
  if (event.target.closest("[data-action='relation-prev-page']")) { await loadRelationReview(state.predictionMarket.relationReview.view, Math.max(0, state.predictionMarket.relationReview.offset - RELATION_REVIEW_PAGE_SIZE)); return; }
  if (event.target.closest("[data-action='relation-next-page']")) { await loadRelationReview(state.predictionMarket.relationReview.view, state.predictionMarket.relationReview.offset + RELATION_REVIEW_PAGE_SIZE); return; }
  if (event.target.closest("[data-action='relation-back']")) { state.predictionMarket.relationReview.detail = null; renderPredictionMarket(); return; }
  const relationAction = event.target.closest("[data-action='approve-relation'], [data-action='reject-relation'], [data-action='revoke-relation']");
  if (relationAction) { await mutateRelation(relationAction.dataset.action.replace("-relation", ""), relationAction.dataset.relationVersionId || ""); return; }
  const relationRow = event.target.closest("[data-relation-version-id]");
  if (relationRow) {
    const review = state.predictionMarket.relationReview;
    if (relationRow.dataset.relationVersionId === review.detail?.version_id) {
      review.detail = null;
      renderPredictionMarket();
      return;
    }
    await loadRelationDetail(relationRow.dataset.relationVersionId || "");
    return;
  }
  if (event.target.closest("[data-prediction-filter-engine]")) {
    const current = state.predictionMarket.filter.engine || "all";
    state.predictionMarket.filter.engine = current === "all" ? "N_LEG" : "all";
    renderPredictionMarket();
    return;
  }
  const filterKind = event.target.closest("[data-prediction-filter-kind]");
  if (filterKind) {
    state.predictionMarket.filter.kind = filterKind.dataset.predictionFilterKind || "all";
    renderPredictionMarket();
    return;
  }
  if (event.target.closest("[data-prediction-filter-legs]")) {
    const current = state.predictionMarket.filter.legs;
    state.predictionMarket.filter.legs = current === null || current === undefined ? "2" : null;
    renderPredictionMarket();
    return;
  }
  if (event.target.closest("[data-prediction-filter-scope]")) {
    const current = state.predictionMarket.filter.scope;
    state.predictionMarket.filter.scope = current === "cross_venue" ? "same_venue" : current === "same_venue" ? null : "cross_venue";
    renderPredictionMarket();
    return;
  }
  const history = event.target.closest("[data-history]");
  if (history) {
    state.predictionMarket.historyKind = history.dataset.history || "signals";
    renderPredictionMarket();
    loadPredictionHistory(state.predictionMarket.historyKind);
    return;
  }
  const reset = event.target.closest("[data-action='open-reset']");
  if (reset) {
    openPredictionModal("reset", reset, state.predictionMarket.payload?.breaker?.incident || {incident_id: reset.dataset.incidentId});
    return;
  }
  const cleanup = event.target.closest("[data-action='open-allowance-cleanup']");
  if (cleanup) {
    openPredictionModal("allowance_cleanup", cleanup, state.predictionMarket.payload?.predict_allowance_cleanup || {});
    return;
  }
  const pauseCrossAuto = event.target.closest("[data-action='pause-cross-auto']");
  if (pauseCrossAuto) {
    pauseCrossAuto.disabled = true;
    try {
      await predictionPost("/api/prediction-arbitrage/cross-auto/pause", {confirm: true});
    } catch (error) {
      state.predictionMarket.error = error instanceof Error ? error.message : String(error);
    }
    await fetchPredictionState();
    return;
  }
  const modeButton = event.target.closest("[data-action='set-mode']");
  if (modeButton) {
    const mode = String(modeButton.dataset.mode || "");
    if (!["observe_only", "manual", "auto"].includes(mode)) return;
    try {
      await predictionPost("/api/prediction-arbitrage/mode", {mode});
    } catch (error) {
      state.predictionMarket.error = error instanceof Error ? error.message : String(error);
    }
    await fetchPredictionState();
    return;
  }
  const participate = event.target.closest("[data-action='participate']");
  if (!participate || participate.disabled) return;
  const opportunityId = participate.dataset.opportunityId;
  if (!opportunityId) return;
  participate.disabled = true;
  try {
    const preview = await predictionPost("/api/prediction-arbitrage/preview", {opportunity_id: opportunityId});
    if (!preview || preview.state !== "previewed" || !String(preview.preview_id || "").trim()) {
      const reason = String(preview?.reason || "preview_unavailable");
      const messages = {
        circuit_breaker_open: "交易已熔断，暂不允许下单。",
        active_execution: "已有另一笔交易正在执行，请等待完成。",
        execution_lock: "已有另一笔操作正在确认，请稍后重试。",
        opportunity_unavailable: "机会已变化或已失效，请刷新后重新检查。",
        readiness_unavailable: "交易钱包、地区或余额检查未通过。",
      };
      state.predictionMarket.error = messages[reason] || `后台拒绝预览：${reason}`;
      participate.disabled = false;
      renderPredictionMarket();
      return;
    }
    if (!predictionPreviewIsComplete(preview)) {
      state.predictionMarket.error = "预览数据不完整，未下单";
      participate.disabled = false;
      renderPredictionMarket();
      return;
    }
    openPredictionModal("order", participate, preview);
  } catch (error) {
    state.predictionMarket.error = error instanceof Error ? error.message : String(error);
    participate.disabled = false;
    renderPredictionMarket();
  }
}

async function handlePredictionModalClick(event) {
  const action = event.target.closest("[data-modal-action]")?.dataset.modalAction;
  // Issue 162（定案 4）：LP 三类弹窗在 busy 期间放行「取消」——转圈可放弃。
  const busyCancelAllowed = action === "cancel" && LP_MODAL_KINDS.has(predictionModal?.kind || "");
  if ((!action || predictionModal.busy) && !busyCancelAllowed) return;
  // Issue 162（定案 3）：捕获点击时刻的模态世代与 kind；每个 await 之后先
  // 校验——弹窗已被关闭/替换（epoch 或 kind 变化）的迟到响应整包丢弃。
  const modalEpoch = predictionModal.epoch;
  const modalKind = predictionModal.kind;
  const staleResponse = () => predictionModal.epoch !== modalEpoch || predictionModal.kind !== modalKind;
  if (action === "cancel") {
    closePredictionModal();
    return;
  }
  // Issue 158: case switches are instant UI-only re-renders.
  if (action === "lp-order-case") {
    lpOrderSwitchCase(String(event.target.closest("[data-modal-action]")?.dataset.caseMode || ""));
    return;
  }
  if (action === "lp-augment-case") {
    lpAugmentSwitchCase(String(event.target.closest("[data-modal-action]")?.dataset.caseMode || ""));
    return;
  }
  // Issue 162（定案 6）：动作-kind 匹配守卫——映射内动作必须命中当前 kind，
  // 未登记动作视为不匹配；一律 return，不发请求、不进 busy。
  if (PREDICTION_MODAL_ACTION_KINDS[action] !== predictionModal.kind) return;
  if (action === "lp-cancel-confirm") {
    await confirmLpCancel();
    return;
  }
  // Issue 163 定案 6/7：幂等键在确认点击时铸造；一次最终确认 = 立即关窗 +
  // 「正在提交」toast + 10 秒共享锁 + 恰一次 POST。回执无论多迟都按键归属
  // 自己那条 toast，与弹窗世代无关；HTTP 200 不等于成功——一律按 body.state 分支。
  if (action === "lp-order-confirm" || action === "lp-augment-confirm") {
    const augment = action === "lp-augment-confirm";
    const data = predictionModal.data;
    const root = elements["prediction-market-modal-root"];
    if (augment) {
      const qtyInput = root.querySelector("#lp-augment-quantity");
      const priceInput = root.querySelector("#lp-augment-price");
      if (qtyInput) data.quantity = qtyInput.value;
      if (priceInput) data.price = priceInput.value;
    } else {
      const priceInput = root.querySelector("#lp-order-price");
      const qtyInput = root.querySelector("#lp-order-quantity");
      if (priceInput) data.price = priceInput.value;
      if (qtyInput) data.quantity = qtyInput.value;
    }
    // 定案 2：本地格式校验不过 → 不发请求、不锁 10 秒，只弹「格式异常」toast。
    const priceText = String(data.price ?? "").trim();
    const quantityText = String(data.quantity ?? "").trim();
    const priceNumber = Number(priceText);
    const quantityNumber = Number(quantityText);
    const formatBad = augment
      ? !quantityText || !Number.isFinite(quantityNumber) || quantityNumber <= 0
        || (priceText && (!Number.isFinite(priceNumber) || priceNumber <= 0))
      : !priceText || !quantityText
        || !Number.isFinite(priceNumber) || !Number.isFinite(quantityNumber);
    if (formatBad) {
      lpSubmitToastPush({
        id: predictionIdempotencyKey(),
        kind: "danger",
        main: "格式异常：价格或数量不是有效数字，未提交",
        sub: "请修正后重新确认；本次未发出请求、未锁定入口",
      });
      renderPredictionMarket();
      return;
    }
    const key = predictionIdempotencyKey();
    let path;
    let body;
    let submittingMain;
    if (augment) {
      path = "/api/prediction-arbitrage/lp/augment";
      body = {
        session_id: String(data.session?.session_id || ""),
        quantity: quantityText,
        idempotency_key: key,
      };
      // Issue 167 D1：可选价位——默认组价，可改；空值沿用服务端组价缺省。
      if (priceText) body.price = priceText;
      submittingMain = `正在提交 · 追加 ${quantityText} 份 @ ${priceText || String(data.session?.price ?? "")}`;
    } else {
      const row = data.row && typeof data.row === "object" ? data.row : {};
      path = "/api/prediction-arbitrage/lp/orders";
      body = {
        market_id: String(row.market_id || ""),
        condition_id: String(row.condition_id || ""),
        // Issue 174: token 与 outcome 同源——取弹窗捕获的 selected_direction（data.token），
        // 不取行顶层评估腿；两腿不同时旧取法会发 mismatch 组合被服务端 #163 拒绝。
        token_id: String(data.token || ""),
        outcome: String(data.outcome || ""),
        price: priceText,
        quantity: quantityText,
        review_at: String(data.reviewAtText ?? ""),
        idempotency_key: key,
      };
      // informational-only 加 5% 默认量原样透传（同 #158 预检体约定）。
      const rowTarget = row.estimated_target_quantity;
      if (rowTarget !== null && rowTarget !== undefined && String(rowTarget).trim() !== "") {
        body.estimated_target_quantity = String(rowTarget);
      }
      // Only the trial anchors to its captured quote level; legacy rows
      // omit the marker and retain the server's default level one.
      if (data.mode === "trial") {
        body.candidate_policy = "best_bid_minimum";
        if (data.trialBidLevel !== null && data.trialBidLevel !== undefined) {
          body.candidate_bid_level = data.trialBidLevel;
        }
      }
      submittingMain = `正在提交 · 买 ${body.outcome} @ ${priceText} × ${quantityText} 份`;
    }
    closePredictionModal();
    lpSubmitToastPush({
      id: key,
      kind: "submitting",
      main: submittingMain,
      sub: "服务端按提交时最新事实校验，通过即挂 post-only · 入口锁定 10 秒",
    });
    lpSubmitStartCooldown(key);
    renderPredictionMarket();
    try {
      const result = await predictionPost(path, body);
      const registered = lpSubmitToastResult(key, result, augment ? "augment" : "entry");
      if (registered) {
        const sessionShort = lpShortSessionId(result?.session_id);
        state.predictionMarket.lpCancelSummary = augment
          ? `已追加 · ${quantityText} 份 @ ${String(data.price ?? data.session?.price ?? "")} · 并入会话 ${sessionShort}`
          : `已登记 · 会话 ${sessionShort} · 位置保护已生效`;
        await fetchPredictionLpDashboard();
      }
      renderPredictionMarket();
    } catch (error) {
      // 网络异常 = 结果未知：按键更新自己的 toast，绝不宣称 失败/成功。
      lpSubmitToastUpdate(key, {
        kind: "unknown",
        main: "结果未知：网络错误，是否已提交未知",
        sub: "系统不会自动重试 · 请以看板与会话状态为准",
      });
      renderPredictionMarket();
    }
    return;
  }
  setPredictionModalBusy(true);
  try {
    if (action === "arm-cleanup") {
      predictionModal.data = {...(predictionModal.data || {}), armed: true};
      elements["prediction-market-modal-root"].innerHTML = predictionModalHtml("allowance_cleanup", predictionModal.data);
      elements["prediction-market-modal-root"].querySelector(".pm-modal")?.focus();
      predictionModal.busy = false;
      return;
    }
    if (action === "cleanup") {
      const result = await predictionPost("/api/prediction-arbitrage/predict-allowance/cleanup", {confirm: true});
      if (staleResponse()) return;
      if (!result || ["locked", "busy", "rejected"].includes(String(result.state || "").toLowerCase())) {
        throw new Error("授权清零未完成，系统继续保持只读。");
      }
      closePredictionModal();
      await fetchPredictionState();
      return;
    }
    if (action === "nleg-confirm") {
      const solution = predictionModal.data?.n_leg_solution;
      const fingerprint = String(solution?.execution?.execution_solution_fingerprint || "");
      if (!fingerprint) throw new Error("方案指纹未返回，未入队。");
      const result = await predictionPost("/api/prediction-arbitrage/n-leg/orders/confirm", {
        component_id: String(solution?.component_id || ""),
        displayed_fingerprint: fingerprint,
        idempotency_key: predictionIdempotencyKey(),
      });
      if (staleResponse()) return;
      if (!result || String(result.state || "") !== "PENDING") {
        throw new Error("确认未入队，请刷新后重试。");
      }
      closePredictionModal();
      await fetchPredictionState();
      return;
    }
    if (action === "nleg-incident-unlock") {
      // Server re-checks batch receipts + ledger before actually releasing;
      // any inconsistency keeps the incident state.
      await predictionPost("/api/prediction-arbitrage/n-leg/incidents/acknowledge", {
        execution_batch_id: String(predictionModal.data?.execution_batch_id || ""),
        actor: "operator",
        reconciliation: "fresh_clean",
      });
      if (staleResponse()) return;
      closePredictionModal();
      await fetchPredictionState();
      return;
    }
    if (action === "confirm") {
      const previewId = predictionModal.data?.preview_id || predictionModal.data?.id;
      if (!String(previewId || "").trim()) throw new Error("预览已失效，请重新获取机会。");
      const result = await predictionPost("/api/prediction-arbitrage/executions", {preview_id: String(previewId || ""), idempotency_key: predictionIdempotencyKey()});
      if (staleResponse()) return;
      if (!result || ["locked", "busy", "rejected"].includes(String(result.state || "").toLowerCase()) || !String(result.execution_id || "").trim()) {
        throw new Error("确认时后台未接受订单，未提交新的执行任务。");
      }
      state.predictionMarket.activeExecutionId = result.execution_id || "";
      closePredictionModal();
      await fetchPredictionState();
      return;
    }
    if (action === "reset") {
      const incidentId = predictionModal.data?.incident_id || predictionModal.data?.id;
      const result = await predictionPost("/api/prediction-arbitrage/circuit-breaker/reset", {incident_id: String(incidentId || "")});
      if (staleResponse()) return;
      if (!result || ["locked", "busy", "rejected"].includes(String(result.state || "").toLowerCase())) {
        const reason = String(result?.reason || "").trim();
        throw new Error(reason ? `事故仍未解除：${predictionReasonLabel(reason)}` : "事故仍未解除，系统继续保持熔断。");
      }
      closePredictionModal();
      await fetchPredictionState();
    }
  } catch (error) {
    // Issue 162（定案 3）：弹窗已被关闭/替换的迟到失败——不写 error、不改
    // busy、不渲染（弹窗此刻可能属于另一个会话）。
    if (staleResponse()) return;
    state.predictionMarket.error = error instanceof Error ? error.message : String(error);
    setPredictionModalBusy(false);
    renderPredictionMarket();
  }
}

function handlePredictionModalKeydown(event) {
  if (!predictionModal.kind) return;
  if (event.key === "Escape") {
    event.preventDefault();
    // Issue 162（定案 4）：LP 三类弹窗 busy 期间 Esc 仍可关闭；关闭即让
    // 迟到响应按 epoch 过期。
    if (!predictionModal.busy || LP_MODAL_KINDS.has(predictionModal.kind)) closePredictionModal();
    return;
  }
  if (event.key !== "Tab") return;
  const modal = elements["prediction-market-modal-root"].querySelector(".pm-modal");
  if (!modal) return;
  const focusable = [...modal.querySelectorAll("button:not(:disabled), [href], input:not(:disabled), select:not(:disabled), [tabindex]:not([tabindex='-1'])")];
  if (!focusable.length) return;
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first.focus();
  }
}

function kellyExperimentStatusLabel(status) {
  const labels = {
    active: { label: "运行中", className: "status-ok" },
    completed: { label: "已完成", className: "status-ok" },
    draft: { label: "草稿", className: "status-muted" },
    paused: { label: "已暂停", className: "status-warn" },
    running: { label: "运行中", className: "status-ok" },
    stopped: { label: "已停止", className: "status-muted" },
  };
  const key = formatPlain(status).toLowerCase();
  return labels[key] || { label: formatPlain(status), className: "status-muted" };
}

function kellySampleStageLabel(stage) {
  const labels = {
    complete: "样本完成",
    enough: "样本足够",
    insufficient: "样本不足",
    open: "采样中",
    ready: "待采样",
  };
  const key = formatPlain(stage).toLowerCase();
  return labels[key] || formatPlain(stage);
}

function renderDashboardViews() {
  renderHeaderSummary();
  const broker = state.brokerFilter;
  const selector = `#account-${broker}-view-panel`;
  const container = elements["account-holdings"] || elements["holdings-body"];
  const frozenPanel = state.accountViews[broker] === "report" && state.trendReportHistories[broker]?.open
    ? container?.querySelector(selector)
    : null;
  renderAccountHoldings();
  if (frozenPanel) container?.querySelector(selector)?.replaceWith(frozenPanel);
}

const TREND_REASON_LABELS = {
  protection_line_already_triggered: "活动保护线已触发",
  danger_signal: "危险信号触发",
  left_trend_right_side: "右侧趋势已结束",
  holding_signal_unknown: "趋势信号不完整",
  symbol_mapping_conflict: "趋势代码映射异常",
  holding_trend_excluded: "已排除趋势查询",
  holding_kline_unavailable: "持仓日线数据不可用",
  holding_lot_size_unavailable: "持仓整手信息不可用",
  trend_intact: "趋势保持完好",
  temperature_changed_to_flat: "趋势温度转平",
  overheat_take_profit: "沸腾/开香槟过热止盈",
  a_share_only: "仅限 A 股股票",
  temperature_missing: "个股趋势温度缺失",
  temperature_transition_not_entry: "不是温转热或温转沸",
  filter_price_missing: "筛选价缺失",
  filter_price_above_200: "筛选价高于 200 元",
  strength_missing: "趋势强度缺失",
  strength_below_95: "趋势强度低于 95",
  industry_id_missing: "行业 ID 缺失",
  industry_temperature_missing: "行业温度缺失",
  industry_temperature_not_hot: "行业温度未达到要求",
  phase_missing: "趋势节气缺失",
  phase_after_summer_solstice: "趋势节气晚于夏至",
  market_cap_missing: "市值缺失",
  market_cap_below_100: "市值低于 100 亿元",
  amount_missing: "日成交额缺失",
  amount_below_2: "日成交额不足 2 亿元",
  right_side_days_missing: "右侧天数缺失",
  right_side_not_true: "尚未进入右侧趋势",
  strength_not_above_90: "趋势强度未超过 90",
  right_side_days_not_below_10: "进入右侧趋势已满 10 天",
  not_tradable: "当前不可交易",
  amount_below_1: "日成交额不足 1 亿元",
  danger_unknown: "危险信号未知",
  name_missing: "标的名称缺失",
  asset_missing: "资产类型缺失",
  unsupported_asset: "不属于 A 股股票或境内 ETF",
  already_held: "当前账户已经持有",
  excluded_security: "北交所、ST 或退市标的",
  unsupported_exchange: "不属于沪深市场",
  atr_unavailable: "缺少 ATR 数据",
  data_date_mismatch: "数据日期不一致",
  strategy_identity_not_eligible: "策略身份不匹配",
  round_not_attributed: "无法归属策略",
  costs_incomplete: "成本不完整",
  net_return_unavailable: "净收益不可用",
  no_matching_opening_strategy_action: "无匹配开仓策略动作",
  scaled_entry_attribution_conflict: "加仓归属冲突",
  relative_rotation: "相对强度替换",
};

const CURRENT_TREND_EXIT_DISCIPLINES = new Set(["CN:v9", "US:v6", "HK:v6"]);

function currentTrendExitDiscipline(report) {
  const market = formatPlain(report?.market).toUpperCase();
  const version = formatPlain(report?.strategy_version);
  return CURRENT_TREND_EXIT_DISCIPLINES.has(`${market}:${version}`);
}

function trendReasonLabel(item, report) {
  const reason = formatPlain(item?.reason);
  if (reason !== "protection_line_already_triggered" || !currentTrendExitDiscipline(report)) {
    return TREND_REASON_LABELS[reason] || "未知动作或原因，需人工确认";
  }
  const initial = item?.initial_line;
  const active = item?.active_line;
  return initial !== null && initial !== undefined
    && active !== null && active !== undefined
    && String(initial) === String(active)
    ? "2×ATR14 硬止损"
    : "既有活动保护线触发";
}

function renderTrendReportEntry(broker) {
  if (!TREND_ACCOUNT_BROKERS.includes(broker)) return "";
  const report = state.dashboard?.trend_reports?.[broker] || {};
  const label = "当天趋势报告";
  const reviews = state.dashboard?.trend_reviews;
  const review = reviews?.[broker];
  const reviewLabel = `${formatPlain(review?.market_label || report.market_label || {futu:"美股",phillips:"港股",eastmoney:"A股"}[broker])}复盘`.replaceAll(" ", "");
  const reportButton = report.available
    ? `<button type="button" data-trend-report="${escapeHtml(broker)}">${label}</button>`
    : `<button type="button" disabled>${label}</button>`;
  const reviewButton = !review ? "" : review.available
    ? `<button type="button" data-trend-review="${escapeHtml(broker)}">${escapeHtml(reviewLabel)}</button>`
    : `<button type="button" disabled>${escapeHtml(reviewLabel)}</button>`;
  const details = report.available
    ? `<span>${escapeHtml(formatPlain(report.status_text || "今日已更新"))}</span><span>报告日期 ${escapeHtml(formatPlain(report.report_date))}</span><span>数据截至 ${escapeHtml(formatPlain(report.data_date))}</span>`
    : `<span>${escapeHtml(formatPlain(report.status_text || "今日暂无趋势报告"))}</span>`;
  const reviewStatus = review && !review.available
    ? `<span>${escapeHtml(formatPlain(review.status_text || "暂无复盘数据"))}</span>`
    : "";
  return `<div class="trend-report-entry${report.available ? "" : " trend-report-entry-empty"}">
    <div class="trend-entry-buttons">${reportButton}${reviewButton}</div>
    <div class="trend-entry-details">${details}${reviewStatus}</div>
  </div>`;
}

const TREND_REVIEW_METRICS = [
  {key:"period_net_return", label:"期间净收益率", percent:true, direction:"越高越好"},
  {key:"market_excess_return", label:"相对市场超额收益", percent:true, direction:"越高越好"},
  {key:"max_drawdown", label:"最大回撤", percent:true, direction:"越低越好"},
  {key:"calmar", label:"卡玛比率", percent:false, direction:"越高越好"},
  {key:"sharpe", label:"夏普比率", percent:false, direction:"越高越好"},
];

const TREND_REVIEW_SERIES = [
  {key:"discipline", label:"纪律模拟", shape:"solid-circle"},
  {key:"actual", label:"实际执行", shape:"hollow-circle"},
  {key:"same_period_benchmark", label:"同期市场", shape:"diamond"},
  {key:"market_1y", label:"市场 1 年", shape:"square"},
  {key:"market_5y", label:"市场 5 年", shape:"ring"},
];

function formatTrendReviewValue(cell, percent) {
  const value = numericValue(cell?.value);
  if (value === null) return formatPlain(cell?.reason || "数据不足");
  const formatted = value.toLocaleString("zh-CN", {maximumFractionDigits:2});
  return percent ? `${formatted}%` : formatted;
}

function trendReviewWindow(review, series, metric) {
  const context = review.benchmark_context || {};
  if (series.key === "discipline" || series.key === "actual") {
    const cutoff = review.metric_cutoffs?.[series.key];
    return cutoff ? `同期 · 截至 ${formatPlain(cutoff)}` : "同期";
  }
  if (series.key === "same_period_benchmark") {
    const dates = Array.isArray(context.same_period_dates) ? context.same_period_dates : [];
    return dates.length ? `同期 · ${formatPlain(dates[0])} 至 ${formatPlain(dates[dates.length - 1])}` : "同期";
  }
  const windowKey = series.key === "market_1y" ? "1Y" : "5Y";
  const window = context.windows?.[windowKey] || {};
  const basis = windowKey === "5Y" && metric.key === "period_net_return" ? " · CAGR" : "";
  return `${windowKey === "1Y" ? "1 年" : "5 年"}${window.start && window.cutoff ? ` · ${formatPlain(window.start)} 至 ${formatPlain(window.cutoff)}` : ""}${basis}`;
}

function renderTrendReviewMetric(review, metric) {
  const rows = TREND_REVIEW_SERIES.map((series) => {
    const cell = review.metrics?.[metric.key]?.[series.key] || {};
    const value = numericValue(cell.value);
    const display = formatTrendReviewValue(cell, metric.percent);
    const window = trendReviewWindow(review, series, metric);
    return `<li class="trend-review-series${value === null ? " unavailable" : ""}" data-series="${series.key}" aria-label="${escapeHtml(`${series.label}，${metric.label}，${display}，${window}`)}">
      <span><i class="trend-review-marker trend-review-shape-${series.shape}" aria-hidden="true"></i>${escapeHtml(series.label)}</span>
      <span class="trend-review-window">${escapeHtml(window)}</span>
      <strong>${escapeHtml(display)}</strong>
    </li>`;
  }).join("");
  return `<section class="trend-review-metric">
    <header><h3>${escapeHtml(metric.label)}</h3><span>${escapeHtml(metric.direction)}</span></header>
    <ul class="trend-review-values">${rows}</ul>
  </section>`;
}

function renderTrendReviewStatisticsMeta(review, key, label) {
  const detail = review.sample_details?.[key];
  const sampleCutoff = review.sample_cutoffs?.[key];
  const metricCutoff = review.metric_cutoffs?.[key];
  const disposition = detail?.available === true
    ? `<span>发现 ${detail.discovered_candidate_count} · 排除 ${detail.excluded_candidate_count} · 未闭环 ${detail.incomplete_open_candidate_count}</span>`
    : "<span>统计来源不可用</span>";
  const winRate = detail?.available !== true
    ? {unavailable:true, value:"统计来源不可用", detail:"来源不可用"}
    : detail.eligible_sample_count > 0 && hasValue(detail.win_rate)
      ? {value:trendRiskPercent(detail.win_rate), detail:`${formatDisplayNumber(detail.winning_sample_count)} 胜 / ${formatDisplayNumber(detail.eligible_sample_count)} 闭环`}
      : {value:"数据不足", detail:"0 闭环"};
  const exclusions = Array.isArray(detail?.exclusion_reasons) && detail.exclusion_reasons.length
    ? `<span>排除原因 ${detail.exclusion_reasons.map((item) => `${TREND_REASON_LABELS[item.reason] || "其他原因"} ${item.count}`).join("、")}</span>`
    : "";
  return `<div class="trend-review-statistics" data-series="${key}"><div class="trend-review-statistics-main"><strong>${escapeHtml(label)}</strong>
    <div class="trend-entry-details">
      ${sampleCutoff ? `<span>统计截至 ${escapeHtml(formatPlain(sampleCutoff))}</span>` : ""}
      ${metricCutoff ? `<span>指标截至 ${escapeHtml(formatPlain(metricCutoff))}</span>` : ""}
      ${disposition}${exclusions}
    </div></div><div class="trend-review-win-rate${winRate.unavailable ? " unavailable" : ""}"><span>完整交易胜率</span><strong>${escapeHtml(winRate.value)}</strong><small>${escapeHtml(winRate.detail)}</small></div></div>`;
}

function renderTrendReviewMatrix(review) {
  const refresh = review.benchmark_refresh || {};
  const refreshStatus = refresh.status === "failed"
    ? `<span>本月刷新失败：${escapeHtml(formatPlain(refresh.reason || "未知原因"))}</span>${refresh.attempted_at ? `<span>尝试于 ${escapeHtml(formatPlain(refresh.attempted_at))}</span>` : ""}`
    : refresh.status === "unavailable"
      ? `<span>长期市场基准不可用：${escapeHtml(formatPlain(refresh.reason || "数据不足"))}</span>`
      : "";
  return `<figure class="trend-review-matrix"><figcaption>策略与市场基准</figcaption>
    <div class="trend-review-matrix-meta">
      ${refreshStatus}
      ${refresh.cutoff ? `<span>市场数据截至 ${escapeHtml(formatPlain(refresh.cutoff))}</span>` : ""}
      ${refresh.completed_at ? `<span>快照更新 ${escapeHtml(formatPlain(refresh.completed_at))}</span>` : ""}
      <span>5 年收益 CAGR</span>
    </div>
    <div class="trend-review-statistics-grid">
      ${renderTrendReviewStatisticsMeta(review, "discipline", "纪律模拟")}
      ${renderTrendReviewStatisticsMeta(review, "actual", "实际执行")}
    </div>
    <div class="trend-review-column-groups"><span></span><div class="trend-review-column-groups-values"><span>策略表现</span><span>市场基准</span></div></div>
    ${TREND_REVIEW_METRICS.map((metric) => renderTrendReviewMetric(review, metric)).join("")}
  </figure>`;
}

function formatTrendReviewSampleCount(review, key, label) {
  const count = review.sample_counts?.[key];
  if (!Number.isInteger(count)) return `${label} 数据不可用`;
  const required = Number.isInteger(review.sample_counts?.required) ? review.sample_counts.required : 30;
  return count >= required ? `${label} ${count} 笔` : `${label} ${count} / ${required}，数据不足`;
}

function formatTrendReviewStrategyVersion(value) {
  const version = formatPlain(value);
  const match = /^v(.+)$/i.exec(version);
  return match ? `第 ${match[1]} 版` : version;
}

function renderTrendReviewWorkspace(review, embedded = false) {
  const snapshot = review.strategy_snapshot || {};
  const root = embedded ? "div" : "main";
  const statisticsStatus = review.statistics_status === "failed"
    ? "<span>统计刷新失败；报告继续使用上一个有效快照</span>"
    : review.statistics_status === "stale"
      ? "<span>统计快照已过期；报告继续使用上一个有效快照</span>"
    : review.statistics_status === "unavailable"
      ? "<span>统计刷新状态不可用</span>"
      : "";
  return `<${root} class="trend-review">
    <header class="trend-review-header">
      <div><p>${escapeHtml(`${formatPlain(review.broker_label)}｜${formatPlain(review.market_label)}`)}</p>
      <h1>${escapeHtml(`${formatPlain(review.market_label)}趋势复盘`)}</h1>
      <span>${escapeHtml(formatPlain(snapshot.strategy_name))}｜${escapeHtml(formatTrendReviewStrategyVersion(snapshot.strategy_version))}</span></div>
      <div class="trend-review-header-side">
        ${embedded ? "" : '<button type="button" data-close-trend-report>返回持仓看板</button>'}
        <span>${escapeHtml(formatTrendReviewSampleCount(review,"discipline","纪律模拟"))}</span>
        <span>${escapeHtml(formatTrendReviewSampleCount(review,"actual","实际执行"))}</span>
        ${review.common_cutoff ? `<span>共同截止日 ${escapeHtml(formatPlain(review.common_cutoff))}</span>` : ""}
        ${statisticsStatus}
      </div>
    </header>
    ${renderTrendReviewMatrix(review)}
  </${root}>`;
}

function renderTrendAction(item, kind, report) {
  const identity = [item.symbol, item.name].filter(Boolean).map(formatPlain).join(" ");
  const reason = trendReasonLabel(item, report);
  const fields = [identity];
  if (kind === "buy") {
    fields.push(`约 ${formatDisplayNumber(item.estimated_shares)} 股`);
    fields.push(`金额上限 ${formatDisplayNumber(item.target_amount)}`);
    fields.push(`预计保护线 ${formatDisplayNumber(item.estimated_initial_line)}`);
  } else {
    fields.push(reason);
    if (item.active_line !== null && item.active_line !== undefined && item.active_line !== "") {
      fields.push(`活动保护线 ${formatDisplayNumber(item.active_line)}`);
    }
  }
  return `<li>${fields.map(escapeHtml).join("<span>｜</span>")}</li>`;
}

function renderTrendStage(title, items, kind, report) {
  const rows = Array.isArray(items)
    ? items.filter((item) => item && typeof item === "object" && !Array.isArray(item))
    : [];
  return `<section class="trend-stage">
    <h2>${escapeHtml(title)}</h2>
    ${rows.length ? `<ol>${rows.map((item) => renderTrendAction(item, kind, report)).join("")}</ol>` : "<p>无</p>"}
  </section>`;
}

function renderTrendAudit(audit) {
  const candidates = Array.isArray(audit.candidates)
    ? audit.candidates.filter((item) => item && typeof item === "object" && !Array.isArray(item))
    : [];
  const excluded = audit.excluded && typeof audit.excluded === "object" && !Array.isArray(audit.excluded) ? audit.excluded : {};
  const accountExceptions = Array.isArray(audit.account_exceptions) ? audit.account_exceptions : [];
  const industries = Array.isArray(audit.industry_concentration)
    ? audit.industry_concentration.filter(Array.isArray)
    : [];
  const dataSources = Array.isArray(audit.data_sources) ? audit.data_sources : [];
  return `<details class="trend-audit"><summary>审计详情</summary>
    <section><h3>候选榜</h3><ol>${candidates.length
      ? candidates.map((item) => `<li>${escapeHtml([item.symbol, item.name, `强度 ${formatDisplayNumber(item.strength)}`].filter(Boolean).map(formatPlain).join("｜"))}</li>`).join("")
      : "<li>无</li>"}</ol></section>
    <section><h3>排除项</h3><ul>${Object.entries(excluded).length
      ? Object.entries(excluded).map(([symbol, reasons]) => `<li>${escapeHtml(formatPlain(symbol))}｜${escapeHtml((Array.isArray(reasons) ? reasons : []).map((reason) => TREND_REASON_LABELS[reason] || "未知原因").join("、"))}</li>`).join("")
      : "<li>无</li>"}</ul></section>
    <section><h3>账户不参与项</h3><ul>${accountExceptions.length
      ? accountExceptions.map((item) => `<li>${escapeHtml(formatPlain(item))}</li>`).join("")
      : "<li>无</li>"}</ul></section>
    <section><h3>行业集中度</h3><ul>${industries.length
      ? industries.map((item) => `<li>${escapeHtml(item.map((value, index) => index ? formatDisplayNumber(value) : formatPlain(value)).join("｜"))}</li>`).join("")
      : "<li>无</li>"}</ul></section>
    <p>数据来源：${escapeHtml(dataSources.map(formatPlain).join("、") || "无")}</p>
    <p>API 成本：${escapeHtml(formatDisplayNumber(audit.actual_api_cost ?? audit.estimated_api_cost ?? "未知"))}</p>
  </details>`;
}

function cnTrendRows(items) {
  return Array.isArray(items)
    ? items.filter((item) => item && typeof item === "object" && !Array.isArray(item))
    : [];
}

function usesFinalPlanTrendAudit(report) {
  const market = String(report?.market || "").toUpperCase();
  const version = String(report?.strategy_version || "");
  return (market === "CN" && ["v13", "v14"].includes(version))
    || (["HK", "US"].includes(market) && ["v11", "v12"].includes(version));
}

function usesV2TrendPlanLayout(report) {
  const market = String(report?.market || "").toUpperCase();
  const version = String(report?.strategy_version || "");
  return (market === "CN" && ["v15", "v16"].includes(version))
    || (["HK", "US"].includes(market) && ["v13", "v14"].includes(version))
    || report?.allocation?.version === 2;
}

function renderCnTrendCell(label, value, ariaLabel = "", missingLabel = "—") {
  const display = hasValue(value) ? formatPlain(value) : missingLabel;
  return `<td data-label="${escapeHtml(label)}"${ariaLabel ? ` aria-label="${escapeHtml(ariaLabel)}"` : ""}>${escapeHtml(display)}</td>`;
}

function cnTrendIdentity(item) {
  return [item.symbol, item.name].filter(hasValue).map(formatPlain).join(" ") || "-";
}

function cnTrendTemperature(item) {
  return `${formatPlain(item.temperature_prev)} → ${formatPlain(item.temperature_curr)}`;
}

function trendTemperature(item) {
  if (!hasValue(item?.temperature_prev) || !hasValue(item?.temperature_curr)) return null;
  return `${formatPlain(item.temperature_prev)} → ${formatPlain(item.temperature_curr)}`;
}

function renderTrendCell(label, value, ariaLabel = "") {
  return renderCnTrendCell(label, value, ariaLabel, "数据未提供");
}

function trendIdentity(item) {
  const identity = [item?.symbol, item?.name].filter(hasValue).map(formatPlain).join(" ");
  return identity || null;
}

function renderTrendOptionDialog(item, anomaly) {
  const identity = trendIdentity(item) || "数据未提供";
  const categories = Array.isArray(anomaly.categories)
    ? anomaly.categories.filter((category) => category && typeof category === "object" && !Array.isArray(category))
    : [];
  const categoryRows = categories.length
    ? categories.map((category) => `
      <article class="trend-option-dialog-category">
        <header><strong>${escapeHtml(formatPlain(category.name || "缺失"))}</strong><span>${escapeHtml(translateFutuSignalValue(category.direction || category.state))}</span></header>
        <dl>
          <div><dt>状态</dt><dd>${escapeHtml(translateFutuSignalValue(category.state))}</dd></div>
          <div><dt>方向</dt><dd>${escapeHtml(translateFutuSignalValue(category.direction))}</dd></div>
          <div><dt>详情</dt><dd>${escapeHtml(formatPlain(category.detail || "缺失"))}</dd></div>
          <div><dt>证据日期</dt><dd>${escapeHtml(formatPlain(category.evidence_date || "数据未提供"))}</dd></div>
        </dl>
      </article>`).join("")
    : `<p class="trend-option-dialog-empty">未找到可展示的结构化类别。</p>`;
  const windowDays = hasValue(anomaly.window_days)
    ? `${formatPlain(anomaly.window_days)} 天`
    : "数据未提供";
  return `<dialog class="trend-option-dialog" aria-label="富途期权异动详情：${escapeHtml(identity)}">
    <header class="trend-option-dialog-header">
      <div><p>富途期权异动</p><h3>${escapeHtml(identity)}</h3></div>
      <button type="button" data-option-anomaly-close aria-label="关闭期权异动详情">×</button>
    </header>
    <dl class="trend-option-dialog-meta">
      <div><dt>数据源</dt><dd>富途</dd></div>
      <div><dt>标的</dt><dd>${escapeHtml(identity)}</dd></div>
      <div><dt>运行日期</dt><dd>${escapeHtml(formatPlain(anomaly.run_date || "数据未提供"))}</dd></div>
      <div><dt>观察窗口</dt><dd>${escapeHtml(windowDays)}</dd></div>
    </dl>
    <section class="trend-option-dialog-summary"><h4>摘要</h4><p>${escapeHtml(formatPlain(anomaly.summary || "数据未提供"))}</p></section>
    <dl class="trend-option-dialog-signal">
      <div><dt>信号</dt><dd>${escapeHtml(translateFutuSignalValue(anomaly.signal))}</dd></div>
      <div><dt>置信度</dt><dd>${escapeHtml(translateFutuSignalValue(anomaly.confidence))}</dd></div>
      <div><dt>建议约束</dt><dd>${escapeHtml(translateFutuSignalValue(anomaly.suggested_constraint))}</dd></div>
    </dl>
    <section class="trend-option-dialog-categories"><h4>异动类别</h4><div>${categoryRows}</div></section>
    <footer><button type="button" data-option-anomaly-close>关闭</button></footer>
  </dialog>`;
}

function renderTrendOptionIdentityCell(item) {
  const anomaly = item?.option_anomaly && typeof item.option_anomaly === "object"
    ? item.option_anomaly : {};
  const identity = escapeHtml(trendIdentity(item) || "数据未提供");
  const available = anomaly.available === true;
  const button = available
    ? `<button class="trend-option-button" type="button" data-option-anomaly-open aria-haspopup="dialog">期权异动</button>`
    : "";
  return `<td data-label="标的"><strong>${identity}</strong>${button}${available ? renderTrendOptionDialog(item, anomaly) : ""}</td>`;
}

function handleTrendOptionDialog(event) {
  const target = event?.target;
  const close = target?.closest?.("[data-option-anomaly-close]");
  if (close) {
    const dialog = close.closest("dialog");
    if (typeof dialog?.close === "function") dialog.close();
    return true;
  }
  const open = target?.closest?.("[data-option-anomaly-open]");
  if (!open) return false;
  const dialog = open.parentElement?.querySelector("dialog.trend-option-dialog");
  if (typeof dialog?.showModal === "function") dialog.showModal();
  return true;
}

function trendHints(item) {
  return Array.isArray(item?.entry_hints) && item.entry_hints.length
    ? item.entry_hints.map(formatPlain).join("；")
    : null;
}

function trendMoney(item, normalizedKey, legacyKey) {
  return hasValue(item?.[normalizedKey]) ? item[normalizedKey] : item?.[legacyKey];
}

function cnTrendHints(item) {
  return Array.isArray(item.entry_hints) && item.entry_hints.length
    ? item.entry_hints.map(formatPlain).join("；")
    : "数据不可用";
}

function trendIndustryContext(report, item) {
  const direct = item && item.industry_context && typeof item.industry_context === "object"
    ? item.industry_context : null;
  const contexts = Array.isArray(report?.industry_contexts)
    ? report.industry_contexts : [];
  const itemIndustryId = item?.industry_tm_id ?? item?.industry_id;
  return direct || contexts.find((candidate) => candidate && typeof candidate === "object"
    && ((hasValue(itemIndustryId) && String(candidate.industry_tm_id) === String(itemIndustryId))
      || (hasValue(item?.industry) && String(candidate.industry) === String(item.industry))));
}

function trendIndustryBuyContext(report, item) {
  const context = trendIndustryContext(report, item);
  if (!context) {
    return report?.industry_context_status?.current_complete === false
      ? "行业上下文无效 · 当前数据不完整" : "行业上下文未提供";
  }
  const breadth = hasValue(context.right_count) && hasValue(context.valid_count)
    && hasValue(context.right_share)
    ? `${formatDisplayNumber(context.right_count)} / ${formatDisplayNumber(context.valid_count)} = ${trendIndustryPercent(context.right_share)}`
    : "右侧占比 数据未提供";
  const parts = [
    hasValue(context.temperature) ? `温度 ${formatPlain(context.temperature)}` : "",
    hasValue(context.temperature_direction) ? `方向 ${trendIndustryDirection(context.temperature_direction)}` : "",
    breadth,
  ].filter(Boolean);
  if (context.valid === false) {
    parts.push(`无效 · ${Array.isArray(context.invalid_reasons) && context.invalid_reasons.length
      ? context.invalid_reasons.map(formatPlain).join("、") : "数据不可用"}`);
  }
  return parts.join(" · ") || "行业上下文未提供";
}

function trendIndustryBuyTemperature(report, item) {
  if (hasValue(item?.industry_temperature)) return item.industry_temperature;
  const context = trendIndustryContext(report, item);
  if (context?.valid !== false) return context?.temperature;
  const obsoleteReasons = new Set([
    "component_count_below_10",
    "valid_count_below_10",
  ]);
  const reasons = Array.isArray(context.invalid_reasons)
    ? context.invalid_reasons : [];
  return reasons.length > 0 && reasons.every((reason) => obsoleteReasons.has(reason))
    ? context.temperature : null;
}

function trendRiskPercent(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "—";
  return `${(number * 100).toFixed(2).replace(/\.00$/, "").replace(/(\.\d)0$/, "$1")}%`;
}

function renderTrendRiskSummary(summary, drawdown, reportDate) {
  const hasPlanRisk = summary && typeof summary === "object" && hasValue(summary.status);
  const hasDrawdown = drawdown && typeof drawdown === "object" && hasValue(drawdown.status);
  if (!hasPlanRisk && !hasDrawdown) return "";
  const planned = hasPlanRisk ? `${formatDisplayNumber(summary.portfolio_planned_risk)}（${trendRiskPercent(summary.portfolio_planned_risk_pct)} / ${trendRiskPercent(summary.portfolio_risk_limit_pct)}）` : "";
  const remaining = hasPlanRisk ? `${formatDisplayNumber(summary.portfolio_remaining_risk)}（${trendRiskPercent(summary.portfolio_remaining_risk_pct)}）` : "";
  const single = hasPlanRisk ? `${formatDisplayNumber(summary.single_entry_risk_limit)}（${trendRiskPercent(summary.single_entry_risk_limit_pct)}）` : "";
  const buffer = hasPlanRisk ? `${formatDisplayNumber(summary.abnormal_loss_buffer)}（${trendRiskPercent(summary.abnormal_loss_buffer_pct)}）` : "";
  const status = hasPlanRisk ? summary.status : drawdown.status;
  const bootstrap = hasDrawdown && drawdown.bootstrap_event && typeof drawdown.bootstrap_event === "object"
    ? drawdown.bootstrap_event
    : null;
  const bootstrapNotice = bootstrap && hasValue(reportDate) &&
    String(bootstrap.occurred_at || "").slice(0, 10) === String(reportDate)
    ? `<p><strong>基准已自动建立</strong> · 基准净值 ${escapeHtml(formatDisplayNumber(bootstrap.baseline_equity))} · 快照日期 ${escapeHtml(formatPlain(bootstrap.source_date))}</p>`
    : "";
  const bootstrapRows = bootstrap ? `${bootstrapNotice}
      <details class="trend-drawdown-bootstrap-audit"><summary>回撤基准审计详情</summary><dl>
        <div><dt>事件</dt><dd>${escapeHtml(formatPlain(bootstrap.event_id))}</dd></div>
        <div><dt>基准净值</dt><dd>${escapeHtml(formatDisplayNumber(bootstrap.baseline_equity))}</dd></div>
        <div><dt>快照日期</dt><dd>${escapeHtml(formatPlain(bootstrap.source_date))}</dd></div>
        <div><dt>验收 Git SHA</dt><dd>${escapeHtml(formatPlain(bootstrap.accepted_git_sha))}</dd></div>
        <div><dt>参数哈希</dt><dd>${escapeHtml(formatPlain(bootstrap.parameter_hash))}</dd></div>
        <div><dt>任务身份</dt><dd>${escapeHtml(formatPlain(bootstrap.actor))}</dd></div>
        <div><dt>发生时间</dt><dd>${escapeHtml(formatPlain(bootstrap.occurred_at))}</dd></div>
        <div><dt>允许入场日期</dt><dd>${escapeHtml(formatPlain(bootstrap.entry_eligible_from))}</dd></div>
      </dl></details>` : "";
  const recovery = hasDrawdown && drawdown.recovery_event && typeof drawdown.recovery_event === "object"
    ? drawdown.recovery_event
    : null;
  const recoveryRows = recovery ? `<details class="trend-drawdown-recovery-audit"><summary>状态恢复审计详情</summary><dl>
        <div><dt>事件</dt><dd>${escapeHtml(formatPlain(recovery.event_id))}</dd></div>
        <div><dt>恢复快照</dt><dd>${escapeHtml(formatPlain(recovery.snapshot))}</dd></div>
        <div><dt>状态哈希</dt><dd>${escapeHtml(formatPlain(recovery.state_sha256))}</dd></div>
        <div><dt>任务身份</dt><dd>${escapeHtml(formatPlain(recovery.actor))}</dd></div>
        <div><dt>发生时间</dt><dd>${escapeHtml(formatPlain(recovery.occurred_at))}</dd></div>
      </dl></details>` : "";
  const headline = hasPlanRisk
    ? formatPlain(summary.status_label || "风险预算")
    : formatPlain(drawdown.status_label || "策略回撤");
  return `<details class="trend-risk-summary" data-risk-status="${escapeHtml(formatPlain(status))}" aria-label="模拟策略风险摘要">
    <summary>组合计划风险 <span>${escapeHtml(headline)}</span></summary>
    <div class="trend-risk-summary-body">
    ${hasPlanRisk ? `<header><strong>组合计划风险</strong><span>${escapeHtml(formatPlain(summary.status_label))}</span></header>
      ${hasValue(summary.pause_reason) ? `<p class="trend-risk-pause">${escapeHtml(formatPlain(summary.pause_reason))}</p>` : ""}
      ${hasValue(summary.data_defect_reason) ? `<p class="trend-risk-data-defect">数据缺陷：${escapeHtml(formatPlain(summary.data_defect_reason))}</p>` : ""}
      ${hasValue(summary.pending_entries_note) ? `<p class="trend-risk-pending">${escapeHtml(formatPlain(summary.pending_entries_note))}</p>` : ""}
      <dl>
        <div><dt>组合计划风险</dt><dd>${escapeHtml(planned)}</dd></div>
        <div><dt>组合剩余风险</dt><dd>${escapeHtml(remaining)}</dd></div>
        <div><dt>单笔风险上限</dt><dd>${escapeHtml(single)}</dd></div>
        <div><dt>异常损失缓冲</dt><dd>${escapeHtml(buffer)} · 不得用于开仓</dd></div>
      </dl>
      <p>${escapeHtml(formatPlain(summary.portfolio_remaining_risk_note))}</p>
      <p>${escapeHtml(formatPlain(summary.disclaimer))}</p>` : ""}
    ${hasDrawdown ? `<div class="trend-drawdown-summary"><header><strong>策略累计回撤</strong><span>${escapeHtml(formatPlain(drawdown.status_label))}</span></header>
      ${hasValue(drawdown.pause_reason) ? `<p class="trend-risk-pause">${escapeHtml(formatPlain(drawdown.pause_reason))}</p>` : ""}
      <dl><div><dt>策略累计回撤</dt><dd>${trendRiskPercent(drawdown.drawdown_pct)} / ${trendRiskPercent(drawdown.drawdown_limit_pct)}</dd></div>
      <div><dt>策略模拟净值</dt><dd>${escapeHtml(formatDisplayNumber(drawdown.current_equity))}</dd></div>
      <div><dt>净值高点</dt><dd>${escapeHtml(formatDisplayNumber(drawdown.high_water_mark))}</dd></div></dl>${bootstrapRows}${recoveryRows}</div>` : ""}
    </div>
  </details>`;
}

function trendKellyObservationKey(observation, report) {
  return [
    report?.broker || "",
    report?.artifact || "",
    report?.report_sha256 || "",
    report?.strategy_version || observation?.target_strategy_version || "",
  ].join("|");
}

function trendKellyObservationTimestamp(value, market) {
  const raw = formatPlain(value).trim();
  const match = raw.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):\d{2}(?:\.\d+)?[+-]\d{2}:\d{2}$/);
  if (!match || !Number.isFinite(new Date(raw).getTime())) return raw;
  const suffix = ({US: "ET", HK: "HKT", CN: "北京时间"})[String(market || "").toUpperCase()];
  return suffix ? `${match[2]}-${match[3]} ${match[4]}:${match[5]} ${suffix}` : raw;
}

function validTrendKellyObservation(observation, report = {}) {
  if (!observation || typeof observation !== "object" || Array.isArray(observation)) return false;
  if (typeof observation.kelly_enabled !== "boolean") return false;
  const nonEmptyText = (value) => typeof value === "string" && value.trim() !== "";
  const finiteNumber = (value) => (typeof value === "number" || typeof value === "string")
    && String(value).trim() !== "" && Number.isFinite(Number(value));
  const market = nonEmptyText(observation.target_market)
    ? observation.target_market.toUpperCase() : "";
  const reportMarket = nonEmptyText(report?.market) ? report.market.trim().toUpperCase() : "";
  const targetVersion = nonEmptyText(observation.target_strategy_version)
    ? observation.target_strategy_version.trim() : "";
  const reportVersion = nonEmptyText(report?.strategy_version)
    ? report.strategy_version.trim() : "";
  if (!({US: true, HK: true, CN: true})[market]
      || !reportMarket || market !== reportMarket
      || !nonEmptyText(observation.target_strategy_id)
      || !targetVersion || !reportVersion || targetVersion !== reportVersion) return false;
  const marketTimezones = {US: "America/New_York", HK: "Asia/Hong_Kong", CN: "Asia/Shanghai"};
  const canonicalTimestamp = (value) => {
    const match = value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?[+-]\d{2}:\d{2}$/);
    const instant = new Date(value);
    if (!match || !Number.isFinite(instant.getTime())) return false;
    const localParts = Object.fromEntries(
      new Intl.DateTimeFormat("en-US", {
        timeZone: marketTimezones[market],
        year: "numeric", month: "2-digit", day: "2-digit",
        hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
      }).formatToParts(instant)
        .filter(({type}) => type !== "literal")
        .map(({type, value: part}) => [type, part]),
    );
    return ["year", "month", "day", "hour", "minute", "second"]
      .every((part, index) => localParts[part] === match[index + 1]);
  };
  const eligibleCount = observation.eligible_sample_count;
  const selectedCount = observation.selected_sample_count;
  const minimumSampleCount = observation.minimum_sample_count;
  if (!Number.isInteger(eligibleCount) || eligibleCount < 0
      || !Number.isInteger(selectedCount) || selectedCount < 1
      || !Number.isInteger(minimumSampleCount) || minimumSampleCount < 1
      || selectedCount > eligibleCount
      || selectedCount !== Math.min(eligibleCount, 200)
      || observation.kelly_enabled !== (eligibleCount >= minimumSampleCount)) return false;
  const rows = observation.rounds;
  const selectedRoundIds = observation.selected_round_ids;
  if (!Array.isArray(rows) || rows.length !== selectedCount
      || !Array.isArray(selectedRoundIds) || selectedRoundIds.length !== selectedCount) return false;
  const rowIds = new Set();
  const rowVersionCounts = Object.create(null);
  const rowReturns = [];
  for (const row of rows) {
    if (!row || typeof row !== "object" || Array.isArray(row)) return false;
    const roundId = nonEmptyText(row.round_id) ? row.round_id.trim() : "";
    if (!roundId || rowIds.has(roundId)
        || !nonEmptyText(row.symbol) || !nonEmptyText(row.opening_strategy_version)
        || !Number.isInteger(row.holding_days) || row.holding_days < 0) return false;
    const openedAt = formatPlain(row.opened_at).trim();
    const closedAt = formatPlain(row.closed_at).trim();
    if (!canonicalTimestamp(openedAt) || !canonicalTimestamp(closedAt)) return false;
    if (new Date(closedAt).getTime() < new Date(openedAt).getTime()) return false;
    const calendarDay = (value) => {
      const [year, month, day] = value.slice(0, 10).split("-").map(Number);
      return Date.UTC(year, month - 1, day) / 86400000;
    };
    if (calendarDay(closedAt) - calendarDay(openedAt) !== row.holding_days) return false;
    if (!finiteNumber(row.net_return) || Number(row.net_return) < -1) return false;
    rowReturns.push(Number(row.net_return));
    rowIds.add(roundId);
    const openingVersion = row.opening_strategy_version.trim();
    rowVersionCounts[openingVersion] = (rowVersionCounts[openingVersion] || 0) + 1;
  }
  const selectedIds = new Set();
  for (const value of selectedRoundIds) {
    const roundId = nonEmptyText(value) ? value.trim() : "";
    if (!roundId || selectedIds.has(roundId)) return false;
    selectedIds.add(roundId);
  }
  if (selectedIds.size !== rowIds.size || [...selectedIds].some((roundId) => !rowIds.has(roundId))) return false;
  const compatibleVersions = observation.compatible_opening_versions;
  if (!compatibleVersions || typeof compatibleVersions !== "object" || Array.isArray(compatibleVersions)) return false;
  let compatibleCount = 0;
  for (const [version, count] of Object.entries(compatibleVersions)) {
    if (!nonEmptyText(version) || !Number.isInteger(count) || count < 1) return false;
    compatibleCount += count;
  }
  const rowVersions = Object.keys(rowVersionCounts);
  if (compatibleCount !== selectedCount || Object.keys(compatibleVersions).length !== rowVersions.length
      || rowVersions.some((version) => !Object.prototype.hasOwnProperty.call(compatibleVersions, version)
        || compatibleVersions[version] !== rowVersionCounts[version])
      || !Number.isInteger(observation.exact_current_version_count)
      || observation.exact_current_version_count < 0
      || observation.exact_current_version_count !== (rowVersionCounts[targetVersion] || 0)) return false;
  const metrics = observation.metrics;
  if (!metrics || typeof metrics !== "object" || Array.isArray(metrics)) return false;
  const boundedNumber = (value, minimum, maximum) => finiteNumber(value)
    && Number(value) >= minimum && Number(value) <= maximum;
  if (!boundedNumber(metrics.win_rate, 0, 1)
      || !finiteNumber(metrics.average_net_return) || Number(metrics.average_net_return) < -1
      || !boundedNumber(metrics.shadow_full_kelly, 0, 1)
      || !boundedNumber(metrics.shadow_quarter_kelly, 0, 1)
      || !boundedNumber(metrics.strategy_cap, 0, 1)
      || !boundedNumber(metrics.suggested_position, 0, 1)) return false;
  const metricTolerance = 1e-6;
  const matchesMetric = (actual, expected) => Math.abs(Number(actual) - expected) <= metricTolerance;
  const positiveReturns = rowReturns.filter((value) => value > 0);
  const negativeReturns = rowReturns.filter((value) => value < 0);
  const expectedWinRate = positiveReturns.length / rowReturns.length;
  const expectedAverage = rowReturns.reduce((sum, value) => sum + value, 0) / rowReturns.length;
  if (!matchesMetric(metrics.win_rate, expectedWinRate)
      || !matchesMetric(metrics.average_net_return, expectedAverage)) return false;
  if (positiveReturns.length && negativeReturns.length) {
    const averagePositive = positiveReturns.reduce((sum, value) => sum + value, 0) / positiveReturns.length;
    const averageNegative = negativeReturns.reduce((sum, value) => sum + value, 0) / negativeReturns.length;
    const expectedPayoff = averagePositive / Math.abs(averageNegative);
    if (!finiteNumber(metrics.payoff_ratio) || Number(metrics.payoff_ratio) < 0
        || !matchesMetric(metrics.payoff_ratio, expectedPayoff)
        || metrics.payoff_ratio_status !== "available") return false;
  } else {
    const expectedPayoffStatus = positiveReturns.length ? "no_losses" : "no_wins";
    if (hasValue(metrics.payoff_ratio) || metrics.payoff_ratio_status !== expectedPayoffStatus) return false;
  }
  const maximizeAverageLogGrowth = (returns) => {
    const sum = returns.reduce((total, value) => total + value, 0);
    if (sum <= 0) return 0;
    if (returns.every((value) => value >= 0)) return 1;
    const derivative = (fraction) => {
      let slope = 0;
      for (const value of returns) {
        const denominator = 1 + fraction * value;
        if (denominator <= 0) return null;
        slope += value / denominator;
      }
      return slope;
    };
    const boundaryDerivative = derivative(1);
    if (boundaryDerivative !== null && boundaryDerivative >= 0) return 1;
    let low = 0;
    let high = 1;
    for (let iteration = 0; iteration < 96; iteration += 1) {
      const middle = (low + high) / 2;
      const slope = derivative(middle);
      if (slope !== null && slope > 0) low = middle;
      else high = middle;
    }
    return Math.floor(low / 1e-6) * 1e-6;
  };
  const fullKelly = maximizeAverageLogGrowth(rowReturns);
  const quarterKelly = Math.floor((fullKelly / 4) / 1e-6) * 1e-6;
  const strategyCap = Number(metrics.strategy_cap);
  if (strategyCap <= 0
      || !matchesMetric(metrics.shadow_full_kelly, fullKelly)
      || !matchesMetric(metrics.shadow_quarter_kelly, quarterKelly)
      || !matchesMetric(metrics.suggested_position, Math.min(quarterKelly, strategyCap))) return false;
  return true;
}

function handleTrendKellyObservationPagination(event) {
  const button = event.target?.closest?.(
    "[data-kelly-observation-previous], [data-kelly-observation-next]",
  );
  if (!button) return false;
  const section = button.closest(".trend-kelly-observation");
  const key = section?.dataset.kellyObservationKey || "";
  const observation = state.trendKellyObservationPayloads.get(key);
  if (!section || !observation) return false;
  const rows = Array.isArray(observation.rounds) ? observation.rounds : [];
  const pageCount = Math.max(1, Math.ceil(rows.length / 10));
  const currentPage = Number(state.trendKellyObservationPages.get(key) || 0);
  const nextPage = button.hasAttribute("data-kelly-observation-next")
    ? currentPage + 1 : currentPage - 1;
  if (nextPage < 0 || nextPage >= pageCount || nextPage === currentPage) return true;
  state.trendKellyObservationPages.set(key, nextPage);
  section.outerHTML = renderTrendKellyObservation(
    observation,
    state.trendKellyObservationReports.get(key) || {},
  );
  return true;
}

function renderTrendKellyObservation(observation, report = {}) {
  if (!observation || typeof observation !== "object" || observation.available !== true) {
    return `<section class="trend-kelly-observation unavailable" aria-label="Kelly 观察">
      <h2>Kelly 观察</h2><p class="trend-kelly-observation-unavailable">${escapeHtml(formatPlain(observation?.status_text || "Kelly 统计暂不可用"))}</p>
    </section>`;
  }
  const metrics = observation.metrics && typeof observation.metrics === "object"
    ? observation.metrics : {};
  const rows = Array.isArray(observation.rounds)
    ? observation.rounds.filter((item) => item && typeof item === "object" && !Array.isArray(item))
    : [];
  if (!validTrendKellyObservation(observation, report)) {
    return `<section class="trend-kelly-observation unavailable" aria-label="Kelly 观察">
      <h2>Kelly 观察</h2><p class="trend-kelly-observation-unavailable">Kelly 统计暂不可用</p>
    </section>`;
  }
  const observationKey = trendKellyObservationKey(observation, report);
  const reportIdentity = {
    broker: report?.broker || "",
    artifact: report?.artifact || "",
    report_sha256: report?.report_sha256 || "",
    market: report?.market || "",
    strategy_version: report?.strategy_version || "",
  };
  state.trendKellyObservationPayloads.set(observationKey, observation);
  state.trendKellyObservationReports.set(observationKey, reportIdentity);
  const pageCount = Math.max(1, Math.ceil(rows.length / 10));
  const pageIndex = Math.min(
    Math.max(Number(state.trendKellyObservationPages.get(observationKey) || 0), 0),
    pageCount - 1,
  );
  state.trendKellyObservationPages.set(observationKey, pageIndex);
  const eligibleCount = Number.isInteger(observation.eligible_sample_count)
    ? observation.eligible_sample_count : null;
  const selectedCount = Number.isInteger(observation.selected_sample_count)
    ? observation.selected_sample_count : rows.length;
  const minimumSampleCount = Number.isInteger(observation.minimum_sample_count)
    ? observation.minimum_sample_count : null;
  if (eligibleCount === null || minimumSampleCount === null || minimumSampleCount < 1) {
    return `<section class="trend-kelly-observation unavailable" aria-label="Kelly 观察">
      <h2>Kelly 观察</h2><p class="trend-kelly-observation-unavailable">Kelly 统计暂不可用</p>
    </section>`;
  }
  const versionEntries = observation.compatible_opening_versions
    && typeof observation.compatible_opening_versions === "object"
    && !Array.isArray(observation.compatible_opening_versions)
    ? Object.entries(observation.compatible_opening_versions)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([version, count]) => `${formatPlain(version)} × ${formatDisplayNumber(count)}`)
    : [];
  const currentVersionCount = formatDisplayNumber(observation.exact_current_version_count);
  const targetVersion = formatPlain(observation.target_strategy_version);
  const cap = decimalAsPercent(metrics.strategy_cap, "数据未提供");
  const quarter = decimalAsPercent(metrics.shadow_quarter_kelly, "数据未提供");
  const suggested = decimalAsPercent(metrics.suggested_position, "数据未提供");
  const payoffStatusLabels = {no_wins: "无盈利样本", no_losses: "无亏损样本"};
  const rowHtml = rows.slice(pageIndex * 10, (pageIndex + 1) * 10).map((row) => {
    const holdingDays = Number(row.holding_days);
    const holdingLabel = Number.isFinite(holdingDays)
      ? holdingDays === 0 ? "当日" : `${formatDisplayNumber(holdingDays)} 天`
      : "数据未提供";
    return `<tr class="trend-kelly-observation-row" data-round-id="${escapeHtml(formatPlain(row.round_id))}">
      <td data-label="标的">${escapeHtml(formatPlain(row.symbol))}</td>
      <td data-label="建仓时间">${escapeHtml(trendKellyObservationTimestamp(row.opened_at, observation.target_market))}</td>
      <td data-label="平仓时间">${escapeHtml(trendKellyObservationTimestamp(row.closed_at, observation.target_market))}</td>
      <td data-label="持有天数">${escapeHtml(holdingLabel)}</td>
      <td data-label="净收益" class="${pnlClass(row.net_return)}">${escapeHtml(formatSignedPnl(decimalAsPercent(row.net_return, "数据未提供")))}</td>
    </tr>`;
  }).join("");
  return `<section class="trend-kelly-observation" data-kelly-observation-key="${escapeHtml(observationKey)}" aria-label="Kelly 闭环观察">
    <header class="trend-kelly-observation-header">
      <div><h2>Kelly 闭环观察</h2><p>样本进度 ${escapeHtml(formatDisplayNumber(eligibleCount))} / ${escapeHtml(formatDisplayNumber(minimumSampleCount))} · 影子计算，仅供观察，不用于交易</p></div>
      <span class="trend-kelly-observation-status">${escapeHtml(observation.kelly_enabled === true ? "样本达标 · 影子计算" : "冷启动 · 影子计算")}</span>
    </header>
    <div class="trend-kelly-observation-metrics">
      <article><h3>胜率</h3><strong>${escapeHtml(trendRiskPercent(metrics.win_rate))}</strong></article>
      <article><h3>盈亏比</h3><strong>${escapeHtml(hasValue(metrics.payoff_ratio) ? formatDisplayNumber(metrics.payoff_ratio) : payoffStatusLabels[metrics.payoff_ratio_status] || "数据未提供")}</strong></article>
      <article><h3>平均净收益</h3><strong>${escapeHtml(decimalAsPercent(metrics.average_net_return, "数据未提供"))}</strong></article>
      <article><h3>Kelly 建议仓位</h3><strong>${escapeHtml(suggested)}</strong><small>四分之一 Kelly ${escapeHtml(quarter)} · 策略上限 ${escapeHtml(cap)}</small></article>
    </div>
    <p class="trend-kelly-observation-scope">目标版本 ${escapeHtml(targetVersion)} · 计入 ${escapeHtml(formatDisplayNumber(selectedCount))} 个样本 · 兼容版本 ${escapeHtml(versionEntries.join("、") || "数据未提供")} · 当前版本 ${escapeHtml(currentVersionCount)} 个</p>
    <div class="trend-kelly-observation-rounds"><h3>全部计入闭环</h3>
      <table class="trend-kelly-observation-table"><thead><tr><th scope="col">标的</th><th scope="col">建仓时间</th><th scope="col">平仓时间</th><th scope="col">持有天数</th><th scope="col">净收益</th></tr></thead><tbody>${rowHtml}</tbody></table>
      <nav class="trend-kelly-observation-pagination" aria-label="Kelly 观察分页">
        <button type="button" data-kelly-observation-previous aria-label="上一页"${pageIndex === 0 ? " disabled" : ""}>上一页</button>
        <span data-kelly-observation-page>第 ${pageIndex + 1} / ${pageCount} 页</span>
        <button type="button" data-kelly-observation-next aria-label="下一页"${pageIndex >= pageCount - 1 ? " disabled" : ""}>下一页</button>
      </nav>
    </div>
  </section>`;
}

function renderCnTrendTable(title, kind, headings, rows, note = "") {
  const desktopScroller = kind === "buy" && !isCnTrendMobile();
  const scrollerAttributes = kind === "buy"
    ? ` tabindex="${desktopScroller ? "0" : "-1"}" aria-label="${desktopScroller ? "正式买入计划，可横向滚动" : "正式买入计划"}"`
    : "";
  return `<section class="trend-stage cn-trend-stage cn-trend-${escapeHtml(kind)}"${scrollerAttributes}>
    <h2>${escapeHtml(title)}</h2>
    ${note ? `<p class="cn-trend-price-sources">${escapeHtml(note)}</p>` : ""}
    <table class="cn-trend-table"><thead><tr>${headings.map((heading) => `<th scope="col">${escapeHtml(heading)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table>
    ${rows.length ? "" : "<p>无</p>"}
  </section>`;
}

function trendV2PlanSymbol(value) {
  return String(value || "").trim().toUpperCase();
}

function trendV2PlanPairs(pairs) {
  return cnTrendRows(pairs).filter((pair) => trendV2PlanSymbol(pair.sell_symbol || pair.buy_symbol));
}

function trendV2PlanSellRows(items, pairs, report) {
  const rotationPairs = trendV2PlanPairs(pairs);
  const rotationBySymbol = new Map(
    rotationPairs.map((pair) => [trendV2PlanSymbol(pair.sell_symbol), pair]),
  );
  const rows = [];
  const seen = new Set();
  for (const item of cnTrendRows(items)) {
    if (item.action && !["SELL_ALL", "SELL_PARTIAL"].includes(item.action)) continue;
    const key = trendV2PlanSymbol(item.symbol || item.futu_symbol);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    rows.push({item, pair: rotationBySymbol.get(key) || null});
  }
  for (const pair of rotationPairs) {
    const key = trendV2PlanSymbol(pair.sell_symbol);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    rows.push({
      pair,
      item: {
        symbol: pair.sell_symbol,
        name: pair.sell_name,
        action: "SELL_ALL",
        reason: "relative_rotation",
        clearance_type: "轮换清仓",
        global_strength: pair.sell_global_strength,
        phase: pair.sell_phase,
        temperature_prev: pair.sell_temperature_prev,
        temperature_curr: pair.sell_temperature_curr,
        close: pair.sell_close,
        active_line: pair.sell_active_line,
      },
    });
  }
  return rows.map(({item, pair}) => {
    const overlap = Boolean(pair && item.reason !== "relative_rotation");
    const clearanceType = item.action === "SELL_PARTIAL"
      ? "减仓"
      : String(item.clearance_type || "").includes("轮换")
        || item.reason === "relative_rotation" ? "轮换" : "清仓";
    const clearanceDisplay = !item.action && item.clearance_type
      ? `清仓（${formatPlain(item.clearance_type)}）`
      : clearanceType;
    const reason = trendReasonLabel(item, report);
    const hint = [
      ...((Array.isArray(item.entry_hints) ? item.entry_hints : []).map(formatPlain)),
      ...(overlap || item.clearance_note === "同时符合轮换清仓" ? ["同时符合轮换清仓"] : []),
    ].join("；") || null;
    const carriedForwardClass = trendHoldingCarriedForwardClass(item, report);
    return `<tr class="cn-trend-card${carriedForwardClass ? ` ${carriedForwardClass}` : ""}">
      ${renderTrendCell("标的", trendIdentity(item))}
      ${renderTrendCell("动作", trendSellActionLabel(item))}
      ${renderTrendCell("卖出类型", clearanceDisplay)}
      ${renderTrendCell("执行参考价", hasValue(item.close) ? formatDisplayNumber(item.close) : null)}
      ${renderTrendCell("温度变化", trendTemperature(item))}
      ${renderTrendCell("节气", item.phase)}
      ${renderTrendCell("个体全局强度", item.global_strength ?? item.individual_global_strength)}
      ${renderTrendCell("触发原因", reason)}
      ${renderTrendCell("活动保护线", hasValue(item.active_line) ? formatDisplayNumber(item.active_line) : null)}
      ${renderTrendCell("持仓提示", hint)}
    </tr>`;
  });
}

function trendV2PlanBuyRows(items, pairs) {
  const rows = [];
  const seen = new Set();
  for (const item of cnTrendRows(items)) {
    const key = trendV2PlanSymbol(item.symbol || item.futu_symbol);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    rows.push(item);
  }
  for (const pair of trendV2PlanPairs(pairs)) {
    const key = trendV2PlanSymbol(pair.buy_symbol);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    rows.push({
      symbol: pair.buy_symbol,
      name: pair.buy_name,
      global_strength: pair.buy_global_strength,
      target_amount: pair.target_amount,
      estimated_shares: pair.estimated_shares,
    });
  }
  return rows.map((item, index) => `<tr class="cn-trend-card">
    ${renderTrendCell("序号", index + 1)}
    ${renderTrendCell("标的", trendIdentity(item))}
    ${renderTrendCell("个体全局强度", item.global_strength ?? item.individual_global_strength)}
    ${renderTrendCell("4%目标金额", hasValue(item.target_amount) ? formatDisplayNumber(item.target_amount) : null)}
    ${renderTrendCell("预计数量", hasValue(item.estimated_shares) ? `${formatDisplayNumber(item.estimated_shares)} 股` : null)}
  </tr>`);
}

function trendV2PlanAvailability(report, account) {
  const availability = report?.plan_availability;
  const missing = {status: "unavailable", reason: "计划可用性数据缺失", executable: false};
  const invalid = {status: "unavailable", reason: "计划可用性数据无效", executable: false};
  if (availability == null) return missing;
  if (typeof availability !== "object" || Array.isArray(availability)) return invalid;
  const component = availability[account];
  if (component == null) return missing;
  if (typeof component !== "object" || Array.isArray(component)) return invalid;
  if ((component.status !== "available" && component.status !== "unavailable")
      || typeof component.reason !== "string"
      || typeof component.executable !== "boolean") return invalid;
  return component;
}

function renderTrendV2PlanTable(title, subtitle, kind, headings, rows, availability) {
  const unavailable = availability?.status === "unavailable";
  const renderedRows = unavailable ? [] : rows;
  const reason = unavailable && typeof availability.reason === "string"
    ? availability.reason.trim() : "";
  const empty = unavailable
    ? `<p>不可用${reason ? `：${escapeHtml(reason)}` : ""}</p>`
    : renderedRows.length ? "" : "<p>无</p>";
  return `<section class="trend-plan trend-plan-${escapeHtml(kind)}">
    <header><h2>${escapeHtml(title)}</h2><p>${escapeHtml(subtitle)}</p></header>
    <table class="cn-trend-table" data-legacy-label="清仓类型"><thead><tr>${headings.map((heading) => `<th scope="col">${escapeHtml(heading)}</th>`).join("")}</tr></thead><tbody>${renderedRows.join("")}</tbody></table>
    ${empty}
  </section>`;
}

function renderTrendV2Plans(report) {
  const sellHeadings = [
    "标的", "动作", "卖出类型", "执行参考价", "温度变化", "节气",
    "个体全局强度", "触发原因", "活动保护线", "持仓提示",
  ];
  const buyHeadings = ["序号", "标的", "个体全局强度", "4%目标金额", "预计数量"];
  return [
    renderTrendV2PlanTable(
      "模拟盘卖出计划", "趋势快照 + 模拟持仓快照", "sell",
      sellHeadings,
      trendV2PlanSellRows(report.sell_actions, report.simulate_rotation_pairs, report),
      trendV2PlanAvailability(report, "simulated_account"),
    ),
    renderTrendV2PlanTable(
      "实盘卖出计划", "趋势快照 + 实盘持仓快照", "sell",
      sellHeadings,
      trendV2PlanSellRows(report.real_position_actions, report.real_rotation_pairs, report),
      trendV2PlanAvailability(report, "real_account"),
    ),
    renderTrendV2PlanTable(
      "模拟盘买入计划", "趋势快照 + 模拟账户快照", "buy",
      buyHeadings,
      trendV2PlanBuyRows(report.buy_actions, report.simulate_rotation_pairs),
      trendV2PlanAvailability(report, "simulated_account"),
    ),
    renderTrendV2PlanTable(
      "实盘买入计划", "趋势快照 + 实盘账户快照", "buy",
      buyHeadings,
      trendV2PlanBuyRows(report.real_buy_actions, report.real_rotation_pairs),
      trendV2PlanAvailability(report, "real_account"),
    ),
  ].join("");
}

function isCnTrendMobile() {
  return typeof window !== "undefined"
    && typeof window.matchMedia === "function"
    && window.matchMedia("(max-width: 760px)").matches;
}

function syncCnTrendBuyAccessibility() {
  const workspace = elements["trend-report-workspace"];
  if (!workspace || typeof workspace.querySelector !== "function") return;
  const scroller = workspace.querySelector(".cn-trend-buy");
  if (!scroller) return;
  const mobile = isCnTrendMobile();
  scroller.tabIndex = mobile ? -1 : 0;
  scroller.setAttribute(
    "aria-label",
    mobile ? "正式买入计划" : "正式买入计划，可横向滚动",
  );
}

function trendHoldingActionLabel(item) {
  return {
    SELL_ALL: "全部卖出",
    SELL_PARTIAL: "止盈减仓 30%",
    MANUAL_REVIEW: "人工复核",
    HOLD: "继续持有",
  }[item?.action] || (hasValue(item?.action) ? "数据未提供" : "继续持有");
}

function trendHoldingHeadings() {
  return [
    "标的", "动作", "执行参考价", "温度变化", "节气", "大类内强度", "全局强度", "行业",
    "当前判断", "活动保护线", "持仓提示",
  ];
}

function trendRealHoldingStatus(report) {
  return report?.real_position_status ?? report?.real_holdings_status;
}

function trendRealHoldingReason(report) {
  return report?.real_position_reason ?? report?.real_holdings_reason;
}

function trendRealHoldingSource(report) {
  const source = report?.real_position_source ?? report?.real_holdings_source;
  return source && typeof source === "object" ? source : {};
}

function validTrendHoldingGeneration(value) {
  return typeof value === "string" && /^sha256:[0-9a-f]{64}$/.test(value);
}

function validTrendHoldingDate(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function trendHoldingFreshnessNoteText(report) {
  const broker = brokerKey(report?.broker);
  const reportSource = trendRealHoldingSource(report);
  const accountSource = state.accountSnapshot?.sources?.account?.brokers?.[broker];
  const latestDate = firstPresent(accountSource?.data_as_of, accountSource?.as_of);
  const reportDate = firstPresent(reportSource.snapshot_period, reportSource.data_as_of);
  const latestGeneration = state.accountSnapshot?.accepted_holding_generation?.[broker];
  const reportGeneration = reportSource.holding_generation;
  const sourceStatus = String(accountSource?.status || "").trim().toLowerCase();
  const accountAvailable = Boolean(state.accountSnapshot)
    && !state.accountError
    && ["healthy", "ok"].includes(sourceStatus);
  let status = "最新持仓状态暂不可核对";
  if (accountAvailable) {
    const hasLatestGeneration = validTrendHoldingGeneration(latestGeneration);
    const hasReportGeneration = validTrendHoldingGeneration(reportGeneration);
    if (hasLatestGeneration && hasReportGeneration) {
      status = latestGeneration === reportGeneration
        ? "本报告已采用当前持仓"
        : "新持仓已到账，报告待更新";
    } else if (
      validTrendHoldingDate(latestDate)
      && validTrendHoldingDate(reportDate)
      && latestDate > reportDate
    ) {
      status = "新持仓已到账，报告待更新";
    } else {
      status = "本报告未记录持仓版本，暂无法核对";
    }
  }
  return `最新持仓 ${formatPlain(latestDate)} · 报告持仓 ${formatPlain(reportDate)} · ${status}`;
}

function renderTrendHoldingFreshnessNote(report, historical = false) {
  const broker = brokerKey(report?.broker);
  if (
    historical
    || !["phillips", "eastmoney"].includes(broker)
    || !report
  ) {
    return "";
  }
  return `<p class="cn-trend-price-sources trend-report-holding-note" data-current-trend-holding-note data-broker="${escapeHtml(broker)}">${escapeHtml(trendHoldingFreshnessNoteText(report))}</p>`;
}

function updateCurrentTrendHoldingNote() {
  const notes = [];
  const addNotes = (container) => {
    if (!container) return;
    if (typeof container.querySelectorAll === "function") {
      notes.push(...Array.from(container.querySelectorAll("[data-current-trend-holding-note]")));
    } else if (typeof container.querySelector === "function") {
      const note = container.querySelector("[data-current-trend-holding-note]");
      if (note) notes.push(note);
    }
  };
  addNotes(typeof document !== "undefined" ? document : null);
  addNotes(elements["trend-report-workspace"]);
  addNotes(elements["account-holdings"]);
  const seen = new Set();
  notes.forEach((note) => {
    if (!note || seen.has(note)) return;
    seen.add(note);
    const broker = brokerKey(note.dataset?.broker);
    const report = state.dashboard?.trend_reports?.[broker];
    if (report && typeof note.textContent !== "undefined") {
      note.textContent = trendHoldingFreshnessNoteText(report);
    }
  });
}

function trendHoldingCarriedForwardClass(item, report) {
  const signalDate = formatPlain(item?.signal_as_of_date);
  const reportDate = formatPlain(report?.data_date || report?.as_of_date);
  if (/^\d{4}-\d{2}-\d{2}$/.test(signalDate)
      && /^\d{4}-\d{2}-\d{2}$/.test(reportDate)
      && signalDate < reportDate) {
    return "trend-holding-carried-forward";
  }
  return "";
}

function trendHoldingRowClass(item, report) {
  const classes = {
    included: "trend-holding-included",
    excluded: "trend-holding-excluded",
    blacklisted: "trend-holding-blacklisted",
  }[item?.trend_report_state] || "trend-holding-excluded";
  const carriedForwardClass = trendHoldingCarriedForwardClass(item, report);
  return carriedForwardClass ? `${classes} ${carriedForwardClass}` : classes;
}

function renderTrendHoldingRows(items, report) {
  const optionMarket = ["US", "HK"].includes(String(report?.market || "").toUpperCase());
  return cnTrendRows(items).map((item) => `<tr class="cn-trend-card ${trendHoldingRowClass(item, report)}">
    ${optionMarket ? renderTrendOptionIdentityCell(item) : renderTrendCell("标的", trendIdentity(item))}
    ${renderTrendCell("动作", trendHoldingActionLabel(item))}
    ${renderTrendCell("执行参考价", hasValue(item.close) ? formatDisplayNumber(item.close) : null)}
    ${renderTrendCell("温度变化", trendTemperature(item))}
    ${renderTrendCell("节气", item.phase)}
    ${renderTrendCell("大类内强度", hasValue(item.strength) ? formatDisplayNumber(item.strength) : null)}
    ${renderTrendCell("全局强度", hasValue(item.global_strength) ? formatDisplayNumber(item.global_strength) : null)}
    ${renderTrendCell("行业", item.industry)}
    ${renderTrendCell("当前判断", trendReasonLabel(item, report))}
    ${renderTrendCell("活动保护线", hasValue(item.active_line) ? formatDisplayNumber(item.active_line) : null)}
    ${renderTrendCell("持仓提示", trendHints(item))}
  </tr>`);
}

function renderTrendHoldingTable(items, report) {
  const headings = trendHoldingHeadings();
  const rows = renderTrendHoldingRows(items, report);
  return `<table class="cn-trend-table"><thead><tr>${headings.map((heading) => `<th scope="col">${escapeHtml(heading)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table>${rows.length ? "" : "<p>无</p>"}`;
}

function renderHoldingOriginSection(title, rows, tableHtml) {
  return `<section class="holding-origin-section">
    <div class="holding-origin-heading"><h3>${escapeHtml(title)}</h3><span>${escapeHtml(formatDisplayNumber(rows.length))} 条</span></div>
    ${rows.length ? tableHtml : '<p class="account-empty">无</p>'}
  </section>`;
}

function renderHistoricalTrendHoldingWarning() {
  return '<p class="account-empty missing-text">历史买入计划归属暂不可用，未执行分组</p>';
}

function renderTrendAccountExceptions(source) {
  const raw = source?.account_exceptions;
  if (!raw) return "";
  const labels = String(raw).split("；").map((item) => {
    const trimmed = String(item).trim();
    const futuPrefix = "unsupported Futu asset: ";
    const eastmoneyPrefix = "unsupported Eastmoney asset: ";
    let prefix = "";
    let identity = trimmed;
    if (trimmed.startsWith(futuPrefix)) {
      prefix = "富途账户不支持的资产";
      identity = trimmed.slice(futuPrefix.length);
    } else if (trimmed.startsWith(eastmoneyPrefix)) {
      prefix = "东方财富账户不支持的资产";
      identity = trimmed.slice(eastmoneyPrefix.length);
    }
    if (!prefix) return trimmed;
    const match = identity.match(/^(.*?)\s*\((.*)\)$/);
    const symbol = match
      ? match[1].replace("<missing-symbol>", "代码缺失").replace("<missing-name>", "名称缺失")
      : identity;
    return `${prefix}：${symbol}`;
  });
  return `<p class="cn-trend-price-sources">账户例外：${labels.map(escapeHtml).join("；")}</p>`;
}

function renderTrendHoldingSource(report) {
  const status = trendRealHoldingStatus(report);
  if (status !== "available") return "";
  const source = trendRealHoldingSource(report);
  const broker = source.broker_label || report?.broker_label || "数据源";
  const period = source.snapshot_period || "数据未提供";
  const kind = {
    manual: "手工快照",
    live: "账户",
    live_account: "账户",
    statement: "结单",
  }[String(source.source_kind || "").trim().toLowerCase()] || "持仓快照";
  const freshness = source.freshness_text || "数据未提供";
  const readOnly = source.read_only_text || "只读，不自动下单";
  return `<p class="cn-trend-price-sources">${escapeHtml(formatPlain(`${broker} · ${kind} ${period} · ${freshness} · ${readOnly}`))}</p>${renderTrendAccountExceptions(source)}`;
}

function renderTrendHoldingPanel(report, view, items) {
  const status = trendRealHoldingStatus(report);
  if (view === "real") {
    if (status === undefined || status === null) {
      return '<p class="account-empty">当前报告未包含真实持仓判断</p>';
    }
    if (status === "legacy") {
      return '<p class="account-empty">当前报告未包含真实持仓判断</p>';
    }
    if (status === "unavailable") {
      const reason = trendRealHoldingReason(report) || "数据未提供";
      return `<p class="account-empty missing-text">真实持仓数据不可用：${escapeHtml(formatPlain(reason))}</p>`;
    }
    const rows = Array.isArray(items) ? items : [];
    const split = splitHistoricalTrendHoldings(rows, report);
    if (!split) {
      return `${renderTrendHoldingSource(report)}${renderHistoricalTrendHoldingWarning()}${renderTrendHoldingTable(rows, report)}`;
    }
    return `${renderTrendHoldingSource(report)}${renderHoldingOriginSection("趋势持仓", split.trend, renderTrendHoldingTable(split.trend, report))}${renderHoldingOriginSection("非趋势持仓", split.nonTrend, renderTrendHoldingTable(split.nonTrend, report))}`;
  }
  const rows = Array.isArray(items) ? items : [];
  return renderTrendHoldingTable(rows, report);
}

function renderTrendHoldingStage(report) {
  const realItems = Array.isArray(report?.real_position_actions) ? report.real_position_actions : [];
  const simulatedItems = Array.isArray(report?.hold_actions) ? report.hold_actions : [];
  return `<section class="trend-stage cn-trend-stage cn-trend-hold" data-trend-holding-section>
    <h2>盘中持续 · 已有持仓</h2>
    <div class="account-view-tabs" role="tablist" aria-label="趋势报告持仓视图">
      <button id="trend-holding-real-tab" class="account-view-tab" type="button" role="tab" data-trend-holding-view="real" aria-selected="true" tabindex="0" aria-controls="trend-holding-real-panel">真实持仓</button>
      <button id="trend-holding-simulate-tab" class="account-view-tab" type="button" role="tab" data-trend-holding-view="simulate" aria-selected="false" tabindex="-1" aria-controls="trend-holding-simulate-panel">模拟盘持仓</button>
    </div>
    <div id="trend-holding-real-panel" class="trend-holding-panel" role="tabpanel" aria-labelledby="trend-holding-real-tab" data-trend-holding-panel="real">
      ${renderTrendHoldingPanel(report, "real", realItems)}
    </div>
    <div id="trend-holding-simulate-panel" class="trend-holding-panel" role="tabpanel" aria-labelledby="trend-holding-simulate-tab" data-trend-holding-panel="simulate" hidden>
      ${renderTrendHoldingPanel(report, "simulate", simulatedItems)}
    </div>
  </section>`;
}

function handleTrendHoldingTab(event) {
  const button = event?.target?.closest?.("[data-trend-holding-view]");
  if (!button) return false;
  const section = button.closest("[data-trend-holding-section]");
  if (!section) return false;
  const view = button.dataset.trendHoldingView;
  if (!["real", "simulate"].includes(view)) return false;
  section.querySelectorAll("[data-trend-holding-view]").forEach((tab) => {
    const selected = tab.dataset.trendHoldingView === view;
    tab.setAttribute("aria-selected", String(selected));
    tab.tabIndex = selected ? 0 : -1;
  });
  section.querySelectorAll("[data-trend-holding-panel]").forEach((panel) => {
    panel.hidden = panel.dataset.trendHoldingPanel !== view;
  });
  return true;
}

function handleTrendHoldingTabKeydown(event) {
  const tab = event?.target?.closest?.("[data-trend-holding-view]");
  if (!tab || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
  const section = tab.closest("[data-trend-holding-section]");
  if (!section) return;
  event.preventDefault();
  const tabs = [...section.querySelectorAll("[data-trend-holding-view]")];
  const current = tabs.indexOf(tab);
  const index = event.key === "Home" ? 0
    : event.key === "End" ? tabs.length - 1
      : (current + (event.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length;
  handleTrendHoldingTab({target: tabs[index]});
  tabs[index].focus();
}

function renderTrendSellOrHoldStage(title, items, kind, report) {
  if (kind === "hold") {
    const rows = renderTrendHoldingRows(items, report);
    return renderCnTrendTable(title, kind, trendHoldingHeadings(), rows);
  }
  const action = { sell: trendSellActionLabel, review: () => "人工复核" }[kind] || (() => "继续持有");
  const reasonHeading = kind === "sell" ? "触发原因" : kind === "review" ? "复核原因" : "当前判断";
  const showClearanceType = kind === "sell" && (
    report?.allocation?.version === 2
    || (Array.isArray(items) && items.some((item) => hasValue(item?.clearance_type)))
  );
  const optionMarket = ["US", "HK"].includes(String(report?.market || "").toUpperCase());
  const headings = [
    "标的", "动作", "执行参考价", "温度变化", "节气", "强度",
    ...(kind === "hold" ? ["行业"] : []),
    ...(showClearanceType ? ["清仓类型"] : []),
    reasonHeading, "活动保护线", "持仓提示",
  ];
  const rows = cnTrendRows(items).map((item) => `<tr class="cn-trend-card${trendHoldingCarriedForwardClass(item, report) ? ` ${trendHoldingCarriedForwardClass(item, report)}` : ""}">
    ${kind === "hold" && optionMarket ? renderTrendOptionIdentityCell(item) : renderTrendCell("标的", trendIdentity(item))}
    ${renderTrendCell("动作", action(item))}
    ${renderTrendCell("执行参考价", hasValue(item.close) ? formatDisplayNumber(item.close) : null)}
    ${renderTrendCell("温度变化", trendTemperature(item))}
    ${renderTrendCell("节气", item.phase)}
    ${renderTrendCell("强度", hasValue(item.strength) ? formatDisplayNumber(item.strength) : null)}
    ${kind === "hold" ? renderTrendCell("行业", item.industry) : ""}
    ${showClearanceType ? renderTrendCell("清仓类型", item.clearance_type) : ""}
    ${renderTrendCell(reasonHeading, trendReasonLabel(item, report))}
    ${renderTrendCell("活动保护线", hasValue(item.active_line) ? formatDisplayNumber(item.active_line) : null)}
    ${renderTrendCell("持仓提示", trendHints(item))}
  </tr>`);
  return renderCnTrendTable(title, kind, headings, rows);
}

function isTrendRotationBuyAction(item) {
  return [item?.reason, item?.action].some((value) =>
    String(value || "").trim().toLowerCase() === "relative_rotation"
  );
}

function trendFinalPlanBuyActions(report) {
  const rows = cnTrendRows(report?.buy_actions);
  return usesFinalPlanTrendAudit(report)
    ? rows.filter((item) => !isTrendRotationBuyAction(item))
    : rows;
}

function renderTrendBuyStage(report) {
  const headings = [
    "标的", "动作", "筛选价（Trend Animals）", "执行参考价",
    "温度变化", "节气", "大类内强度", "全局强度", "行业", "行业温度", "行业确认", "市值（亿元）",
    "日成交额（亿元）", "目标仓位（占净值）", "目标金额", "预计数量", "预计保护线", "额外风险",
  ];
  const optionMarket = ["US", "HK"].includes(String(report?.market || "").toUpperCase());
  const row = (item, action) => {
    const targetWeight = decimalAsPercent(item.target_weight, null);
    const shares = hasValue(item.estimated_shares)
      ? `${formatDisplayNumber(item.estimated_shares)} 股` : null;
    const pending = item.executable === false;
    const sizingNote = hasValue(item.sizing_note) ? formatPlain(item.sizing_note) : null;
    return `<tr class="cn-trend-card${pending ? " trend-buy-pending" : ""}">
      ${optionMarket ? renderTrendOptionIdentityCell(item) : renderTrendCell("标的", trendIdentity(item))}
      ${renderTrendCell("动作", pending ? "待条件" : action)}
      ${renderTrendCell("筛选价（Trend Animals）", hasValue(item.filter_price) ? formatDisplayNumber(item.filter_price) : null)}
      ${renderTrendCell("执行参考价", hasValue(item.close) ? formatDisplayNumber(item.close) : null)}
      ${renderTrendCell("温度变化", trendTemperature(item))}
      ${renderTrendCell("节气", item.phase)}
      ${renderTrendCell("大类内强度", hasValue(item.strength) ? formatDisplayNumber(item.strength) : null)}
      ${renderTrendCell("全局强度", hasValue(item.global_strength) ? formatDisplayNumber(item.global_strength) : null)}
      ${renderTrendCell("行业", item.industry)}
      ${renderTrendCell("行业温度", trendIndustryBuyTemperature(report, item))}
      ${renderTrendCell("行业确认", trendIndustryBuyContext(report, item))}
      ${renderTrendCell("市值（亿元）", hasValue(trendMoney(item, "market_cap_cny_100m", "market_cap")) ? formatDisplayNumber(trendMoney(item, "market_cap_cny_100m", "market_cap")) : null)}
      ${renderTrendCell("日成交额（亿元）", hasValue(trendMoney(item, "amount_cny_100m", "amount")) ? formatDisplayNumber(trendMoney(item, "amount_cny_100m", "amount")) : null)}
      ${renderTrendCell("目标仓位（占净值）", targetWeight, hasValue(targetWeight) ? `目标仓位 ${targetWeight}` : "")}
      ${renderTrendCell("目标金额", hasValue(item.target_amount) ? formatDisplayNumber(item.target_amount) : null)}
      ${renderTrendCell("预计数量", shares)}
      ${renderTrendCell("预计保护线", hasValue(item.estimated_initial_line) ? formatDisplayNumber(item.estimated_initial_line) : null)}
      ${renderTrendCell("额外风险", sizingNote)}
    </tr>`;
  };
  const rows = trendFinalPlanBuyActions(report).map((item) => row(item, "正式买入"));
  const simulateStage = renderCnTrendTable(
    `${formatPlain(report.buy_window)} · 模拟盘正式买入计划`, "buy", headings, rows,
    "价格口径：筛选价（Trend Animals）｜执行参考价（各市场报告来源）",
  );
  if (usesFinalPlanTrendAudit(report)) return simulateStage;
  const realHeadings = ["卖出", "买入", "动作", "强度差", "目标仓位（占净值）", "目标金额", "预计数量", "目标交易日", "状态"];
  const realRows = cnTrendRows(report.real_rotation_pairs).map((pair) => {
    const executionStatus = [pair.execution_status, pair.status, pair.order_status].find(hasValue);
    const status = executionStatus ?? "待人工确认";
    return `<tr class="cn-trend-card">
      ${renderTrendCell("卖出", trendIdentity({symbol: pair.sell_symbol, name: pair.sell_name}))}
      ${renderTrendCell("买入", trendIdentity({symbol: pair.buy_symbol, name: pair.buy_name}))}
      ${renderTrendCell("动作", "卖出后买入")}
      ${renderTrendCell("强度差", hasValue(pair.strength_gap) ? formatDisplayNumber(pair.strength_gap) : null)}
      ${renderTrendCell("目标仓位（占净值）", decimalAsPercent(pair.target_weight, null))}
      ${renderTrendCell("目标金额", hasValue(pair.target_amount) ? formatDisplayNumber(pair.target_amount) : null)}
      ${renderTrendCell("预计数量", hasValue(pair.estimated_shares) ? `${formatDisplayNumber(pair.estimated_shares)} 股` : null)}
      ${renderTrendCell("目标交易日", pair.execution_date || report.report_date)}
      ${renderTrendCell("状态", status)}
    </tr>`;
  });
  const realStage = renderCnTrendTable(
    "实盘买入计划 · 人工确认", "buy", realHeadings, realRows,
    "按实盘持仓独立生成；仅人工确认，不自动下单。",
  );
  return simulateStage + realStage;
}

const TREND_DISCIPLINE_ROW_NAMES = {
  holding: new Set(["初始保护线", "过热跟踪", "保护线不下降", "活动保护线"]),
  exit: new Set([
    "退出条件", "过热止盈比例", "过热止盈信号", "过热止盈次数",
    "过热止盈取整", "不足一手处理", "清仓优先级",
  ]),
};

function trendFrozenStrategyRows(report) {
  const rows = report && Array.isArray(report.strategy_parameter_rows)
    ? report.strategy_parameter_rows
    : [];
  return rows.filter((row) => row && typeof row === "object" && !Array.isArray(row)
    && hasValue(row.group) && hasValue(row.name) && hasValue(row.value));
}

function trendDisplayedStrategyRows(report) {
  const current = report && Array.isArray(report.current_strategy_parameter_rows)
    ? report.current_strategy_parameter_rows
    : null;
  return current === null ? trendFrozenStrategyRows(report)
    : current.filter((row) => row && typeof row === "object" && !Array.isArray(row)
      && hasValue(row.group) && hasValue(row.name) && hasValue(row.value));
}

function trendDisciplineLifecycle(parameterRows) {
  const rows = Array.isArray(parameterRows)
    ? parameterRows.filter((row) => row && typeof row === "object" && !Array.isArray(row)
      && hasValue(row.group) && hasValue(row.name) && hasValue(row.value))
    : [];
  const groups = [
    {key: "entry", title: "入场门槛", rows: []},
    {key: "sort", title: "候选排序", rows: []},
    {key: "execution", title: "仓位与执行", rows: []},
    {key: "holding", title: "持有管理", rows: []},
    {key: "exit", title: "退出规则", rows: []},
    {key: "other", title: "其他设置", rows: []},
  ];
  const byKey = Object.fromEntries(groups.map((group) => [group.key, group]));
  rows.forEach((row) => {
    const group = formatPlain(row.group);
    const name = formatPlain(row.name);
    let key = "other";
    if (group === "候选来源" || group === "入场过滤") key = "entry";
    else if (group === "候选排序") key = "sort";
    else if (group === "仓位执行") key = "execution";
    else if (group === "退出保护") {
      key = TREND_DISCIPLINE_ROW_NAMES.holding.has(name) ? "holding"
        : TREND_DISCIPLINE_ROW_NAMES.exit.has(name) ? "exit" : "other";
    } else if (group === "累计回撤") {
      key = "other";
    }
    byKey[key].rows.push(row);
  });
  return groups;
}

function renderTrendDisciplineCategory(card) {
  const rows = card.rows || [];
  const compact = rows.slice(0, 2).map((row) => `${formatPlain(row.name)}：${formatPlain(row.value)}`).join("；");
  const emptyLabel = "本报告未提供该类纪律参数";
  const body = rows.length
    ? `<dl>${rows.map((row) => `<div><dt>${escapeHtml(`${formatPlain(row.group)} · ${formatPlain(row.name)}`)}</dt><dd>${escapeHtml(formatPlain(row.value))}</dd></div>`).join("")}</dl>`
    : `<p>${escapeHtml(emptyLabel)}</p>`;
  return `<details class="trend-discipline-category" data-discipline="${escapeHtml(card.key)}">
    <summary><strong>${escapeHtml(card.title)}</strong><span>${escapeHtml(`${rows.length} 项`)}</span><small>${escapeHtml(compact || emptyLabel)}</small></summary>
    <div class="trend-discipline-category-body">${body}</div>
  </details>`;
}

function renderTrendDisciplineCards(report) {
  const rows = trendDisplayedStrategyRows(report);
  const cards = trendDisciplineLifecycle(rows);
  const version = formatPlain(report?.current_strategy_version || report?.strategy_version || "-");
  const current = Array.isArray(report?.current_strategy_parameter_rows);
  const headline = `${cards.length} 类 · ${rows.length} 项 · ${current ? `当前版本 ${version}` : `报告版本 ${version}`}`;
  const note = current
    ? "展示当前生效纪律；所选报告的冻结参数仍保留在历史审计数据中。"
    : "当前纪律不可用，展示所选报告生成时冻结的策略参数。";
  return `<details class="trend-discipline-workspace" aria-label="纪律">
    <summary>纪律 <span>${escapeHtml(headline)}</span><small>已折叠</small></summary>
    <div class="trend-discipline-workspace-body">
      <p class="trend-discipline-note">${escapeHtml(note)}</p>
      <div class="trend-discipline-grid">${cards.map((card) => renderTrendDisciplineCategory(card)).join("")}</div>
    </div>
  </details>`;
}

function formatTrendApiCost(value) {
  const raw = formatPlain(value).trim();
  const match = raw.match(/^([+-]?)(\d+)(?:\.(\d+))?$/);
  if (!match) return raw;
  const sign = match[1];
  const integer = match[2];
  const fraction = match[3] || "";
  if (/^0+$/.test(`${integer}${fraction}`)) return "0";
  const normalizedInteger = integer.replace(/^0+(?=\d)/, "");
  const normalizedFraction = fraction.replace(/0+$/, "");
  return `${sign === "-" ? "-" : ""}${normalizedInteger}${normalizedFraction ? `.${normalizedFraction}` : ""}`;
}

function trendReportCostLabel(report) {
  const cost = report && report.api_cost && typeof report.api_cost === "object"
    ? report.api_cost : null;
  if (cost && hasValue(cost.label)) return formatPlain(cost.label);
  const actual = cost?.actual ?? report?.audit?.actual_api_cost;
  const estimated = cost?.estimated ?? report?.audit?.estimated_api_cost;
  if (hasValue(actual)) return `本报告 API 费用：实扣 ${formatTrendApiCost(actual)} Trend Animals 余额单位`;
  if (hasValue(estimated)) {
    const estimateComplete = cost?.estimate_complete ?? report?.estimated_api_cost_complete ?? true;
    return estimateComplete === false
      ? `本报告 API 费用：未知（快照估算 ${formatTrendApiCost(estimated)} Trend Animals 余额单位；成分费用未计）`
      : `本报告 API 费用：估算 ${formatTrendApiCost(estimated)} Trend Animals 余额单位（实扣不可得）`;
  }
  return "本报告 API 费用：未知";
}

function trendIndustryDirection(value) {
  return ({rising: "上升", falling: "下降", unchanged: "持平"})[String(value)] || formatPlain(value);
}

function trendIndustryPercent(value) {
  if (!hasValue(value)) return null;
  const number = Number(value);
  if (!Number.isFinite(number)) return null;
  const percent = Math.abs(number) <= 1 ? number * 100 : number;
  return `${percent.toLocaleString("zh-CN", {maximumFractionDigits: 2})}%`;
}

function trendIndustryTransition(current, prior) {
  const currentText = trendIndustryPercent(current);
  if (!currentText) return "未提供";
  const priorText = trendIndustryPercent(prior);
  return priorText ? `${priorText} → ${currentText}` : `${currentText} · 基准建立中`;
}

function trendIndustryStructureCopy(context) {
  if (!hasValue(context.aggregate_right_count_ratio)
      || !hasValue(context.aggregate_right_market_cap_ratio)) return "";
  const count = Number(context.aggregate_right_count_ratio);
  const marketCap = Number(context.aggregate_right_market_cap_ratio);
  if (!Number.isFinite(count) || !Number.isFinite(marketCap)) return "";
  const gap = (marketCap - count) * 100;
  const relation = gap > 0 ? "高于" : gap < 0 ? "低于" : "等于";
  const bias = gap > 0 ? "右侧更偏大市值成分"
    : gap < 0 ? "右侧更偏小市值成分" : "两个占比相同";
  let text = `当前右侧市值占比${relation}右侧个数占比 ${formatDisplayNumber(Math.abs(gap))} 个百分点，${bias}。`;
  const priorCount = hasValue(context.prior_aggregate_right_count_ratio)
    ? Number(context.prior_aggregate_right_count_ratio) : null;
  const priorMarketCap = hasValue(context.prior_aggregate_right_market_cap_ratio)
    ? Number(context.prior_aggregate_right_market_cap_ratio) : null;
  if (Number.isFinite(priorMarketCap)) {
    const marketCapChange = (marketCap - priorMarketCap) * 100;
    const marketCapDirection = marketCapChange > 0 ? "上升"
      : marketCapChange < 0 ? "下降" : "持平";
    text = `较前一有效交易日${marketCapDirection} ${formatDisplayNumber(Math.abs(marketCapChange))} 个百分点。${text}`;
  }
  if (Number.isFinite(priorCount) && Number.isFinite(priorMarketCap)) {
    const change = gap - (priorMarketCap - priorCount) * 100;
    const direction = change > 0 ? "扩大" : change < 0 ? "收窄" : "持平";
    text += `结构差较前值${direction} ${formatDisplayNumber(Math.abs(change))} 个百分点。`;
  }
  return `${text}该指标不是账户仓位或上涨概率。`;
}

function trendIndustryRatioChangeCopy(label, definition, current, prior) {
  if (!hasValue(current) || !Number.isFinite(Number(current))) return "";
  let text = `${label}：${definition}。`;
  if (hasValue(prior) && Number.isFinite(Number(prior))) {
    const change = (Number(current) - Number(prior)) * 100;
    const direction = change > 0 ? "上升" : change < 0 ? "下降" : "持平";
    text += `较前一有效交易日${direction} ${formatDisplayNumber(Math.abs(change))} 个百分点。`;
  } else {
    text += "历史基准建立中。";
  }
  return text;
}

function trendIndustryMetric(value, help) {
  const visible = value || "未提供";
  const label = help ? `${visible}：${help}` : visible;
  return `<button type="button" class="trend-industry-metric" data-trend-industry-help="${escapeHtml(help)}" aria-expanded="false" aria-label="${escapeHtml(label)}">${escapeHtml(visible)}</button>`;
}

function showTrendIndustryHelp(trigger, pinned = false) {
  const section = trigger.closest?.(".trend-industry-context");
  const tooltip = section?.querySelector?.(".trend-industry-tooltip");
  const text = trigger.dataset.trendIndustryHelp || "";
  if (!tooltip || !text) return;
  closeTrendIndustryHelp();
  tooltip.textContent = text;
  tooltip.hidden = false;
  tooltip.setAttribute("aria-hidden", "false");
  trigger.dataset.trendIndustryHelpOpen = pinned ? "pinned" : "hover";
  trigger.setAttribute("aria-expanded", String(pinned));
  const target = trigger.getBoundingClientRect();
  const box = tooltip.getBoundingClientRect();
  const viewportWidth = typeof window !== "undefined" ? window.innerWidth : 1024;
  tooltip.style.left = `${Math.min(Math.max(12, target.left), viewportWidth - box.width - 12)}px`;
  tooltip.style.top = `${target.top >= box.height + 20 ? target.top - box.height - 8 : target.bottom + 8}px`;
}

function closeTrendIndustryHelp(trigger = null) {
  const sections = trigger?.closest?.(".trend-industry-context")
    ? [trigger.closest(".trend-industry-context")]
    : [...(document.querySelectorAll?.(".trend-industry-context") || [])];
  sections.forEach((section) => {
    const tooltip = section.querySelector?.(".trend-industry-tooltip");
    if (tooltip) {
      tooltip.hidden = true;
      tooltip.setAttribute("aria-hidden", "true");
      tooltip.textContent = "";
    }
    section.querySelectorAll?.("[data-trend-industry-help]").forEach((item) => {
      delete item.dataset.trendIndustryHelpOpen;
      item.setAttribute("aria-expanded", "false");
    });
  });
}

function trendIndustryContextFallback(status, contexts) {
  if (!(contexts || []).length && !hasValue(status?.ordering_mode)
      && status?.current_complete !== true) {
    return '<p class="trend-industry-context-fallback">当前行业上下文未提供，无法确认排序；未使用当前规则</p>';
  }
  const mode = formatPlain(status?.ordering_mode);
  const invalid = mode.startsWith("legacy") || status?.current_complete === false;
  if (!invalid) return "";
  const reasons = [];
  if (status && hasValue(status.fallback_reason)) reasons.push(formatPlain(status.fallback_reason));
  if (status && status.validation_reasons && typeof status.validation_reasons === "object") {
    Object.values(status.validation_reasons).flatMap((value) => Array.isArray(value) ? value : [value])
      .filter(hasValue).forEach((reason) => reasons.push(formatPlain(reason)));
  }
  (contexts || []).filter((context) => context && context.valid === false).forEach((context) => {
    (Array.isArray(context.invalid_reasons) ? context.invalid_reasons : ["行业上下文无效"])
      .filter(hasValue).forEach((reason) => reasons.push(formatPlain(reason)));
  });
  const reasonText = [...new Set(reasons)].join("、") || "当前行业上下文不完整";
  return `<p class="trend-industry-context-fallback">当前行业上下文无效，已回退旧排序：${escapeHtml(reasonText)}</p>`;
}

function renderTrendIndustryContext(report) {
  const contexts = Array.isArray(report?.industry_contexts)
    ? report.industry_contexts.filter((context) => context && typeof context === "object" && !Array.isArray(context))
    : [];
  const status = report?.industry_context_status && typeof report.industry_context_status === "object"
    ? report.industry_context_status : {};
  if (usesFinalPlanTrendAudit(report) || usesV2TrendPlanLayout(report)) {
    const rows = contexts.map((context) => `<tr class="trend-industry-context-row${context.valid === false ? " invalid" : ""}">
      <th scope="row" data-label="行业"><strong>${escapeHtml(formatPlain(context.industry || "行业"))}</strong></th>
      <td data-label="当前温度">${escapeHtml(hasValue(context.temperature) ? formatPlain(context.temperature) : "数据未提供")}</td>
      <td data-label="温度方向">${escapeHtml(hasValue(context.temperature_direction) ? trendIndustryDirection(context.temperature_direction) : "数据未提供")}</td>
    </tr>`).join("");
    return `<section class="trend-industry-context" aria-label="行业上下文">
      <header><h2>行业上下文</h2><span>${escapeHtml(status.current_complete === false ? "当前数据不完整" : `${contexts.length} 个行业`)}</span></header>
      ${trendIndustryContextFallback(status, contexts)}
      ${rows
        ? `<div class="trend-industry-context-table-wrap"><table class="trend-industry-context-table"><thead><tr><th scope="col">行业</th><th scope="col">当前温度</th><th scope="col">温度方向</th></tr></thead><tbody>${rows}</tbody></table></div>`
        : "<p>行业上下文数据未提供</p>"}
    </section>`;
  }
  const rows = contexts.map((context) => {
    const countValue = trendIndustryTransition(
      context.aggregate_right_count_ratio,
      context.prior_aggregate_right_count_ratio,
    );
    const marketCapValue = trendIndustryTransition(
      context.aggregate_right_market_cap_ratio,
      context.prior_aggregate_right_market_cap_ratio,
    );
    const countHelp = trendIndustryRatioChangeCopy(
      "右侧个数占比", "右侧成分数 ÷ 行业有效成分数",
      context.aggregate_right_count_ratio,
      context.prior_aggregate_right_count_ratio,
    );
    const marketCapHelp = trendIndustryRatioChangeCopy(
      "右侧市值占比", "右侧成分总市值 ÷ 行业有效成分总市值",
      context.aggregate_right_market_cap_ratio,
      context.prior_aggregate_right_market_cap_ratio,
    );
    const countExplanation = countHelp || "当前右侧个数占比不可用。";
    const marketCapExplanation = marketCapHelp
      ? `${marketCapHelp}${trendIndustryStructureCopy(context)}`
      : "当前右侧市值占比不可用。";
    return `<tr class="trend-industry-context-row${context.valid === false ? " invalid" : ""}">
      <th scope="row" data-label="行业"><strong>${escapeHtml(formatPlain(context.industry || "行业"))}</strong></th>
      <td data-label="当前温度">${escapeHtml(hasValue(context.temperature) ? formatPlain(context.temperature) : "数据未提供")}</td>
      <td data-label="温度方向">${escapeHtml(hasValue(context.temperature_direction) ? trendIndustryDirection(context.temperature_direction) : "数据未提供")}</td>
      <td data-label="趋势强度">${escapeHtml(hasValue(context.strength) ? formatDisplayNumber(context.strength) : "数据未提供")}</td>
      <td data-label="温转热数量">${escapeHtml(hasValue(context.warm_to_hot_count) ? formatDisplayNumber(context.warm_to_hot_count) : "数据未提供")}</td>
      <td data-label="右侧个数占比">${trendIndustryMetric(countValue, countExplanation)}</td>
      <td data-label="右侧市值占比">${trendIndustryMetric(marketCapValue, marketCapExplanation)}</td>
    </tr>`;
  }).join("");
  const countHeader = trendIndustryMetric("右侧个数占比", "右侧成分数 ÷ 行业有效成分数。");
  const marketCapHeader = trendIndustryMetric("右侧市值占比", "右侧成分总市值 ÷ 行业有效成分总市值。");
  return `<section class="trend-industry-context" aria-label="行业上下文">
    <header><h2>行业上下文</h2><span>${escapeHtml(status.current_complete === false ? "当前数据不完整" : `${contexts.length} 个行业`)}</span></header>
    ${trendIndustryContextFallback(status, contexts)}
    ${rows
      ? `<div class="trend-industry-context-table-wrap"><table class="trend-industry-context-table"><thead><tr><th scope="col">行业</th><th scope="col">当前温度</th><th scope="col">温度方向</th><th scope="col">趋势强度</th><th scope="col">温转热数量</th><th scope="col">${countHeader}</th><th scope="col">${marketCapHeader}</th></tr></thead><tbody>${rows}</tbody></table></div><div class="trend-industry-tooltip" role="tooltip" aria-hidden="true" hidden></div>`
      : "<p>行业上下文数据未提供</p>"}
  </section>`;
}

function cnTrendAuditValue(value, suffix = "") {
  if (!hasValue(value)) return "数据未提供";
  if (typeof value === "boolean") return value ? "是" : "否";
  return `${formatDisplayNumber(value)}${suffix}`;
}

function cnTrendAuditDanger(value) {
  return value === true ? "已触发"
    : value === false ? "未触发"
    : "数据未提供";
}

function cnTrendAuditList(value) {
  return Array.isArray(value) && value.length
    ? value.map(formatPlain).join("或")
    : "";
}

function cnTrendAuditRequirement(parameters, key, render) {
  const value = parameters && typeof parameters === "object"
    ? parameters[key]
    : undefined;
  return hasValue(value) ? render(value) : "冻结策略参数未提供";
}

function cnTrendAuditReason(reason, item, parameters, report) {
  const temperature = `${cnTrendAuditValue(item.temperature_prev)} → ${cnTrendAuditValue(item.temperature_curr)}`;
  const rules = {
    a_share_only: ["资产类型", cnTrendAuditValue(item.asset), "要求：仅限 A 股股票"],
    temperature_missing: ["个股温度", "数据未提供", "要求：个股温度必须存在"],
    temperature_transition_not_entry: [
      "温度变化", temperature,
      cnTrendAuditRequirement(parameters, "temperature_transition", (value) => {
        const from = cnTrendAuditList(value && value.from);
        const to = cnTrendAuditList(value && value.to);
        return from && to ? `要求：${from} → ${to}` : "冻结策略参数未提供";
      }),
    ],
    filter_price_missing: ["筛选价", "数据未提供", "要求：筛选价必须存在"],
    filter_price_above_200: [
      "筛选价", cnTrendAuditValue(item.filter_price, " 元"),
      cnTrendAuditRequirement(parameters, "max_filter_price", (value) => `要求：不高于 ${formatDisplayNumber(value)} 元`),
    ],
    strength_missing: ["趋势强度", "数据未提供", "要求：趋势强度必须存在"],
    strength_below_95: [
      "趋势强度", cnTrendAuditValue(item.strength),
      cnTrendAuditRequirement(parameters, "min_strength", (value) => `要求：不低于 ${formatDisplayNumber(value)}`),
    ],
    industry_id_missing: ["行业 ID", "数据未提供", "要求：行业 ID 必须存在"],
    industry_temperature_missing: ["行业温度", "数据未提供", "要求：行业温度必须存在"],
    industry_temperature_not_hot: [
      "行业温度", cnTrendAuditValue(item.industry_temperature),
      cnTrendAuditRequirement(parameters, "allowed_industry_temperatures", (value) => `要求：${cnTrendAuditList(value) || "冻结策略参数未提供"}`),
    ],
    phase_missing: ["趋势节气", "数据未提供", "要求：趋势节气必须存在"],
    phase_after_summer_solstice: [
      "趋势节气", cnTrendAuditValue(item.phase),
      cnTrendAuditRequirement(parameters, "allowed_phases", (value) => `要求：${cnTrendAuditList(value) || "冻结策略参数未提供"}`),
    ],
    market_cap_missing: ["总市值", "数据未提供", "要求：总市值必须存在"],
    market_cap_below_100: [
      "总市值", cnTrendAuditValue(item.market_cap, " 亿元"),
      cnTrendAuditRequirement(parameters, "min_market_cap_100m", (value) => `要求：至少 ${formatDisplayNumber(value)} 亿元`),
    ],
    amount_missing: ["日成交额", "数据未提供", "要求：日成交额必须存在"],
    amount_below_2: [
      "日成交额", cnTrendAuditValue(item.amount, " 亿元"),
      cnTrendAuditRequirement(parameters, "min_amount_100m", (value) => `要求：至少 ${formatDisplayNumber(value)} 亿元`),
    ],
    right_side_days_missing: ["右侧天数", "数据未提供", "要求：右侧天数必须存在"],
    right_side_not_true: ["右侧趋势", "未进入右侧", "要求：必须处于右侧趋势"],
    not_tradable: ["交易状态", "当前不可交易", "要求：必须可交易"],
    danger_signal: ["危险信号", cnTrendAuditDanger(item.danger), "要求：不得触发"],
    danger_unknown: ["危险信号", "数据未提供", "要求：危险信号必须明确"],
    name_missing: ["标的名称", "数据未提供", "要求：标的名称必须存在"],
    asset_missing: ["资产类型", "数据未提供", "要求：资产类型必须存在"],
    unsupported_asset: ["资产类型", cnTrendAuditValue(item.asset), "要求：A 股股票"],
    already_held: ["账户状态", "当前已持有", "要求：新开仓候选不得已持有"],
    excluded_security: [
      "证券范围",
      [item.name, item.exchange].filter(hasValue).map(formatPlain).join(" / ") || "数据未提供",
      "要求：非北交所、ST 或退市标的",
    ],
    unsupported_exchange: ["交易所", cnTrendAuditValue(item.exchange), "要求：沪深市场"],
    atr_unavailable: ["ATR14", "数据未提供", "该历史策略版本要求 ATR14"],
    data_date_mismatch: [
      "数据日期", cnTrendAuditValue(item.as_of_date),
      hasValue(report && report.data_date)
        ? `要求：与报告数据日 ${formatPlain(report.data_date)} 一致`
        : "报告数据日未提供",
    ],
    amount_below_1: [
      "日成交额", cnTrendAuditValue(item.amount, " 亿元"),
      cnTrendAuditRequirement(parameters, "min_amount_100m", (value) => `要求：至少 ${formatDisplayNumber(value)} 亿元`),
    ],
    strength_not_above_90: [
      "趋势强度", cnTrendAuditValue(item.strength),
      cnTrendAuditRequirement(parameters, "min_strength", (value) => `要求：高于 ${formatDisplayNumber(value)}`),
    ],
    right_side_days_not_below_10: [
      "右侧天数", cnTrendAuditValue(item.days, " 天"),
      cnTrendAuditRequirement(parameters, "max_right_side_days_exclusive", (value) => `要求：少于 ${formatDisplayNumber(value)} 天`),
    ],
  };
  const values = Object.prototype.hasOwnProperty.call(rules, reason)
    ? rules[reason]
    : undefined;
  return values
    ? {code: reason, label: values[0], actual: values[1], requirement: values[2]}
    : {
      code: formatPlain(reason),
      label: `未识别规则：${formatPlain(reason)}`,
      actual: "无法解析",
      requirement: "请核对冻结报告",
    };
}

function cnTrendAuditTableTemperature(item) {
  return cnTrendAuditValue(item.temperature_prev) + " → " + cnTrendAuditValue(item.temperature_curr);
}

function renderFinalPlanTrendAudit(report) {
  const audit = report?.audit && typeof report.audit === "object" && !Array.isArray(report.audit)
    ? report.audit : {};
  const market = String(report?.market || "").trim().toUpperCase();
  const auditKey = (item, symbol = item?.symbol, futuSymbol = item?.futu_symbol) =>
    normalizeActionKey("", futuSymbol)
      || normalizeActionKey("", symbol)
      || normalizeActionKey(market, symbol);
  const plannedSymbols = new Set([
    ...cnTrendRows(report?.buy_actions),
    ...cnTrendRows(report?.simulate_rotation_pairs).map((item) => ({
      symbol: item.buy_symbol, futu_symbol: item.buy_futu_symbol,
    })),
    ...cnTrendRows(report?.real_rotation_pairs).map((item) => ({
      symbol: item.buy_symbol, futu_symbol: item.buy_futu_symbol,
    })),
  ].map((item) => auditKey(item)).filter(Boolean));
  const finalSkips = cnTrendRows(report?.risk_skips).filter(
    (item) => !plannedSymbols.has(auditKey(item)),
  );
  const disciplineFailures = cnTrendRows(audit.candidates).filter(
    (item) => item.eligible === false && !plannedSymbols.has(auditKey(item)),
  );
  const finalRows = finalSkips.map((item) => `<tr class="trend-audit-row">
    <td data-label="标的"><strong>${escapeHtml(cnTrendIdentity(item))}</strong></td>
    <td data-label="最终原因">${escapeHtml(formatPlain(item.reason || "未纳入买入计划"))}</td>
  </tr>`).join("") || '<tr class="trend-audit-empty"><td colspan="2">无</td></tr>';
  const failureRows = disciplineFailures.map((item) => `<tr class="trend-audit-row">
    <td data-label="标的"><strong>${escapeHtml(cnTrendIdentity(item))}</strong></td>
    <td data-label="纪律结果">没有通过纪律</td>
  </tr>`).join("") || '<tr class="trend-audit-empty"><td colspan="2">无</td></tr>';
  return `<details class="trend-audit"><summary>候选审计 · 为什么没有进入买入计划</summary>
    <section><h3>通过纪律，但未纳入最终计划</h3><table class="trend-audit-table"><thead><tr><th scope="col">标的</th><th scope="col">最终原因</th></tr></thead><tbody>${finalRows}</tbody></table></section>
    <section><details class="trend-audit-discipline"><summary>最后 · 没有通过纪律 ${disciplineFailures.length}</summary><table class="trend-audit-table"><thead><tr><th scope="col">标的</th><th scope="col">纪律结果</th></tr></thead><tbody>${failureRows}</tbody></table></details></section>
  </details>`;
}

function renderCnTrendAudit(audit, report = {}) {
  audit = audit && typeof audit === "object" ? audit : {};
  const candidates = cnTrendRows(audit.candidates);
  const parameters = audit.strategy_parameters
    && typeof audit.strategy_parameters === "object"
    && !Array.isArray(audit.strategy_parameters)
    ? audit.strategy_parameters : {};
  const industries = Array.isArray(audit.industry_concentration)
    ? audit.industry_concentration.filter(Array.isArray) : [];
  const dataSources = Array.isArray(audit.data_sources) ? audit.data_sources : [];
  const reasonCounts = new Map();

  const rows = candidates.map((item) => {
    const reasons = Array.isArray(item.excluded_reasons)
      ? item.excluded_reasons.map((reason) =>
        cnTrendAuditReason(reason, item, parameters, report))
      : [];
    reasons.forEach((reason) =>
      reasonCounts.set(reason.label, (reasonCounts.get(reason.label) || 0) + 1));
    const status = item.eligible === true
      ? {key: "passed", text: "通过纪律"}
      : item.eligible === false && reasons.length
        ? {key: "excluded", text: "已排除 · " + reasons.length + " 项未通过"}
        : item.eligible === false
          ? {key: "missing", text: "数据缺失"}
          : {key: "review", text: "待确认"};
    const failed = reasons.length
      ? reasons.map((reason) => (
        '<div class="trend-audit-reason"><strong>' + escapeHtml(reason.label)
          + '</strong><span>' + escapeHtml(reason.actual) + " → "
          + escapeHtml(reason.requirement) + "</span></div>"
      )).join("")
      : '<span class="trend-audit-none">无</span>';
    const facts = [
      "温度 " + cnTrendAuditTableTemperature(item),
      "强度 " + cnTrendAuditValue(item.strength),
      "节气 " + cnTrendAuditValue(item.phase),
      "危险信号 " + cnTrendAuditDanger(item.danger),
    ].map((fact) => "<span>" + escapeHtml(fact) + "</span>").join("");
    const details = Object.entries(item).map(([key, value]) => {
      const display = key === "rank" && !hasValue(value)
        ? "未进入候选排名"
        : Array.isArray(value)
        ? value.map(formatPlain).join("、")
        : value && typeof value === "object"
          ? JSON.stringify(value)
          : cnTrendAuditValue(value);
      return "<div><dt>" + escapeHtml(key) + "</dt><dd>"
        + escapeHtml(display) + "</dd></div>";
    }).join("");
    return '<tr class="trend-audit-row">'
      + '<td data-label="标的"><strong>' + escapeHtml(cnTrendIdentity(item))
      + '</strong><span>' + escapeHtml(cnTrendAuditValue(item.industry)) + "</span></td>"
      + '<td data-label="结论"><span class="trend-audit-status" data-status="'
      + status.key + '">' + escapeHtml(status.text) + "</span></td>"
      + '<td data-label="未通过项目"><div class="trend-audit-reasons">' + failed + "</div></td>"
      + '<td data-label="已通过的关键事实"><div class="trend-audit-facts">' + facts + "</div></td>"
      + '<td data-label="审计"><details class="trend-audit-more"><summary>查看全部字段</summary><dl>'
      + details + "</dl></details></td></tr>";
  }).join("");
  const passed = candidates.filter((item) => item.eligible === true).length;
  const excluded = candidates.filter((item) => item.eligible === false).length;
  const reasonSummary = [...reasonCounts.entries()]
    .map(([label, count]) => "<span>" + escapeHtml(label) + " " + count + "</span>").join("");
  const tableBody = rows || '<tr class="trend-audit-empty"><td colspan="5">无候选审计数据</td></tr>';
  return '<details class="trend-audit"><summary>审计详情</summary>'
    + '<section><h3>为什么没有进入买入名单</h3>'
    + '<div class="trend-audit-summary"><span>候选 ' + candidates.length
    + "</span><span>通过 " + passed + "</span><span>排除 " + excluded + "</span>"
    + '</div><div class="trend-audit-reason-counts">'
    + (reasonSummary || "<span>无未通过原因</span>")
    + '</div><table class="trend-audit-table"><thead><tr>'
    + '<th scope="col">标的</th><th scope="col">结论</th><th scope="col">未通过项目</th>'
    + '<th scope="col">已通过的关键事实</th><th scope="col">审计</th>'
    + "</tr></thead><tbody>" + tableBody + "</tbody></table></section>"
    + '<section><h3>行业集中度</h3><ul>'
    + (industries.length
      ? industries.map((item) => "<li>" + escapeHtml(item.map(formatPlain).join("｜")) + "</li>").join("")
      : "<li>无</li>")
    + "</ul></section>"
    + '<p>数据来源：' + escapeHtml(dataSources.map(formatPlain).join("、") || "无") + "</p>"
    + '<p>API 成本：' + escapeHtml(formatPlain(audit.actual_api_cost ?? audit.estimated_api_cost ?? "未知"))
    + "</p></details>";
}

function renderTrendAllocation(report) {
  const allocation = report?.allocation;
  const roots = allocation?.roots;
  const markets = allocation?.markets;
  if (!allocation || typeof allocation !== "object" || !roots || !markets) return "";
  const currentMarket = String(report.market || "").toUpperCase();
  const v2 = allocation.version === 2;
  const cards = [
    ["CN", "A股"], ["HK", "港股"], ["US", "美股"],
  ].sort(([left], [right]) => (
    Number(markets[left]?.rank ?? Infinity) - Number(markets[right]?.rank ?? Infinity)
  )).map(([market, label]) => {
    const root = roots[market] || {};
    const values = markets[market] || {};
    const stock = root.stock || {};
    const etf = root.etf || {};
    const current = market === currentMarket ? " · 当前报告" : "";
    const details = v2
      ? `<div><dt>${escapeHtml(formatPlain(stock.asset))} 全局强度</dt><dd>${escapeHtml(formatDisplayNumber(stock.global_strength))}</dd></div>
        <div aria-label="单仓基准 4%"><dt>单仓基准</dt><dd>4%</dd></div>
        <div aria-label="持仓席位 ${escapeHtml(formatPlain(values.position_limit))}"><dt>持仓席位</dt><dd>${escapeHtml(formatPlain(values.position_limit))}</dd></div>
        <div aria-label="席位名义仓位 ${escapeHtml(decimalAsPercent(values.nominal_weight, "-"))}"><dt>席位名义仓位</dt><dd>${escapeHtml(decimalAsPercent(values.nominal_weight, "-"))}</dd></div>`
      : `<div><dt>${escapeHtml(formatPlain(stock.asset))} 全局强度</dt><dd>${escapeHtml(formatDisplayNumber(stock.global_strength))}</dd></div>
        <div><dt>${escapeHtml(formatPlain(etf.asset))} 全局强度</dt><dd>${escapeHtml(formatDisplayNumber(etf.global_strength))}</dd></div>
        <div><dt>市场分数</dt><dd>${escapeHtml(formatDisplayNumber(values.score))}</dd></div>
        <div><dt>分数来源</dt><dd>${escapeHtml(formatPlain(values.score_source))}</dd></div>
        <div aria-label="单仓基准 ${escapeHtml(decimalAsPercent(values.entry_weight, "-"))}"><dt>单仓基准</dt><dd>${escapeHtml(decimalAsPercent(values.entry_weight, "-"))}</dd></div>
        <div aria-label="10 席位名义仓位 ${escapeHtml(decimalAsPercent(values.nominal_weight, "-"))}"><dt>10 席位名义仓位</dt><dd>${escapeHtml(decimalAsPercent(values.nominal_weight, "-"))}</dd></div>`;
    return `<article class="trend-allocation-card" data-market="${market}" data-current-report="${market === currentMarket}">
      <header><h3>${escapeHtml(label)}</h3><span>第 ${escapeHtml(formatPlain(values.rank))} 名${current}</span></header>
      <dl>${details}</dl>
      <p>来源 ${escapeHtml(formatPlain(stock.as_of_date))}${v2 ? "" : ` / ${escapeHtml(formatPlain(etf.as_of_date))}`}</p>
    </article>`;
  }).join("");
  const status = allocation.reused
    ? `沿用旧排名 · ${formatPlain(allocation.stale_a_trading_days)} 个 A 股交易日 · 原快照 ${formatPlain(allocation.allocation_date)}`
    : "当日排名";
  const failure = hasValue(allocation.failure_reason)
    ? `<p class="trend-allocation-warning">本次更新失败原因：${escapeHtml(formatPlain(allocation.failure_reason))}</p>`
    : "";
  return `<section class="trend-allocation-panel" aria-label="市场资源排名">
    <header><h2>市场资源排名</h2><span data-status="${allocation.reused ? "reused" : "current"}">${escapeHtml(status)}</span></header>
    <div class="trend-allocation-cards">${cards}</div>
    <p class="trend-allocation-meta">“全局强度”采用趋势动物 API 返回的全局比较值，不是小程序收藏夹显示的收藏夹内排名分位。</p>
    <p class="trend-allocation-meta">快照 ${escapeHtml(formatPlain(allocation.allocation_date))}｜生成 ${escapeHtml(formatPlain(allocation.generated_at))}｜目标交易日 ${escapeHtml(formatPlain(report.report_date))}｜SHA ${escapeHtml(String(allocation.sha256 || "-").slice(0, 12))}</p>
    ${failure}
  </section>`;
}

function renderTrendRotations(report) {
  if (!report?.allocation) return "";
  const group = (title, mode, comparisons, pairs, statusLabel) => {
    const comparisonRows = cnTrendRows(comparisons).filter(
      (comparison) => String(comparison.outcome || "") === "planned",
    );
    const headings = [
      "卖出标的", "买入标的", "比较口径", "大类内强度", "全局强度", "强度差",
      "判断", "目标仓位（占净值）", "目标金额", "预计数量", "目标交易日", statusLabel,
    ];
    const sourceRows = comparisonRows.length
      ? comparisonRows.map((comparison) => ({
          comparison,
          pair: cnTrendRows(pairs).find((item) => item.pair_index === comparison.pair_index) || {},
        }))
      : cnTrendRows(pairs).map((pair) => ({pair}));
    const rows = sourceRows.map(({comparison, pair}) => {
      comparison = comparison || {
        sell_symbol: pair.sell_symbol,
        sell_name: pair.sell_name,
        buy_symbol: pair.buy_symbol,
        buy_name: pair.buy_name,
        strength_basis: "global",
        sell_local_strength: null,
        buy_local_strength: null,
        sell_global_strength: pair.sell_global_strength,
        buy_global_strength: pair.buy_global_strength,
        strength_gap: pair.strength_gap,
      };
      const basisLabel = comparison.strength_basis === "local" ? "大类内强度" : comparison.strength_basis === "global" ? "全局强度" : "数据未提供";
      const executionStatus = [pair.execution_status, pair.status, pair.order_status].find(hasValue);
      const status = executionStatus ?? (mode === "automatic" ? "待执行" : "待人工确认");
      const route = (label, localValue, globalValue) => renderTrendCell(
        label,
        `${hasValue(localValue) ? formatDisplayNumber(localValue) : "数据未提供"} → ${hasValue(globalValue) ? formatDisplayNumber(globalValue) : "数据未提供"}`,
      );
      return `<tr class="cn-trend-card">
        ${renderTrendCell("卖出标的", trendIdentity({symbol: comparison.sell_symbol, name: comparison.sell_name}))}
        ${renderTrendCell("买入标的", trendIdentity({symbol: comparison.buy_symbol, name: comparison.buy_name}))}
        ${renderTrendCell("比较口径", basisLabel)}
        ${route("大类内强度", comparison.sell_local_strength, comparison.buy_local_strength)}
        ${route("全局强度", comparison.sell_global_strength, comparison.buy_global_strength)}
        ${renderTrendCell("强度差", hasValue(comparison.strength_gap) ? formatDisplayNumber(comparison.strength_gap) : null)}
        ${renderTrendCell("判断", "已触发")}
        ${renderTrendCell("目标仓位（占净值）", decimalAsPercent(pair.target_weight, null))}
        ${renderTrendCell("目标金额", hasValue(pair.target_amount) ? formatDisplayNumber(pair.target_amount) : null)}
        ${renderTrendCell("预计数量", hasValue(pair.estimated_shares) ? `${formatDisplayNumber(pair.estimated_shares)} 股` : null)}
        ${renderTrendCell("目标交易日", pair.execution_date || report.report_date)}
        ${renderTrendCell(statusLabel, status)}
      </tr>`;
    });
    return renderCnTrendTable(
      title, "buy", headings, rows,
      mode === "automatic"
        ? "只显示已触发（强度差 ≥ 20）的合格轮换；未达标项不显示。"
        : "按实盘持仓独立生成；仅人工确认，不自动下单。",
    );
  };
  return `<section class="trend-rotation-panel" aria-label="相对强度轮换"><h2>相对强度轮换</h2>`
    + group("模拟盘自动轮换", "automatic", report.simulate_rotation_comparisons, report.simulate_rotation_pairs, "执行状态")
    + group("实盘手动轮换", "manual", report.real_rotation_comparisons, report.real_rotation_pairs, "状态")
    + `</section>`;
}

function renderCnTrendReportWorkspace(report, embedded = false, historical = false, trailingContent = "") {
  const counts = report.counts || {};
  const audit = report.audit || {};
  const isCn = String(report.market || "").toUpperCase() === "CN";
  const v2PlanLayout = usesV2TrendPlanLayout(report);
  const finalPlanAudit = usesFinalPlanTrendAudit(report);
  const sellOrHold = renderTrendSellOrHoldStage;
  const buyStage = v2PlanLayout
    ? renderTrendV2Plans(report)
    : finalPlanAudit && !trendFinalPlanBuyActions(report).length
      ? "" : renderTrendBuyStage(report);
  const root = embedded ? "div" : "main";
  const identity = report.artifact && report.report_sha256 && report.strategy_version
    ? ` data-report-artifact="${escapeHtml(formatPlain(report.artifact))}" data-report-sha256="${escapeHtml(formatPlain(report.report_sha256))}" data-strategy-version="${escapeHtml(formatPlain(report.strategy_version))}"`
    : "";
  const strategyVersion = report.strategy_version
    ? `<span>版本 ${escapeHtml(formatPlain(report.strategy_version))}</span>`
    : "";
  const batchSha = report.execution_batch?.report_sha256;
  const revisionAnomaly = report.revision_anomaly === true
    ? `<p class="trend-revision-anomaly">发现后续报告版本，执行仍锁定原批次 · 批次 ${escapeHtml(String(batchSha || "—").slice(0, 12))} · 最新 ${escapeHtml(String(report.latest_report_sha256 || "—").slice(0, 12))}</p>`
    : "";
  const batchError = report.execution_batch_blocking === true
    ? `<p class="trend-execution-batch-error">${escapeHtml(formatPlain(report.execution_batch_error || "执行批次无效，已阻止操作投影"))}</p>`
    : "";
  const sellStage = v2PlanLayout
    ? ""
    : sellOrHold("优先处理 · 卖出触发", report.sell_actions, "sell", report);
  const reviewStage = Array.isArray(report.review_actions) && report.review_actions.length
    ? sellOrHold("需要确认 · 人工复核", report.review_actions, "review", report)
    : "";
  const holdStage = renderTrendHoldingStage(report);
  const disciplineCards = renderTrendDisciplineCards(report);
  const industryContext = renderTrendIndustryContext(report);
  const riskSummary = renderTrendRiskSummary(report.risk_summary, report.drawdown_summary, report.report_date);
  const allocation = renderTrendAllocation(report);
  const rotations = v2PlanLayout ? "" : renderTrendRotations(report);
  const readinessBanner = renderTrendReadinessBanner(report);
  return `<${root} class="cn-trend-report"${identity}>
    <header class="trend-report-header">
      <div><p>${escapeHtml(`${formatPlain(report.broker_label)}｜${formatPlain(report.market_label)}`)}</p><h1>当天趋势报告</h1>${strategyVersion}</div>
      ${embedded
        ? historical
          ? `<button class="trend-history-button" type="button" data-current-trend-report="${escapeHtml(report.broker)}">返回当前报告</button>`
          : `<button class="trend-history-button" type="button" data-report-history="${escapeHtml(report.broker)}">历史报告</button>`
        : '<button type="button" data-close-trend-report>返回持仓看板</button>'}
      <dl>
        <div><dt>报告</dt><dd>${escapeHtml(formatPlain(report.report_date))}</dd></div>
        <div><dt>数据</dt><dd>${escapeHtml(formatPlain(report.data_date))}</dd></div>
        <div><dt>生成</dt><dd>${escapeHtml(formatPlain(report.generated_at))}</dd></div>
        <div><dt>账户</dt><dd>${escapeHtml(formatPlain(report.account_status))}</dd></div>
      </dl>
      <div class="trend-report-metrics cn-trend-counts">
        <span>卖出 ${escapeHtml(formatDisplayNumber(counts.sell || 0))}</span>
        <span>买入 ${escapeHtml(formatDisplayNumber(counts.buy || 0))}</span>
        <span>持有 ${escapeHtml(formatDisplayNumber(counts.hold || 0))}</span>
        <span>复核 ${escapeHtml(formatDisplayNumber(counts.review || 0))}</span>
      </div>
      <div class="trend-report-facts">
        <span>状态 ${escapeHtml(formatPlain(report.status_text || report.data_status || report.account_status || "数据未提供"))}</span>
        <span class="trend-report-cost">${escapeHtml(trendReportCostLabel(report))}</span>
      </div>
      ${renderTrendHoldingFreshnessNote(report, historical)}
    </header>
    ${readinessBanner}
    ${renderTrendKellyObservation(report.kelly_observation, report)}
    ${renderTrendV2ExecutionStatus(report)}
    ${allocation}
    ${batchError}
    ${revisionAnomaly}
    ${sellStage}
    ${rotations}
    ${buyStage}
    ${reviewStage}
    ${holdStage}
    ${industryContext}
    ${disciplineCards}
    ${riskSummary}
    ${renderTrendControllerStatus(report.broker)}
    ${finalPlanAudit ? renderFinalPlanTrendAudit(report) : isCn ? renderCnTrendAudit(audit, report) : renderTrendAudit(audit)}
    ${trailingContent}
  </${root}>`;
}

function trendSellActionLabel(item) {
  return item?.action === "SELL_PARTIAL" ? "止盈减仓 30%" : "全部卖出";
}

function renderTrendReadinessBanner(report) {
  const controller = state.dashboard?.trend_controllers?.[report.broker] || {};
  if (report.ready_for_next_trading_day) {
    return `<div class="trend-readiness-banner ready" role="status"><strong>最新报告</strong><span>可用于下一交易日 ${escapeHtml(formatPlain(report.report_date))}。</span></div>`;
  }
  const waiting = controller.waiting;
  if (waiting) {
    return `<div class="trend-readiness-banner waiting" role="status"><strong>报告未就绪</strong><span>${escapeHtml(formatPlain(waiting))}</span></div>`;
  }
  return "";
}

function renderTrendV2ExecutionStatus(report) {
  if (!usesV2TrendPlanLayout(report)) return "";
  const batch = report.execution_batch && typeof report.execution_batch === "object"
    ? report.execution_batch : {};
  const status = report.execution_batch_blocking === true
    ? report.execution_batch_error || "执行批次不可用"
    : report.run_status || report.status_text || "未开始";
  return `<details class="trend-execution-status" open>
    <summary>报告与执行状态 <span>${escapeHtml(formatPlain(status))}</span></summary>
    <dl>
      <div><dt>报告 SHA</dt><dd>${escapeHtml(formatPlain(report.report_sha256 || "—"))}</dd></div>
      <div><dt>执行日期</dt><dd>${escapeHtml(formatPlain(report.execution_date || report.report_date || "—"))}</dd></div>
      <div><dt>执行状态</dt><dd>${escapeHtml(formatPlain(status))}</dd></div>
      ${hasValue(batch.report_sha256) ? `<div><dt>执行批次 SHA</dt><dd>${escapeHtml(formatPlain(batch.report_sha256))}</dd></div>` : ""}
    </dl>
  </details>`;
}

function renderTrendControllerStatus(broker) {
  const configured = state.dashboard?.trend_controllers?.[broker];
  const controller = configured && typeof configured === "object"
    ? configured
    : {health: "unavailable", blocking: false, reason: "控制器状态未提供"};
  const health = String(controller.health || "unavailable");
  const blocking = controller.blocking === true;
  const headline = health === "readonly"
    ? "只读部署，不运行本机控制器"
    : health === "healthy" ? "执行主机控制器正常" : "控制器不可用";
  const facts = [
    ["执行模式", controller.effective_mode],
    ["执行主机", controller.executor_host],
    ["本地主机", controller.local_host],
    ["PID", controller.pid],
    ["Git SHA", controller.git_sha],
    ["当前阶段", controller.phase],
    ["心跳", controller.heartbeat_at],
    ["最近成功", formatTrendControllerLastSuccess(controller.last_success)],
    ["当前阻塞", controller.blocker || controller.reason],
    ["下次检查", controller.next_check_at],
  ];
  return `<details class="trend-controller-status${blocking ? " blocking" : ""}" data-health="${escapeHtml(health)}">
    <summary>策略控制器 <span>${escapeHtml(headline)}</span><small>已折叠</small></summary>
    <div class="trend-controller-status-body"><dl>${facts.map(([label, value]) => `<div><dt>${label}</dt><dd>${escapeHtml(hasValue(value) ? formatPlain(value) : "—")}</dd></div>`).join("")}</dl></div>
  </details>`;
}

function formatTrendControllerLastSuccess(value) {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value !== "object" || Array.isArray(value)) return formatPlain(value);
  const labels = {
    status: "状态", market: "市场", date: "日期",
    submitted_count: "提交数", artifact_paths: "产物",
  };
  const keys = ["status", "market", "date", "submitted_count", "artifact_paths"]
    .filter((key) => Object.hasOwn(value, key));
  const ordered = keys.length ? keys : Object.keys(value).sort();
  const parts = ordered.map((key) => {
    const item = value[key];
    const rendered = Array.isArray(item)
      ? item.length ? item.map(formatPlain).join("，") : "无"
      : formatPlain(item);
    return `${labels[key] || key} ${rendered}`;
  });
  return parts.length ? parts.join(" · ") : "—";
}

function renderTrendReportWorkspace(report, embedded = false, historical = false, trailingContent = "") {
  return renderCnTrendReportWorkspace(report || {}, embedded, historical, trailingContent);
}

function renderHeaderSummary() {
  const summary = state.accountSnapshot?.summary || {};
  elements["current-view-value"].textContent = formatMoney(summary.portfolio_value_hkd, "HKD");
  elements["current-view-holding-value"].textContent = `持仓资产 ${formatMoney(summary.holding_value_hkd, "HKD")}`;
  elements["current-view-holding-weight"].textContent = formatPlain(summary.holding_weight_hkd);
  elements["current-view-cash-note"].textContent = `现金类资产 ${formatMoney(summary.cash_like_value_hkd, "HKD")} · 持仓 ${formatDisplayNumber(summary.holding_count)}`;
  elements["current-view-label"].textContent = currentViewLabel(activeAccountRowCount());
}

function activeAccountRowCount() {
  const group = accountHoldingGroups().find((item) => item.broker === state.brokerFilter);
  if (!group) return 0;
  return group.rows.filter(({display}) => state.marketFilter === "ALL"
    || String(display.market || "").toUpperCase() === state.marketFilter).length;
}

function currentViewLabel(count) {
  const marketLabel = state.marketFilter === "ALL" ? "全部市场" : state.marketFilter === "CN" ? "A 股" : state.marketFilter;
  const brokerLabel = brokerDisplayName(state.brokerFilter);
  return `当前视图：${marketLabel} · ${brokerLabel} · ${formatDisplayNumber(count)} 条`;
}

function renderSummary() {
  const snapshot = state.accountSnapshot || {};
  const summary = snapshot.summary || {};
  elements["summary-value"].textContent = formatMoney(summary.portfolio_value_hkd, "HKD");
  elements["summary-holding-value"].textContent = `持仓资产 ${formatMoney(summary.holding_value_hkd, "HKD")}`;
  elements["summary-holding-weight"].textContent = formatPlain(summary.holding_weight_hkd);
  elements["summary-cash-note"].textContent = `现金类资产 ${formatMoney(summary.cash_like_value_hkd, "HKD")} · ${formatPlain(summary.cash_like_weight_hkd)} · 持仓 ${formatDisplayNumber(summary.holding_count)}`;
  elements["summary-holding-bar"].style.width = percentBarWidth(summary.holding_weight_hkd);
  elements["summary-brokers"].textContent = `${formatDisplayNumber(summary.broker_count)} 个`;
  elements["summary-detail-month"].textContent = snapshot.generated_at
    ? `账户快照 ${snapshot.generated_at}` : "账户快照不可用";
  elements["summary-health"].textContent = accountActionsEnabled() ? "明细可用" : "账户不可用";
  elements["summary-health-note"].textContent = accountSnapshotStatusText();
}

function percentBarWidth(value) {
  if (!hasValue(value)) {
    return "0%";
  }
  const parsed = Number.parseFloat(String(value).replace("%", ""));
  if (!Number.isFinite(parsed)) {
    return "0%";
  }
  return `${Math.min(100, Math.max(0, parsed))}%`;
}

function firstPresent(...values) {
  return values.find((value) => hasValue(value));
}

function renderHoldings() {
  renderAccountHoldings();
}

function renderAccountTabs(groups) {
  const counts = new Map(groups.map((group) => [group.broker, group.rows.length]));
  return ACCOUNT_BROKERS.map((broker) => {
    const selected = broker === state.brokerFilter;
    return `<button id="account-tab-${escapeHtml(broker)}" class="account-tab ${selected ? "active" : ""}" type="button" role="tab"
      data-broker="${escapeHtml(broker)}" aria-selected="${selected}" tabindex="${selected ? "0" : "-1"}" aria-controls="account-holdings">
      ${escapeHtml(brokerDisplayName(broker))}<span>${escapeHtml(formatDisplayNumber(counts.get(broker) || 0))}</span>
    </button>`;
  }).join("");
}

function selectBroker(broker) {
  if (!ACCOUNT_BROKERS.includes(broker)) return;
  state.brokerFilter = broker;
  state.selectedHoldingKey = "";
  state.selectedHoldingDetail = "decision";
  syncDecisionDeepLink();
  renderAccountHoldings();
  if (elements["current-view-label"]) renderHeaderSummary();
}

function handleBrokerSelection(event) {
  const button = event.target.closest("[data-broker]");
  if (button) selectBroker(button.dataset.broker || "");
}

function handleBrokerTabKeydown(event) {
  const tab = event.target.closest('[role="tab"][data-broker]');
  if (!tab || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
  event.preventDefault();
  const current = ACCOUNT_BROKERS.indexOf(tab.dataset.broker || "");
  const index = event.key === "Home" ? 0
    : event.key === "End" ? ACCOUNT_BROKERS.length - 1
      : (current + (event.key === "ArrowRight" ? 1 : -1) + ACCOUNT_BROKERS.length) % ACCOUNT_BROKERS.length;
  const broker = ACCOUNT_BROKERS[index];
  selectBroker(broker);
  elements["account-tabs"].querySelector(`[data-broker="${broker}"]`)?.focus();
}

function accountViewLabel(broker, view) {
  if (view === "real") return "真实持仓";
  if (view === "simulate") return "模拟盘持仓";
  return "趋势报告";
}

function renderAccountViewTabs(broker) {
  const selectedView = state.accountViews[broker] || "real";
  return `<div class="account-view-tabs" role="tablist" aria-label="${escapeHtml(brokerDisplayName(broker))}账户视图">
    ${ACCOUNT_VIEW_KEYS.map((view) => {
      const selected = view === selectedView;
      return `<button id="account-${escapeHtml(broker)}-view-${escapeHtml(view)}" class="account-view-tab" type="button" role="tab" data-account-broker="${escapeHtml(broker)}" data-account-view="${escapeHtml(view)}" aria-selected="${selected}" tabindex="${selected ? "0" : "-1"}" aria-controls="account-${escapeHtml(broker)}-view-panel">${escapeHtml(accountViewLabel(broker, view))}</button>`;
    }).join("")}
  </div>`;
}

async function setAccountView(broker, view) {
  if (!TREND_ACCOUNT_BROKERS.includes(broker) || !ACCOUNT_VIEW_KEYS.includes(view)) return;
  state.accountViews[broker] = view;
  state.selectedHoldingKey = "";
  state.selectedHoldingDetail = "decision";
  state.selectedDecisionTab = "final";
  syncDecisionDeepLink();
  const needsSimulation = view === "simulate";
  if (needsSimulation && !Object.hasOwn(state.trendSimulatePositions, broker)) {
    await loadTrendSimulatePositions(broker);
  } else {
    renderAccountViewPanelOnly(broker);
  }
}

function handleAccountViewTabKeydown(event) {
  const tab = event.target.closest('[role="tab"][data-account-view]');
  if (!tab || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
  event.preventDefault();
  const broker = tab.dataset.accountBroker || "";
  const current = ACCOUNT_VIEW_KEYS.indexOf(tab.dataset.accountView || "");
  const index = event.key === "Home" ? 0
    : event.key === "End" ? ACCOUNT_VIEW_KEYS.length - 1
      : (current + (event.key === "ArrowRight" ? 1 : -1) + ACCOUNT_VIEW_KEYS.length) % ACCOUNT_VIEW_KEYS.length;
  const view = ACCOUNT_VIEW_KEYS[index];
  setAccountView(broker, view);
  elements["account-holdings"].querySelector(`[data-account-view="${view}"]`)?.focus();
}

async function loadTrendSimulatePositions(broker) {
  if (state.accountViews[broker] !== "simulate") return;
  state.trendSimulatePositions[broker] = {loading: true};
  renderAccountViewPanelOnly(broker);
  try {
    const response = await fetch(`/api/trend-simulate-positions/${encodeURIComponent(broker)}`, {cache: "no-store"});
    if (!response.ok) throw new Error(`simulate positions ${response.status}`);
    state.trendSimulatePositions[broker] = await response.json();
  } catch (error) {
    state.trendSimulatePositions[broker] = {
      available: false,
      positions: [],
      error: error instanceof Error ? error.message : String(error),
    };
  }
  if (state.brokerFilter === broker && state.accountViews[broker] === "simulate") {
    renderAccountViewPanelOnly(broker);
  }
}

function accountScrollY() {
  return typeof window !== "undefined" && Number.isFinite(window.scrollY) ? window.scrollY : 0;
}

function restoreAccountScroll(scrollY) {
  if (typeof window !== "undefined" && typeof window.scrollTo === "function") {
    window.scrollTo(0, scrollY);
  }
}

async function openTrendReportHistory(broker) {
  if (!TREND_ACCOUNT_BROKERS.includes(broker)) return;
  const existing = state.trendReportHistories[broker];
  const scrollY = accountScrollY();
  if (existing && Array.isArray(existing.rows)) {
    state.trendReportHistories[broker] = {...existing, open: true, scrollY};
    renderAccountViewPanelOnly(broker);
    if (state.brokerFilter === broker) restoreAccountScroll(scrollY);
    return;
  }
  state.trendReportHistories[broker] = {open: true, loading: true, rows: [], scrollY};
  renderAccountViewPanelOnly(broker);
  try {
    const response = await fetch(`/api/trend-reports/${encodeURIComponent(broker)}/history`, {cache: "no-store"});
    if (!response.ok) throw new Error(`report history ${response.status}`);
    const rows = await response.json();
    const history = state.trendReportHistories[broker] || {};
    state.trendReportHistories[broker] = {
      ...history,
      loading: false,
      rows,
      error: "",
    };
  } catch (error) {
    const history = state.trendReportHistories[broker] || {};
    state.trendReportHistories[broker] = {
      ...history,
      loading: false,
      rows: [],
      error: error instanceof Error ? error.message : String(error),
    };
  }
  const history = state.trendReportHistories[broker];
  if (state.brokerFilter === broker && state.accountViews[broker] === "report" && history.open) {
    renderAccountViewPanelOnly(broker);
    restoreAccountScroll(history.scrollY);
  }
}

async function loadHistoricalTrendReport(broker, artifact) {
  if (!TREND_ACCOUNT_BROKERS.includes(broker) || !artifact) return;
  state.trendReportHistories[broker] = {
    ...(state.trendReportHistories[broker] || {}),
    open: true,
    scrollY: accountScrollY(),
  };
  state.accountViews[broker] = "report";
  state.trendHistoricalReports[broker] = {artifact, loading: true};
  renderAccountViewPanelOnly(broker);
  try {
    const response = await fetch(`/api/trend-reports/${encodeURIComponent(broker)}/history/${encodeURIComponent(artifact)}`, {cache: "no-store"});
    if (!response.ok) throw new Error(`historical report ${response.status}`);
    const report = await response.json();
    if (state.trendHistoricalReports[broker]?.artifact !== artifact) return;
    state.trendHistoricalReports[broker] = {artifact, report};
  } catch (error) {
    if (state.trendHistoricalReports[broker]?.artifact !== artifact) return;
    state.trendHistoricalReports[broker] = {
      artifact,
      error: error instanceof Error ? error.message : String(error),
    };
  }
  const history = state.trendReportHistories[broker] || {};
  if (state.brokerFilter === broker
      && state.accountViews[broker] === "report"
      && history.open
      && state.trendHistoricalReports[broker]?.artifact === artifact) {
    renderAccountViewPanelOnly(broker);
    restoreAccountScroll(history.scrollY);
  }
}

function showCurrentTrendReport(broker) {
  const history = state.trendReportHistories[broker] || {};
  delete state.trendHistoricalReports[broker];
  if (Object.hasOwn(state.trendReportHistories, broker)) {
    state.trendReportHistories[broker] = {...history, open: false};
  }
  renderAccountViewPanelOnly(broker);
  if (state.brokerFilter === broker) {
    restoreAccountScroll(history.scrollY || 0);
    const historyButton = elements["account-holdings"]
      ?.querySelector(`[data-report-history="${broker}"]`);
    if (typeof historyButton?.focus === "function") historyButton.focus();
  }
}

function filterAccountRows(rows) {
  return rows.filter(({display}) => state.marketFilter === "ALL"
    || String(display.market || "").toUpperCase() === state.marketFilter);
}

function accountDisclosureKey(root, details) {
  const path = [];
  let current = details;
  while (current && current !== root) {
    const parent = current.parentElement;
    if (!parent) return "";
    const index = Array.from(parent.children).indexOf(current);
    const identity = current.tagName === "DETAILS"
      ? [
        current.className || "",
        current.getAttribute("aria-label") || "",
        current.getAttribute("data-discipline") || "",
        current.getAttribute("data-health") || "",
        current.getAttribute("data-risk-status") || "",
      ].join("|")
      : current.tagName || "";
    path.unshift(`${identity}#${index}`);
    current = parent;
  }
  return path.join("/");
}

function accountDisclosureScope(root, broker, view) {
  const section = root?.querySelector?.(`#account-${broker}`);
  if (!section || typeof section.querySelector !== "function") return null;
  const panel = section.querySelector(`#account-${broker}-view-panel`);
  if (TREND_ACCOUNT_BROKERS.includes(broker)
      && panel?.getAttribute("aria-labelledby") !== `account-${broker}-view-${view}`) {
    return null;
  }
  const report = panel?.querySelector?.(".cn-trend-report");
  return [
    broker,
    view,
    report?.dataset?.reportArtifact || "",
    report?.dataset?.reportSha256 || "",
    report?.dataset?.strategyVersion || "",
  ].join("|");
}

function captureAccountDisclosureState(root, broker, view) {
  const section = root?.querySelector?.(`#account-${broker}`);
  const scope = accountDisclosureScope(root, broker, view);
  if (!section || scope === null || typeof section.querySelectorAll !== "function") return null;
  const states = new Map();
  section.querySelectorAll("details").forEach((details) => {
    const key = accountDisclosureKey(section, details);
    if (key) states.set(key, details.open);
  });
  const holdingView = section.querySelector(
    '[data-trend-holding-view][aria-selected="true"]',
  )?.dataset?.trendHoldingView || "";
  return {scope, states, holdingView};
}

function restoreAccountDisclosureState(root, broker, view, snapshot) {
  if (!snapshot) return;
  const section = root?.querySelector?.(`#account-${broker}`);
  if (!section || accountDisclosureScope(root, broker, view) !== snapshot.scope
      || typeof section.querySelectorAll !== "function") return;
  section.querySelectorAll("details").forEach((details) => {
    const key = accountDisclosureKey(section, details);
    if (snapshot.states.has(key)) details.open = snapshot.states.get(key);
  });
  const holdingTab = snapshot.holdingView
    ? section.querySelector(`[data-trend-holding-view="${snapshot.holdingView}"]`)
    : null;
  if (holdingTab) handleTrendHoldingTab({target: holdingTab});
}

function renderAccountViewPanelOnly(broker) {
  const container = elements["account-holdings"] || elements["holdings-body"];
  const panel = state.brokerFilter === broker && typeof container?.querySelector === "function"
    ? container.querySelector(`#account-${broker}-view-panel`)
    : null;
  if (!panel) return;
  const group = accountHoldingGroups().find((item) => item.broker === broker);
  if (!group) return;
  const view = state.accountViews[broker] || "real";
  const rows = filterAccountRows(group.rows);
  const visibleRows = view === "simulate"
    ? filterAccountRows(simulatedAccountRows(broker))
    : rows;
  const disclosureSnapshot = captureAccountDisclosureState(container, broker, view);
  if (elements["visible-count"]) {
    elements["visible-count"].textContent = `${formatDisplayNumber(visibleRows.length)} 条`;
  }
  panel.innerHTML = renderAccountViewPanel({...group, rows, allRows: group.rows});
  panel.setAttribute("aria-labelledby", `account-${broker}-view-${view}`);
  restoreAccountDisclosureState(container, broker, view, disclosureSnapshot);
  container.querySelectorAll?.(`#account-${broker} [data-account-view]`).forEach((tab) => {
    const selected = tab.dataset.accountView === view;
    tab.setAttribute("aria-selected", String(selected));
    tab.tabIndex = selected ? 0 : -1;
  });
}

function renderAccountHoldings() {
  const container = elements["account-holdings"] || elements["holdings-body"];
  const focusedView = document.activeElement?.dataset?.accountView || "";
  const focusedBroker = document.activeElement?.dataset?.accountBroker || "";
  elements["workspace-grid"].classList.remove("detail-mode");
  container.classList.remove("hidden");
  elements["symbol-detail-panel"].classList.add("hidden");
  elements["symbol-detail-panel"].innerHTML = "";
  if (!state.accountSnapshot) {
    setAccountHoldingsFallbackLabel("账户持仓不可用");
    elements["visible-count"].textContent = "0 条";
    const groups = accountHoldingGroups();
    const active = groups.find((group) => group.broker === state.brokerFilter) || groups[0];
    container.innerHTML = active
      ? renderAccountSection({...active, rows: [], allRows: active.rows})
      : `<div class="empty-state">${escapeHtml(accountSnapshotStatusText())}</div>`;
    return;
  }
  const groups = accountHoldingGroups();
  const active = groups.find((group) => group.broker === state.brokerFilter) || groups[0];
  if (active && active.broker !== state.brokerFilter) state.brokerFilter = active.broker;
  elements["account-tabs"].innerHTML = renderAccountTabs(groups);
  if (active && typeof container.setAttribute === "function") {
    if (typeof container.removeAttribute === "function") container.removeAttribute("aria-label");
    container.setAttribute("aria-labelledby", `account-tab-${active.broker}`);
  }
  const rows = active ? filterAccountRows(active.rows) : [];
  const simulated = active ? simulatedAccountRows(active.broker) : [];
  const visibleRows = active && state.accountViews[active.broker] === "simulate"
    ? filterAccountRows(simulated)
    : rows;
  const disclosureSnapshot = active
    ? captureAccountDisclosureState(
      container,
      active.broker,
      state.accountViews[active.broker] || "real",
    )
    : null;
  elements["visible-count"].textContent = `${formatDisplayNumber(visibleRows.length)} 条`;
  container.innerHTML = active
    ? renderAccountSection({...active, rows, allRows: active.rows})
    : '<div class="empty-state">暂无券商账户</div>';
  if (active) {
    restoreAccountDisclosureState(
      container,
      active.broker,
      state.accountViews[active.broker] || "real",
      disclosureSnapshot,
    );
  }
  if (active?.broker === focusedBroker && focusedView) {
    container.querySelector(`[data-account-view="${focusedView}"]`)?.focus({preventScroll: true});
  }
}

function setAccountHoldingsFallbackLabel(label) {
  const container = elements["account-holdings"] || elements["holdings-body"];
  if (elements["account-tabs"]) elements["account-tabs"].innerHTML = "";
  if (typeof container.removeAttribute === "function") container.removeAttribute("aria-labelledby");
  if (typeof container.setAttribute === "function") container.setAttribute("aria-label", label);
}

function renderAccountSection(group) {
  const headingId = `account-${group.broker}-title`;
  const rows = group.rows;
  const alias = brokerAccountAlias(group.broker, group.summary);
  const sync = brokerSyncStatus(group.broker);
  const source = sync.display;
  const sourceTime = firstPresent(
    state.accountSnapshot?.sources?.account?.brokers?.[group.broker]?.data_as_of,
    state.accountSnapshot?.sources?.account?.brokers?.[group.broker]?.as_of,
    group.summary.generated_at, group.summary.as_of, "-",
  );
  return `<section id="account-${escapeHtml(group.broker)}" class="account-section">
    <header class="account-section-header">
      <div><h2 id="${headingId}">${escapeHtml(brokerDisplayName(group.summary))}</h2>
      <span>${escapeHtml(group.profile.horizon)} · ${escapeHtml(group.profile.strategy)}</span>
      <span>${escapeHtml(formatPlain(alias))}</span></div>
      <div class="account-section-meta">
        <span>持仓资产 ${escapeHtml(formatMoney(group.summary.holding_value_hkd, "HKD"))}</span>
        <span>现金 ${escapeHtml(formatMoney(group.summary.cash_like_value_hkd, "HKD"))}</span>
        ${group.broker === "tiger" && hasValue(group.summary.available_to_trade_hkd)
          ? `<span>可交易额度 ${escapeHtml(formatMoney(group.summary.available_to_trade_hkd, "HKD"))}</span>`
          : ""}
        <span>持仓 ${escapeHtml(formatDisplayNumber(group.summary.holding_count))}</span>
        <span>来源 ${escapeHtml(formatPlain(source))}</span>
        <span>时间 ${escapeHtml(formatPlain(sourceTime))}</span>
        ${renderAccountCashDetails(group)}
      </div>
      <div class="account-section-actions">
        <strong>${escapeHtml(formatMoney(group.summary.portfolio_value_hkd, "HKD"))}</strong>
        ${renderStatementUpload(group.broker)}
      </div>
      ${TREND_ACCOUNT_BROKERS.includes(group.broker) ? renderAccountViewTabs(group.broker) : ""}
    </header>
    ${renderAccountSyncAlert(group.broker)}
    ${TREND_ACCOUNT_BROKERS.includes(group.broker)
      ? `<div id="account-${escapeHtml(group.broker)}-view-panel" class="account-view-panel" role="tabpanel" aria-labelledby="account-${escapeHtml(group.broker)}-view-${escapeHtml(state.accountViews[group.broker] || "real")}">${renderAccountViewPanel(group)}</div>`
      : rows.length ? renderAccountTable(rows) : '<p class="account-empty">当前筛选下没有持仓</p>'}
  </section>`;
}

function renderAccountSyncAlert(broker) {
  const sync = brokerSyncStatus(broker);
  if (!sync.unsafe) return "";
  const title = !state.accountSnapshot ? "账户快照不可用。"
    : sync.status === "failed" ? `${brokerDisplayName(broker)}账户同步失败。`
    : sync.status === "stale" ? `${brokerDisplayName(broker)}账户数据已过期。`
    : `${brokerDisplayName(broker)}账户同步状态未知。`;
  const detail = !state.accountSnapshot
    ? "账户数据尚未确认；新做T提醒及依赖当前持仓的动作已暂停。"
    : `${sync.display}。以下为已接受数据；新做T提醒及依赖当前持仓的动作已暂停。`;
  return `<div class="account-sync-alert ${escapeHtml(sourceStatusClass(sync.status))}" role="status"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(detail)}</span></div>`;
}

function renderAccountViewPanel(group) {
  const view = state.accountViews[group.broker] || "real";
  if (view === "simulate") return renderSimulatedAccountView(group.broker);
  if (view === "report") return renderEmbeddedTrendReport(group.broker);
  const completeRows = Array.isArray(group.allRows) ? group.allRows : group.rows;
  if (!group.rows.length && !completeRows.length) {
    const accountTotal = accountIndustryMoneyMinor(group.summary?.portfolio_value_hkd);
    if (accountTotal === null || accountTotal <= 0n) return '<p class="account-empty">当前筛选下没有持仓</p>';
    const report = state.dashboard?.trend_reports?.[group.broker];
    const distribution = renderAccountIndustryDistribution(
      [],
      report,
      report?.real_position_actions,
      group.summary?.portfolio_value_hkd,
    );
    return `${distribution}<p class="account-empty">当前筛选下没有持仓</p>`;
  }
  const report = state.dashboard?.trend_reports?.[group.broker];
  const split = splitHistoricalTrendHoldings(completeRows, report);
  const visibleSplit = splitHistoricalTrendHoldings(group.rows, report);
  if (!split || !visibleSplit) return `${renderHistoricalTrendHoldingWarning()}${renderAccountTable(group.rows)}`;
  const distribution = renderAccountIndustryDistribution(
    split.trend,
    report,
    report?.real_position_actions,
    group.summary?.portfolio_value_hkd,
  );
  if (!group.rows.length) return `${distribution}<p class="account-empty">当前筛选下没有持仓</p>`;
  return `${distribution}${renderHoldingOriginSection("趋势持仓", visibleSplit.trend, renderAccountTable(visibleSplit.trend))}${renderHoldingOriginSection("非趋势持仓", visibleSplit.nonTrend, renderAccountTable(visibleSplit.nonTrend))}`;
}

function accountIndustryKeys(value, report) {
  const keys = new Set();
  const futuKey = normalizeActionKey("", value?.futu_symbol);
  if (futuKey) {
    keys.add(futuKey);
  }
  const market = String(value?.market || report?.market || "").trim().toUpperCase();
  const symbol = String(value?.symbol || "").trim().toUpperCase();
  const logicalKey = normalizeActionKey(market, symbol);
  if (logicalKey) {
    keys.add(logicalKey);
  }
  const canonical = futuKey.match(/^(SH|SZ|BJ)\.(.+)$/);
  const cnSymbol = symbol || (canonical && canonical[2]) || "";
  if ((market === "CN" || canonical) && cnSymbol) {
    keys.add(`CN.${cnSymbol}`);
    for (const prefix of ["SH", "SZ", "BJ"]) {
      keys.add(`${prefix}.${cnSymbol}`);
    }
  }
  return Array.from(keys);
}

function accountIndustryMoneyMinor(value) {
  if (!hasValue(value)) return null;
  const raw = String(value).trim();
  const validNumber = raw.includes(",")
    ? /^\+?\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?$/.test(raw)
    : /^\+?(?:\d+(?:\.\d{1,2})?|\.\d{1,2})$/.test(raw);
  if (!validNumber) return null;
  const normalized = raw.replace(/,/g, "").replace(/^\+/, "");
  const [rawInteger = "", fraction = ""] = normalized.split(".");
  const integer = (rawInteger || "0").replace(/^0+(?=\d)/, "");
  if (integer.length > 14) return null;
  const minor = BigInt(integer) * 100n + BigInt(fraction.padEnd(2, "0") || "0");
  return minor <= BigInt(Number.MAX_SAFE_INTEGER) ? minor : null;
}

function accountIndustryMoneyText(minor) {
  const integer = minor / 100n;
  const fraction = String(minor % 100n).padStart(2, "0").replace(/0+$/, "");
  return formatMoney(`${integer}${fraction ? `.${fraction}` : ""}`, "HKD");
}

function accountIndustryPercentText(minor, total) {
  const scaled = (minor * 10000n * 2n + total) / (2n * total);
  const integer = scaled / 100n;
  const fraction = String(scaled % 100n).padStart(2, "0").replace(/0+$/, "");
  return `${integer}${fraction ? `.${fraction}` : ""}`;
}

function renderAccountIndustryDistribution(rows, report, actions, accountTotalValue) {
  const byKey = new Map();
  (Array.isArray(actions) ? actions : []).forEach((action) => {
    const keys = accountIndustryKeys(action, report);
    const industry = String(action?.industry || "").trim();
    keys.forEach((key) => {
      const entry = byKey.get(key) || {labels: new Set()};
      if (industry) entry.labels.add(industry);
      byKey.set(key, entry);
    });
  });
  const namedByIndustry = new Map();
  let unknownValue = 0n;
  let excludedCount = 0;
  rows.forEach((row) => {
    const value = accountIndustryMoneyMinor(row?.display?.market_value_hkd);
    if (value === null || value <= 0n) {
      excludedCount += 1;
      return;
    }
    const entries = accountIndustryKeys(row?.holding || row, report)
      .map((key) => byKey.get(key))
      .filter(Boolean);
    const labels = new Set();
    entries.forEach((entry) => {
      entry.labels.forEach((label) => labels.add(label));
    });
    const industries = Array.from(labels).sort((left, right) => left < right ? -1 : left > right ? 1 : 0);
    if (!industries.length) {
      unknownValue += value;
      return;
    }
    const divisor = BigInt(industries.length);
    const allocation = value / divisor;
    let remainder = value % divisor;
    industries.forEach((industry) => {
      const share = allocation + (remainder > 0n ? 1n : 0n);
      if (remainder > 0n) remainder -= 1n;
      namedByIndustry.set(industry, (namedByIndustry.get(industry) || 0n) + share);
    });
  });
  const holdingsTotal = Array.from(namedByIndustry.values()).reduce((sum, value) => sum + value, unknownValue);
  const accountTotal = accountIndustryMoneyMinor(accountTotalValue);
  const reconciled = accountTotal !== null && accountTotal > 0n && accountTotal >= holdingsTotal;
  const total = reconciled ? accountTotal : holdingsTotal;
  const cashValue = reconciled && accountTotal > holdingsTotal ? accountTotal - holdingsTotal : 0n;
  const excludedText = excludedCount ? ` · ${formatDisplayNumber(excludedCount)} 条未计入` : "";
  const basisText = reconciled
    ? "按账户总资产港元市值；现金及其他资产含非趋势资产及现金类资产及行业分布外账户价值"
    : accountTotalValue !== undefined
      ? "账户总资产暂不可核对，仅按趋势持仓港元市值"
      : "按趋势持仓港元市值";
  const totalLabel = reconciled ? "总资产" : "趋势持仓合计";
  if (total <= 0n) {
    return `<section class="account-industry-distribution" aria-labelledby="account-industry-distribution-title">
      <header class="account-industry-distribution-header"><h3 id="account-industry-distribution-title">资产与行业分布</h3><span>${escapeHtml(`${basisText}${excludedText}`)}</span></header>
      <p class="account-empty">行业分布暂无可用市值${excludedCount ? `（${escapeHtml(formatDisplayNumber(excludedCount))} 条未计入）` : ""}</p>
    </section>`;
  }
  const displayName = (industry) => ["现金及其他资产", "行业未知"].includes(industry)
    ? `${industry}（行业）` : industry;
  const named = Array.from(namedByIndustry, ([industry, value]) => ({
    kind: "named", industry, display: displayName(industry), value,
  }))
    .sort((left, right) => right.value === left.value
      ? left.industry.localeCompare(right.industry)
      : right.value > left.value ? 1 : -1);
  const entries = [...named];
  if (cashValue > 0n) entries.push({kind: "cash", industry: "现金及其他资产", display: "现金及其他资产", value: cashValue});
  if (unknownValue > 0n) entries.push({kind: "unknown", industry: "行业未知", display: "行业未知", value: unknownValue});
  entries.sort((left, right) => right.value === left.value
    ? left.display.localeCompare(right.display)
    : right.value > left.value ? 1 : -1);
  const share = (value) => `${accountIndustryPercentText(value, total)}%`;
  const facts = entries.map(({display, value}) => `${display} ${accountIndustryMoneyText(value)}，占 ${share(value)}`);
  const colors = ["var(--trend-info)", "var(--trend-hold)", "var(--accent)", "var(--success)", "var(--danger)", "var(--primary)", "#2f6f8f", "#9a6b2f", "#0f766e", "#c2410c", "#6b4ca5", "#475569"];
  const specialColors = {"现金及其他资产": "#5b6472", "行业未知": "#7c3aed"};
  const colorFor = (entry, index) => entry.kind === "cash" ? specialColors["现金及其他资产"]
    : entry.kind === "unknown" ? specialColors["行业未知"]
      : colors[index % colors.length];
  const ariaExcluded = excludedCount ? `；${formatDisplayNumber(excludedCount)} 条未计入` : "";
  let offset = 0n;
  const gradient = entries.map(({value}, index) => {
    const start = accountIndustryPercentText(offset, total);
    offset += value;
    const end = accountIndustryPercentText(offset, total);
    return `${colorFor(entries[index], index)} ${start}% ${end}%`;
  }).join(", ");
  const rowsHtml = entries.map((entry, index) => `<tr><th scope="row"><span class="account-industry-swatch" style="background: ${colorFor(entry, index)}" aria-hidden="true"></span>${escapeHtml(entry.display)}</th><td>${escapeHtml(accountIndustryMoneyText(entry.value))}</td><td>${escapeHtml(share(entry.value))}</td></tr>`).join("");
  return `<section class="account-industry-distribution" aria-labelledby="account-industry-distribution-title">
    <header class="account-industry-distribution-header"><h3 id="account-industry-distribution-title">资产与行业分布</h3><span>${escapeHtml(`${basisText}${excludedText}`)}</span></header>
    <div class="account-industry-distribution-body">
      <div class="account-industry-pie" role="img" aria-label="${escapeHtml(`资产与行业分布：${totalLabel} ${accountIndustryMoneyText(total)}；${facts.join("；")}${ariaExcluded}`)}" style="background: conic-gradient(${gradient})"></div>
      <div class="account-industry-detail"><table class="account-industry-table"><caption>资产与行业分布明细（${totalLabel} ${escapeHtml(accountIndustryMoneyText(total))}）</caption><thead><tr><th scope="col">行业</th><th scope="col">港元市值</th><th scope="col">占比</th></tr></thead><tbody>${rowsHtml}</tbody></table></div>
    </div>
  </section>`;
}

function simulatedAccountRows(broker) {
  const payload = state.trendSimulatePositions[broker] || {};
  const positions = Array.isArray(payload.positions) ? payload.positions : [];
  return positions.map((position, index) => {
    const display = {
      ...accountPositionDisplay(position),
      total_quantity: position.quantity,
      avg_cost_price: position.cost_price,
    };
    return {
      key: `simulate:${broker}:${display.market || ""}:${display.symbol || ""}:${index}`,
      broker,
      holding: position,
      display,
      index,
    };
  });
}

function accountPositionDisplay(position) {
  const valuation = position?.current_valuation;
  if (!valuation || typeof valuation !== "object") return position;
  const fields = [
    "price", "price_kind", "price_as_of", "market_value_usd", "market_value_hkd",
  ];
  if (fields.some((field) => !hasValue(valuation[field]))) return position;
  return {
    ...position,
    last_price: valuation.price,
    price_kind: valuation.price_kind,
    price_as_of: valuation.price_as_of,
    market_value_usd: valuation.market_value_usd,
    market_value_hkd: valuation.market_value_hkd,
  };
}

function accountValuationKey(position) {
  return String(
    position?.position_id
      || [position?.broker, position?.account_alias, position?.market, position?.symbol].join(":"),
  );
}

function accountValuationSignature(position) {
  const valuation = position?.current_valuation;
  if (!valuation || typeof valuation !== "object") return "";
  return JSON.stringify([
    valuation.price,
    valuation.price_kind,
    valuation.price_as_of,
    valuation.market_value_usd,
    valuation.market_value_hkd,
  ]);
}

function accountValuationUpdates(previous, next) {
  const updates = new Set();
  if (!previous || !Array.isArray(previous.positions) || !Array.isArray(next?.positions)) {
    return updates;
  }
  const previousByKey = new Map(
    previous.positions.map((position) => [accountValuationKey(position), position]),
  );
  next.positions.forEach((position) => {
    const before = previousByKey.get(accountValuationKey(position));
    const signature = accountValuationSignature(position);
    if (before && signature && accountValuationSignature(before) !== signature) {
      updates.add(accountValuationKey(position));
    }
  });
  return updates;
}

function renderSimulatedAccountView(broker) {
  const payload = state.trendSimulatePositions[broker];
  if (!payload || payload.loading) return '<p class="account-empty">模拟盘持仓加载中</p>';
  if (!payload.available) {
    return `<p class="account-empty missing-text">${escapeHtml(formatPlain(payload.error || "模拟盘持仓不可用"))}</p>`;
  }
  const allRows = simulatedAccountRows(broker);
  const rows = filterAccountRows(allRows);
  const report = state.dashboard?.trend_reports?.[broker] || {};
  const distribution = renderAccountIndustryDistribution(
    allRows,
    report,
    report.hold_actions,
    payload.portfolio_value_hkd,
  );
  const excludedNote = Array.isArray(payload.excluded_positions) && payload.excluded_positions.length
    ? `<p class="account-empty">非股票资产未计入持仓明细：${payload.excluded_positions.map((row) => `${escapeHtml(formatPlain(row?.code || ""))} · ${escapeHtml(formatPlain(row?.name || ""))} · 市值 ${escapeHtml(formatPlain(row?.market_value || ""))} ${escapeHtml(formatPlain(row?.currency || ""))}`).join("；")}</p>`
    : "";
  return `${distribution}${rows.length
    ? renderAccountTable(rows, {simulated: true})
    : '<p class="account-empty">当前无模拟盘持仓</p>'}${excludedNote}`;
}

function renderEmbeddedTrendReport(broker) {
  const historical = state.trendHistoricalReports[broker];
  if (historical) {
    if (historical.loading) return '<p class="account-empty">历史报告加载中</p>';
    if (historical.error) return `<div class="trend-history-panel"><button class="trend-history-button" type="button" data-current-trend-report="${escapeHtml(broker)}">返回当前报告</button><p class="missing-text">${escapeHtml(historical.error)}</p></div>`;
    return renderTrendReportWorkspace(historical.report || {}, true, true);
  }
  const history = state.trendReportHistories[broker];
  if (history?.open) return renderTrendReportHistory(broker, history);
  const report = state.dashboard?.trend_reports?.[broker] || {};
  const review = state.dashboard?.trend_reviews?.[broker];
  const reviewPanel = !review ? "" : review.available
    ? `<details class="trend-audit trend-review-disclosure"><summary>趋势复盘 <span>${escapeHtml(`${formatTrendReviewSampleCount(review, "discipline", "纪律模拟")} · ${formatTrendReviewSampleCount(review, "actual", "实际执行")}`)}</span></summary>${renderTrendReviewWorkspace(review, true)}</details>`
    : `<details class="trend-audit trend-review-disclosure"><summary>趋势复盘 <span>${escapeHtml(formatPlain(review.status_text || "暂无复盘数据"))}</span></summary><p class="account-empty">${escapeHtml(formatPlain(review.status_text || "暂无复盘数据"))}</p></details>`;
  if (report.available) return renderTrendReportWorkspace(report, true, false, reviewPanel);
  const statusClass = report.execution_batch_blocking === true
    ? "trend-execution-batch-error"
    : "account-empty";
  return `${renderTrendControllerStatus(broker)}<p class="${statusClass}">${escapeHtml(formatPlain(report.status_text || "今日暂无趋势报告"))}</p>${reviewPanel}`;
}

function renderTrendReportHistory(broker, history) {
  const rows = Array.isArray(history.rows) ? history.rows : [];
  const content = history.loading
    ? '<p class="account-empty">历史报告加载中</p>'
    : history.error
      ? `<p class="missing-text">${escapeHtml(history.error)}</p>`
      : rows.length
        ? `<ul class="trend-history-list">${rows.map((row) => row.available
          ? `<li><button type="button" data-history-broker="${escapeHtml(broker)}" data-history-artifact="${escapeHtml(row.artifact)}"><strong>报告 ${escapeHtml(formatPlain(row.execution_date))} · ${escapeHtml(formatPlain(row.strategy_version))}</strong><span class="trend-history-meta"><span>${escapeHtml(row.artifact)}</span><span>数据截至 ${escapeHtml(formatPlain(row.data_date))}</span><span>生成时间 ${escapeHtml(formatPlain(row.generated_at))}</span><span>策略版本 ${escapeHtml(formatPlain(row.strategy_version))}</span><span>执行摘要 卖出 ${escapeHtml(formatPlain(row.execution_counts?.sell))} · 买入 ${escapeHtml(formatPlain(row.execution_counts?.buy))} · 持有 ${escapeHtml(formatPlain(row.execution_counts?.hold))} · 复核 ${escapeHtml(formatPlain(row.execution_counts?.review))}</span></span></button></li>`
          : `<li><span class="missing-text">${escapeHtml(formatPlain(row.artifact))} · ${escapeHtml(formatPlain(row.status_text))}</span></li>`).join("")}</ul>`
        : '<p class="account-empty">暂无历史报告</p>';
  return `<section class="trend-history-panel"><header><h1>历史报告</h1><button class="trend-history-button" type="button" data-current-trend-report="${escapeHtml(broker)}">返回当前报告</button></header>${content}</section>`;
}

function renderAccountCashDetails(group) {
  const components = group.broker === "tiger" && Array.isArray(group.summary.cash_components)
    ? group.summary.cash_components
    : [];
  if (!components.length) return "";
  const rows = components.map((component) => `<li><span>${escapeHtml(formatPlain(component.label))}</span><strong>${escapeHtml(formatMoney(component.value_hkd, "HKD"))}</strong></li>`).join("");
  return `<details class="account-cash-details"><summary>现金构成</summary><ul>${rows}</ul></details>`;
}

function renderStatementUpload(broker) {
  if (!["phillips", "eastmoney"].includes(broker)) return "";
  const active = state.statementUpload.broker === broker;
  const busy = active && state.statementUpload.busy;
  const message = active ? state.statementUpload.message : "";
  const tone = active && state.statementUpload.error ? " error" : "";
  return `<div class="statement-upload">
    <input class="statement-upload-input" type="file" accept=".pdf,application/pdf" data-statement-file="${escapeHtml(broker)}" hidden>
    <button class="secondary-button" type="button" data-statement-upload="${escapeHtml(broker)}" ${busy || !accountActionsEnabled() ? "disabled" : ""}>${busy ? "上传中…" : "上传结单"}</button>
    <span class="statement-upload-status${tone}" role="status">${escapeHtml(message)}</span>
  </div>`;
}

async function uploadStatement(broker, file) {
  if (!/\.pdf$/i.test(String(file?.name || ""))) {
    throw new Error("请选择 PDF 文件");
  }
  if (Number(file.size) > 20 * 1024 * 1024) {
    throw new Error("PDF 不能超过 20 MiB");
  }
  const response = await fetch(`/api/v1/account/statements/${encodeURIComponent(broker)}`, {
    method: "POST",
    headers: {"Content-Type": "application/pdf"},
    body: file,
  });
  const payload = await response.json();
  if (!response.ok || payload.status === "error") {
    throw new Error(payload.message || `上传失败 (${response.status})`);
  }
  return payload;
}

async function handleStatementFileSelection(event) {
  const input = event.target.closest("[data-statement-file]");
  const file = input?.files?.[0];
  if (!input || !file) return;
  const broker = input.dataset.statementFile || "";
  state.statementUpload = {broker, busy: true, message: "", error: false};
  renderAccountHoldings();
  try {
    const payload = await uploadStatement(broker, file);
    state.statementUpload = {
      broker,
      busy: false,
      message: `已暂存 ${payload.statement_date} · 等待账户同步`,
      error: false,
    };
    setTimeout(() => {
      if (state.statementUpload.broker === broker && !state.statementUpload.error) {
        state.statementUpload.message = "";
        renderAccountHoldings();
      }
    }, 4000);
  } catch (error) {
    state.statementUpload = {
      broker,
      busy: false,
      message: error instanceof Error ? error.message : String(error),
      error: true,
    };
  } finally {
    input.value = "";
    renderAccountHoldings();
  }
}

const ACCOUNT_HOLDING_COLUMNS = [
  "明细", "市场", "标的", "数量", "成本价", "实时价", "美元市值", "港元市值", "账户权重", "组合权重", "盈亏",
];

function renderSimulationAttribution(position, broker) {
  if (position.attribution_status === "conflict") {
    return '<span class="missing-text">报告关联冲突</span>';
  }
  const report = position.report && typeof position.report === "object" ? position.report : null;
  if (position.attribution_status !== "linked" || !report) {
    return '<span class="meta-text">未关联历史报告</span>';
  }
  return `<button class="report-attribution-link" type="button" data-history-broker="${escapeHtml(broker)}" data-history-artifact="${escapeHtml(report.artifact)}">报告 ${escapeHtml(formatPlain(report.execution_date))} · ${escapeHtml(formatPlain(report.strategy_version))}</button>`;
}

function renderAccountHoldingRow(row, {simulated = false} = {}) {
  const holding = row.holding;
  const display = row.display;
  const enrichment = holding.enrichment_status === "unavailable"
    ? '<span class="meta-text">关联不可用</span>' : "";
  const isSelected = !simulated && row.key === state.selectedHoldingKey;
  const selectedDetail = isSelected ? normalizeHoldingDetailMode(state.selectedHoldingDetail) : "";
  const pnlTone = pnlClass(display.unrealized_pnl_pct);
  const valuationClass = state.accountValuationUpdates.has(row.key)
    ? " account-valuation-updated" : "";
  const detailActions = simulated ? "" : brokerSyncStatus(row.broker).unsafe
    ? '<span class="account-review-action">人工复核</span>'
    : `<button class="${escapeHtml(tSignalButtonClass(holding))}" type="button" data-detail-key="${escapeHtml(row.key)}" data-detail-mode="t_signal">做T</button>`;
  const attribution = simulated ? renderSimulationAttribution(holding, row.broker) : "";
  const controllerFields = [
    ["quantity", display.quantity],
    ["cost-price", display.cost_price],
    ["last-price", display.last_price],
    ["price-kind", display.price_kind],
    ["price-as-of", display.price_as_of],
    ["market-value-usd", display.market_value_usd],
    ["market-value-hkd", display.market_value_hkd],
    ["account-weight-hkd", display.account_weight_hkd],
    ["portfolio-weight-hkd", display.portfolio_weight_hkd],
    ["unrealized-pnl", display.unrealized_pnl],
    ["unrealized-pnl-pct", display.unrealized_pnl_pct],
  ].map(([name, value]) => ` data-${name}="${escapeHtml(value ?? "")}"`).join("");
  const cells = `<tr class="account-holding-row ${isSelected ? "active-row" : ""}" data-broker="${escapeHtml(row.broker)}" data-symbol="${escapeHtml(String(display.symbol || "").toUpperCase())}"${controllerFields}>
    <td class="account-holding-actions"><span class="account-mobile-label">明细</span>${detailActions}</td>
    <td class="account-holding-market"><span class="account-mobile-label">市场</span>${escapeHtml(formatPlain(display.market))}</td>
    <td class="symbol-cell account-holding-symbol"><span class="account-mobile-label">标的</span><strong>${escapeHtml(formatPlain(display.symbol))}</strong><span class="meta-text">${escapeHtml(formatPlain(display.name))}</span>${enrichment}${attribution}</td>
    <td class="number-cell account-holding-quantity"><span class="account-mobile-label">数量</span>${escapeHtml(formatDisplayNumber(display.quantity))}</td>
    <td class="number-cell account-holding-cost"><span class="account-mobile-label">成本价</span>${escapeHtml(formatDisplayNumber(display.cost_price))}</td>
    <td class="number-cell account-holding-price${valuationClass}"><span class="account-mobile-label">实时价</span>${renderAccountHoldingPrice(display)}</td>
    <td class="number-cell account-holding-usd-value${valuationClass}"><span class="account-mobile-label">美元市值</span>${escapeHtml(hasValue(display.market_value_usd) ? formatMoney(display.market_value_usd, "USD") : "-")}</td>
    <td class="number-cell account-holding-market-value${valuationClass}"><span class="account-mobile-label">港元市值</span>${escapeHtml(formatMoney(display.market_value_hkd, "HKD"))}</td>
    <td class="number-cell account-holding-account-weight"><span class="account-mobile-label">账户权重</span>${escapeHtml(formatPlain(display.account_weight_hkd))}</td>
    <td class="number-cell account-holding-portfolio-weight"><span class="account-mobile-label">组合权重</span>${escapeHtml(formatPlain(display.portfolio_weight_hkd))}</td>
    <td class="number-cell account-holding-pnl${pnlTone ? ` ${pnlTone}` : ""}"><span class="account-mobile-label">盈亏</span>${escapeHtml(formatSignedPnl(display.unrealized_pnl_pct))}</td>
  </tr>`;
  if (!isSelected) return cells;
  return `${cells}<tr class="decision-detail-row"><td colspan="${ACCOUNT_HOLDING_COLUMNS.length}"><div class="symbol-detail-panel inline-symbol-detail">${selectedDetail === "t_signal"
    ? renderTSignalDetail(holding)
    : renderSymbolDetail(holding, row.index)}</div></td></tr>`;
}

function renderAccountTable(rows, options = {}) {
  const body = rows.map((row) => renderAccountHoldingRow(row, options)).join("");
  return `<div class="table-wrap account-holdings-table-wrap"><table class="account-holdings-table"><thead><tr>${ACCOUNT_HOLDING_COLUMNS.map((label) => `<th scope="col">${label}</th>`).join("")}</tr></thead><tbody>${body}</tbody></table></div>`;
}

function holdingKey(holding, index) {
  return [
    holding.market || "",
    holding.symbol || "",
    holding.name || "",
    index,
  ].map((part) => String(part)).join(":");
}

function selectedHolding(rows = accountHoldingGroups().flatMap((group) => group.rows)) {
  if (!state.selectedHoldingKey) {
    return null;
  }
  return rows.find((row) => row.key === state.selectedHoldingKey) || null;
}

function showSymbolDetail(detailKey, detailMode = "decision") {
  state.selectedHoldingKey = detailKey;
  state.selectedHoldingDetail = normalizeHoldingDetailMode(detailMode);
  state.selectedDecisionTab = "final";
  syncDecisionDeepLink();
  renderHoldings();
}

function normalizeHoldingDetailMode() {
  return "t_signal";
}

function tSignalButtonClass(holding) {
  const signal = holding && holding.t_signal && typeof holding.t_signal === "object"
    ? holding.t_signal
    : {};
  const active = (
    signal.status === "ok"
    && signal.session_phase === "regular"
    && ["BUY_T", "SELL_T"].includes(signal.action)
  );
  return active
    ? "expand-button t-signal-button t-signal-button-active"
    : "expand-button t-signal-button";
}

function openTradeActionDetail(actionKey) {
  const normalizedActionKey = normalizeActionKey("", actionKey);
  if (!normalizedActionKey) {
    return;
  }
  const rows = accountHoldingGroups().flatMap((group) => group.rows);
  for (const row of rows) {
    if (holdingActionKeys(row.holding).includes(normalizedActionKey)) {
      resetHoldingFilters(row.broker);
      state.selectedHoldingKey = row.key;
      state.selectedHoldingDetail = "decision";
      state.selectedDecisionTab = "final";
      syncDecisionDeepLink();
      renderDashboardViews();
      return;
    }
  }
}

function resetHoldingFilters(broker = state.brokerFilter) {
  state.marketFilter = "ALL";
  state.brokerFilter = ACCOUNT_BROKERS.includes(broker) ? broker : ACCOUNT_BROKERS[0];
  setFilterActiveByDataset(elements["header-market-filters"], "market", "ALL");
}

function setFilterActiveByDataset(container, datasetKey, value) {
  if (!container) {
    return;
  }
  container.querySelectorAll(".filter-button").forEach((button) => {
    button.classList.toggle("active", button.dataset[datasetKey] === value);
  });
}

function renderSymbolDetail(holding, index) {
  const title = `${formatPlain(holding.market)}.${formatPlain(holding.symbol)}`;
  return `
    <div class="detail-header trading-decision-header">
      <div>
        <button class="raw-toggle" type="button" data-back-to-holdings>返回持仓列表</button>
        <h2>交易决策 · ${escapeHtml(title)}</h2>
        <p>${escapeHtml(formatPlain(holding.name))} · 基于已接入的交易决策与市场事实数据展示。</p>
      </div>
      <button class="raw-toggle" type="button" data-back-to-holdings>收起</button>
    </div>
    <div class="trading-decision-layout">
      ${renderTradingDecisionTabs(holding)}
    </div>
  `;
}

function renderTSignalDetail(holding) {
  const title = `${formatPlain(holding.market)}.${formatPlain(holding.symbol)}`;
  const signal = holding && holding.t_signal && typeof holding.t_signal === "object"
    ? holding.t_signal
    : null;
  if (!signal || signal.available === false) {
    const message = signal && signal.error ? signal.error : "暂无做T信号数据。";
    return `
      <div class="detail-header trading-decision-header">
        <div>
          <button class="raw-toggle" type="button" data-back-to-holdings>返回持仓列表</button>
          <h2>做T信号 · ${escapeHtml(title)}</h2>
          <p>${escapeHtml(message)}</p>
        </div>
        <button class="raw-toggle" type="button" data-back-to-holdings>收起</button>
      </div>
      <section class="detail-section t-signal-section">
        <h3>当前状态</h3>
        <p class="muted-copy">该标的尚未生成做T信号，或本市场 latest 信号文件不存在。</p>
      </section>
    `;
  }

  return `
    <div class="detail-header trading-decision-header">
      <div>
        <button class="raw-toggle" type="button" data-back-to-holdings>返回持仓列表</button>
        <h2>做T信号 · ${escapeHtml(title)}</h2>
        <p>${escapeHtml(formatPlain(signal.signal_summary_zh || signal.current_status))}</p>
      </div>
      <button class="raw-toggle" type="button" data-back-to-holdings>收起</button>
    </div>
    <div class="t-signal-layout">
      <section class="detail-section t-signal-section">
        <div class="t-signal-status-row">
          <div>
            <h3>${escapeHtml(tSignalActionLabel(signal.action))}</h3>
            <p>${escapeHtml(formatPlain(signal.current_status))}</p>
          </div>
          <span class="status-pill ${escapeHtml(tSignalStatusClass(signal.status))}">${escapeHtml(tSignalStatusLabel(signal.status))}</span>
        </div>
        <div class="t-signal-metric-grid">
          ${renderTSignalMetric("确定比例", tSignalRatioText(signal.suggested_ratio))}
          ${renderTSignalMetric("更新时间", signal.updated_at)}
          ${renderTSignalMetric("交易时段", tSignalSessionLabel(signal.session_phase))}
          ${renderTSignalMetric("提醒状态", tSignalNotificationText(signal.notification))}
        </div>
        ${signal.error ? `<p class="t-signal-error">${escapeHtml(signal.error)}</p>` : ""}
      </section>
      ${renderTSignalEvidence(signal)}
      ${renderTSignalPrerequisites(signal)}
      ${renderTSignalDetails(signal)}
      ${renderTSignalTimeline(signal)}
    </div>
  `;
}

function renderTSignalMetric(label, value) {
  return `
    <div class="t-signal-metric">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(formatPlain(value))}</strong>
    </div>
  `;
}

function renderTSignalEvidence(signal) {
  const evidence = Array.isArray(signal.evidence) ? signal.evidence : [];
  return `
    <section class="detail-section t-signal-section">
      <h3>信号依据</h3>
      <div class="t-signal-evidence-list">
        ${evidence.length > 0 ? evidence.map((item) => `
          <div class="t-signal-evidence-item">
            <strong>${escapeHtml(formatPlain(item.message_zh))}</strong>
            <span>${escapeHtml(tSignalDirectionLabel(item.direction))} · ${escapeHtml(tSignalStrengthLabel(item.strength))}</span>
          </div>
        `).join("") : `<p class="muted-copy">暂无明确买卖依据。</p>`}
      </div>
    </section>
  `;
}

function renderTSignalPrerequisites(signal) {
  const gates = Array.isArray(signal.hard_gates) ? signal.hard_gates : [];
  return `
    <section class="detail-section t-signal-section">
      <h3>前置条件</h3>
      <div class="t-signal-gate-grid">
        ${gates.length > 0 ? gates.map((gate) => `
          <div class="t-signal-gate">
            <span>${escapeHtml(tSignalGateNameLabel(gate.name))}</span>
            ${renderTSignalGateStatus(gate.status)}
            <small>${escapeHtml(formatPlain(gate.message_zh))}</small>
          </div>
        `).join("") : `<p class="muted-copy">暂无前置条件记录。</p>`}
      </div>
    </section>
  `;
}

function renderTSignalDetails(signal) {
  return `
    <section class="detail-section t-signal-section">
      <h3>详细信息</h3>
      <div class="t-signal-detail-grid">
        <div>
          <h4>价格</h4>
          ${renderDecisionFactRows([
            { label: "最新价", value: tSignalPriceText(nestedValue(signal.price, "last_price")) },
            { label: "日内涨跌", value: percentText(nestedValue(signal.price, "day_change_pct")) },
            { label: "VWAP", value: tSignalPriceText(nestedValue(signal.price, "vwap")) },
            { label: "日内区间", value: tSignalPriceRangeText(nestedValue(signal.price, "day_low"), nestedValue(signal.price, "day_high")) },
          ])}
        </div>
        <div>
          <h4>技术 / 盘口</h4>
          ${renderDecisionFactRows([
            { label: "5分钟 RSI", value: nestedValue(signal.technical, "rsi_5m") },
            { label: "5分钟量比", value: nestedValue(signal.technical, "volume_ratio_5m") },
            { label: "价格位置", value: tSignalPricePositionLabel(nestedValue(signal.technical, "price_position")) },
            { label: "盘口状态", value: tSignalDepthStatusLabel(nestedValue(signal.liquidity, "depth_status")) },
          ])}
        </div>
      </div>
    </section>
  `;
}

function renderTSignalTimeline(signal) {
  const timeline = Array.isArray(signal.timeline) ? signal.timeline : [];
  return `
    <section class="detail-section t-signal-section">
      <h3>消息 timeline</h3>
      <div class="t-signal-timeline">
        ${timeline.length > 0 ? timeline.map((event) => `
          <div class="t-signal-timeline-event">
            <time>${escapeHtml(formatPlain(event.event_at))}</time>
            <strong>${escapeHtml(tSignalTimelineLabel(event.event_type))}</strong>
            <span>${escapeHtml(formatPlain(event.message_zh))}</span>
          </div>
        `).join("") : `<p class="muted-copy">暂无消息记录。</p>`}
      </div>
    </section>
  `;
}

function nestedValue(source, key) {
  return source && typeof source === "object" ? source[key] : "";
}

function percentText(value) {
  if (!hasValue(value)) return "-";
  const raw = String(value).trim();
  return raw.endsWith("%") ? raw : `${raw}%`;
}

function tSignalPriceText(value) {
  return hasValue(value) ? formatDisplayNumber(value) : "-";
}

function tSignalPriceRangeText(low, high) {
  return hasValue(low) || hasValue(high)
    ? `${tSignalPriceText(low)} / ${tSignalPriceText(high)}`
    : "-";
}

function tSignalRatioText(value) {
  return hasValue(value) ? `${value}%` : "-";
}

function tSignalActionLabel(action) {
  const labels = {
    BUY_T: "买入做T",
    SELL_T: "卖出做T",
    HOLD: "观察",
    REVIEW: "人工复核",
  };
  return labels[action] || formatPlain(action);
}

function tSignalStatusLabel(status) {
  const labels = {
    ok: "有效",
    review: "需复核",
    blocked: "已阻断",
    error: "错误",
    stale: "已过期",
  };
  return labels[status] || "未知";
}

function tSignalStatusClass(status) {
  if (status === "ok") {
    return "status-ok";
  }
  if (status === "review" || status === "blocked" || status === "stale") {
    return "status-partial";
  }
  if (status === "error") {
    return "status-failed";
  }
  return "status-muted";
}

function tSignalSessionLabel(value) {
  const labels = {
    pre_market: "盘前",
    regular: "盘中",
    post_market: "盘后",
    closed: "休市",
    unknown: "未知",
  };
  return labels[value] || formatPlain(value);
}

function tSignalNotificationText(notification) {
  if (!notification || typeof notification !== "object") {
    return "-";
  }
  if (notification.notified === true) {
    return hasValue(notification.last_notified_at)
      ? `已发起提醒 · ${notification.last_notified_at}`
      : "已发起提醒";
  }
  if (hasValue(notification.last_attempted_dedupe_key)) {
    return "已尝试发起提醒";
  }
  if (notification.should_notify === true) {
    return "待提醒";
  }
  return "不提醒";
}

function tSignalDirectionLabel(value) {
  const labels = { buy: "买入依据", sell: "卖出依据", neutral: "中性", risk: "风险" };
  return labels[value] || formatPlain(value);
}

function tSignalStrengthLabel(value) {
  const labels = { low: "弱", medium: "中", high: "强" };
  return labels[value] || formatPlain(value);
}

function tSignalGateStatusLabel(value) {
  const labels = { pass: "通过", block: "阻断", warn: "提醒", missing: "缺失" };
  return labels[value] || formatPlain(value);
}

function renderTSignalGateStatus(status) {
  const normalized = ["pass", "block", "warn", "missing"].includes(status) ? status : "missing";
  return `
    <strong class="t-signal-gate-status">
      <span class="t-signal-checkmark t-signal-checkmark-${escapeHtml(normalized)}" aria-hidden="true"></span>
      <span>${escapeHtml(tSignalGateStatusLabel(normalized))}</span>
    </strong>
  `;
}

function tSignalGateNameLabel(value) {
  const labels = {
    session_phase: "交易时段",
    baseline: "底仓数量",
    technical: "技术完整性",
    liquidity: "流动性",
    symbol: "标的匹配",
  };
  return labels[value] || formatPlain(value);
}

function tSignalPricePositionLabel(value) {
  const labels = {
    near_support: "接近支撑",
    near_resistance: "接近压力",
    below_vwap_reclaim: "低于 VWAP 后回收",
    above_vwap_reject: "高于 VWAP 后受压",
    middle_range: "区间中部",
    breakout: "突破",
    breakdown: "跌破",
    unknown: "未知",
  };
  return labels[value] || formatPlain(value);
}

function tSignalDepthStatusLabel(value) {
  const labels = { pass: "正常", thin: "深度不足", wide_spread: "价差偏大", missing: "缺失" };
  return labels[value] || formatPlain(value);
}

function tSignalTimelineLabel(value) {
  const labels = {
    signal_created: "生成信号",
    signal_changed: "信号变化",
    notification_sent: "已发送提醒",
    notification_suppressed: "已抑制重复提醒",
    notification_failed: "提醒失败",
    signal_expired: "信号过期",
    review_required: "需要复核",
  };
  return labels[value] || formatPlain(value);
}

function renderDecisionPlan(holding) {
  const plan = holding && holding.decision_plan && typeof holding.decision_plan === "object"
    ? holding.decision_plan
    : {};
  if (plan.available !== true) {
    return `<div class="decision-plan-failed status-failed">${escapeHtml(plan.error || "交易计划未生成")}</div>`;
  }
  if (plan.mode === "validated_plan") {
    return renderValidatedDecisionPlan(plan);
  }
  if (plan.mode === "fallback_advice") {
    return renderFallbackDecisionPlan(plan);
  }
  return `<div class="decision-plan-failed status-failed">交易计划类型无效</div>`;
}

function renderValidatedDecisionPlan(plan) {
  const conditions = Array.isArray(plan.conditions) ? plan.conditions : [];
  const next = conditions.find((condition) => condition.condition_id === plan.next_condition_id) || conditions[0];
  const strategy = plan.strategy && typeof plan.strategy === "object" ? plan.strategy : {};
  return `
    <section class="decision-plan decision-plan-validated">
      ${renderDecisionPlanHeader(plan, "已通过回测闸门", decisionPlanStatusLabel(plan.status))}
      <div class="decision-plan-overview">
        <article><span>当前结论</span><strong>${escapeHtml(plan.action_summary || "等待条件触发")}</strong></article>
        <article><span>下一条件</span><strong>${escapeHtml(next ? decisionConditionSummary(next) : "暂无")}</strong></article>
        <article><span>策略</span><strong>${escapeHtml(strategy.name_zh || strategy.id || "-")}</strong></article>
        <article><span>仓位上限</span><strong>${escapeHtml(decisionPlanWeight(plan.max_weight))}</strong></article>
      </div>
      <div class="decision-plan-layout">
        <div>
          <div class="decision-plan-section-heading"><h4>条件与动作</h4><span>风险条件优先 · 可重复触发</span></div>
          <div class="decision-plan-condition-list">
            ${conditions.length ? conditions.map(renderDecisionPlanCondition).join("") : '<p class="decision-plan-empty">当前没有可执行条件。</p>'}
          </div>
        </div>
        <aside class="decision-plan-evidence">
          <h4>回测闸门</h4>
          ${renderDecisionPlanBacktests(plan.backtests)}
        </aside>
      </div>
      ${renderPreviousDecisionReview(plan.previous_review)}
    </section>
  `;
}

function renderDecisionPlanHeader(plan, eyebrow, status) {
  return `
    <header class="decision-plan-header">
      <div><span>${escapeHtml(eyebrow)}</span><h3>今日交易计划</h3><p>${escapeHtml(plan.run_date || "-")} · ${escapeHtml(plan.plan_id || "")}</p></div>
      <strong class="decision-plan-status decision-plan-status-${escapeHtml(plan.status || "waiting")}">${escapeHtml(status)}</strong>
    </header>
  `;
}

function renderDecisionPlanCondition(condition, index) {
  const tone = condition.priority === "risk" ? "risk" : "ordinary";
  return `
    <article class="decision-plan-condition decision-plan-condition-${tone}" data-plan-condition="${escapeHtml(condition.condition_id || String(index))}">
      <div class="decision-plan-condition-head">
        <span>${condition.priority === "risk" ? "风险优先" : "普通条件"}</span>
        <b>已触发 ${escapeHtml(formatDisplayNumber(condition.trigger_count || 0))} 次</b>
      </div>
      <h5>${escapeHtml(decisionConditionSummary(condition))}</h5>
      <div class="decision-plan-condition-metrics">
        <div><span>执行动作</span><strong>${escapeHtml(condition.suggested_action || "-")}</strong></div>
        <div><span>目标仓位</span><strong>${escapeHtml(decisionPlanWeight(condition.target_weight))}</strong></div>
        <div><span>目标数量</span><strong>${escapeHtml(formatDisplayNumber(condition.target_quantity))}</strong></div>
      </div>
      ${renderDecisionPlanProvenance(condition)}
    </article>
  `;
}

function renderDecisionPlanProvenance(item) {
  const inputs = item.inputs && typeof item.inputs === "object"
    ? Object.entries(item.inputs).map(([key, value]) => `${key}=${formatPlain(value)}`).join(" · ")
    : "-";
  return `
    <details class="decision-plan-provenance">
      <summary>参数来源</summary>
      <dl>
        <div><dt>公式</dt><dd>${escapeHtml(item.formula || "-")}</dd></div>
        <div><dt>输入</dt><dd>${escapeHtml(inputs)}</dd></div>
        <div><dt>数据日期</dt><dd>${escapeHtml(item.source_date || "-")}</dd></div>
      </dl>
    </details>
  `;
}

function renderDecisionPlanBacktests(backtests) {
  const rows = Array.isArray(backtests) ? backtests : [];
  if (!rows.length) {
    return '<p class="decision-plan-empty">没有回测证据。</p>';
  }
  return `
    <div class="decision-plan-backtests">
      ${rows.map((item) => {
        const strategy = item.strategy || {};
        const benchmark = item.market_benchmark || {};
        const heading = [item.range, item.strategy_id].filter(hasValue).join(" · ") || "-";
        const returns = [
          ["策略收益", strategy.total_return_pct, "pnl"],
          [benchmark.symbol || "基准", benchmark.total_return_pct, "pnl"],
          ["超额收益", item.market_excess_return_pct, "pnl"],
          ["最大回撤", strategy.max_drawdown_pct, "drawdown"],
        ];
        return `
          <article>
            <div><strong>${escapeHtml(heading)}</strong><span class="status-pill status-${item.gate && item.gate.passed === true ? "ok" : "failed"}">${item.gate && item.gate.passed === true ? "通过" : "未通过"}</span></div>
            <dl>
              ${returns.map(([label, value, kind]) => {
                const display = kind === "drawdown"
                  ? drawdownPercent(value)
                  : formatSignedPnl(decisionPlanPercent(value));
                const tone = pnlClass(display);
                return `<div><dt>${escapeHtml(label)}</dt><dd${tone ? ` class="${tone}"` : ""}>${escapeHtml(display)}</dd></div>`;
              }).join("")}
              <div><dt>夏普比率</dt><dd>${escapeHtml(strategy.sharpe_ratio || "-")}</dd></div>
              <div><dt>卡玛比率</dt><dd>${escapeHtml(decisionPlanRatio(strategy.calmar_ratio))}</dd></div>
            </dl>
          </article>
        `;
      }).join("")}
    </div>
  `;
}

function renderFallbackDecisionPlan(plan) {
  const fallback = plan.fallback && typeof plan.fallback === "object" ? plan.fallback : {};
  const facts = Array.isArray(fallback.facts) ? fallback.facts : [];
  const tradingagents = fallback.tradingagents && typeof fallback.tradingagents === "object"
    ? fallback.tradingagents : {};
  return `
    <section class="decision-plan decision-plan-fallback">
      ${renderDecisionPlanHeader(plan, fallback.label || "非执行型建议", "禁止自动执行")}
      <div class="decision-plan-fallback-banner">
        <div><span>建议</span><strong>${escapeHtml(fallback.recommendation || "禁止加仓")}</strong></div>
        <div><span>仓位上限</span><strong>${escapeHtml(decisionPlanWeight(fallback.max_weight || plan.max_weight))}</strong></div>
      </div>
      <div class="decision-plan-section-heading"><h4>市场事实</h4><span>仅供判断，不构成可触发策略</span></div>
      <div class="decision-plan-fact-grid">${facts.map(renderDecisionPlanFact).join("")}</div>
      <div class="decision-plan-fallback-reason">
        <article><h4>TradingAgents 解读</h4><p>${escapeHtml(tradingagents.core_reason || tradingagents.current_action || "暂无")}</p></article>
        <article><h4>为什么没有可执行计划</h4><p>${escapeHtml(fallback.reason || "没有策略通过当前回测闸门")}</p></article>
      </div>
      <div class="decision-plan-section-heading"><h4>回测闸门</h4><span>候选策略均未通过，仅展示证据</span></div>
      ${renderDecisionPlanBacktests(plan.backtests)}
      ${renderPreviousDecisionReview(plan.previous_review)}
    </section>
  `;
}

function renderDecisionPlanFact(fact) {
  const labels = {
    ma20_distance_pct: "距 MA20",
    rsi14: "RSI 14",
    bollinger_position: "布林带位置",
    relative_volume: "相对成交量",
  };
  return `
    <article class="decision-plan-fact">
      <span>${escapeHtml(labels[fact.key] || fact.key || "事实")}</span>
      <strong>${escapeHtml(formatDisplayNumber(fact.calculated_value))}</strong>
      ${renderDecisionPlanProvenance(fact)}
    </article>
  `;
}

function renderPreviousDecisionReview(review) {
  if (!review || typeof review !== "object") {
    return "";
  }
  return `
    <details class="decision-plan-review">
      <summary>上期复盘 · ${escapeHtml(review.run_date || "-")}</summary>
      <div>
        <span>上期状态 <strong>${escapeHtml(decisionPlanStatusLabel(review.status))}</strong></span>
        <span>条件触发 <strong>${escapeHtml(formatDisplayNumber(review.trigger_count || 0))} 次</strong></span>
        <span>期初数量 <strong>${escapeHtml(formatDisplayNumber(review.starting_quantity))}</strong></span>
        <span>本期期初数量 <strong>${escapeHtml(formatDisplayNumber(review.closing_quantity))}</strong></span>
      </div>
    </details>
  `;
}

function decisionConditionSummary(condition) {
  return `价格 ${condition.operator || ""} ${formatDisplayNumber(condition.calculated_value)}`.trim();
}

function decisionPlanWeight(value) {
  const number = Number(value);
  return Number.isFinite(number) ? `${(number * 100).toFixed(2).replace(/\.00$/, "")}%` : "-";
}

function decisionPlanPercent(value) {
  const number = Number(value);
  return Number.isFinite(number) ? `${number.toFixed(2).replace(/\.00$/, "")}%` : "-";
}

function decisionPlanRatio(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number.toFixed(2) : "-";
}

function decisionPlanStatusLabel(status) {
  return ({waiting: "等待条件", triggered: "条件已触发", expired: "计划已过期"})[status] || "状态未知";
}

function decisionTabViews(holding) {
  const facts = holding && holding.decision_facts && typeof holding.decision_facts === "object"
    ? holding.decision_facts : {};
  const futuFacts = holding && holding.futu_skill_facts && typeof holding.futu_skill_facts === "object"
    ? holding.futu_skill_facts : {};
  const summary = holding && holding.tradingagents_summary && typeof holding.tradingagents_summary === "object"
    ? holding.tradingagents_summary : {};
  const technicalFacts = holding && typeof holding.technical_facts === "object"
    ? holding.technical_facts : null;
  const futuModules = ["technical_anomaly", "capital_anomaly", "derivatives_anomaly"]
    .map((key) => futuFacts[key]);
  const futuNews = futuSkillNewsSentimentModule(holding);
  const definitions = {
    final: {
      available: Boolean(holding && holding.decision_plan && holding.decision_plan.available === true),
      error: holding && holding.decision_plan && holding.decision_plan.error,
      html: renderDecisionPlan(holding),
    },
    tradingagents: {
      available: summary.available === true,
      error: summary.error,
      html: renderTradingAgentsSummaryCard(holding),
    },
    kline: {
      available: Boolean(facts.kline && facts.kline.available === true) || technicalFactsUsable(technicalFacts),
      error: (facts.kline && facts.kline.error) || (technicalFacts && technicalFacts.error),
      html: renderDecisionPluginCard(klineDecisionFactsPlugin(holding)),
    },
    news: {
      available: Boolean(facts.news_sentiment && facts.news_sentiment.available === true)
        || Boolean(futuNews && futuNews.available === true),
      error: (facts.news_sentiment && facts.news_sentiment.error) || (futuNews && futuNews.error),
      html: renderDecisionPluginCard(newsSentimentPlugin(holding)),
    },
    futu: {
      available: futuModules.some((module) => module && module.available === true),
      error: futuModules.map((module) => module && module.error).find(hasValue),
      html: futuAnomalySignalsPlugin(holding),
    },
  };
  return DECISION_TABS.map((tab) => ({ ...tab, ...definitions[tab.key] }));
}

function renderTradingDecisionTabs(holding) {
  const views = decisionTabViews(holding);
  const selected = views.find((view) => view.key === state.selectedDecisionTab) || views[0];
  const panel = selected.available
    ? selected.html
    : `<div class="decision-tab-empty status-failed">${escapeHtml(selected.error || "数据未生成")}</div>`;
  return `
    <section class="detail-section trading-decision-section">
      <div class="trading-decision-section-header"><div><h3>交易决策</h3><p>结论先行，按证据模块逐项复核。</p></div></div>
      <div class="decision-tab-list" role="tablist" aria-label="交易决策模块">
        ${views.map((view) => `<button id="decision-tab-${view.key}" class="decision-tab${view.key === selected.key ? " active" : ""}${view.available ? "" : " decision-tab-failed"}" type="button" role="tab" aria-selected="${view.key === selected.key}" aria-controls="decision-panel-${view.key}" data-decision-tab="${view.key}">${escapeHtml(view.label)}</button>`).join("")}
      </div>
      <div id="decision-panel-${selected.key}" class="decision-tab-panel" role="tabpanel" aria-labelledby="decision-tab-${selected.key}">${panel}</div>
    </section>
  `;
}

function renderTradingAgentsSummaryCard(holding) {
  const summary = holding && holding.tradingagents_summary && typeof holding.tradingagents_summary === "object"
    ? holding.tradingagents_summary
    : {};
  const rows = [
    ["ta_view", "TA 观点"],
    ["current_action", "当前动作"],
    ["core_reason", "核心理由"],
    ["ta_report_date", "TA 报告日期"],
    ["latest_run_date", "当前 latest"],
  ].map(([key, label]) => ({
    label,
    value: formatTradingAgentsSummaryValue(summary[key]),
  }));
  return `
    <article class="decision-plugin-card">
      <div class="decision-plugin-card-header">
        <h4>TradingAgents</h4>
      </div>
      ${renderDecisionFactRows(rows)}
    </article>
  `;
}

function formatTradingAgentsSummaryValue(value) {
  return hasValue(value) ? formatPlain(value) : "缺失";
}

function decisionFactsPlugin(holding, config) {
  const module = decisionFactsModule(holding, config.moduleKey);
  const fields = module && module.fields && typeof module.fields === "object"
    ? module.fields
    : {};
  const rows = config.fieldOrder.map(([key, label]) => ({
    label,
    value: hasValue(fields[key]) ? formatPlain(fields[key]) : "缺失",
  }));
  const missingLabels = missingDecisionFactFieldLabels(fields, config.fieldOrder);
  const available = Boolean(module && module.available === true);
  const complete = available && missingLabels.length === 0;
  return {
    title: config.title,
    status: complete ? "可用" : (available ? "不完整" : "缺失"),
    tone: complete ? "ok" : "partial",
    score: config.score,
    headline: rows[0] ? rows[0].value : "缺失",
    detail: "",
    bodyHtml: renderDecisionFactRows(rows),
    condition: "",
  };
}

function klineDecisionFactsPlugin(holding) {
  const module = decisionFactsModule(holding, "kline");
  const fieldOrder = [
    ["trend", "趋势"],
    ["position", "位置"],
    ["momentum", "动能"],
    ["key_levels", "关键位"],
    ["risk", "风险"],
  ];
  const plugin = decisionFactsPlugin(holding, {
    title: "趋势 / K 线",
    moduleKey: "kline",
    fieldOrder,
    score: "K线",
  });
  const detail = holding && typeof holding.technical_facts === "object"
    ? holding.technical_facts
    : null;
  const timeframes = technicalFactsUsable(detail)
    ? detail.facts.timeframes
    : [];
  const hasFixedFields = module
    && module.fields
    && typeof module.fields === "object"
    && fieldOrder.some(([key]) => Object.prototype.hasOwnProperty.call(module.fields, key));
  if (detail && plugin.status === "缺失" && !hasFixedFields) {
    return klineTechnicalFactsPlugin(holding);
  }
  return {
    ...plugin,
    bodyHtml: `${timeframes.length ? renderBollingerSection(timeframes, holding.last_price) : ""}${plugin.bodyHtml}`,
  };
}

function newsSentimentPlugin(holding) {
  const plugin = decisionFactsPlugin(holding, {
    title: "新闻 / 舆论",
    moduleKey: "news_sentiment",
    fieldOrder: [
      ["direction", "方向"],
      ["change", "变化"],
      ["catalyst", "催化"],
      ["risk", "风险"],
      ["attention", "热度"],
    ],
    score: "舆论",
  });
  const domesticHtml = futuSkillNewsSentimentPlugin(holding);
  return {
    ...plugin,
    bodyHtml: plugin.bodyHtml + domesticHtml,
  };
}

function futuSkillNewsSentimentPlugin(holding) {
  const module = futuSkillNewsSentimentModule(holding);
  if (!module || module.available !== true) {
    return "";
  }
  const discussion = module.domestic_discussion && typeof module.domestic_discussion === "object"
    ? module.domestic_discussion
    : {};
  const rows = [
    {
      label: "讨论关键词",
      htmlValue: renderDomesticKeywordTags(discussion.keyword_counts),
    },
    { label: "国内讨论结论", value: formatPlain(discussion.summary) },
    { label: "主要关注点", value: formatPlain(discussion.focus) },
    { label: "分歧 / 风险", value: formatPlain(discussion.divergence_risk) },
    { label: "可信度", value: formatPlain(discussion.credibility), tone: "warn" },
    { label: "交易约束", value: formatPlain(discussion.trading_constraint), tone: "warn" },
  ];
  return `
    <div class="decision-fact-source-block">
      <div class="domestic-section-header">
        <b>富途社区 / 国内讨论</b>
        <span>LLM 总结 · stock_feed</span>
      </div>
      ${renderDomesticDiscussionRows(rows)}
    </div>
  `;
}

function futuSkillNewsSentimentModule(holding) {
  const facts = holding && holding.futu_skill_facts && typeof holding.futu_skill_facts === "object"
    ? holding.futu_skill_facts
    : {};
  const module = facts.news_sentiment;
  return module && typeof module === "object" ? module : null;
}

function futuAnomalySignalsPlugin(holding) {
  const facts = holding && holding.futu_skill_facts && typeof holding.futu_skill_facts === "object"
    ? holding.futu_skill_facts
    : {};
  const modules = [
    ["technical_anomaly", "技术异动"],
    ["capital_anomaly", "资金异动"],
    ["derivatives_anomaly", "衍生品异动"],
  ].map(([key, title]) => futuSignalModuleView(facts[key], key, title));
  const available = modules.filter((module) => module.available).length;
  const overall = deriveFutuSignalOverall(modules);
  return `
    <article class="decision-plugin-card futu-signal-card">
      <div class="decision-plugin-card-header">
        <h4>市场信号 · 富途异动信号</h4>
        <span class="status-pill status-${escapeHtml(overall.tone)}">${escapeHtml(available)}/3 模块可用</span>
      </div>
      <div class="futu-signal-overall">
        <strong>${escapeHtml(overall.label)}</strong>
        <div>
          <b>${escapeHtml(overall.headline)}</b>
          <span>${escapeHtml(overall.detail)}</span>
        </div>
        <div class="futu-signal-pill-row">
          <span>${escapeHtml(translateFutuSignalValue(overall.signal))}</span>
          <span>${escapeHtml(translateFutuSignalValue(overall.constraint))}</span>
        </div>
      </div>
      <div class="futu-signal-module-grid">
        ${modules.map(renderFutuSignalModule).join("")}
      </div>
      <p class="condition-box">模板约束：模块标题、状态、方向、置信度、约束、类别顺序固定；缺失、无异常和权限失败必须显式展示。</p>
    </article>
  `;
}

function futuSignalModuleView(module, key, title) {
  const value = module && typeof module === "object" ? module : {};
  const status = hasValue(value.status) ? String(value.status) : "missing";
  const signal = value.available === true && !["missing", "error", "stale", "stale_run_date"].includes(status) && hasValue(value.signal)
    ? String(value.signal)
    : status;
  return {
    key,
    title,
    available: value.available === true,
    status,
    signal,
    confidence: hasValue(value.confidence) ? String(value.confidence) : "low",
    suggestedConstraint: hasValue(value.suggested_constraint) ? String(value.suggested_constraint) : "",
    summary: hasValue(value.summary) ? String(value.summary) : "缺失",
    categories: Array.isArray(value.categories) ? value.categories.slice(0, 3) : [],
  };
}

function deriveFutuSignalOverall(modules) {
  const constraints = modules.map((module) => module.suggestedConstraint).filter(hasValue);
  const signals = modules.map((module) => module.signal).filter(hasValue);
  const constraint = constraints.includes("no_add")
    ? "no_add"
    : constraints.includes("review")
      ? "review"
      : "";
  if (signals.includes("error") || signals.includes("missing") || signals.includes("stale") || signals.includes("stale_run_date")) {
    return {
      tone: "warn",
      label: "需复核",
      signal: signals.includes("error") ? "error" : (signals.includes("stale_run_date") ? "stale_run_date" : (signals.includes("stale") ? "stale" : "missing")),
      constraint: constraint || "review",
      headline: "市场信号数据不可用，不能视为中性。",
      detail: "缺失、错误或过期模块会保留数据质量状态，不会自动改写成交易方向。",
    };
  }
  if (signals.includes("risk_up") || signals.includes("mixed")) {
    return {
      tone: constraint ? "warn" : "ok",
      label: constraint ? "谨慎" : "分歧",
      signal: signals.includes("risk_up") ? "risk_up" : "mixed",
      constraint,
      headline: "市场信号存在分歧，需要结合主结论复核。",
      detail: "统一结论只来自三个模块的结构化字段；不会展示自由发挥的长段落。",
    };
  }
  if (signals.includes("opposing")) {
    return {
      tone: "warn",
      label: "反对",
      signal: "opposing",
      constraint,
      headline: "市场信号反对当前交易方向。",
      detail: "统一结论只来自三个模块的结构化字段；不会展示自由发挥的长段落。",
    };
  }
  if (signals.includes("supportive")) {
    return {
      tone: "ok",
      label: "支持",
      signal: "supportive",
      constraint,
      headline: "市场信号支持当前交易方向。",
      detail: "统一结论只来自三个模块的结构化字段；不会展示自由发挥的长段落。",
    };
  }
  return {
    tone: "muted",
    label: "中性",
    signal: "neutral",
    constraint,
    headline: "窗口内未发现明显异动。",
    detail: "缺失、无异常和权限失败会在模块内显式展示。",
  };
}

function renderFutuSignalModule(module) {
  return `
    <section class="futu-signal-module">
      <div class="futu-signal-module-header">
        <h5>${escapeHtml(module.title)}</h5>
        <span class="status-pill status-${escapeHtml(futuSignalStatusTone(module.status))}">${escapeHtml(translateFutuSignalValue(module.status))}</span>
      </div>
      <div class="futu-signal-metrics">
        <div><span>方向</span><strong>${escapeHtml(translateFutuSignalValue(module.signal))}</strong></div>
        <div><span>${module.suggestedConstraint ? "约束" : "置信度"}</span><strong>${escapeHtml(translateFutuSignalValue(module.suggestedConstraint || module.confidence))}</strong></div>
      </div>
      <div class="futu-signal-category-list">
        ${renderFutuSignalCategories(module.categories)}
      </div>
    </section>
  `;
}

function renderFutuSignalCategories(categories) {
  if (!categories.length) {
    return `
      <div class="futu-signal-category empty">
        <div><strong>缺失</strong><span>缺失</span></div>
        <p>未找到可展示的结构化类别。</p>
      </div>
    `;
  }
  return categories.map((category) => {
    const state = hasValue(category.state) ? String(category.state) : "none";
    const direction = hasValue(category.direction) ? String(category.direction) : "";
    const date = hasValue(category.evidence_date) ? ` · ${category.evidence_date}` : "";
    return `
      <div class="futu-signal-category ${escapeHtml(futuSignalCategoryTone(state, direction))}">
        <div>
          <strong>${escapeHtml(category.name || "缺失")}</strong>
          <span>${escapeHtml(translateFutuSignalValue(direction || state) + date)}</span>
        </div>
        <p>${escapeHtml(category.detail || "缺失")}</p>
      </div>
    `;
  }).join("");
}

function translateFutuSignalValue(value) {
  const key = hasValue(value) ? String(value) : "";
  const labels = {
    supportive: "支持",
    opposing: "反对",
    neutral: "中性",
    risk_up: "风险上升",
    mixed: "分歧",
    no_add: "不加仓",
    review: "需复核",
    reduce_only: "只减不加",
    wait_for_event: "等待事件",
    ok: "正常",
    partial: "部分可用",
    missing: "缺失",
    error: "错误",
    stale: "已过期",
    stale_run_date: "已过期",
    anomaly: "异常",
    none: "无异常",
    not_applicable: "不适用",
    bullish: "偏多",
    bearish: "偏空",
    high: "高",
    medium: "中等",
    low: "低",
    "": "-",
  };
  return Object.prototype.hasOwnProperty.call(labels, key) ? labels[key] : "未知";
}

function futuSignalStatusTone(status) {
  if (status === "ok") return "ok";
  if (status === "partial") return "warn";
  if (status === "stale" || status === "stale_run_date") return "stale";
  if (status === "error") return "failed";
  return "muted";
}

function futuSignalCategoryTone(state, direction) {
  if (state === "error") return "failed";
  if (state === "none" || state === "not_applicable") return "empty";
  if (direction === "bearish" || direction === "risk_up") return "watch";
  if (direction === "bullish") return "positive";
  return "mixed";
}

function renderDomesticDiscussionRows(rows) {
  return `
    <div class="domestic-list">
      ${rows.map((row) => `
        <div class="domestic-row ${row.tone === "warn" ? "warn" : ""}">
          <span>${escapeHtml(row.label)}</span>
          ${row.htmlValue || `<strong>${escapeHtml(row.value)}</strong>`}
        </div>
      `).join("")}
    </div>
  `;
}

function renderDomesticKeywordTags(keywordCounts) {
  const items = Array.isArray(keywordCounts)
    ? keywordCounts
        .filter((item) => item && hasValue(item.keyword) && Number.isInteger(item.count) && item.count > 0)
        .slice(0, 3)
    : [];
  if (!items.length) {
    return `<strong>缺失</strong>`;
  }
  return `
    <div class="domestic-keyword-list">
      ${items.map((item) => `
        <b class="domestic-keyword">
          <span>${escapeHtml(formatPlain(item.keyword))}</span>
          <em>${escapeHtml(formatDisplayNumber(item.count))}</em>
        </b>
      `).join("")}
    </div>
  `;
}

function decisionFactsModule(holding, moduleKey) {
  const detail = holding && holding.decision_facts && typeof holding.decision_facts === "object"
    ? holding.decision_facts
    : {};
  const module = detail[moduleKey];
  return module && typeof module === "object" ? module : null;
}

function missingDecisionFactFieldLabels(fields, fieldOrder) {
  return fieldOrder
    .filter(([key]) => !hasValue(fields[key]) || formatPlain(fields[key]) === "缺失")
    .map(([, label]) => label);
}

function renderDecisionFactRows(rows) {
  return `
    <div class="decision-fact-grid">
      ${rows.map((row) => `
        <div class="decision-fact-row">
          <span>${escapeHtml(row.label)}</span>
          <strong>${escapeHtml(row.value)}</strong>
        </div>
      `).join("")}
    </div>
  `;
}

function renderDecisionPluginCard(plugin) {
  return `
    <article class="decision-plugin-card">
      <div class="decision-plugin-card-header">
        <h4>${escapeHtml(plugin.title)}</h4>
        <span class="status-pill status-${escapeHtml(plugin.tone)}">${escapeHtml(plugin.status)}</span>
      </div>
      <div class="decision-plugin-output">
        <strong>${escapeHtml(plugin.score)}</strong>
        <div>
          <b>${escapeHtml(plugin.headline)}</b>
          <span>${escapeHtml(plugin.detail)}</span>
        </div>
      </div>
      ${plugin.bodyHtml || ""}
      ${hasValue(plugin.condition) ? `<p class="condition-box">${escapeHtml(plugin.condition)}</p>` : ""}
    </article>
  `;
}

function klineTechnicalFactsPlugin(holding) {
  const detail = holding && typeof holding.technical_facts === "object"
    ? holding.technical_facts
    : null;
  if (technicalFactsUsable(detail)) {
    const timeframes = detail.facts && Array.isArray(detail.facts.timeframes)
      ? detail.facts.timeframes
      : [];
    const bollingerHtml = renderBollingerSection(timeframes, holding.last_price);
    const dateText = technicalFactsDateText(detail);
    return {
      title: "趋势 / K 线",
      status: "可用",
      tone: "ok",
      score: "K线",
      headline: dateText || "当前可用",
      detail: technicalFactsFreshnessText(detail) || "技术面事实来自日 K 行情。",
      bodyHtml: bollingerHtml,
      condition: "",
    };
  }
  const unavailable = technicalFactsUnavailableText(detail);
  return {
    title: "趋势 / K 线",
    status: "不可用",
    tone: unavailable.tone,
    score: "-",
    headline: unavailable.label,
    detail: unavailable.detail,
    bodyHtml: renderTechnicalFactsMeta(detail),
    condition: "条件：只有技术事实可用、来源未过期且周期完整时，才作为当前 K 线依据。",
  };
}

function technicalFactsUsable(detail) {
  return Boolean(
    detail
    && detail.available === true
    && detail.status === "usable"
    && detail.facts
    && Array.isArray(detail.facts.timeframes)
    && detail.facts.timeframes.length,
  );
}

function technicalFactsUnavailableText(detail) {
  const status = detail && hasValue(detail.status) ? String(detail.status) : "missing_file";
  const labels = {
    missing_file: "缺少文件",
    missing_record: "缺少记录",
    stale_source_hash: "来源已过期",
    extraction_error: "抽取失败",
    missing_source: "缺少来源",
    missing_source_hash: "缺少来源哈希",
    missing_timeframe: "缺少周期",
  };
  const tones = {
    missing_file: "partial",
    missing_record: "partial",
    stale_source_hash: "stale",
    extraction_error: "failed",
    missing_source: "failed",
    missing_source_hash: "failed",
    missing_timeframe: "failed",
  };
  return {
    label: labels[status] || "不可用",
    tone: tones[status] || "partial",
    detail: firstPresent(detail && detail.error, technicalFactsFreshnessText(detail), "暂无可用 K 线技术事实。"),
  };
}

function technicalFactsDateText(detail) {
  const parts = [];
  if (detail && hasValue(detail.data_date)) {
    parts.push(`数据日 ${detail.data_date}`);
  }
  if (detail && hasValue(detail.run_date)) {
    parts.push(`运行 ${detail.run_date}`);
  }
  return parts.join(" · ");
}

function technicalFactsRunText(detail) {
  const dates = technicalFactsDateText(detail);
  if (!dates) {
    return "";
  }
  if (detail && detail.source_type === "futu_kline") {
    return `条件：${dates}；来源为日 K 行情。`;
  }
  return `条件：${dates}；来源哈希已与最新报告校验。`;
}

function technicalFactsFreshnessText(detail) {
  const freshness = detail && detail.freshness && typeof detail.freshness === "object"
    ? detail.freshness
    : {};
  return firstPresent(freshness.message, freshness.status);
}

function renderTechnicalFactsMeta(detail) {
  const dates = technicalFactsDateText(detail);
  if (!dates) {
    return "";
  }
  return `<div class="technical-facts-meta">${escapeHtml(dates)}</div>`;
}

function renderBollingerSection(timeframes, holdingPrice) {
  const timeframesWithObjects = Array.isArray(timeframes)
    ? timeframes.filter((timeframe) => timeframe && typeof timeframe === "object")
    : [];
  const preferred = timeframesWithObjects.find((timeframe) => {
    const key = String(timeframe.timeframe || timeframe.period || "").toLowerCase();
    return key === "daily" || key === "day" || key === "1d";
  }) || timeframesWithObjects[0];
  if (!preferred) {
    return renderBollingerCard({}, "", "");
  }
  const bollinger = preferred.bollinger && typeof preferred.bollinger === "object"
    ? preferred.bollinger
    : {};
  const currentPrice = firstPresent(holdingPrice, preferred.current_price, bollinger.current_price);
  return renderBollingerCard(bollinger, currentPrice, timeframeLabel(preferred));
}

function renderBollingerCard(bollinger, currentPrice, timeframe) {
  const status = bollingerStatus(bollinger);
  const statusMeta = bollingerStatusMeta(status);
  const summary = firstPresent(
    bollinger.summary_zh,
    defaultBollingerSummary(status, timeframe),
  );
  const detail = firstPresent(
    bollinger.detail_zh,
    defaultBollingerDetail(status),
  );
  return `
    <section class="technical-bollinger-card ${escapeHtml(statusMeta.className)}">
      <div class="technical-bollinger-header">
        <span>${escapeHtml(timeframe ? `${timeframe}布林带` : "布林带")}</span>
        <strong>${escapeHtml(statusMeta.label)}</strong>
      </div>
      <div class="technical-bollinger-copy">
        <strong>${escapeHtml(summary)}</strong>
        <p>${escapeHtml(detail)}</p>
      </div>
      ${renderBollingerBand(bollinger, currentPrice)}
      ${renderBollingerMetrics(bollinger, currentPrice, status)}
    </section>
  `;
}

function bollingerStatus(bollinger) {
  const status = String(bollinger && bollinger.status ? bollinger.status : "").trim();
  if (["upper_risk", "lower_opportunity", "neutral", "unknown"].includes(status)) {
    return status;
  }
  return "unknown";
}

function bollingerStatusMeta(status) {
  const map = {
    upper_risk: { label: "回调风险升高", className: "upper-risk" },
    lower_opportunity: { label: "低位机会区域", className: "lower-opportunity" },
    neutral: { label: "中性区间", className: "middle-range" },
    unknown: { label: "布林带数据缺失", className: "missing" },
  };
  return map[status] || map.unknown;
}

function defaultBollingerSummary(status, timeframe) {
  const label = timeframe || "日线";
  if (status === "upper_risk") {
    return `当前价格贴近或超过${label}布林带上轨`;
  }
  if (status === "lower_opportunity") {
    return `当前价格接近${label}布林带下轨`;
  }
  if (status === "neutral") {
    return `当前价格位于${label}布林带中性区间`;
  }
  return "布林带数据缺失";
}

function defaultBollingerDetail(status) {
  if (status === "upper_risk") {
    return "价格靠近布林带上沿，说明短线偏热。这个状态用于提醒可能接近回调区，不直接给出交易动作。";
  }
  if (status === "lower_opportunity") {
    return "价格靠近布林带下沿，说明进入低位观察区。这个状态用于提醒可能出现低位机会，不直接给出交易动作。";
  }
  if (status === "neutral") {
    return "价格没有贴近上轨或下轨，布林带暂未给出需要特别关注的位置提醒。";
  }
  return "当前报告没有提供完整布林带事实。";
}

function renderBollingerBand(bollinger, currentPrice) {
  const lower = indicatorValue(bollinger.lower);
  const middle = indicatorValue(bollinger.middle);
  const upper = indicatorValue(bollinger.upper);
  const markerStyle = bollingerMarkerStyle(bollinger, currentPrice);
  return `
    <div class="technical-bollinger-band">
      <div class="technical-bollinger-track">
        <span class="technical-bollinger-marker" style="${escapeHtml(markerStyle)}"></span>
      </div>
      <div class="technical-bollinger-labels">
        <span>下轨 ${escapeHtml(formatDisplayNumber(lower || "缺失"))}</span>
        <span>中轨 ${escapeHtml(formatDisplayNumber(middle || "缺失"))}</span>
        <span>上轨 ${escapeHtml(formatDisplayNumber(upper || "缺失"))}</span>
      </div>
    </div>
  `;
}

function bollingerMarkerStyle(bollinger, currentPrice) {
  const lower = numericValue(indicatorValue(bollinger.lower));
  const upper = numericValue(indicatorValue(bollinger.upper));
  const current = numericValue(indicatorValue(currentPrice));
  if (lower === null || upper === null || current === null || upper <= lower) {
    return "left: 50%";
  }
  const raw = ((current - lower) / (upper - lower)) * 100;
  const clamped = Math.max(2, Math.min(98, raw));
  return `left: ${clamped.toFixed(1)}%`;
}

function renderBollingerMetrics(bollinger, currentPrice, status) {
  const referenceLabel = bollingerReferenceLabel(bollinger, status);
  const referenceValue = firstPresent(
    bollinger.reference_value,
    bollingerReferenceValue(bollinger, status),
  );
  const distance = firstPresent(bollinger.distance_pct, bollingerDistanceFallback(status));
  return renderDecisionFactRows([
    { label: "当前价", value: bollingerMetricValue(currentPrice) },
    { label: referenceLabel, value: bollingerMetricValue(referenceValue) },
    { label: "偏离幅度", value: bollingerMetricValue(distance) },
  ]);
}

function bollingerMetricValue(value) {
  return hasValue(value) ? formatDisplayNumber(value) : "缺失";
}

function bollingerReferenceLabel(bollinger, status) {
  if (status === "upper_risk") {
    return "上轨";
  }
  if (status === "lower_opportunity") {
    return "下轨";
  }
  if (status === "neutral") {
    return "中轨";
  }
  const referenceBand = String(bollinger.reference_band || "");
  if (referenceBand === "upper") {
    return "上轨";
  }
  if (referenceBand === "lower") {
    return "下轨";
  }
  return "参考轨道";
}

function bollingerReferenceValue(bollinger, status) {
  if (status === "upper_risk") {
    return bollinger.upper;
  }
  if (status === "lower_opportunity") {
    return bollinger.lower;
  }
  if (status === "neutral") {
    return bollinger.middle;
  }
  return firstPresent(bollinger.upper, bollinger.lower, bollinger.middle);
}

function bollingerDistanceFallback(status) {
  if (status === "neutral") {
    return "中性区间";
  }
  return "缺失";
}

function renderTechnicalFactRows(rows) {
  if (!rows.length) {
    return `<p class="compact-empty">暂无可展示的周期指标。</p>`;
  }
  return `
    <div class="technical-fact-grid">
      ${rows.map((row) => `
        <div class="technical-fact-row">
          <span>${escapeHtml(row.label)}</span>
          <strong>${escapeHtml(row.value)}</strong>
        </div>
      `).join("")}
    </div>
  `;
}

function technicalFactRows(facts) {
  const timeframes = facts && Array.isArray(facts.timeframes) ? facts.timeframes : [];
  return timeframes.flatMap((timeframe) => technicalFactRowsForTimeframe(timeframe));
}

function technicalFactRowsForTimeframe(timeframe) {
  if (!timeframe || typeof timeframe !== "object") {
    return [];
  }
  const label = timeframeLabel(timeframe);
  const rows = [];
  addTechnicalFactRow(rows, `${label} 当前价`, indicatorValue(timeframe.current_price));
  addTechnicalFactRow(rows, `${label} RSI`, indicatorValue(timeframe.rsi));
  addTechnicalFactRow(rows, `${label} MACD`, macdValue(timeframe.macd));
  addTechnicalFactRow(rows, `${label} MACD`, indicatorValue(timeframe.macd_golden_cross));
  addTechnicalFactRow(rows, `${label} 金叉`, goldenCrossText(timeframe.golden_cross));
  addTechnicalFactRow(rows, `${label} 趋势`, indicatorValue(timeframe.trend_summary || timeframe.trend));
  addTechnicalFactRow(rows, `${label} ATR`, atrValue(timeframe.atr));
  addTechnicalFactRow(rows, `${label} 支撑`, supportResistanceValue(timeframe, "support"));
  addTechnicalFactRow(rows, `${label} 阻力`, supportResistanceValue(timeframe, "resistance"));
  addTechnicalFactRow(rows, `${label} 均线`, movingAverageValue(timeframe));
  return rows;
}

function addTechnicalFactRow(rows, label, value) {
  if (hasValue(value)) {
    rows.push({ label, value: formatDisplayNumber(value) });
  }
}

function timeframeLabel(timeframe) {
  const explicit = timeframe.timeframe_label || timeframe.label;
  if (hasValue(explicit)) {
    return formatPlain(explicit);
  }
  const key = String(timeframe.timeframe || timeframe.period || "").toLowerCase();
  const labels = {
    daily: "日线",
    day: "日线",
    "1d": "日线",
    weekly: "周线",
    week: "周线",
    "1w": "周线",
    monthly: "月线",
    month: "月线",
    "1m": "月线",
    yearly: "年线",
    year: "年线",
    "1y": "年线",
  };
  return labels[key] || formatPlain(timeframe.timeframe || timeframe.period || "未标明周期");
}

function indicatorValue(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return value;
  }
  return firstPresent(value.value, value.text, value.status, value.signal, value.summary);
}

function indicatorDisplayNumber(value) {
  const item = indicatorValue(value);
  return hasValue(item) ? formatDisplayNumber(item) : "";
}

function macdValue(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return value;
  }
  const macdLine = firstPresent(value.macd, value.value);
  const parts = [
    hasValue(macdLine) ? `MACD ${formatDisplayNumber(macdLine)}` : "",
    hasValue(value.signal) ? `Signal ${formatDisplayNumber(value.signal)}` : "",
    hasValue(value.histogram) ? `Hist ${formatDisplayNumber(value.histogram)}` : "",
    indicatorValue(value.crossover),
    goldenCrossText(value.golden_cross),
  ].filter(Boolean);
  return parts.join(" · ");
}

function atrValue(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return value;
  }
  return [
    indicatorDisplayNumber(value.value),
    indicatorDisplayNumber(value.percent_of_price),
  ].filter((part) => hasValue(part)).join(" · ");
}

function supportResistanceValue(timeframe, kind) {
  const payload = timeframe.support_resistance && typeof timeframe.support_resistance === "object"
    ? timeframe.support_resistance
    : {};
  const schemaValue = kind === "support"
    ? payload.support_levels
    : payload.resistance_levels;
  const legacyValue = kind === "support" ? timeframe.support : timeframe.resistance;
  return listValue(firstPresent(schemaValue, legacyValue));
}

function listValue(value) {
  if (Array.isArray(value)) {
    return value
      .map((item) => indicatorDisplayNumber(item))
      .filter((item) => hasValue(item))
      .join(" · ");
  }
  return indicatorDisplayNumber(value);
}

function goldenCrossText(value) {
  if (value === true) {
    return "金叉";
  }
  if (value === false) {
    return "未金叉";
  }
  return indicatorValue(value);
}

function movingAverageValue(timeframe) {
  const averages = timeframe.moving_averages || timeframe.ma || timeframe.averages;
  if (averages && typeof averages === "object" && !Array.isArray(averages)) {
    const parts = Object.entries(averages)
      .filter(([, value]) => hasValue(value))
      .map(([key, value]) => `${key.toUpperCase()} ${formatDisplayNumber(value)}`);
    if (parts.length) {
      return parts.join(" · ");
    }
  }
  const parts = [
    hasValue(timeframe.ma20) ? `MA20 ${formatDisplayNumber(timeframe.ma20)}` : "",
    hasValue(timeframe.ma50) ? `MA50 ${formatDisplayNumber(timeframe.ma50)}` : "",
    hasValue(timeframe.ma200) ? `MA200 ${formatDisplayNumber(timeframe.ma200)}` : "",
  ].filter(Boolean);
  return parts.join(" · ");
}

function renderLLMDecisionTemplate(holding) {
  const action = currentDecisionAction(holding);
  const actionRows = operationRows(holding);
  const price = firstSafePrimaryValue(action.limit_price, action.last_price, holding.last_price);
  const quantity = firstSafePrimaryValue(action.suggested_quantity, action.target_quantity, action.quantity);
  const stopValue = firstSafePrimaryValue(action.stop_price, holding.strategy && holding.strategy.stop_loss);
  const templateRows = [
    ["最终动作", desiredActionText(holding)],
    ["执行方式", "人工确认后执行；不自动下单。"],
    ["执行时机", price ? `当前价格仍满足策略价位 ${price} 时。` : "价格信息确认后再执行。"],
    ["执行前检查", `确认实时持仓仍为 ${formatPlain(holding.total_quantity || "-")}，行情正常，订单数量 ${quantity || "需人工确认"}。`],
    ["不执行条件", stopValue ? `行情缺失、持仓不一致、价格跌破 ${stopValue}、出现重大新公告。` : "行情缺失、持仓不一致、价格跌破保护价、出现重大新公告。"],
    ["复评安排", nextReviewText(holding)],
  ];
  return `
    <section class="detail-section trading-decision-section llm-decision-template">
      <div class="trading-decision-section-header">
        <div>
          <h3>大模型决策模板</h3>
          <p>基于已接入的 TradingAgents 交易决策生成，作为执行前复核模板。</p>
        </div>
        <span class="status-pill status-partial">人工确认</span>
      </div>
      <div class="llm-template-summary">
        <strong>${escapeHtml(finalConclusionText(holding))}</strong>
        <span>${escapeHtml(finalReasonText(holding))}</span>
      </div>
      <div class="llm-template-grid">
        ${templateRows.map(([label, value]) => renderLLMTemplateField(label, value)).join("")}
      </div>
      <div class="llm-template-actions">
        <dl class="compact-kv">
          ${actionRows.map(([label, value]) => renderCompactKv(label, value)).join("")}
        </dl>
      </div>
      <p class="condition-box strong-condition">${escapeHtml(finalConditionText(holding))}</p>
    </section>
  `;
}

function renderLLMTemplateField(label, value) {
  return `
    <article class="llm-template-field">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(formatPlain(value))}</strong>
    </article>
  `;
}

function renderLanguageToggle() {
  return `
    <div class="language-toggle" role="group" aria-label="详情语言">
      ${Object.entries(DETAIL_LANGUAGE_LABELS).map(([value, label]) => `
        <button
          class="${state.detailLanguage === value ? "active" : ""}"
          type="button"
          data-detail-language="${value}"
        >${escapeHtml(label)}</button>
      `).join("")}
    </div>
  `;
}

function renderMetric(label, value) {
  return `
    <article class="detail-metric">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(formatPlain(value))}</strong>
    </article>
  `;
}

function renderAgentReportSection(report, holding) {
  if (!sectionAvailable(report)) {
    return renderDetailSection("TradingAgents 报告", renderStatusMessage("暂无 TradingAgents 报告", report));
  }
  const reportText = firstValue(report, ["summary", "report", "analysis", "content", "markdown"]);
  const rawText = firstValue(report, ["raw_report", "raw_decision", "raw", "full_report"]);
  if (state.detailLanguage !== "en") {
    const translatedText = firstValue(report, ["summary_zh", "report_zh", "analysis_zh", "content_zh", "markdown_zh"]);
    const body = `
      ${renderChineseAgentSummary(report, holding)}
      ${hasValue(translatedText) ? `<div class="report-text translated-report">${escapeHtml(translatedText)}</div>` : renderStatusMessage("暂无中文译文，请先运行 translate-agent-reports", report)}
      ${renderEnglishSourceBlock(reportText, rawText, "查看英文原文")}
    `;
    return renderDetailSection("TradingAgents 报告", body);
  }
  const usedFallback = report.fallback_used || report.used_fallback || report.source_status === "fallback";
  const terms = [
    renderTerm("观点", report.rating || report.advice_action),
    renderTerm("状态", report.status),
    renderTerm("生成时间", report.generated_at || report.run_date),
    renderTerm("来源", report.source),
    renderTerm("来源状态", report.source_status),
    renderTerm("回退", usedFallback ? "使用历史报告回退" : ""),
    renderTerm("回退原因", report.fallback_reason),
    renderTerm("回退日期", report.fallback_from_date),
  ].filter(Boolean).join("");
  const rawReport = hasValue(rawText)
    ? `<button class="raw-toggle" type="button" data-toggle-raw-report>查看原始报告</button><pre class="raw-report hidden">${escapeHtml(rawText)}</pre>`
    : "";
  const body = `
    ${terms ? `<dl class="detail-dl">${terms}</dl>` : ""}
    ${renderStatusWarning(report)}
    ${hasValue(reportText) ? `<div class="report-text">${escapeHtml(reportText)}</div>` : renderStatusMessage("暂无 TradingAgents 报告", report)}
    ${rawReport}
  `;
  return renderDetailSection("TradingAgents 报告", body);
}

function renderChineseAgentSummary(report, holding) {
  const strategy = holding.strategy || {};
  const action = holding.trade_action || holding.premarket_action || {};
  const reason = safeChineseReason(action, strategy, report);
  const terms = [
    renderRequiredTerm("观点", firstMappedActionLabel(report.rating, report.advice_action)),
    renderRequiredTerm("报告状态", mappedActionStatusLabel(report.status)),
    renderRequiredTerm("生成时间", report.generated_at || report.run_date),
    renderChineseTerm("交易动作", firstMappedActionLabel(action.action, action.suggested_action)),
    renderChineseTerm("动作状态", mappedActionStatusLabel(action.status)),
    renderChineseTerm("触发状态", decisionTriggerText(action)),
    renderChineseTerm("核心理由", reason),
    renderChineseTerm("目标价", safeRangeText(strategy.target_1, strategy.target_2) || safePrimaryValue(strategy.target_range)),
    renderChineseTerm("止损价", firstSafePrimaryValue(strategy.stop_loss, action.stop_price)),
  ].filter(Boolean).join("");
  return terms ? `<dl class="detail-dl translated-summary">${terms}</dl>` : "";
}

function renderStrategySection(strategy, holding) {
  if (!sectionAvailable(strategy)) {
    return renderDetailSection("交易策略", renderStatusMessage("暂无交易策略", strategy));
  }
  if (state.detailLanguage !== "en") {
    const englishText = firstValue(strategy, ["plan_text", "rationale", "agent_excerpt"]);
    return renderDetailSection(
      "交易策略",
      `${renderStatusWarning(strategy)}${renderChineseStrategyTerms(strategy, holding)}${renderEnglishSourceBlock(englishText, "", "查看英文原文")}`,
    );
  }
  const terms = [
    renderRequiredTerm("观点", strategy.view || strategy.stance || strategy.signal || strategy.rating),
    renderRequiredTerm("买入区间", joinRange(strategy.entry_min, strategy.entry_max) || joinRange(strategy.entry_zone_low, strategy.entry_zone_high) || strategy.entry_range),
    renderRequiredTerm("加仓价", strategy.add_price),
    renderRequiredTerm("止损价", strategy.stop_loss),
    renderRequiredTerm("目标价", joinRange(strategy.target_1, strategy.target_2) || strategy.target_range),
    renderRequiredTerm("仓位上限", strategy.target_weight || strategy.target_position || strategy.max_weight),
    renderRequiredTerm("催化因素", strategy.catalyst),
    renderRequiredTerm("时间周期", strategy.time_horizon),
    renderTerm("风险", strategy.risk_level || strategy.risk),
    renderRequiredTerm("计划", strategy.plan_text),
    renderTerm("说明", strategy.rationale || strategy.agent_reason || strategy.agent_excerpt || strategy.notes),
  ].filter(Boolean).join("");
  return renderDetailSection("交易策略", `${renderStatusWarning(strategy)}${terms ? `<dl class="detail-dl">${terms}</dl>` : renderStatusMessage("暂无交易策略", strategy)}`);
}

function renderChineseStrategyTerms(strategy, holding) {
  const action = holding.trade_action || {};
  const terms = [
    renderRequiredTerm("观点", firstMappedActionLabel(strategy.view, strategy.stance, strategy.signal, strategy.rating)),
    renderChineseTerm("买入区间", safeRangeText(strategy.entry_min, strategy.entry_max) || safeRangeText(strategy.entry_zone_low, strategy.entry_zone_high) || safePrimaryValue(strategy.entry_range)),
    renderChineseTerm("加仓价", safePrimaryValue(strategy.add_price)),
    renderChineseTerm("止损价", firstSafePrimaryValue(strategy.stop_loss, action.stop_price)),
    renderChineseTerm("目标价", safeRangeText(strategy.target_1, strategy.target_2) || safePrimaryValue(strategy.target_range)),
    renderChineseTerm("仓位上限", firstSafePrimaryValue(strategy.target_weight, strategy.target_position, strategy.max_weight)),
    renderSafeChineseTerm("时间周期", strategy.time_horizon_zh, strategy.time_horizon),
    renderSafeChineseTerm("催化因素", strategy.catalyst_zh, strategy.catalyst),
    renderSafeChineseTerm("风险", strategy.risk_level_zh, strategy.risk_zh, strategy.risk_level, strategy.risk),
    renderChineseTerm("当前动作", firstMappedActionLabel(action.action, action.suggested_action)),
    renderChineseTerm("触发状态", decisionTriggerText(action)),
    renderSafeChineseTerm("说明", action.agent_reason_zh, strategy.agent_reason_zh, strategy.notes_zh, action.agent_reason, strategy.agent_reason, strategy.notes),
  ].filter(Boolean).join("");
  if (!terms) {
    return renderStatusMessage("暂无交易策略", strategy);
  }
  return `<dl class="detail-dl translated-summary">${terms}</dl>`;
}

function renderEnglishSourceBlock(text, rawText, buttonText) {
  const sourceText = firstAvailableText(rawText, text);
  if (!hasValue(sourceText)) {
    return "";
  }
  return `
    <button class="raw-toggle english-source-toggle" type="button" data-toggle-raw-report>${escapeHtml(buttonText)}</button>
    ${renderSplitSourceRows(sourceText)}
  `;
}

function renderTradeActionSection(detailHolding) {
  const premarketAction = detailHolding.premarket_action || {};
  const tradeAction = detailHolding.trade_action || {};
  if (!sectionAvailable(tradeAction) && !sectionAvailable(premarketAction)) {
    return renderDetailSection("当前交易动作", renderStatusMessage("暂无触发中的交易动作", tradeAction));
  }
  const action = sectionAvailable(tradeAction) ? tradeAction : premarketAction;
  const body = `
    ${renderStatusWarning(action)}
    ${renderTradeDecisionBand(action, detailHolding)}
    ${renderTradeImpactGrid(action, detailHolding)}
    ${typeof renderRationaleDialogue === "function" ? renderRationaleDialogue(detailHolding) : ""}
  `;
  return renderDetailSection("当前交易动作", body);
}

function renderAnalysisStrategySection(holding) {
  const body = `
    ${renderReportStatusLine(holding)}
    <div class="decision-dashboard">
      <article class="decision-card primary">
        <span>当前希望你做什么</span>
        <strong>${escapeHtml(desiredActionText(holding))}</strong>
        <p>${escapeHtml(decisionSubline(holding))}</p>
      </article>
      <article class="decision-card">
        <span>操作指令</span>
        <dl class="operation-list">
          ${operationRows(holding).map(([label, value]) => renderCompactKv(label, value)).join("")}
        </dl>
      </article>
      <article class="decision-card">
        <span>今天重点关注</span>
        <p>${escapeHtml(watchPointText(holding))}</p>
      </article>
    </div>
    <div class="decision-metric-strip" aria-label="分析指标">
      ${decisionMetricCells(holding).map(([label, value]) => `
        <article>
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(formatPlain(value))}</strong>
        </article>
      `).join("")}
    </div>
    ${renderAnalystDialogue(holding)}
    ${renderFinalConclusion(holding)}
    ${renderSourceReview(holding)}
  `;
  return renderDetailSection("分析与交易策略", body, "analysis-strategy-section");
}

function renderReportStatusLine(holding) {
  const report = holding.agent_report || {};
  const action = currentDecisionAction(holding);
  const usedFallback = report.fallback_used || report.used_fallback || report.source_status === "fallback";
  const parts = [
    analystViewText(holding),
    mappedActionStatusLabel(report.status),
    usedFallback ? "使用历史报告回退" : "",
    mappedActionStatusLabel(action.status),
    report.generated_at || report.run_date,
    "只读 · 需要人工确认",
  ].filter((part) => hasValue(part) && part !== "-");
  const fallbackWarning = renderStatusWarning(report) || renderStatusWarning(action);
  return `
    <div class="report-status-line">
      <span>${escapeHtml(parts.join(" · ") || "只读 · 需要人工确认")}</span>
      ${fallbackWarning}
    </div>
  `;
}

function renderAnalystDialogue(holding) {
  const rows = rationaleRows(rationaleSource(holding))
    .map((row) => ({
      label: row.label,
      text: chineseDisplayText(row.text),
    }))
    .filter((row) => hasValue(row.text) && row.text !== "-" && safePrimaryValue(row.text));
  if (!rows.length) {
    return `
      <section class="analyst-dialogue">
        <h4>分析师对话</h4>
        <p class="compact-empty">暂无可展示的中文分析对话。</p>
      </section>
    `;
  }
  return `
    <section class="analyst-dialogue">
      <h4>分析师对话</h4>
      <div class="dialogue-list">
        ${rows.map((row) => `
          <div class="dialogue-row">
            <strong>${escapeHtml(row.label)}</strong>
            <span>${escapeHtml(row.text)}</span>
          </div>
        `).join("")}
      </div>
    </section>
  `;
}

function renderFinalConclusion(holding) {
  return renderResearchConclusions(holding);
}

function renderResearchConclusions(holding) {
  const researchView = holding.research_view || {};
  const original = researchConclusionWithFallback(
    researchView.tradingagents_conclusion,
    holding,
  );
  const userConclusion = researchConclusion(researchView.user_llm_conclusion);
  const detailKey = holdingKey(holding);
  return `
    <section class="final-conclusion research-conclusion-section">
      <div class="research-conclusion-header">
        <h4>最终结论</h4>
        <span>展示两个来源：投研原始结论，以及你和 LLM 讨论后的最终结论。</span>
      </div>
      <div class="research-conclusion-grid">
        ${renderResearchConclusionCard({
          title: "投研给出的结论",
          conclusion: original,
          actionHtml: renderSourceReviewButton(holding),
          missingText: "缺失",
        })}
        ${renderResearchConclusionCard({
          title: "我和 LLM 探讨后的结论",
          conclusion: userConclusion,
          actionHtml: `<button class="raw-toggle" type="button" data-research-chat="${escapeHtml(detailKey)}">${userConclusion.present ? "继续讨论" : "开始讨论"}</button>`,
          missingText: "缺失",
        })}
      </div>
    </section>
  `;
}

function researchConclusion(value) {
  const conclusion = value && typeof value === "object" ? value : {};
  const content = meaningfulConclusionText(conclusion.content || "");
  return {
    present: conclusion.status === "present" && hasValue(content),
    content,
    reason: formatPlain(conclusion.reason || ""),
    condition: formatPlain(conclusion.condition || conclusion.conditions || ""),
    failure: formatPlain(conclusion.failure_condition || conclusion.failure || ""),
  };
}

function researchConclusionWithFallback(value, holding) {
  const conclusion = researchConclusion(value);
  if (conclusion.present) {
    return conclusion;
  }
  return legacyFinalConclusion(holding);
}

function legacyFinalConclusion(holding) {
  const fields = Object.fromEntries(
    finalConclusionItems(holding).map((item) => [item.label, formatPlain(item.text)]),
  );
  const content = meaningfulConclusionText(fields["结论"]);
  return {
    present: hasValue(content),
    content,
    reason: meaningfulConclusionText(fields["理由"]),
    condition: meaningfulConclusionText(fields["条件"]),
    failure: meaningfulConclusionText(fields["失败条件"]),
  };
}

function meaningfulConclusionText(value) {
  const text = formatPlain(value);
  if (!hasValue(text) || text === "-" || text === "暂无明确结论。") {
    return "";
  }
  return text;
}

function renderResearchConclusionCard({ title, conclusion, actionHtml, missingText }) {
  const statusText = conclusion.present ? "已生成" : "缺失";
  const body = conclusion.present
    ? `
      <div class="research-conclusion-body">
        <strong>${escapeHtml(conclusion.content)}</strong>
        ${renderResearchConclusionField("理由", conclusion.reason)}
        ${renderResearchConclusionField("条件", conclusion.condition)}
        ${renderResearchConclusionField("失败条件", conclusion.failure)}
      </div>
    `
    : `
      <div class="research-conclusion-body missing">
        <strong>${escapeHtml(missingText)}</strong>
        <p>打开聊天窗口后，系统会自动加载投研结论、原始资料、你的仓位与关注点。只有点击“生成最终结论”后才写入这里。</p>
      </div>
    `;
  return `
    <article class="research-conclusion-card">
      <div class="research-conclusion-card-header">
        <h5>${escapeHtml(title)}</h5>
        <span class="status-pill ${conclusion.present ? "status-ok" : "status-muted"}">${escapeHtml(statusText)}</span>
      </div>
      ${body}
      <div class="research-conclusion-actions">${actionHtml}</div>
    </article>
  `;
}

function renderResearchConclusionField(label, value) {
  if (!hasValue(value) || value === "-") {
    return "";
  }
  return `
    <div class="research-conclusion-field">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
    </div>
  `;
}

function renderSourceReviewButton(holding) {
  return hasValue(sourceReviewText(holding))
    ? `<button class="raw-toggle english-source-toggle" type="button" data-toggle-raw-report>查看英文原文</button>`
    : "";
}

function renderSourceReview(holding) {
  const sourceText = sourceReviewText(holding);
  if (!hasValue(sourceText)) {
    return "";
  }
  return `
    <section class="source-review">
      ${renderSplitSourceRows(sourceText)}
    </section>
  `;
}

async function openResearchChat(detailKey) {
  const holding = holdingByKey(detailKey);
  if (!holding) {
    return;
  }
  const researchView = holding.research_view || {};
  const previousKey = state.researchChat.holdingKey;
  state.researchChat.holdingKey = detailKey;
  if (previousKey !== detailKey) {
    state.researchChat.sessionId = "";
  }
  elements["research-chat-title"].textContent = `LLM 深度讨论 · ${holding.market}.${holding.symbol}`;
  elements["research-chat-context-note"].textContent = `上下文已自动加载 · ${researchView.research_date || "-"}`;
  renderResearchChatContext(holding);
  renderResearchChatMessages([]);
  openResearchChatLayer();
  if (!researchView.available) {
    state.researchChat.sessionId = "";
    elements["research-chat-context-note"].textContent = "暂无投研上下文";
    elements["research-chat-messages"].innerHTML = `<p class="compact-empty">暂无投研上下文，无法开始讨论。</p>`;
    setResearchChatBusy(false, "暂无投研上下文，无法开始讨论");
    return;
  }
  await createResearchChatSession(holding);
}

function openResearchChatLayer() {
  elements["research-chat-layer"].hidden = false;
  elements["research-chat-layer"].classList.remove("hidden");
  elements["research-chat-input"].focus();
}

function closeResearchChat() {
  elements["research-chat-layer"].hidden = true;
  elements["research-chat-layer"].classList.add("hidden");
}

function renderResearchChatContext(holding) {
  const researchView = holding.research_view || {};
  const original = researchConclusion(researchView.tradingagents_conclusion);
  elements["research-chat-context-list"].innerHTML = `
    <div><dt>投研结论</dt><dd>${escapeHtml(original.content || "缺失")}</dd></div>
    <div><dt>用户上下文</dt><dd>组合权重 ${escapeHtml(formatPlain(holding.portfolio_weight_hkd || "-"))}；风险标记 ${escapeHtml(formatPlain(holding.risk_flag || "-"))}</dd></div>
    <div><dt>输出目标</dt><dd>生成 user_llm_conclusion.json 后刷新看板。</dd></div>
  `;
}

async function createResearchChatSession(holding) {
  const requestKey = state.researchChat.holdingKey || holdingKey(holding);
  setResearchChatBusy(true, "正在加载上下文...");
  try {
    const session = await postDashboardJson("/api/research-chat/sessions", {
      market: holding.market,
      symbol: holding.symbol,
    });
    if (state.researchChat.holdingKey !== requestKey) {
      return;
    }
    state.researchChat.sessionId = session.session_id || "";
    renderResearchChatMessages(session.messages || []);
    setResearchChatStatus("上下文已自动加载。");
  } catch (error) {
    if (state.researchChat.holdingKey === requestKey) {
      setResearchChatStatus(error.message || String(error));
    }
  } finally {
    if (state.researchChat.holdingKey === requestKey) {
      setResearchChatBusy(false);
    }
  }
}

async function sendResearchChatMessage() {
  const content = elements["research-chat-input"].value.trim();
  if (!content || !state.researchChat.sessionId || state.researchChat.busy) {
    return;
  }
  const optimisticMessages = [
    ...state.researchChat.messages,
    { role: "user", content, localOnly: true },
    { role: "assistant", content: "LLM 正在处理...", pending: true },
  ];
  elements["research-chat-input"].value = "";
  renderResearchChatMessages(optimisticMessages);
  setResearchChatBusy(true, "LLM 正在处理...");
  try {
    const session = await postDashboardJson(
      `/api/research-chat/sessions/${encodeURIComponent(state.researchChat.sessionId)}/messages`,
      { content },
    );
    renderResearchChatMessages(session.messages || []);
    setResearchChatStatus("对话已保存。");
  } catch (error) {
    renderResearchChatMessages([
      ...state.researchChat.messages.filter((message) => !message.pending),
      {
        role: "assistant",
        content: `发送失败：${error.message || String(error)}`,
        localOnly: true,
      },
    ]);
    setResearchChatStatus(error.message || String(error));
  } finally {
    setResearchChatBusy(false);
  }
}

async function finalizeResearchChat() {
  if (!state.researchChat.sessionId || state.researchChat.busy) {
    return;
  }
  setResearchChatBusy(true, "正在生成最终结论...");
  try {
    await postDashboardJson(
      `/api/research-chat/sessions/${encodeURIComponent(state.researchChat.sessionId)}/finalize`,
      {},
    );
    setResearchChatStatus("最终结论已生成。");
    closeResearchChat();
    await loadDashboard();
  } catch (error) {
    setResearchChatStatus(error.message || String(error));
  } finally {
    setResearchChatBusy(false);
  }
}

function renderResearchChatMessages(messages) {
  const rows = Array.isArray(messages) ? messages : [];
  state.researchChat.messages = rows;
  elements["research-chat-messages"].innerHTML = rows.length
    ? rows.map((message) => `
      <div class="research-chat-message ${message.role === "user" ? "user" : "assistant"}${message.pending ? " pending" : ""}">
        <strong>${message.role === "user" ? "你" : "LLM"}</strong>
        <span>${escapeHtml(message.content || "")}</span>
      </div>
    `).join("")
    : `<p class="compact-empty">上下文已加载，可以开始讨论。</p>`;
  state.researchChat.messageCount = rows.filter((message) => !message.pending && !message.localOnly).length;
  elements["research-chat-finalize"].disabled = state.researchChat.messageCount < 2;
  elements["research-chat-messages"].scrollTop = elements["research-chat-messages"].scrollHeight;
}

function setResearchChatBusy(busy, statusText) {
  state.researchChat.busy = busy;
  elements["research-chat-send"].disabled = busy || !state.researchChat.sessionId;
  elements["research-chat-finalize"].disabled = busy
    || !state.researchChat.sessionId
    || state.researchChat.messageCount < 2;
  if (statusText) {
    setResearchChatStatus(statusText);
  }
}

function setResearchChatStatus(text) {
  elements["research-chat-status"].textContent = text;
}

async function postDashboardJson(url, payload) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify(payload || {}),
  });
  const data = await response.json();
  if (!response.ok || data.status === "error") {
    throw new Error(data.message || `request ${response.status}`);
  }
  return data;
}

function holdingByKey(detailKey) {
  return holdingByKeyFromRows(getHoldings(), detailKey)
    || accountHoldingGroups().flatMap((group) => group.rows)
      .find((row) => row.key === detailKey)?.holding
    || null;
}

function holdingByKeyFromRows(rows, detailKey) {
  for (let index = 0; index < rows.length; index += 1) {
    if (
      holdingKey(rows[index], index) === detailKey
      || holdingKey(rows[index]) === detailKey
    ) {
      return rows[index];
    }
  }
  return null;
}

function renderTradeDecisionBand(action, holding) {
  return `
    <div class="decision-band">
      <article class="decision-block">
        <h4>清晰交易策略</h4>
        <strong>${escapeHtml(strategyHeadline(action, holding))}</strong>
        <p>${escapeHtml(strategySubline(action, holding))}</p>
      </article>
      <article class="decision-block">
        <h4>操作方向与价位</h4>
        <dl class="compact-kv">
          ${renderCompactKv("动作", reportActionStatusLabel(action))}
          ${renderCompactKv("限价", formatDisplayNumber(firstSafePrimaryValue(action.limit_price, action.last_price)))}
          ${renderCompactKv("数量", formatDisplayNumber(firstSafePrimaryValue(action.suggested_quantity, action.target_quantity, action.quantity)))}
          ${renderCompactKv("金额", safeActionNotionalText(action))}
          ${renderCompactKv("止损", formatDisplayNumber(firstSafePrimaryValue(action.stop_price)))}
        </dl>
      </article>
      <article class="decision-block">
        <h4>简短触发理由</h4>
        <p class="decision-reason">${escapeHtml(shortActionReason(action))}</p>
      </article>
    </div>
  `;
}

function renderTradeImpactGrid(action, holding) {
  const cells = [
    ["当前数量", formatDisplayNumber(firstSafePrimaryValue(action.current_quantity, holding.total_quantity))],
    ["交易后数量", formatDisplayNumber(firstSafePrimaryValue(action.post_trade_quantity))],
    ["建议金额", safeActionNotionalText(action)],
    ["交易后权重", firstSafePrimaryValue(action.post_trade_weight)],
    ["下一触发", nextTriggerText(action, holding)],
  ];
  return `
    <div class="impact-grid" aria-label="交易影响">
      ${cells.map(([label, value]) => `
        <article class="impact-cell">
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(formatPlain(value))}</strong>
        </article>
      `).join("")}
    </div>
  `;
}

function renderRationaleDialogue(holding) {
  const rows = rationaleRows(rationaleSource(holding))
    .map((row) => ({
      label: row.label,
      text: chineseDisplayText(row.text),
    }))
    .filter((row) => {
      return hasValue(row.text) && row.text !== "-" && safePrimaryValue(row.text);
    });
  if (!rows.length) {
    return "";
  }
  return `
    <div class="rationale-dialogue">
      <h4>理由对话</h4>
      <div class="dialogue-list">
        ${rows.map((row) => `
          <div class="dialogue-row">
            <strong>${escapeHtml(row.label)}</strong>
            <span>${escapeHtml(row.text)}</span>
          </div>
        `).join("")}
      </div>
    </div>
  `;
}

function renderSplitSourceRows(text) {
  const rows = sourceRows(text);
  if (!rows.length) {
    return `<pre class="raw-report english-source hidden">${escapeHtml(text)}</pre>`;
  }
  return `
    <div class="raw-report english-source split-source hidden">
      ${rows.map((row) => `
        <div class="dialogue-row">
          <strong>${escapeHtml(row.label)}</strong>
          <span>${escapeHtml(row.text)}</span>
        </div>
      `).join("")}
    </div>
  `;
}

function sourceRows(text) {
  return splitRationaleText(text).map((sentence, index, sentences) => ({
    label: rationaleLabel(sentence, index, sentences.length),
    text: sentence,
  }));
}

function renderCompactKv(label, value) {
  return `
    <div>
      <dt>${escapeHtml(label)}</dt>
      <dd>${escapeHtml(formatPlain(value))}</dd>
    </div>
  `;
}

function strategyHeadline(action, holding) {
  const symbol = actionSymbol(action) !== "-" ? actionSymbol(action) : `${formatPlain(holding.market)}.${formatPlain(holding.symbol)}`;
  const actionText = firstMappedActionLabel(action.action, action.suggested_action);
  if (actionText === "-") {
    return `${symbol} 交易策略`;
  }
  return `${actionText} ${symbol}`;
}

function strategySubline(action, holding) {
  const strategy = holding.strategy || {};
  const view = firstMappedActionLabel(strategy.view, strategy.stance, strategy.signal, strategy.rating);
  const status = mappedActionStatusLabel(action.status);
  const parts = [view, status].filter((part) => part && part !== "-");
  if (parts.length) {
    return `${parts.join(" · ")}；执行前保持人工确认。`;
  }
  return "执行前保持人工确认。";
}

function nextTriggerText(action, holding) {
  const watchTrigger = primaryChineseText(action.watch_trigger_zh)
    || firstMappedLabel(TRIGGER_STATUS_LABELS, action.watch_trigger)
    || firstMappedLabel(REASON_LABELS, action.watch_trigger)
    || safePrimaryValue(action.watch_trigger);
  if (watchTrigger) {
    return watchTrigger;
  }
  const strategy = holding.strategy || {};
  const targetText = safeRangeText(strategy.target_1, strategy.target_2) || safePrimaryValue(strategy.target_range);
  if (hasValue(targetText)) {
    return `目标价 ${targetText}`;
  }
  const planText = primaryChineseText(strategy.plan_text_zh, strategy.rationale_zh)
    || firstSafePrimaryValue(strategy.plan_text);
  if (planText) {
    return compactSentence(planText, 48);
  }
  return "";
}

function currentDecisionAction(holding) {
  const tradeAction = holding.trade_action || {};
  if (sectionAvailable(tradeAction)) {
    return tradeAction;
  }
  const premarketAction = holding.premarket_action || {};
  if (sectionAvailable(premarketAction)) {
    return premarketAction;
  }
  return {};
}

function desiredActionText(holding) {
  const action = currentDecisionAction(holding);
  const symbol = detailSymbol(holding);
  const actionText = firstMappedActionLabel(action.action, action.suggested_action);
  if (actionText === "-") {
    return `今天暂无触发中的交易动作`;
  }
  const quantity = firstSafePrimaryValue(action.suggested_quantity, action.target_quantity, action.quantity);
  const quantityText = quantity ? `，数量 ${quantity}` : "";
  return `${actionText} ${symbol}${quantityText}`;
}

function detailSymbol(holding) {
  const market = formatPlain(holding.market);
  const symbol = formatPlain(holding.symbol);
  if (market === "-" && symbol === "-") {
    return "-";
  }
  if (market === "-") {
    return symbol;
  }
  if (symbol === "-") {
    return market;
  }
  return `${market}.${symbol}`;
}

function decisionTriggerText(action) {
  const mappedTrigger = firstMappedLabel(TRIGGER_STATUS_LABELS, action.trigger_status, action.watch_trigger);
  if (mappedTrigger) {
    return mappedTrigger;
  }
  const direct = primaryChineseText(action.trigger_status_zh, action.watch_trigger_zh);
  if (direct) {
    return direct;
  }
  return safePrimaryValue(action.watch_trigger) || "-";
}

function primaryChineseText(...values) {
  for (const value of values) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    if (text && /[\u3400-\u9fff]/.test(text) && !hasRawEnglishProse(text)) {
      return text;
    }
  }
  return "";
}

function safePrimaryValue(value) {
  const text = formatPlain(value);
  if (text === "-") {
    return "";
  }
  if (/[\u3400-\u9fff]/.test(text)) {
    return hasRawEnglishProse(text) ? "" : text;
  }
  const englishWords = text.match(/\b[A-Za-z][A-Za-z'-]*\b/g) || [];
  if (!englishWords.length) {
    return text;
  }
  const allowedTokens = new Set(["HKD", "USD", "ETF", "ETFS", "MACD", "RSI", "YOY", "QOQ", "OPENAI", "IPHONE"]);
  const hasUnsafeEnglish = englishWords.some((word) => !allowedTokens.has(word.toUpperCase()));
  if (hasUnsafeEnglish) {
    return "";
  }
  return text;
}

function firstSafePrimaryValue(...values) {
  for (const value of values) {
    const safe = safePrimaryValue(value);
    if (safe) {
      return safe;
    }
  }
  return "";
}

function safeRangeText(low, high) {
  const safeLow = safePrimaryValue(low);
  const safeHigh = safePrimaryValue(high);
  return joinRange(safeLow, safeHigh);
}

function mappedActionLabel(value) {
  const mapped = firstMappedLabel(ACTION_LABELS, value);
  if (mapped) {
    return mapped;
  }
  const safe = safePrimaryValue(value);
  return safe || "-";
}

function firstMappedActionLabel(...values) {
  for (const value of values) {
    const label = mappedActionLabel(value);
    if (label !== "-") {
      return label;
    }
  }
  return "-";
}

function mappedActionStatusLabel(value) {
  const mapped = firstMappedLabel(ACTION_STATUS_LABELS, value);
  return mapped || "-";
}

function reportActionStatusLabel(action) {
  const actionText = firstMappedActionLabel(action.action, action.suggested_action);
  const statusText = mappedActionStatusLabel(action.status);
  if (actionText === "-" && statusText === "-") {
    return "-";
  }
  if (actionText === "-") {
    return statusText;
  }
  if (statusText === "-") {
    return actionText;
  }
  return `${actionText} · ${statusText}`;
}

function decisionSubline(holding) {
  const action = currentDecisionAction(holding);
  if (!sectionAvailable(action)) {
    const view = analystViewText(holding);
    return view === "-" ? "暂无触发动作，继续观察。" : `${view}，暂无触发动作，继续观察。`;
  }
  const trigger = decisionTriggerText(action);
  const reason = shortActionReason(action);
  const parts = [trigger, reason].filter((part) => part && part !== "-");
  if (!parts.length) {
    return "执行前保持人工确认。";
  }
  return `${parts.join("；")} 执行前保持人工确认。`;
}

function operationRows(holding) {
  const action = currentDecisionAction(holding);
  const strategy = holding.strategy || {};
  return [
    ["动作", reportActionStatusLabel(action)],
    ["价格", firstSafePrimaryValue(action.limit_price, action.last_price, strategy.target_1, strategy.target_range)],
    ["仓位", firstSafePrimaryValue(action.suggested_quantity, action.suggested_notional, strategy.max_weight, strategy.target_weight)],
    ["止损", firstSafePrimaryValue(action.stop_price, strategy.stop_loss)],
  ];
}

function watchPointText(holding) {
  const action = currentDecisionAction(holding);
  const strategy = holding.strategy || {};
  const direct = primaryChineseText(
    action.trigger_reason_zh,
    action.watch_trigger_zh,
    strategy.catalyst_zh,
    strategy.plan_text_zh,
    strategy.rationale_zh,
  );
  if (direct) {
    return compactSentence(direct, 92);
  }
  const mappedTrigger = firstMappedLabel(TRIGGER_STATUS_LABELS, action.trigger_status, action.watch_trigger);
  if (mappedTrigger && mappedTrigger !== "未触发") {
    const reviewText = nextReviewText(holding);
    const reviewSuffix = reviewText && reviewText !== "-"
      ? `继续观察 ${reviewText}。`
      : "执行前保持人工确认。";
    return compactSentence(`${mappedTrigger}；${reviewSuffix}`, 92);
  }
  const catalyst = firstSafePrimaryValue(strategy.catalyst, strategy.time_horizon, strategy.plan_text);
  if (catalyst) {
    return compactSentence(catalyst, 92);
  }
  return "暂无新的触发条件，继续观察。";
}

function decisionMetricCells(holding) {
  const action = currentDecisionAction(holding);
  const strategy = holding.strategy || {};
  const target = safeRangeText(
    formatDisplayNumber(strategy.target_1),
    formatDisplayNumber(strategy.target_2),
  ) || formatDecisionTarget(strategy.target_range);
  return [
    ["观点", analystViewText(holding)],
    ["目标价", target],
    ["触发状态", decisionTriggerText(action)],
    ["动作状态", mappedActionStatusLabel(action.status)],
    ["下次复评", nextReviewText(holding)],
  ];
}

function analystViewText(holding) {
  const strategy = holding.strategy || {};
  const report = holding.agent_report || {};
  return firstMappedActionLabel(strategy.view, strategy.stance, strategy.signal, strategy.rating, report.rating, report.advice_action);
}

function nextReviewText(holding) {
  const strategy = holding.strategy || {};
  const action = currentDecisionAction(holding);
  const direct = primaryChineseText(strategy.catalyst_zh, strategy.time_horizon_zh, action.watch_trigger_zh);
  if (direct) {
    return compactSentence(direct, 32);
  }
  const text = firstSafePrimaryValue(strategy.catalyst, strategy.time_horizon, action.watch_trigger);
  return text ? compactSentence(text, 32) : "-";
}

function finalConclusionItems(holding) {
  const action = currentDecisionAction(holding);
  const strategy = holding.strategy || {};
  const stopValue = firstSafePrimaryValue(action.stop_price, strategy.stop_loss);
  return [
    ["结论", finalConclusionText(holding)],
    ["理由", finalReasonText(holding)],
    ["条件", finalConditionText(holding)],
    ["失败条件", stopValue ? `跌破 ${stopValue} 后进入防守复核。` : "触发风险条件后进入人工复核。"],
  ].map(([label, text]) => ({ label, text: formatPlain(text) }));
}

function finalConclusionText(holding) {
  const action = currentDecisionAction(holding);
  const view = analystViewText(holding);
  const actionText = firstMappedActionLabel(action.action, action.suggested_action);
  if (actionText === "-" && view === "-") {
    return "暂无明确结论。";
  }
  if (actionText === "-") {
    return `${view}，但今天暂无触发动作。`;
  }
  if (view === "-") {
    return `${actionText}，执行前保持人工确认。`;
  }
  return `${view}，当前动作是${actionText}。`;
}

function finalReasonText(holding) {
  const action = currentDecisionAction(holding);
  const reason = primaryChineseText(
    action.trigger_reason_zh,
    action.reason_zh,
    action.agent_reason_zh,
    holding.strategy && holding.strategy.agent_reason_zh,
    holding.agent_report && holding.agent_report.summary_zh,
  );
  if (reason) {
    return compactSentence(reason, 82);
  }
  const mapped = firstMappedLabel(REASON_LABELS, action.trigger_reason, action.reason);
  return mapped || "理由见分析师对话。";
}

function finalConditionText(holding) {
  const strategy = holding.strategy || {};
  const action = currentDecisionAction(holding);
  const text = primaryChineseText(strategy.plan_text_zh, strategy.catalyst_zh, action.watch_trigger_zh);
  if (text) {
    return compactSentence(text, 82);
  }
  const trigger = firstMappedLabel(TRIGGER_STATUS_LABELS, action.watch_trigger, action.trigger_status);
  return trigger ? `${trigger} 后复核。` : "出现新的价格或事件触发后复核。";
}

function sourceReviewText(holding) {
  const report = holding.agent_report || {};
  const strategy = holding.strategy || {};
  const action = currentDecisionAction(holding);
  return uniqueSourceText(
    report.raw_decision,
    report.raw_report,
    report.full_report,
    report.summary,
    strategy.agent_excerpt,
    strategy.plan_text,
    strategy.rationale,
    strategy.agent_reason,
    strategy.notes,
    action.agent_excerpt,
    action.agent_reason,
    action.reason,
    action.trigger_reason,
    action.watch_trigger,
  );
}

function uniqueSourceText(...values) {
  const seen = new Set();
  const parts = [];
  for (const value of values) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    if (!text || seen.has(text)) {
      continue;
    }
    seen.add(text);
    parts.push(text);
  }
  return parts.join("\n");
}

function suggestedNotionalText(action) {
  if (hasValue(action.suggested_notional)) {
    const currency = formatPlain(action.notional_currency);
    return currency === "-" ? action.suggested_notional : `${action.suggested_notional} ${currency}`;
  }
  if (hasValue(action.order_value_hkd)) {
    return formatMoney(action.order_value_hkd, "HKD");
  }
  return "";
}

function renderBrokerDetailSection(details) {
  if (!Array.isArray(details) || details.length === 0) {
    return renderDetailSection("券商账户明细", renderStatusMessage("暂无券商账户明细"), "broker-detail-section");
  }
  const rows = details.map((detail) => {
    const pnlTone = pnlClass(detail.unrealized_pnl);
    return `
      <tr>
        <td>${escapeHtml(formatPlain(detail.broker))}</td>
        <td>${escapeHtml(formatPlain(detail.account_alias))}</td>
        <td class="number-cell">${escapeHtml(formatDisplayNumber(detail.quantity))}</td>
        <td class="number-cell">${escapeHtml(formatDisplayNumber(detail.cost_price))}</td>
        <td class="number-cell">${escapeHtml(formatDisplayNumber(detail.last_price))}</td>
        <td class="number-cell">${escapeHtml(formatDisplayNumber(detail.market_value))}</td>
        <td class="number-cell${pnlTone ? ` ${pnlTone}` : ""}">${escapeHtml(formatSignedPnl(detail.unrealized_pnl))}</td>
      </tr>
    `;
  }).join("");
  return renderDetailSection("券商账户明细", `
    <div class="compact-detail-table">
      <table>
        <thead>
          <tr>
            <th>券商</th>
            <th>账户</th>
            <th>数量</th>
            <th>成本价</th>
            <th>持仓价</th>
            <th>市值</th>
            <th>盈亏</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  `, "broker-detail-section");
}

function renderDetailSection(title, body, extraClass = "") {
  const classes = ["detail-section", extraClass].filter(Boolean).join(" ");
  return `
    <section class="${escapeHtml(classes)}">
      <h3>${escapeHtml(title)}</h3>
      ${body}
    </section>
  `;
}

function renderStatusMessage(emptyText, section) {
  const error = section && hasValue(section.error)
    ? `<span class="detail-warning">${escapeHtml(section.error)}</span>`
    : "";
  return `<p class="compact-empty">${escapeHtml(emptyText)}${error}</p>`;
}

function renderStatusWarning(section) {
  if (!section || typeof section !== "object") {
    return "";
  }
  if (section.status === "manual_review") {
    return `<div class="detail-warning">需要人工复核${hasValue(section.error) ? `：${escapeHtml(section.error)}` : ""}</div>`;
  }
  if (section.status === "error") {
    return `<div class="detail-warning">${escapeHtml(formatPlain(section.error || "数据读取错误"))}</div>`;
  }
  return "";
}

function renderTerm(label, value) {
  if (!hasValue(value) || value === "-") {
    return "";
  }
  return renderRequiredTerm(label, value);
}

function renderRequiredTerm(label, value) {
  return `
    <div>
      <dt>${escapeHtml(label)}</dt>
      <dd>${escapeHtml(formatPlain(value))}</dd>
    </div>
  `;
}

function renderChineseTerm(label, value) {
  const text = chineseDisplayText(value);
  if (!hasValue(text) || text === "-") {
    return "";
  }
  return renderRequiredTerm(label, text);
}

function renderSafeChineseTerm(label, ...values) {
  const text = firstSafePrimaryValue(...values);
  if (!hasValue(text) || text === "-") {
    return "";
  }
  return renderRequiredTerm(label, text);
}

function chineseDisplayText(value) {
  const raw = formatPlain(value);
  if (raw === "-") {
    return raw;
  }
  const mapped = formatActionReason(formatTriggerStatus(formatActionStatus(formatAction(raw))));
  let text = mapped
    .replace(/\bOverweight\b/gi, "超配")
    .replace(/\bUnderweight\b/gi, "低配")
    .replace(/\bNeutral\b/gi, "中性")
    .replace(/\bHold\b/gi, "持有")
    .replace(/\bReduce\b/gi, "减仓")
    .replace(/\bTrim\b/gi, "减仓")
    .replace(/\bBuy\b/gi, "买入")
    .replace(/\bSell\b/gi, "卖出")
    .replace(/\bmonths\b/gi, "个月")
    .replace(/\bmonth\b/gi, "个月")
    .replace(/\breassess\b/gi, "复评")
    .replace(/\bearnings\b/gi, "财报");
  if (hasRawEnglishProse(text)) {
    return "";
  }
  return text;
}

function safeChineseDisplayText(value) {
  const text = chineseDisplayText(value);
  return hasValue(text) && text !== "-" ? text : "";
}

function safeChineseReason(action, strategy, report) {
  return primaryChineseText(
    action.reason_zh,
    action.agent_reason_zh,
    action.trigger_reason_zh,
    action.watch_trigger_zh,
    strategy.agent_reason_zh,
    strategy.rationale_zh,
    strategy.plan_text_zh,
    report.summary_zh,
    report.analysis_zh,
    report.report_zh,
  ) || firstMappedLabel(
    REASON_LABELS,
    action.reason,
    action.agent_reason,
    action.trigger_reason,
    action.watch_trigger,
    strategy.agent_reason,
    report.agent_reason,
  ) || firstMappedLabel(TRIGGER_STATUS_LABELS, action.trigger_status);
}

function hasRawEnglishProse(text) {
  const residual = String(text || "")
    .replace(/\b(?:HKD|USD|ETF|ETFs|MACD|RSI|YoY|QoQ|OpenAI|iPhone)\b/gi, "");
  const words = residual.match(/\b[A-Za-z][A-Za-z'-]{2,}\b/g) || [];
  return words.length >= 2;
}

function dataHealthText(holding) {
  const confidence = formatPlain(holding.confidence);
  const riskFlag = formatPlain(holding.risk_flag);
  if (confidence !== "-" && riskFlag !== "-") {
    return `${confidence} · ${riskFlag}`;
  }
  if (confidence !== "-") {
    return confidence;
  }
  return riskFlag;
}

function joinRange(min, max) {
  if (hasValue(min) && hasValue(max)) {
    return `${min} - ${max}`;
  }
  if (hasValue(min)) {
    return `>= ${min}`;
  }
  if (hasValue(max)) {
    return `<= ${max}`;
  }
  return "";
}

function sectionAvailable(section) {
  if (!section || typeof section !== "object") {
    return false;
  }
  if (section.available === false) {
    return false;
  }
  return section.available === true || Object.keys(section).some((key) => key !== "available" && key !== "error" && hasValue(section[key]));
}

function firstValue(source, keys) {
  if (!source || typeof source !== "object") {
    return "";
  }
  for (const key of keys) {
    if (hasValue(source[key])) {
      return source[key];
    }
  }
  return "";
}

function firstAvailableText(...values) {
  for (const value of values) {
    if (hasValue(value)) {
      return value;
    }
  }
  return "";
}

function sortedTradeActions(actions) {
  return [...actions].sort((left, right) => {
    const statusDelta = actionStatusRank(left.status) - actionStatusRank(right.status);
    if (statusDelta !== 0) {
      return statusDelta;
    }
    const priorityDelta = priorityRank(left.priority) - priorityRank(right.priority);
    if (priorityDelta !== 0) {
      return priorityDelta;
    }
    return `${left.market || ""}.${left.symbol || ""}`.localeCompare(`${right.market || ""}.${right.symbol || ""}`);
  });
}

function actionStatusRank(status) {
  const normalized = String(status || "").trim().toLowerCase();
  if (normalized === "ready") {
    return 0;
  }
  if (normalized === "review") {
    return 1;
  }
  if (normalized === "watch") {
    return 2;
  }
  return 3;
}

function priorityRank(priority) {
  const normalized = String(priority || "").trim().toLowerCase();
  const ranks = { critical: 0, high: 1, medium: 2, low: 3 };
  return Object.prototype.hasOwnProperty.call(ranks, normalized) ? ranks[normalized] : 4;
}

function tradeActionCounts(actions) {
  const counts = { ready: 0, review: 0, watch: 0 };
  for (const action of actions) {
    const status = String(action.status || "").trim().toLowerCase();
    if (status === "ready") {
      counts.ready += 1;
    } else if (status === "review") {
      counts.review += 1;
    } else if (status === "watch") {
      counts.watch += 1;
    }
  }
  return counts;
}

function actionDetailKey(action) {
  if (!action) {
    return "";
  }
  return normalizeActionKey("", action.futu_symbol)
    || normalizeActionKey(action.market, action.symbol);
}

function holdingActionKeys(holding) {
  const keys = [
    normalizeActionKey("", holding && holding.futu_symbol),
    normalizeActionKey(holding && holding.market, holding && holding.symbol),
    actionDetailKey(holding && holding.trade_action),
    actionDetailKey(holding && holding.premarket_action),
  ].filter(Boolean);
  return Array.from(new Set(keys));
}

function normalizeActionKey(market, symbol) {
  let normalizedMarket = String(market || "").trim().toUpperCase();
  let normalizedSymbol = String(symbol || "").trim().toUpperCase();
  if (!normalizedMarket && normalizedSymbol.includes(".")) {
    const parts = normalizedSymbol.split(".");
    normalizedMarket = parts.shift() || "";
    normalizedSymbol = parts.join(".");
  }
  if (!normalizedMarket || !normalizedSymbol) {
    return "";
  }
  if (normalizedMarket === "HK" && /^\d+$/.test(normalizedSymbol)) {
    normalizedSymbol = normalizedSymbol.padStart(5, "0");
  }
  return `${normalizedMarket}.${normalizedSymbol}`;
}

function splitHistoricalTrendHoldings(items, report) {
  const membership = report?.historical_buy_plan_membership;
  if (membership?.available !== true || !Array.isArray(membership.symbols)) return null;
  const planned = new Set(membership.symbols.map((key) => normalizeActionKey("", key)).filter(Boolean));
  const trend = [];
  const nonTrend = [];
  for (const item of items) {
    const position = item?.holding || item;
    const key = normalizeActionKey("", position?.futu_symbol)
      || normalizeActionKey(position?.market || report?.market, position?.symbol);
    (key && planned.has(key) ? trend : nonTrend).push(item);
  }
  return {trend, nonTrend};
}

function actionSymbol(action) {
  const futu = formatPlain(action.futu_symbol);
  if (futu !== "-") {
    return futu;
  }
  const market = formatPlain(action.market);
  const symbol = formatPlain(action.symbol);
  if (market === "-" && symbol === "-") {
    return "-";
  }
  if (market === "-") {
    return symbol;
  }
  if (symbol === "-") {
    return market;
  }
  return `${market}.${symbol}`;
}

function actionSourceContext(action) {
  const parts = [
    formatTriggerStatus(action.trigger_status),
    formatPriority(action.priority),
  ].filter((part) => part && part !== "-");
  return parts.join(" · ") || "交易计划触发";
}

function shortActionReason(action) {
  const translatedReason = primaryChineseText(
    action.trigger_reason_zh,
    action.reason_zh,
    action.agent_reason_zh,
    action.watch_trigger_zh,
  );
  if (translatedReason) {
    return compactSentence(translatedReason, 96);
  }

  const mappedReason = firstMappedLabel(
    REASON_LABELS,
    action.trigger_reason,
    action.reason,
    action.agent_reason,
    action.rationale,
    action.watch_trigger,
  );
  if (mappedReason) {
    return compactSentence(mappedReason, 96);
  }

  const mappedTrigger = firstMappedLabel(TRIGGER_STATUS_LABELS, action.trigger_status, action.watch_trigger);
  if (mappedTrigger && mappedTrigger !== "未触发") {
    return compactSentence(`${mappedTrigger}，请查看完整策略。`, 96);
  }

  return fallbackShortActionReason(action);
}

function firstChineseText(...values) {
  for (const value of values) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    if (text && /[\u3400-\u9fff]/.test(text)) {
      return text;
    }
  }
  return "";
}

function firstMappedLabel(map, ...values) {
  for (const value of values) {
    const mapped = mappedLabel(map, value);
    if (mapped) {
      return mapped;
    }
  }
  return "";
}

function mappedLabel(map, value) {
  const raw = formatPlain(value);
  if (raw === "-") {
    return "";
  }
  return map[raw] || map[raw.toLowerCase()] || "";
}

function fallbackShortActionReason(action) {
  const status = String(action.status || "").trim().toLowerCase();
  const actionType = String(action.action || action.suggested_action || "").trim().toLowerCase();
  const trigger = String(action.trigger_status || action.watch_trigger || "").trim().toLowerCase();
  if (status === "review" || actionType === "review" || status === "error" || trigger === "missing_quote") {
    return "需要人工复核后再决定。";
  }
  if (status === "watch" || actionType === "hold" || actionType === "watch" || trigger === "watch" || trigger === "no_trigger") {
    return "暂无触发中的交易计划。";
  }
  return "交易计划已触发，请查看完整策略。";
}

function compactSentence(text, maxLength) {
  const normalized = String(text || "").replace(/\s+/g, " ").trim();
  if (!normalized) {
    return "";
  }
  if (normalized.length <= maxLength) {
    return normalized;
  }
  return `${normalized.slice(0, Math.max(0, maxLength - 1)).trim()}…`;
}

function actionNotionalText(action) {
  if (hasValue(action.suggested_notional)) {
    const currency = formatPlain(action.notional_currency);
    const notional = formatDisplayNumber(action.suggested_notional);
    return currency === "-" ? notional : `${currency} ${notional}`;
  }
  if (hasValue(action.order_value_hkd)) {
    return formatMoney(action.order_value_hkd, "HKD");
  }
  return "-";
}

function safeActionNotionalText(action) {
  const notional = safePrimaryValue(action.suggested_notional);
  if (notional) {
    const currency = safePrimaryValue(action.notional_currency);
    const formattedNotional = formatDisplayNumber(notional);
    return currency ? `${currency} ${formattedNotional}` : formattedNotional;
  }
  const orderValueHkd = safePrimaryValue(action.order_value_hkd);
  if (orderValueHkd) {
    return formatMoney(orderValueHkd, "HKD");
  }
  return "";
}

function actionCardStatusLabel(action) {
  const actionText = formatAction(action.action || action.suggested_action);
  const statusText = formatActionStatus(action.status);
  if (actionText === "-" && statusText === "-") {
    return "-";
  }
  if (actionText === "-") {
    return statusText;
  }
  if (statusText === "-") {
    return actionText;
  }
  return `${actionText} · ${statusText}`;
}

function rationaleSource(holding) {
  const action = sectionAvailable(holding.trade_action) ? holding.trade_action : (holding.premarket_action || {});
  const strategy = holding.strategy || {};
  const report = holding.agent_report || {};
  return firstAvailableText(
    action.agent_reason_zh,
    action.reason_zh,
    action.trigger_reason_zh,
    action.agent_excerpt_zh,
    strategy.plan_text_zh,
    strategy.rationale_zh,
    strategy.agent_reason_zh,
    strategy.agent_excerpt_zh,
    report.summary_zh,
    report.report_zh,
    report.analysis_zh,
    action.agent_reason,
    action.reason,
    action.trigger_reason,
    action.agent_excerpt,
    strategy.plan_text,
    strategy.rationale,
    strategy.agent_reason,
    strategy.agent_excerpt,
    report.summary,
    report.raw_decision,
  );
}

function rationaleRows(text) {
  const sentences = splitRationaleText(text);
  const rows = sentences.map((sentence, index) => ({
    label: rationaleLabel(sentence, index, sentences.length),
    text: sentence,
  }));
  if (rows.length === 0) {
    return [];
  }
  return rows.slice(0, 8);
}

function splitRationaleText(text) {
  const raw = String(text || "").trim();
  if (!raw) {
    return [];
  }
  const lineParts = raw
    .split(/\r?\n+/)
    .map((part) => part.trim())
    .filter(Boolean);
  const sourceParts = lineParts.length > 1 ? lineParts : splitOnSentenceEnd(raw);
  const parts = sourceParts
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part) => cleanListMarker(part))
    .filter(Boolean);
  const rows = [];
  let buffer = "";
  for (const part of parts) {
    const candidate = buffer ? `${buffer} ${part}` : part;
    if (candidate.length <= 120) {
      buffer = candidate;
    } else {
      if (buffer) {
        rows.push(buffer);
      }
      buffer = part;
    }
  }
  if (buffer) {
    rows.push(buffer);
  }
  return rows;
}

function splitOnSentenceEnd(text) {
  const parts = [];
  let buffer = "";
  for (const character of String(text || "")) {
    buffer += character;
    if ("。！？!?".includes(character)) {
      parts.push(buffer.trim());
      buffer = "";
    }
  }
  if (buffer.trim()) {
    parts.push(buffer.trim());
  }
  return parts;
}

function cleanListMarker(text) {
  return String(text || "")
    .replace(/^\s*(?:[-*•]\s+|\d{1,3}(?:[.)]\s+|、\s*))/, "")
    .trim();
}

function rationaleLabel(text, index, total) {
  const lower = String(text || "").toLowerCase();
  if (/(macd|rsi|趋势|反弹|突破|阻力|支撑|均线|technical|trend|momentum)/i.test(lower)) {
    return "趋势派";
  }
  if (/(风险|止损|回撤|衰减|升水|仓位|风控|risk|stop|drawdown|decay|contango|position)/i.test(lower)) {
    return "风控派";
  }
  if (/(宏观|政策|财报|油|利率|伊朗|地缘|事件|macro|policy|earnings|oil|rate|geopolitical)/i.test(lower)) {
    return "事件派";
  }
  if (index === total - 1 || /(结论|因此|所以|减仓|买入|卖出|持有|配置|action|trim|buy|sell|hold|allocation)/i.test(lower)) {
    return "组合结论";
  }
  return `依据${index + 1}`;
}

function renderTradeActions() {
  if (!elements["action-count"] || !elements["trade-actions"]) {
    return;
  }
  const actions = sortedTradeActions((state.dashboard && state.dashboard.trade_actions) || []);
  const counts = tradeActionCounts(actions);
  const pendingCount = counts.ready + counts.review;
  elements["action-count"].textContent = `${pendingCount} 待处理`;
  if (!actions.length) {
    elements["trade-actions"].innerHTML = `<div class="empty-state">暂无交易动作</div>`;
    return;
  }
  elements["trade-actions"].innerHTML = `
    ${renderActionQueueSummary(counts)}
    <div class="action-card-list">
      ${actions.map(renderActionCard).join("")}
    </div>
  `;
}

function renderActionQueueSummary(counts) {
  return `
    <div class="action-summary-grid" role="group" aria-label="交易动作摘要">
      <div><span>待确认</span><strong>${escapeHtml(String(counts.ready))}</strong></div>
      <div><span>复核</span><strong>${escapeHtml(String(counts.review))}</strong></div>
      <div><span>观察</span><strong>${escapeHtml(String(counts.watch))}</strong></div>
    </div>
  `;
}

function renderActionCard(action) {
  const key = actionDetailKey(action);
  const status = String(action.status || "").toLowerCase();
  const statusClass = status === "review" ? "review" : status === "ready" ? "ready" : "watch";
  return `
    <article class="action-card ${statusClass}">
      <div class="action-card-header">
        <div>
          <strong>${escapeHtml(actionSymbol(action))}</strong>
          <span>${escapeHtml(actionSourceContext(action))}</span>
        </div>
        <span class="badge">${escapeHtml(actionCardStatusLabel(action))}</span>
      </div>
      <div class="action-card-metrics">
        <div><span>限价</span><strong>${escapeHtml(formatDisplayNumber(firstPresent(action.limit_price, action.last_price)))}</strong></div>
        <div><span>数量</span><strong>${escapeHtml(formatDisplayNumber(action.suggested_quantity))}</strong></div>
        <div><span>金额</span><strong>${escapeHtml(actionNotionalText(action))}</strong></div>
      </div>
      <div class="action-card-reason">
        <span>短触发理由</span>
        <p>${escapeHtml(shortActionReason(action))}</p>
      </div>
      <button class="raw-toggle action-detail-button" type="button" data-action-detail="${escapeHtml(key)}">查看完整策略</button>
    </article>
  `;
}

function renderConnectionPanel() {
  const snapshot = state.accountSnapshot || {};
  const quoteSource = snapshot.sources?.quotes || {};
  const quoteStatus = String(quoteSource.status || "unknown").trim().toLowerCase();
  const quoteHealthy = ["healthy", "ok", "fresh"].includes(quoteStatus);
  const quoteAsOf = firstPresent(snapshot.quote_as_of, quoteSource.as_of, "-");
  const transport = state.accountError ? "账户快照请求失败" : "账户快照请求正常";
  const quoteLabel = quoteHealthy ? "行情正常" : quoteStatus === "stale" ? "行情已过期" : "行情不可用";
  setElementText(
    "connection-status",
    snapshot.status === "healthy" && !state.accountError && quoteHealthy ? "账户与行情正常" : "账户或行情不可用",
  );
  setElementText("connection-success", quoteAsOf);
  setElementText("connection-poll", `${transport} · ${quoteLabel}`);
  setElementText(
    "connection-task",
    `${accountSnapshotStatusText()} · 最近接受快照 ${formatPlain(snapshot.generated_at || "-")}`,
  );
}

function renderLoadError(error) {
  state.dashboard = null;
  state.dashboardError = error;
  renderHeaderSummary();
  renderSourceStatusListIntoHeader();
  renderKellyLab();
  renderHoldings();
}

function setElementText(id, text) {
  if (elements[id]) {
    elements[id].textContent = text;
  }
}

function renderDashboardErrorState() {
  const container = elements["account-holdings"] || elements["holdings-body"];
  setAccountHoldingsFallbackLabel("账户持仓不可用");
  container.innerHTML = '<div class="empty-state">看板数据加载失败</div>';
}

function filteredHoldings() {
  return getHoldings().filter((holding) => {
    const market = String(holding.market || "").toUpperCase();
    const brokers = rowBrokers(holding);
    const marketMatches = state.marketFilter === "ALL" || market === state.marketFilter;
    const brokerMatches = brokers.includes(state.brokerFilter);
    return marketMatches && brokerMatches;
  });
}

function renderUsdMarketValue(holding) {
  const currency = String(holding && holding.currency || "").trim().toUpperCase();
  if (currency !== "USD") {
    return "-";
  }
  return formatMoney(holding.market_value, "USD");
}

function getHoldings() {
  return (state.dashboard && Array.isArray(state.dashboard.holding_enrichment))
    ? state.dashboard.holding_enrichment
    : [];
}

function accountHoldingGroups() {
  const legacyHoldings = Array.isArray(state.dashboard?.holding_enrichment) ? state.dashboard.holding_enrichment : [];
  const groups = Object.entries(ACCOUNT_STRATEGY_PROFILES).map(([broker, profile]) => {
    const summary = brokerSummaries().find((item) => brokerKey(item) === broker) || {broker};
    const rows = (Array.isArray(state.accountSnapshot?.positions)
      ? state.accountSnapshot.positions : [])
      .filter((position) => brokerKey(position) === broker && isAccountHoldingPosition(position))
      .map((position, index) => {
        const matches = position.instrument_id
          ? legacyHoldings.filter((holding) => holding.instrument_id === position.instrument_id)
          : [];
        const enrichment = matches.length === 1 ? matches[0] : {};
        const holding = {
          ...enrichment, ...position, brokers: broker,
          enrichment_status: matches.length === 1 ? "" : "unavailable",
        };
        return {
          key: String(position.position_id || ""), broker, holding,
          display: accountPositionDisplay(position), index,
        };
      });
    return {broker, profile, summary, rows};
  });
  return groups;
}

function numericValue(value) {
  if (!hasValue(value)) {
    return null;
  }
  const raw = String(value).trim();
  const validNumber = raw.includes(",")
    ? /^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$/.test(raw)
    : /^[+-]?(?:\d+|\d*\.\d+)$/.test(raw);
  if (!validNumber) {
    return null;
  }
  const parsed = Number(raw.replace(/,/g, ""));
  return Number.isFinite(parsed) ? parsed : null;
}


function brokerSummaries() {
  return (state.accountSnapshot && Array.isArray(state.accountSnapshot.broker_summaries))
    ? state.accountSnapshot.broker_summaries
    : [];
}

function brokerSyncStatus(broker) {
  const source = state.accountSnapshot?.sources?.account?.brokers?.[broker];
  const rawStatus = String(source?.status || "unknown").trim().toLowerCase();
  const status = rawStatus === "healthy" ? "ok" : rawStatus;
  const dataAsOf = formatPlain(source?.data_as_of || source?.as_of);
  const fallback = status === "ok" ? "同步正常"
    : status === "failed" ? `同步失败${dataAsOf !== "-" ? ` · 数据截至 ${dataAsOf}` : ""}`
    : status === "stale" ? `数据已过期${dataAsOf !== "-" ? ` · 数据截至 ${dataAsOf}` : ""}`
    : "同步状态未知 · 数据未验证";
  return {
    status,
    display: formatPlain(source?.display || fallback),
    unsafe: !accountActionsEnabled() || ["failed", "stale", "unknown"].includes(status),
  };
}

function brokerSourceTime(broker, source) {
  const live = ["futu", "tiger"].includes(broker);
  const raw = String(firstPresent(
    source?.data_as_of,
    live ? source?.last_success_at : "",
  ) || "");
  if (live) {
    const match = raw.match(/(?:T|\s|^)(\d{2}:\d{2})(?::\d{2})?/);
    return match ? match[1] : "";
  }
  const match = raw.match(/\b\d{4}-(\d{2}-\d{2})\b/);
  return match ? match[1] : "";
}

function brokerSourceStatus(broker) {
  const sync = brokerSyncStatus(broker);
  const source = state.accountSnapshot?.sources?.account?.brokers?.[broker] || {};
  const live = ["futu", "tiger"].includes(broker);
  const time = brokerSourceTime(broker, source);
  const suffix = time ? ` · ${time}` : "";
  const display = sync.status === "ok"
    ? (live ? `同步正常${suffix}` : (time ? `数据截至${suffix}` : "同步正常"))
    : sync.status === "failed"
      ? `同步失败${time ? ` · ${live ? "上次 " : "数据截至 "}${time}` : ""}`
      : sync.status === "stale"
        ? `数据已过期${time ? ` · 截至 ${time}` : ""}`
        : "同步状态未知 · 数据未验证";
  return {...sync, display};
}

function renderBrokerCards() {
  elements["broker-summary-cards"].innerHTML = renderBrokerSummaryCards();
}

function renderBrokerSummaryCards() {
  const summaries = brokerSummaries();
  return ACCOUNT_BROKERS.map((broker) => {
    const summary = summaries.find((item) => brokerKey(item) === broker) || {broker};
    const profile = ACCOUNT_STRATEGY_PROFILES[broker] || {horizon: "-", strategy: "-"};
    return `<button class="broker-summary-card ${escapeHtml(sourceStatusClass(brokerSyncStatus(broker).status))}" type="button" data-broker="${escapeHtml(broker)}">
      <span class="summary-label">${escapeHtml(brokerDisplayName(summary))}</span>
      <span class="account-horizon-label">${escapeHtml(profile.horizon)} · ${escapeHtml(profile.strategy)}</span>
      <span class="broker-account-alias">账户 ${escapeHtml(formatPlain(brokerAccountAlias(broker, summary)))}</span>
      <strong>${escapeHtml(formatMoney(summary.portfolio_value_hkd, "HKD"))}</strong>
      <span class="summary-note">持仓 ${escapeHtml(formatDisplayNumber(summary.holding_count))} · ${escapeHtml(brokerSummarySourceText(summary))}</span>
    </button>`;
  }).join("");
}

function brokerAccountAlias(broker, summary = {}) {
  const cash = getCashRows().find((row) => brokerKey(row) === broker) || {};
  const position = (state.accountSnapshot?.positions || []).find((row) => brokerKey(row) === broker) || {};
  return firstPresent(summary.account_alias, summary.accounts, cash.account_alias, cash.accounts, position.account_alias,
    position.accounts, "-");
}

function brokerSummarySourceText(summary) {
  return brokerSyncStatus(brokerKey(summary)).display;
}

function renderSourceStatusListIntoHeader() {
  elements["source-status-list"].innerHTML = renderSourceStatusList();
}

function renderSourceStatusList() {
  return ACCOUNT_SOURCE_GROUPS.map((group) => `
    <div class="source-status-group">${escapeHtml(group.label)}</div>
    ${group.brokers.map((broker) => {
      const sync = brokerSourceStatus(broker);
      return `
        <div class="source-status-row ${escapeHtml(sourceStatusClass(sync.status))}" data-broker="${escapeHtml(broker)}">
          <strong>${escapeHtml(brokerDisplayName(broker))}账户</strong>
          <span>${escapeHtml(sync.display)}</span>
        </div>
      `;
    }).join("")}
  `).join("");
}

function sourceStatusClass(status) {
  const normalized = String(status || "").trim().toLowerCase();
  if (normalized === "ok" || normalized === "healthy" || normalized === "real_time" || normalized === "fresh") {
    return "status-ok";
  }
  if (normalized === "non_realtime" || normalized === "statement") {
    return "status-partial";
  }
  if (normalized === "stale") {
    return "status-stale";
  }
  if (normalized === "missing" || normalized === "failed" || normalized === "error") {
    return "status-failed";
  }
  return "status-muted";
}

function getCashRows() {
  return (state.accountSnapshot && Array.isArray(state.accountSnapshot.cash_balances))
    ? state.accountSnapshot.cash_balances
    : [];
}

function accountActionsEnabled() {
  return Boolean(state.accountSnapshot)
    && !state.accountError
    && state.accountSnapshot.status === "healthy"
    && !state.accountSnapshot.stale;
}

function accountSnapshotStatusText() {
  if (state.accountError) return "账户快照不可用，已冻结上次数据";
  if (!state.accountSnapshot) return "账户快照不可用";
  if (!accountActionsEnabled()) return "账户快照已过期，操作已禁用";
  return "账户快照正常";
}

function sourceKindText(value) {
  const normalized = String(value || "").trim().toLowerCase();
  if (normalized === "live_account" || normalized === "real_time" || normalized === "ok" || normalized === "fresh") {
    return "实时";
  }
  if (normalized === "quote_and_live_account") {
    return "行情与账户";
  }
  if (normalized === "statement" || normalized === "non_realtime") {
    return "非实时";
  }
  if (normalized === "missing") {
    return "暂无数据";
  }
  return formatPlain(value);
}

function rowBrokers(row) {
  if (!row || typeof row !== "object") {
    return [];
  }
  const brokers = splitList(row.brokers);
  const broker = brokerKey(row);
  if (broker && !brokers.includes(broker)) {
    brokers.push(broker);
  }
  return brokers;
}

function brokerKey(value) {
  const raw = typeof value === "object" && value !== null
    ? firstPresent(value.broker, value.broker_key)
    : value;
  const normalized = String(raw || "").trim().toLowerCase();
  if (normalized === "phillip") {
    return "phillips";
  }
  return normalized;
}

function brokerDisplayName(value) {
  if (typeof value === "object" && value !== null) {
    const label = firstPresent(value.label, value.display_name);
    if (hasValue(label)) {
      return label;
    }
  }
  const key = brokerKey(value);
  const labels = {
    eastmoney: "东方财富",
    futu: "富途",
    tiger: "老虎",
    phillips: "辉立",
  };
  return labels[key] || formatPlain(value);
}

function quoteNotApplicable(holding) {
  const market = String(holding.market || "").toUpperCase();
  const assetClass = String(holding.asset_class || "").toLowerCase();
  return market === "CASH" || assetClass === "cash" || assetClass === "money_market_fund";
}

function isAccountHoldingPosition(position) {
  const quantity = numericValue(firstPresent(position.total_quantity, position.quantity));
  return !quoteNotApplicable(position) && quantity !== 0;
}

function detailLivePrice(holding, quote) {
  if (quoteNotApplicable(holding)) {
    return "-";
  }
  return quote && hasValue(quote.last_price) ? quote.last_price : "缺行情";
}

function renderQuotePrice(holding, quote) {
  if (quoteNotApplicable(holding)) {
    return escapeHtml("-");
  }
  if (!quote || !hasValue(quote.last_price)) {
    return `<span class="missing-text">缺行情</span>`;
  }
  const sessionKey = String(quote.price_session || "");
  const session = String(holding && holding.market || "").toUpperCase() === "US"
    ? sessionQuoteLabel(sessionKey) : "";
  if (!session) return escapeHtml(formatDisplayNumber(quote.last_price));
  const detail = quote.current_session_quote
    ? quoteTimeEt(quote.price_time)
    : "上一有效价";
  return `<span class="session-quote"><span class="session-quote-label" data-session="${escapeHtml(sessionKey)}">${escapeHtml(session)}</span><strong class="session-quote-price">${escapeHtml(formatDisplayNumber(quote.last_price))}</strong>${detail ? `<span class="session-quote-time">· ${escapeHtml(detail)}</span>` : ""}</span>`;
}

function renderAccountHoldingPrice(display) {
  if (!hasValue(display?.last_price)) return '<span class="missing-text">缺行情</span>';
  const kind = String(display.price_kind || "");
  const label = ({overnight: "夜盘", pre_market: "盘前", live: "盘中", after_hours: "盘后", statement: "结单", account_snapshot: "账户快照"})[kind] || "";
  const isUs = String(display.market || "").toUpperCase() === "US";
  if (!label || (!isUs && kind !== "statement" && kind !== "account_snapshot")) {
    return escapeHtml(formatDisplayNumber(display.last_price));
  }
  const detail = display.price_as_of ? `· ${escapeHtml(quoteTimeEt(display.price_as_of))}` : "";
  return `<span class="session-quote ${kind === "statement" ? "statement-quote" : ""}"><span class="session-quote-label" data-session="${escapeHtml(kind)}">${escapeHtml(label)}</span><strong class="session-quote-price">${escapeHtml(formatDisplayNumber(display.last_price))}</strong>${detail ? `<span class="session-quote-time">${detail}</span>` : ""}</span>`;
}

function sessionQuoteLabel(value) {
  return ({overnight: "夜盘", pre_market: "盘前", regular: "盘中", after_hours: "盘后"})[value] || "";
}

function quoteTimeEt(value) {
  const match = String(value || "").match(/\b\d{4}-\d{2}-\d{2}[ T](\d{2}:\d{2})/);
  return match ? `${match[1]} ET` : "";
}

function renderActionBadge(action, status) {
  const actionText = formatAction(action);
  const statusText = formatActionStatus(status);
  if (actionText === "-" && statusText === "-") {
    return `<span class="badge">-</span>`;
  }
  return `<span class="badge">${escapeHtml(actionText)}${statusText !== "-" ? ` · ${escapeHtml(statusText)}` : ""}</span>`;
}

function quoteStatusLabel(status) {
  if (status === "ok") {
    return "行情正常";
  }
  if (status === "partial") {
    return "部分缺行情";
  }
  if (status === "failed") {
    return "刷新失败";
  }
  return "等待行情";
}

function quoteStatusClass(status) {
  if (status === "ok") {
    return "status-ok";
  }
  if (status === "partial") {
    return "status-partial";
  }
  if (status === "failed") {
    return "status-failed";
  }
  return "status-muted";
}

function formatDiagnostic(payload) {
  if (!payload || !payload.status) {
    return "-";
  }
  const diagnostic = payload.diagnostic || {};
  if (diagnostic.reason) {
    return formatDiagnosticMessage(diagnostic.reason);
  }
  if (diagnostic.message) {
    return formatDiagnosticMessage(diagnostic.message);
  }
  if (diagnostic.next_step) {
    return formatDiagnosticMessage(diagnostic.next_step);
  }
  return quoteStatusLabel(payload.status);
}

function formatAction(action) {
  return labelFromMap(ACTION_LABELS, action);
}

function formatActionStatus(status) {
  return labelFromMap(ACTION_STATUS_LABELS, status);
}

function formatPriority(priority) {
  return labelFromMap(PRIORITY_LABELS, priority);
}

function formatTriggerStatus(status) {
  return labelFromMap(TRIGGER_STATUS_LABELS, status);
}

function formatActionReason(reason) {
  return labelFromMap(REASON_LABELS, reason);
}

function formatDiagnosticMessage(message) {
  return labelFromMap(REASON_LABELS, message);
}

function labelFromMap(map, value) {
  const raw = formatPlain(value);
  if (raw === "-") {
    return raw;
  }
  return map[raw] || map[raw.toLowerCase()] || raw;
}

function setActiveFilter(container, activeButton) {
  container.querySelectorAll(".filter-button").forEach((button) => {
    button.classList.toggle("active", button === activeButton);
  });
}

function splitList(value) {
  return String(value || "")
    .split(";")
    .map((item) => item.trim())
    .filter(Boolean);
}

function formatDisplayNumber(value) {
  const raw = formatPlain(value).trim();
  const match = raw.match(/^([+-]?)(\d+)(?:\.(\d+))?$/);
  if (!match) return raw;
  const [, sign, rawInteger, rawFraction = ""] = match;
  const rounded = (BigInt(`${rawInteger}${rawFraction.slice(0, 2).padEnd(2, "0")}`)
    + ((rawFraction[2] || "0") >= "5" ? 1n : 0n)).toString().padStart(rawInteger.length + 2, "0");
  const integer = rounded.slice(0, -2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const fraction = rounded.slice(-2).replace(/0+$/, "");
  return `${sign}${integer}${fraction ? `.${fraction}` : ""}`;
}

function formatDecisionTarget(value) {
  const raw = safePrimaryValue(value);
  const range = raw.match(/^([+-]?\d+(?:\.\d+)?)(\s+-\s+)([+-]?\d+(?:\.\d+)?)$/);
  if (range) return `${formatDisplayNumber(range[1])}${range[2]}${formatDisplayNumber(range[3])}`;
  const threshold = raw.match(/^([<>]=?\s*)([+-]?\d+(?:\.\d+)?)$/);
  if (threshold) return `${threshold[1]}${formatDisplayNumber(threshold[2])}`;
  return formatDisplayNumber(raw);
}

function formatMoney(value, currency) {
  if (!hasValue(value)) return "-";
  return `${currency} ${formatDisplayNumber(value)}`;
}

function formatSignedPnl(value) {
  const raw = formatPlain(value).trim();
  const suffix = raw.endsWith("%") ? "%" : "";
  const numberText = suffix ? raw.slice(0, -1) : raw;
  const number = numericValue(numberText);
  if (number === null) return raw;
  const digits = formatDisplayNumber(numberText.replace(/^[+-]/, "").replace(/,/g, ""));
  const sign = number > 0 ? "+" : number < 0 ? "-" : "";
  return `${sign}${digits}${suffix}`;
}

function formatSignedMoney(value, currency) {
  return hasValue(value) ? `${currency} ${formatSignedPnl(value)}` : "-";
}

function pnlClass(value) {
  const number = numericValue(String(value || "").replace("%", ""));
  return number > 0 ? "pnl-profit" : number < 0 ? "pnl-loss" : "";
}

function formatPlain(value) {
  return hasValue(value) ? String(value) : "-";
}

function hasValue(value) {
  return value !== null && value !== undefined && String(value).trim() !== "";
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function lpAutoFundsAndOrders(auto) {
  if (!auto || typeof auto !== "object") return "";
  const funds = auto.funds || {};
  const slots = auto.slots || {};
  const pendingReview = Number(slots.pending_review ?? slots.unknown ?? 0);
  const pendingSubmitting = Math.max(0, Number(slots.pending ?? 0) - pendingReview);
  const money = (value) => predictionHasValue(value) ? lpDashboardMoney(value) : "UNKNOWN";
  const candidates = (auto.last_round?.candidates || []).map((row) => {
    const estimate = row.minimum_order_estimate || {};
    return `<tr><td>${escapeHtml(row.condition_id || "—")}</td><td>${escapeHtml(predictionValue(estimate.quantity, "UNKNOWN"))}</td><td>${escapeHtml(money(estimate.capital_usd))}</td><td>${escapeHtml(money(estimate.hourly_reward_usd))}</td><td>${escapeHtml(predictionValue(estimate.yield_pct_per_hour, "UNKNOWN"))}%</td></tr>`;
  }).join("");
  return `<div class="pm-lp-auto-funds">
    <p class="pm-lp-budget-line">目标 ${escapeHtml(String(auto.target_buy_count ?? 0))} · 有效 BUY ${escapeHtml(String(slots.active ?? 0))} · 待核对占位 ${escapeHtml(String(pendingReview))} · 提交中 ${escapeHtml(String(pendingSubmitting))} · 撤单中 ${escapeHtml(String(slots.canceling ?? 0))} · 共占位 ${escapeHtml(String(slots.occupied ?? 0))}</p>
    <p>策略总资金 <strong>${escapeHtml(money(funds.total_usd))}</strong> · 可用 <strong>${escapeHtml(money(funds.available_usd))}</strong> · 库存成本 ${escapeHtml(money(funds.inventory_cost_usd))} · BUY 总预留 ${escapeHtml(money(funds.buy_reserved_usd))}（其中在途 ${escapeHtml(money(funds.pending_reserved_usd))}）</p>
    <p>净分配 ${escapeHtml(money(funds.net_allocation_usd))} · 已核实交易盈亏 ${escapeHtml(money(funds.realized_pnl_usd))} · 资金缺口 ${escapeHtml(money(funds.deficit_usd))} · ${funds.status === "known" ? "账本已核对" : "账本待核对"} · 奖励本期不复投</p>
    ${candidates ? `<details><summary>最小合法评分单估算（完整合格池共 ${escapeHtml(String(auto.last_round.candidate_count || 0))} 个方向，展示前 10）</summary><div class="table-wrap"><table><thead><tr><th>市场</th><th>实际数量</th><th>占用</th><th>预估奖励 / 小时</th><th>预估收益率 / 小时</th></tr></thead><tbody>${candidates}</tbody></table></div></details>` : ""}
    <p class="sub">本轮：${escapeHtml(auto.last_round?.reason || "尚未运行")} · ${escapeHtml(String(auto.last_round?.actions?.length || 0))} 项动作。</p>
  </div>`;
}
