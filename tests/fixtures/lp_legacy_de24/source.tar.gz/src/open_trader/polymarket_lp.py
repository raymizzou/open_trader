"""Durable, single-market Polymarket liquidity-provider session."""

from __future__ import annotations

import inspect
import hashlib
import json
import logging
import math
import os
import sqlite3
import sys
import threading
import uuid
from time import monotonic
from copy import deepcopy
from contextlib import ExitStack, contextmanager, nullcontext
from collections.abc import Callable, Collection, Mapping, MutableMapping, Sequence
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, as_completed, wait
from datetime import UTC, date, datetime, time, timedelta
from decimal import ROUND_HALF_UP, Decimal
from typing import Any, cast
from types import MappingProxyType
from zoneinfo import ZoneInfo

from .polymarket_lp_risk import (
    BOOK_FRESHNESS_SECONDS,
    _MARKET_METADATA_MAX_AGE_SECONDS,
    LP_QUEUE_PROTECTION_THRESHOLD,
    TERMINAL_ORDER_STATES,
    _account_after_reservations,
    _decimal,
    _event_window_check,
    _executable_bid_value,
    _field,
    _freshness,
    _has_market_order,
    _items,
    _levels,
    _maybe_decimal,
    _projected_taker_fee,
    _qualify_reward_quote,
    _select_bid_level,
    _timestamp,
    estimate_lp_queue_position,
    estimate_lp_stress_exit,
    estimate_lp_target_share_yield,
    evaluate_lp_entry,
    minimum_order_estimate,
    first_observation_baseline,
)
from .polymarket_lp_accounting import (
    build_account_financial_facts, build_planning_account_facts, reservation_is_manually_released, reservation_is_released,
    buy_action_is_covered, unresolved_buy_action, submission_action_kind,
    project_planning_buy_holds,
)
from .polymarket_lp_errors import LpObservationWait
from .polymarket_lp_notification_batches import (
    ChannelStatuses,
    matching_batch_channels,
    plan_notification_batches,
)
from .polymarket_lp_scratch import (
    LPDirectionIndex, LPDirectionScratch, LPReadOverlay, LPReadRows, LPReadScratch,
)
from .prediction_arbitrage_store import (
    LP_RESERVED_MANUAL_SESSION_ID,
    PredictionArbitrageStore,
)
from .notifications import beijing_clock, notification_delivery_episode
from .polymarket_trading import (
    PolymarketTradingClient,
    LpAccountReadError,
    LpAccountRoundInvalid,
    LpNewerAccountFacts,
    _lp_maker_order_is_self,
    _lp_read_stage,
    _lp_read_task,
    _lp_flush_read_logs,
    _lp_read_lock,
    _lp_market_read_diagnostic,
    _lp_causal_event,
    _lp_capture_read_log,
    _lp_trade,
    _safe_read_error_chain,
    _safe_sqlite_error_facts,
)


STOP_LOSS = Decimal("5")


class _PreparationDatabaseFailure(Exception):
    """Carry redacted adapter database facts to the global preparation boundary."""

    def __init__(self, facts: Mapping[str, object]) -> None:
        self.facts = facts
        super().__init__("preparation_database_failure")


SCORING_STALE_SECONDS = Decimal("15")
# Issue 163 定案 8 / Issue 166: an augment can only land on ``entry_open``.
# Every other non-terminal state maps to its real rejection reason; the two
# augment entry points (single-shot submit_augment and the legacy two-phase
# _augment_session) share this one table so the two paths never drift.
_LP_AUGMENT_STATE_BLOCKS = {
    "review": "session_review_exit",
    "stop_loss_exit": "session_stop_loss_exit",
    "needs_attention": "session_needs_attention",
    "passive_exit": "session_passive_exit",
    "entry_submit_pending": "session_entry_pending",
}
SCORING_POLL_SECONDS = Decimal("5")
SCORING_FAILURE_WINDOW_SECONDS = Decimal("60")
GTD_REVIEW_BUFFER_SECONDS = 60
SDK_MIN_EXPIRATION_SECONDS = 180
PREVIEW_TTL_SECONDS = 10
REWARD_THRESHOLD = Decimal("1")
REWARD_STALE_SECONDS = Decimal("180")
LP_CANDIDATE_REFRESH_SECONDS = Decimal("300")
LP_RECOMMENDATION_REFRESH_SECONDS = Decimal("60")
# Issue #146: maintenance refreshes the head's sources on the oldest source
# age (30-second lead) instead of waiting for the 60-second expiry.
LP_RECOMMENDATION_REFRESH_LEAD_SECONDS = Decimal("30")
# Issue #146: after consecutive maintenance failures the next attempt waits
# 60/120/300 seconds counted from the attempt's finish; three or more
# consecutive failures hold at 300 seconds. A success resets the schedule.
_CANDIDATE_MAINTENANCE_BACKOFF_SECONDS = (
    Decimal("60"),
    Decimal("120"),
    Decimal("300"),
)
# Issue #146: scheduler waits never spin below one second and never exceed
# the 300-second scan cadence.
_CANDIDATE_SCHEDULER_WAIT_FLOOR_SECONDS = 1.0
_CANDIDATE_SCHEDULER_WAIT_CEILING_SECONDS = 300.0
# Issue #157 rolling pool: an estimate stays valid for five minutes from its
# own judgment time; expiry is computed against the current clock on every
# read and publish, never by a background event.
LP_CANDIDATE_VALIDITY_SECONDS = Decimal("300")
# Issue #157: one exploration batch handles at most ten distinct markets in
# one order-book read (binary markets: at most 20 tokens).
_LP_CANDIDATE_BATCH_SIZE = 10
# Issue #157: the exploration loop never polls faster than one batch per two
# seconds; the runtime scheduler clamps its wait to this floor.
_LP_CANDIDATE_BATCH_MIN_INTERVAL_SECONDS = 2.0
# Issue #157: official competition refreshes on its own thread; candidate
# paths only read the in-memory cache and never block on a competition read.
# #181: 密度是慢变量，小时级节奏。
_LP_COMPETITION_REFRESH_SECONDS = 3600
# Issue #306: bounded writes and cooperative yield; see the replay measurement record.
_LP_COMPETITION_BATCH_SIZE = 500
_LP_COMPETITION_BATCH_PAUSE_SECONDS = 0.01
# Issue #157: pool publications persist at most once every five seconds.
_LP_CANDIDATE_SNAPSHOT_SAVE_MIN_INTERVAL_SECONDS = 5.0
_LP_BOOK_SAMPLE_BATCH_SIZE = 100
_LP_BOOK_SAMPLE_MAX_CONCURRENCY = 8
_LP_PRICE_HISTORY_BATCH_SIZE = 20
_LP_PRICE_HISTORY_MAX_CONCURRENCY = 4
_LP_PRICE_HISTORY_WINDOW = timedelta(hours=24)
_LP_PRICE_HISTORY_OVERLAP = timedelta(minutes=1)
_LP_METADATA_BATCH_SIZE = 1500
# Keep transient preparation failures recoverable while still bounding the
# amount of upstream work during an outage.  The final interval is repeated
# indefinitely until a validated read succeeds or an operator blocker is
# classified.
_LP_PREPARATION_RETRY_DELAYS_SECONDS = (300, 600, 1200, 1800, 1800)
_BEIJING = ZoneInfo("Asia/Shanghai")
TERMINAL_TRADE_STATES = frozenset({"CONFIRMED", "FAILED"})
# Issue 152: consecutive tick-level data outages (snapshot/book unknown) turn
# into a conservative cancel of the protected BUY once this limit is reached.
LP_PROTECTION_DATA_FAILURE_LIMIT = 10
# 「需要核对」克制通知：进入该状态满 5 分钟仍未自愈才经 _notify_protection
# 推一条；同一次进入（episode）只推一条，恢复后清键重置。
LP_NEEDS_ATTENTION_NOTIFY_SECONDS = 300
# Issue 152: only these tick early-exit reasons count as data outages;
# identity/holding conflicts are decision blockers, not data outages.
_QUEUE_DATA_FAILURE_REASONS = frozenset(
    {"external_snapshot_unknown", "book_unknown", "book_freshness_unknown"}
)

logger = logging.getLogger(__name__)


class AutoEntryNotSent(ValueError):
    """A pre-POST guard proved that the automatic entry was not sent."""


def _submit_failure_facts(exc: BaseException) -> dict[str, object]:
    """Persist safe submit failure facts without SDK messages or secrets."""

    chain = _safe_read_error_chain(exc)
    status = getattr(exc, "status", None)
    return {
        "submit_error_chain": chain,
        "submit_status_code": status if type(status) is int and 100 <= status <= 599 else None,
        "submit_timeout": bool({"TimeoutError", "ReadTimeout"} & set(chain)),
    }


class _MutationBlocked(RuntimeError):
    """The shared execution guard currently forbids an exchange mutation."""


def _now_utc() -> datetime:
    return datetime.now(UTC)


def _text(value: object) -> str | None:
    return value.strip() if isinstance(value, str) and value.strip() else None


def _reward_accrual_rows(value: object) -> tuple[dict[str, object], ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return ()
    rows: list[dict[str, object]] = []
    for item in value:
        if not isinstance(item, Mapping):
            continue
        amount = _maybe_decimal(item.get("amount"))
        asset = _text(item.get("asset"))
        if amount is None or amount < 0 or asset is None:
            continue
        row: dict[str, object] = {"amount": amount, "asset": asset}
        address = _text(item.get("asset_address"))
        if address is not None:
            row["asset_address"] = address
        rows.append(row)
    return tuple(rows)


def _iso(moment: datetime) -> str:
    return moment.astimezone(UTC).isoformat(timespec="microseconds").replace(
        "+00:00", "Z"
    )


def _first_seen_stamp_key(value: object) -> float:
    """Anchor tie-break sort key: venue stamps ascend, missing stamps last."""

    stamp = value if isinstance(value, datetime) else None
    if stamp is None:
        return float("inf")
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=UTC)
    return stamp.timestamp()


def _first_seen_stamp_value(value: object, *, default: datetime) -> datetime:
    """Parse a first-seen stamp, accepting ISO strings and datetimes."""

    if isinstance(value, datetime):
        return value if value.tzinfo is not None else value.replace(tzinfo=UTC)
    text = str(value or "").strip()
    if text:
        try:
            stamp = datetime.fromisoformat(text.replace("Z", "+00:00"))
            return stamp if stamp.tzinfo is not None else stamp.replace(tzinfo=UTC)
        except ValueError:
            pass
    return default


def _queue_decimal_text(value: Decimal | None) -> str:
    """Render a share/price amount without trailing zeros (issue 152)."""

    if value is None:
        return "UNKNOWN"
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text or "0"


def _queue_ratio_percent_text(ratio: Decimal | None) -> str:
    """Render an A ratio as a two-decimal percent without trailing zeros."""

    if ratio is None:
        return "UNKNOWN"
    return _queue_decimal_text(
        (ratio * Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    )


def _queue_protection_level_buckets(
    protection: object,
    *,
    default_order_id: str = "",
) -> dict[str, dict[str, object]]:
    """Issue 167 D6: normalize any queue-protection payload into buckets.

    Three-tier fallback, and it never raises:
    - missing/invalid payload → ``{}`` (protection not enabled, the old
      ``.get`` guard semantics);
    - v2 ``levels`` mapping → per-price buckets; a bucket whose
      baseline_price or order id is unreadable is marked ``unknown`` alone
      (its group's other buckets and the group accounting keep working);
    - legacy scalar shape (baseline_price, no levels) → wrapped as one
      bucket so old sessions keep running; the next payload write lands in
      the v2 shape naturally.

    Keys are the canonical ``format(price, "f")`` texts; bucket lookups by
    price must compare ``baseline_price`` values, not keys.
    """

    if not isinstance(protection, Mapping):
        return {}
    raw_levels = protection.get("levels")
    if isinstance(raw_levels, Mapping):
        buckets: dict[str, dict[str, object]] = {}
        for raw_key, raw_value in raw_levels.items():
            key = str(raw_key)
            if not isinstance(raw_value, Mapping):
                buckets[key] = {
                    "state": "unknown",
                    "reason_codes": ["level_payload_invalid"],
                }
                continue
            bucket = dict(raw_value)
            if (
                _maybe_decimal(bucket.get("baseline_price")) is None
                or not str(bucket.get("order_id") or "").strip()
            ):
                bucket["state"] = "unknown"
            buckets[key] = bucket
        return buckets
    price = _maybe_decimal(protection.get("baseline_price"))
    if price is None:
        return {}
    bucket = dict(protection)
    # Group-level keys never live inside a bucket: the v2 payload keeps the
    # outage counter at the top, and a stale legacy copy must not leak into
    # the wrapped bucket.
    bucket.pop("levels", None)
    bucket.pop("version", None)
    bucket.pop("data_failures", None)
    bucket.setdefault("order_id", default_order_id)
    return {format(price, "f"): bucket}


def _queue_group_failures_int(value: object) -> int:
    """Normalize the group-level outage counter to a durable JSON number."""

    parsed = _maybe_decimal(value)
    return int(parsed) if parsed is not None else 0


def queue_protection_status_view(protection: object) -> dict[str, object]:
    """Normalized v2 view of a queue-protection payload for read paths.

    ``levels`` carries the per-price buckets (D6 three-tier fallback); with
    exactly one bucket its scalar keys merge onto the view so the legacy
    single-bucket external contract keeps working unchanged.
    """

    levels = _queue_protection_level_buckets(protection)
    failures = (
        _maybe_decimal(protection.get("data_failures"))
        if isinstance(protection, Mapping)
        else None
    )
    view: dict[str, object] = (
        dict(next(iter(levels.values()))) if len(levels) == 1 else {}
    )
    view["version"] = 2
    view["data_failures"] = failures if failures is not None else 0
    view["levels"] = levels
    return view


def _report_boundary_iso(moment: datetime) -> str:
    return moment.astimezone(UTC).isoformat(timespec="seconds").replace(
        "+00:00", "Z"
    )


def _lp_reward_terms(
    market_metadata: Mapping[str, object],
    reward_market: Mapping[str, object],
) -> tuple[object, object]:
    """Use fresh market rules, falling back to this read's reward rules."""

    reward_minimum = market_metadata.get("reward_min_size")
    if reward_minimum is None:
        reward_minimum = reward_market.get("rewards_min_size")
    reward_spread = market_metadata.get("reward_max_spread")
    if reward_spread is None:
        raw_spread = _maybe_decimal(reward_market.get("rewards_max_spread"))
        reward_spread = None if raw_spread is None else raw_spread / Decimal("100")
    return reward_minimum, reward_spread


def _lp_direction_fact(
    market_meta: Mapping[str, object],
    reward_market: Mapping[str, object],
    *,
    condition_id: str,
    token_id: str,
    outcome: str,
    reward_checked_at: object,
    reward_guidance_deadline: object,
    event_end_confirmation: object,
    history_summary: object,
    account: Mapping[str, object] | None,
    compact_market: bool = False,
) -> dict[str, object]:
    """Build one YES/NO direction fact from market and reward rows.

    Single copy of the direction-construction formula, shared by the
    round-start build and the issue-143 batch renewal, so both produce
    identical market fields (including the ``_lp_reward_terms`` minimum and
    spread resolution and the reward-catalog overlays) from the same code.
    ``compact_market`` retains just overrides for a candidate scratch reader
    which reconstructs the rest from its published metadata generation.
    """

    reward_minimum, reward_spread = _lp_reward_terms(market_meta, reward_market)
    market: dict[str, object] = {
        "condition_id": condition_id,
        "token_id": token_id,
        "outcome": outcome,
        "reward_min_size": reward_minimum,
        "reward_max_spread": reward_spread,
    }
    if "rewards_min_size" in reward_market:
        market["_reward_catalog_min_size"] = reward_market.get("rewards_min_size")
    if "rewards_max_spread" in reward_market:
        market["_reward_catalog_max_spread"] = reward_market.get("rewards_max_spread")
    if market_meta.get("reward_min_size") is not None:
        market["_metadata_reward_min_size"] = market_meta.get("reward_min_size")
    if market_meta.get("reward_max_spread") is not None:
        market["_metadata_reward_max_spread"] = market_meta.get("reward_max_spread")
    # Candidate scratch stores just these overrides. Other callers still get
    # the complete market, and participation sees that same complete value.
    full_market = {**dict(market_meta), **market}
    direction: dict[str, object] = {
        "market": market if compact_market else full_market,
        "reward_active": (
            reward_market.get("reward_active")
            if isinstance(reward_market.get("reward_active"), bool)
            else None
        ),
        "daily_pool_usd": reward_market.get("daily_pool_usd"),
        "reward_checked_at": reward_checked_at,
        "reward_guidance_deadline": reward_guidance_deadline,
        "event_end_confirmation": event_end_confirmation,
    }
    if isinstance(history_summary, Mapping):
        direction["history_summary"] = dict(history_summary)
    if account is not None and _has_market_order(account, full_market):
        direction["known_participation"] = True
    return direction


def _lp_metadata_stale_conditions(
    directions_by_condition: Mapping[str, Sequence[Mapping[str, object]]],
    condition_ids: Sequence[str],
    now: datetime,
) -> tuple[str, ...]:
    """Batch conditions whose metadata or fee receipt misses the 60s window."""

    stale: list[str] = []
    for condition_id in condition_ids:
        for direction in directions_by_condition.get(condition_id, ()):
            market = (
                direction.get("market") if isinstance(direction, Mapping) else None
            )
            if isinstance(market, Mapping) and (
                _candidate_source_expired(market.get("metadata_checked_at"), now)
                or _candidate_source_expired(market.get("fees_checked_at"), now)
            ):
                stale.append(condition_id)
                break
    return tuple(stale)


def _lp_reward_stale_conditions(
    directions_by_condition: Mapping[str, Sequence[Mapping[str, object]]],
    condition_ids: Sequence[str],
    now: datetime,
) -> tuple[str, ...]:
    """Batch conditions whose reward receipt misses the 60s window."""

    stale: list[str] = []
    for condition_id in condition_ids:
        for direction in directions_by_condition.get(condition_id, ()):
            if isinstance(direction, Mapping) and _candidate_source_expired(
                direction.get("reward_checked_at"), now
            ):
                stale.append(condition_id)
                break
    return tuple(stale)


def _lp_guidance_is_usable(value: object) -> bool:
    """Require every fact the UI needs before counting a direction as passed."""

    if not isinstance(value, Mapping):
        return False
    for field in (
        "condition_id",
        "token_id",
        "outcome",
        "price",
        "quantity",
        "required_capital",
        "estimated_exit_loss",
        "estimated_exit_loss_ratio",
        "checked_at",
        "expires_at",
    ):
        if value.get(field) in (None, ""):
            return False
    for field in (
        "price",
        "quantity",
        "required_capital",
        "estimated_exit_loss",
        "estimated_exit_loss_ratio",
    ):
        parsed = _maybe_decimal(value.get(field))
        if parsed is None or parsed < 0 or field in {"price", "quantity"} and parsed <= 0:
            return False
    try:
        checked = _timestamp(value.get("checked_at"), name="guidance_checked_at")
        expires = _timestamp(value.get("expires_at"), name="guidance_expiry")
    except ValueError:
        return False
    return expires > checked


def _candidate_source_expired(value: object, now: datetime) -> bool:
    """Return whether a candidate source receipt is missing or older than 60s."""

    try:
        checked_at = _timestamp(value, name="candidate_source_checked_at")
    except ValueError:
        return True
    age = Decimal(str((now - checked_at).total_seconds()))
    return age < 0 or age > LP_RECOMMENDATION_REFRESH_SECONDS


def _candidate_source_due(value: object, now: datetime) -> bool:
    """Return whether a source receipt needs a refresh (30s lead or expired)."""

    try:
        checked_at = _timestamp(value, name="candidate_source_checked_at")
    except ValueError:
        return True
    age = Decimal(str((now - checked_at).total_seconds()))
    return (
        age < 0
        or age >= LP_RECOMMENDATION_REFRESH_LEAD_SECONDS
        or age > LP_RECOMMENDATION_REFRESH_SECONDS
    )


def _candidate_head_source_values(cached: Mapping[str, object]) -> list[object]:
    """Collect the head's source receipt stamps, oldest-age candidates only.

    Shared by the maintenance trigger and
    :meth:`PolymarketLPService.candidate_maintenance_wait_seconds` so both
    judge the same values with the same clock.
    """

    raw_account = cached.get("account")
    values: list[object] = [
        raw_account.get("checked_at") if isinstance(raw_account, Mapping) else None
    ]
    for direction in cached.get("directions", ()):
        if not isinstance(direction, Mapping):
            continue
        market = direction.get("market")
        if isinstance(market, Mapping):
            values.extend(
                [
                    market.get("metadata_checked_at"),
                    market.get("fees_checked_at"),
                ]
            )
        values.extend(
            [
                direction.get("reward_checked_at"),
                direction.get("book", {}).get("received_at")
                if isinstance(direction.get("book"), Mapping)
                else None,
            ]
        )
    return values


def _candidate_head_source_times(
    cached: Mapping[str, object], now: datetime
) -> tuple[list[datetime], bool]:
    """Return the parseable source stamps and whether any source is expired."""

    source_times: list[datetime] = []
    for value in _candidate_head_source_values(cached):
        try:
            checked_at = _timestamp(value, name="candidate_source_checked_at")
        except ValueError:
            continue
        if checked_at > now:
            continue
        source_times.append(checked_at)
    any_expired = any(
        _candidate_source_expired(value, now)
        for value in _candidate_head_source_values(cached)
    )
    return source_times, any_expired


def _lp_candidate_maintenance_log(event: str, facts: Mapping[str, object]) -> None:
    """Capture only pre-redacted, bounded attempt facts in the existing sink."""
    try:
        captured = deepcopy(dict(facts))
        _lp_capture_read_log(lambda: logger.info(
            "lp_candidate_maintenance event=%s facts=%s", event, captured))
    except Exception:
        pass


def _lp_direction_estimate(
    direction: Mapping[str, object],
    guidance: Mapping[str, object],
    *,
    now: datetime,
) -> dict[str, object]:
    """Use the same actual minimum scoring order as automatic BUY ranking."""
    if not isinstance(direction.get("market"), Mapping) or not isinstance(direction.get("book"), Mapping):
        return {"state": "unknown", "reason_codes": ["market_facts_unknown"]}
    estimate = minimum_order_estimate(direction, guidance, now)
    if estimate['state'] != 'known':
        return estimate
    # Keep the published field names for existing API consumers. These now
    # describe the actual legal minimum, not a hypothetical reward-share goal.
    return {**estimate, 'target_quantity': estimate['quantity'],
            'target_capital_usd': estimate['capital_usd'],
            'yield_pct_per_hour_display': estimate['yield_pct_per_hour'].quantize(
                Decimal('0.000001'), rounding=ROUND_HALF_UP)}


def _direction_estimate_raw(result: Mapping[str, object]) -> Decimal | None:
    """Return a direction's unrounded estimated yield, if it has one."""

    estimate = result.get("estimate")
    if not isinstance(estimate, Mapping) or estimate.get("state") != "known":
        return None
    return _maybe_decimal(estimate.get("yield_pct_per_hour"))


def _apply_row_estimate_fields(
    row: dict[str, object], estimate: Mapping[str, object] | None
) -> None:
    """Project one estimate onto a published candidate row.

    Unknown estimates stay UNKNOWN on every field — never zero, and never a
    fallback to the whole-pool optimistic upper bound.
    """

    if isinstance(estimate, Mapping):
        row["estimate_basis"] = estimate.get("basis")
        row["estimate_state"] = (
            "known" if estimate.get("state") == "known" else "unknown"
        )
        row["estimated_yield_raw"] = estimate.get("yield_pct_per_hour")
        row["estimated_yield_pct_per_hour"] = estimate.get(
            "yield_pct_per_hour_display"
        )
        row["estimated_target_quantity"] = estimate.get("target_quantity")
        row["estimated_target_capital_usd"] = estimate.get("target_capital_usd")
        row["estimated_hourly_reward_usd"] = estimate.get("hourly_reward_usd")
        checked_at = estimate.get("checked_at")
        row["estimate_checked_at"] = (
            checked_at.isoformat(timespec="microseconds").replace("+00:00", "Z")
            if isinstance(checked_at, datetime)
            else None
        )
    else:
        row["estimate_basis"] = None
        row["estimate_state"] = "unknown"
        row["estimated_yield_raw"] = None
        row["estimated_yield_pct_per_hour"] = None
        row["estimated_target_quantity"] = None
        row["estimated_target_capital_usd"] = None
        row["estimated_hourly_reward_usd"] = None
        row["estimate_checked_at"] = None
    row["estimate_updated"] = True


def _candidate_row_updated_at(row: Mapping[str, object]) -> datetime | None:
    """Parse one pool row's estimate judgment time (issue #157)."""

    value = row.get("updated_at")
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return _timestamp(value, name="candidate_updated_at")
        except ValueError:
            return None
    return None


def _candidate_row_expires_at(row: Mapping[str, object]) -> datetime | None:
    """Parse one pool row's validity deadline (issue #157)."""

    value = row.get("expires_at")
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        try:
            return _timestamp(value, name="candidate_expires_at")
        except ValueError:
            return None
    return None


def _pool_published_value(value: object) -> object:
    """Normalize one pool row to the published (JSON-like) shape.

    Published candidate rows have always been JSON-round-tripped through
    the durable store, which renders Decimals as strings and datetimes as
    ISO stamps; the rolling pool applies the same normalization at record
    time so in-memory readers and the HTTP projection see one shape.
    """

    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, datetime):
        return _iso(value)
    if isinstance(value, Mapping):
        return {str(key): _pool_published_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_pool_published_value(item) for item in value]
    return value


def _candidate_pool_row_expired(row: Mapping[str, object], now: datetime) -> bool:
    """A pool row leaves the valid set once the current clock passes its
    expiry; reads never extend it (issue #157)."""

    expires_at = _candidate_row_expires_at(row)
    return expires_at is None or now >= expires_at


def _candidate_yield_sort_key(
    row: Mapping[str, object],
) -> tuple[int, Decimal, int, Decimal, str]:
    """Published-table order (issue #157): estimated minimum-order yield
    descending first; UNKNOWN estimates rank after known ones — never as
    zero; the estimate judgment time (newest first) breaks those ties and
    the condition id keeps the order stable.  Competition and actual
    capital left the ranking key: they never reshuffle displayed rows.
    """

    raw_yield = _maybe_decimal(row.get("estimated_yield_raw"))
    yield_key = (0, -raw_yield) if raw_yield is not None else (1, Decimal("0"))
    updated_at = _candidate_row_updated_at(row)
    if updated_at is not None:
        updated_key = (0, -Decimal(str(updated_at.timestamp())))
    else:
        updated_key = (1, Decimal("0"))
    identity = str(row.get("condition_id") or row.get("market_id") or "")
    return (*yield_key, *updated_key, identity)


def _new_candidate_funnel_totals() -> dict[str, object]:
    """Continuous (not per-round) funnel counters for the rolling pool."""

    return {
        "checked": 0,
        "passed": 0,
        "rejected": 0,
        "unknown": 0,
        "batches": 0,
        "backup_read": 0,
        "unchecked": None,
    }


def _lp_funnel_conditions() -> dict[str, object]:
    """Return the user-facing rules applied by every LP funnel batch."""

    return {
        "read": {
            "来源": "奖励目录与市场资料",
            "完整性": "奖励目录全量读取；部分结果可参与筛选，缺失按 UNKNOWN 处理，不阻塞漏斗",
        },
        "base": {
            "奖励": "奖励启用且日奖池>0",
            "市场": "接受订单",
            "参与": "没有已知订单或持仓",
            "摘要": "24h 摘要有效且振幅不超过1¢",
            "事件": "开始前30分钟、进行中、结束后1h冷却不参与",
        },
        "sort": {
            "主排序": "假设每小时收益上限（日奖池÷(24×最低参考占资)）降序；乐观上限仅决定查询顺序，不是预计收益",
            "并列": "官方竞争按密度分档筛选，仅保留轻（[1,30)）、中（[30,300)）两档；重度（≥300）、过薄（<1）、零竞争、无数据整市场排除并计数；库存回退值标「旧」（3 小时窗、无年龄上限）；两档内部并列时按竞争值升序",
            "再排": "参考占资升序；兜底 market_id 升序",
            "备用": "参考价超 1 小时或缺失的进备用队列，按日奖池降序",
        },
        "trial": {
            "展示批": "前 9 个正常候选 + 备用队列补足，不足再以正常队列后续候选补足（最多 10 个）",
            "核验": "每轮仅队首读取实时盘口核验（实时值优先，缺失或无买档保持「待验证」），其余行待验证",
            "超可用": "最低占资超可用资金（实时值优先、缺失用参考值）的候选复核删行、不递补，计入排除数",
            "上限": 10,
            "缺口": "不足 10 个如实展示实际数量与原因；不宣称全市场收益前十",
        },
    }


def expiration_for_review(review_at: datetime, *, now: datetime | None = None) -> int:
    """Bind one GTD expiration to an absolute review deadline.

    The SDK requires the expiration itself to be at least three minutes out;
    the extra minute after review keeps that requirement explicit and prevents
    a restart from rolling the deadline forward.
    """

    current = (now or _now_utc()).astimezone(UTC)
    review = review_at.astimezone(UTC)
    expiration = review + timedelta(seconds=GTD_REVIEW_BUFFER_SECONDS)
    if review <= current or expiration <= current + timedelta(seconds=SDK_MIN_EXPIRATION_SECONDS):
        raise ValueError("review_at_too_soon")
    return int(expiration.timestamp())


class PolymarketLPService:
    """Own one fixed-price opening and its durable exit lifecycle."""

    def __init__(
        self,
        store: PredictionArbitrageStore,
        exchange: object,
        *,
        clock: Callable[[], datetime] = _now_utc,
        owner_lock: object | None = None,
        mutation_guard: Callable[..., bool] | None = None,
        exclusions_enabled: bool | None = None,
    ) -> None:
        self.store = store
        self.exchange = exchange
        self.clock = clock
        self.exclusions_enabled = (
            os.environ.get("OPEN_TRADER_LP_CANDIDATE_EXCLUSIONS") == "1"
            if exclusions_enabled is None else exclusions_enabled
        )
        if type(self.exclusions_enabled) is not bool:
            raise ValueError("exclusions_enabled must be a boolean")
        self._candidate_exclusion_revision = 0
        self._candidate_preparation_wakeup = None
        self.owner_lock = owner_lock
        self._mutation_guard = mutation_guard
        self._candidate_buy_price_level_reader: Callable[[], int] | None = None
        listener = getattr(store, "set_lp_trade_change_listener", None)
        if callable(listener):
            listener(self._invalidate_lp_account_round)
        self._protection_notifier: Callable[..., object] | None = None
        self._mutex = threading.RLock()
        self._entry_sends: set[str] = set()
        self._cancel_sends: set[str] = set()
        self._entry_sends_lock = threading.Lock()
        self._facts_owner = threading.local()
        self._facts_lock = threading.Lock()
        self._facts_apply_lock = threading.Lock()
        self._first_seen_apply_lock = threading.Lock()
        self._account_registration_attempt = 0
        self._account_order_sync_error: str | None = None
        self._deferred_protection_notices = threading.local()
        self._protection_cancel_lock = threading.Lock()
        # Retain consumed action IDs until this instance exits; cache eviction
        # must never rearm an old notice.
        self._protection_cancel_events: set[str] = set()
        self._protection_cancel_enabled = True
        self._facts_inflight: dict[str, dict] = {}
        self._pending_facts: dict[
            str, tuple[Mapping[str, object], int, Mapping[str, object], int]
        ] = {}
        self._facts_capacity = threading.BoundedSemaphore(2)
        self._facts_attention_flusher = None
        self._facts_attention_summary = None
        self._facts_attention_verifier = None
        self._attention_queue_lock = threading.Lock()
        self._attention_delivery_lock = threading.Lock()
        self._attention_delivery_results: dict[tuple[str, bool, str], dict[str, bool]] = {}
        self._attention_pending: dict[str, object] = {}
        self._attention_thread: threading.Thread | None = None
        self._market_reads_lock = threading.Lock()
        self._market_reads = {}
        self._market_read_retry = {}
        self._market_read_timeout = 10.0
        self._lp_account_rounds: set[object] = set()
        self._lp_account_rounds_lock = threading.Lock()
        self._facts_publisher = None
        self._facts_validator = None
        self._facts_wakeup = None
        self._reward_refresh_lock = threading.Lock()
        self._price_history_refresh_lock = threading.Lock()
        self._report_lock = threading.Lock()
        # Issue #146: the full scan and the head maintenance run on
        # independent threads; separate locks let a long scan proceed while
        # maintenance refreshes the published head (and vice versa) without
        # either kind overlapping itself.
        self._candidate_scan_lock = threading.Lock()
        self._candidate_maintenance_lock = threading.Lock()
        self._candidate_state_lock = threading.RLock()
        self._competition_lock = threading.Lock()
        self._competition_refresh_lock = threading.Lock()
        self._competition_version = 0
        self._candidate_queue_build_sequence = 0
        self._competition_state: dict[str, object] = {}
        self._preparation_lock = threading.RLock()
        self._sample_target_lock = threading.Lock()
        self._sample_targets: tuple[tuple[str, str], ...] = ()
        self._sample_target_version = 0
        self._candidate_attempted_at: datetime | None = None
        self._candidate_maintenance_failures = 0
        self._candidate_maintenance_global_failure = False
        self._candidate_maintenance_last_finished_at: datetime | None = None
        self._candidate_qualification_facts: dict[str, object] = {}
        # Issue #157 rolling pool: valid estimates keyed by condition_id, a
        # per-market rotation schedule, and continuous funnel counters.
        # Publications rewrite pool rows one by one; there is no whole-round
        # snapshot or publication generation anymore.
        self._candidate_pool: dict[str, dict[str, object]] = {}
        self._candidate_rotation: dict[str, dict[str, object]] = {}
        self._candidate_funnel_totals: dict[str, object] = (
            _new_candidate_funnel_totals()
        )
        self._candidate_queue_funnel: dict[str, object] = {}
        self._candidate_queue_state: dict[str, object] | None = None
        # Issue #157 review R6: the current queue's condition ids, kept next
        # to the queue funnel so pending can count untried members directly
        # instead of subtracting a rotation that outlives the queue.
        self._candidate_queue_condition_ids: tuple[str, ...] = ()
        self._candidate_pool_last_saved_at: datetime | None = None
        self._prepared_inputs: dict[str, object] | None = None
        self._prepared_inputs_version = 0
        self._candidate_history_version = 0
        self._candidate_snapshot: dict[str, object] = {
            "state": "unknown",
            "complete": False,
            "scanning": False,
            "candidates": [],
            "recommendations": [],
            "selected_results": [],
            "checked_at": None,
            "last_success_at": None,
            "last_attempt_at": None,
            "candidate_rows_fresh": False,
            "missing_metadata_condition_ids": [],
            "missing_book_token_ids": [],
            "catalog_complete": False,
            "funnel": {},
            "selected_market_ids": [],
            "candidate_retention_reason": "background_candidates_retired",
            "candidate_valid_count": 0,
            "candidate_pending_count": 0,
            "candidate_failed_recent_count": 0,
            "stale": False,
        }
        self._preparation: dict[str, object] | None = None
        try:
            self._restore_protection_cancel_events()
        except Exception as exc:
            self._protection_cancel_enabled = False
            logger.warning("lp_protection_cancel_restore_failed notifications_disabled error_type=%s", type(exc).__name__)
        self._restore_preparation()
        self._restore_candidate_snapshot()
        self._evict_excluded_candidates()
        configure = getattr(exchange, "configure_lp_candidate_exclusions", None)
        if callable(configure):
            configure(self.exclusions_enabled)

    def _candidate_allowed(self, identities, *, now=None):
        if not self.exclusions_enabled:
            return tuple(identities)
        return self.store.lp_candidate_allowed(tuple(identities), now=now or self._now())

    def set_candidate_preparation_wakeup(self, callback) -> None:
        self._candidate_preparation_wakeup = callback

    def candidate_exclusion_wait_seconds(self) -> float | None:
        """Reuse the history scheduler for the next normal preparation deadline."""
        if not self.exclusions_enabled:
            return None
        now = self._now()
        deadline = self.store.lp_next_market_exclusion_expiry(now=now)
        return max(1.0, (deadline - now).total_seconds()) if deadline else None

    def _candidate_conditions(self, condition_ids, *, now=None):
        if not self.exclusions_enabled:
            return tuple(condition_ids)
        return self.store.lp_candidate_conditions(tuple(condition_ids), now=now or self._now())

    @staticmethod
    def _candidate_global_generation(value: object) -> int:
        return value if type(value) is int and value >= 0 else 0

    def _current_candidate_global_generation(self) -> int | None:
        reader = getattr(self.store, "lp_preparation", None)
        if not callable(reader):
            return 0
        try:
            preparation = reader()
        except Exception:
            return None
        return (
            self._candidate_global_generation(preparation.get("global_recovery_generation"))
            if isinstance(preparation, Mapping)
            else 0
        )

    def _candidate_generation_allowed(self, expected: int | None) -> bool:
        current = self._current_candidate_global_generation()
        if current is None:
            return False
        if type(expected) is not int or expected < 0:
            return True
        return current <= expected

    def _exclude_candidate(
        self,
        condition_id,
        token_id,
        reason,
        *,
        checked_at,
        market=None,
        exclusion_revision=None,
        global_recovery_generation=None,
    ):
        if not self.exclusions_enabled:
            return False
        if not self._candidate_generation_allowed(global_recovery_generation):
            return False
        seconds = {
            "reward_inactive": 1800, "reward_pool_empty": 1800,
            "market_not_accepting_orders": 300, "competition_empty": 1800,
            "competition_too_thin": 1800, "competition_too_crowded": 1800,
            "history_amplitude_exceeded": 3600, "event_starting_soon": 300,
            "event_in_progress": 300,
        }.get(reason)
        if reason == "event_recovery_pending":
            try:
                # Only the actual official finish time establishes this deadline.
                until = _timestamp((market or {}).get("event_finished_at"), name="event_finished_at") + timedelta(hours=1)
            except ValueError:
                return False
        elif seconds is not None:
            until = checked_at + timedelta(seconds=seconds)
        else:
            return False
        with self._candidate_state_lock:
            if not self._candidate_generation_allowed(global_recovery_generation):
                return False
            if exclusion_revision is not None and exclusion_revision != self._candidate_exclusion_revision:
                return False
            inserted = self.store.lp_record_market_exclusion(
                condition_id, token_id, reason, checked_at=checked_at,
                cooldown_until=until, now=self._now(),
                global_recovery_generation=global_recovery_generation,
            )
            if inserted:
                self._candidate_exclusion_revision += 1
                self._evict_excluded_candidates(condition_id)
                if callable(self._candidate_preparation_wakeup):
                    self._candidate_preparation_wakeup()
            return inserted

    def _candidate_market_rejection(self, reward, market, *, now, competition=None):
        """Reuse existing thresholds, cheap public facts before history/books."""
        if not self.exclusions_enabled or any(row.get(key) is True for row in (reward, market) for key in ("closed", "resolved")):
            return None
        if reward.get("reward_active") is False:
            return "reward_inactive"
        pool = _maybe_decimal(reward.get("daily_pool_usd"))
        if pool is not None and pool <= 0:
            return "reward_pool_empty"
        if market.get("accepting_orders") is False and not _candidate_source_expired(
            market.get("metadata_checked_at"), self._now()
        ):
            return "market_not_accepting_orders"
        from .polymarket_lp_views import (
            _lp_competition_entry, LP_COMPETITION_DENSITY_THIN_FLOOR,
            LP_COMPETITION_DENSITY_MID_MAX,
        )
        cid = str(reward.get("condition_id") or market.get("condition_id") or "")
        projection = self._competition_entries((cid,)) if competition is None else competition
        entry = _lp_competition_entry(projection.get(cid))
        value, stamp = entry["value"], entry["checked_at"]
        if value is not None and stamp is not None and stamp <= now:
            if value == 0:
                return "competition_empty"
            if value < LP_COMPETITION_DENSITY_THIN_FLOOR:
                return "competition_too_thin"
            if value >= LP_COMPETITION_DENSITY_MID_MAX:
                return "competition_too_crowded"
        # Retained raw facts cannot create a new cooldown after their receipt expires.
        if _candidate_source_expired(market.get("metadata_checked_at"), self._now()):
            return None
        state, reason, _, _ = _event_window_check({}, market, now)
        return reason if state == "rejected" and reason in {
            "event_starting_soon", "event_in_progress", "event_recovery_pending"
        } else None

    def _observe_ended_candidate_market(
        self,
        condition_id,
        market,
        *,
        checked_at,
        global_recovery_generation=None,
    ):
        if not self._candidate_generation_allowed(global_recovery_generation):
            return False
        if self.exclusions_enabled and (market.get("closed") is True or market.get("resolved") is True):
            with self._candidate_state_lock:
                if not self._candidate_generation_allowed(global_recovery_generation):
                    return False
                if self.store.lp_clear_ended_market_exclusions(
                    condition_id,
                    checked_at=checked_at,
                    global_recovery_generation=global_recovery_generation,
                ):
                    self._candidate_exclusion_revision += 1
            return True
        return False

    def _evict_excluded_candidates(self, condition_id=None, *, prepared=False):
        """Drop candidate-only details. Trading reads never use this filter."""
        if not self.exclusions_enabled:
            return
        with self._candidate_state_lock:
            conditions = (condition_id,) if condition_id else tuple(dict.fromkeys((
                *self._candidate_pool, *self._candidate_rotation,
                *self._candidate_qualification_facts,
            )))
            allowed_conditions = set(self._candidate_conditions(conditions))
            for cid in conditions:
                row = self._candidate_pool.get(cid)
                selected = (row or {}).get("selected_direction") or {}
                if cid not in allowed_conditions or (row and not self._candidate_allowed(((cid, str(selected.get("token_id") or "")),))):
                    self._candidate_pool.pop(cid, None)
                    self._candidate_qualification_facts.pop(cid, None)
                elif row and isinstance(row.get("directions"), Mapping):
                    row["directions"] = {key: direction for key, direction in row["directions"].items()
                        if self._candidate_allowed(((cid, str(direction.get("token_id") or "")),))}
                if cid not in allowed_conditions:
                    self._candidate_rotation.pop(cid, None)
                cached = self._candidate_qualification_facts.get(cid)
                if isinstance(cached, Mapping):
                    self._candidate_qualification_facts[cid] = {**cached, "directions": [
                        d for d in cached.get("directions", ()) if self._candidate_allowed(
                            ((cid, str(d.get("market", {}).get("token_id") or "")),))]}
            queue = self._candidate_queue_state
            if isinstance(queue, Mapping):
                ids = (condition_id,) if condition_id else tuple(queue.get("directions_by_condition", {}))
                allowed = set(self._candidate_conditions(ids))
                blocked = set(ids) - allowed
                for key in ("queue_normal", "queue_backup"):
                    queue[key] = [r for r in queue.get(key, ()) if r.get("condition_id") not in blocked]
                for key in ("directions_by_condition", "metadata_by_condition", "reward_market_by_condition"):
                    values = queue.get(key, {})
                    for cid in blocked:
                        values.pop(cid, None)
                    if key == "directions_by_condition":
                        for cid in allowed:
                            if isinstance(values, LPDirectionIndex):
                                values.filter_tokens(cid, lambda token: self._candidate_allowed(((cid, token),)))
                            else:
                                values[cid] = [d for d in values.get(cid, ()) if self._candidate_allowed(
                                    ((cid, str(d.get("market", {}).get("token_id") or "")),))]
                self._candidate_queue_condition_ids = tuple(cid for cid in self._candidate_queue_condition_ids if cid not in blocked)
                for row in (*queue.get("queue_normal", ()), *queue.get("queue_backup", ())):
                    cid, token = str(row.get("condition_id") or ""), str(row.get("token_id") or "")
                    if cid in blocked or self._candidate_allowed(((cid, token),)):
                        continue
                    # Reuse the pure queue projection for the surviving direction;
                    # old batch holders see the corrected identity as well.
                    from .polymarket_lp_views import lp_trial_candidates
                    projected = lp_trial_candidates(
                        queue.get("directions_by_condition", {}).get(cid, ()),
                        competition={cid: row.get("competition")},
                        account_budget_facts=queue.get("queue_funnel", {}).get("budget"), now=self._now(),
                    )
                    replacements = (*projected.get("queue_normal", ()), *projected.get("queue_backup", ()))
                    if replacements:
                        row.clear()
                        row.update(replacements[0])
                    self._candidate_queue_state = None
            if condition_id:
                # Rebuild derived directions lazily; raw prepared facts stay immutable.
                self._candidate_queue_state = None
            evict = getattr(self.exchange, "evict_lp_candidate_metadata", None)
            if callable(evict) and (condition_id or prepared):
                evict(condition_ids=(condition_id,) if condition_id else None, now=self._now())

    def set_mutation_guard(self, guard: Callable[..., bool] | None) -> None:
        """Attach the existing execution breaker to exchange writes."""

        self._mutation_guard = guard

    def track_lp_account_round(self, token: object) -> None:
        """Register an externally owned round for trade invalidation."""

        begin = getattr(self.exchange, "lp_account_round_begin", None)
        if callable(begin):
            with self._lp_account_rounds_lock:
                self._lp_account_rounds.add(token)

    def untrack_lp_account_round(self, token: object) -> None:
        with self._lp_account_rounds_lock:
            self._lp_account_rounds.discard(token)

    def _invalidate_lp_account_round(self, session_id: str) -> None:
        """Invalidate the shared bundle after any durable trade fence."""

        del session_id
        invalidate = getattr(self.exchange, "lp_account_round_invalidate", None)
        if callable(invalidate):
            with self._lp_account_rounds_lock:
                tokens = tuple(self._lp_account_rounds)
            for token in tokens:
                invalidate(token)

    def _invalidate_lp_trade_generation(self, expected: int) -> bool:
        """Advance the shared DB fence from exact newer account evidence."""

        advance = getattr(self.store, "lp_advance_trade_generation", None)
        if not callable(advance):
            return False
        # The DB conditional advance is authoritative.  Do not serialize it
        # behind strategy work: urgent off-lock actions may legitimately be
        # in flight while newer evidence arrives.
        with self._lp_account_rounds_lock:
            if not advance(expected):
                return False
            tokens = tuple(self._lp_account_rounds)
        invalidate = getattr(self.exchange, "lp_account_round_invalidate", None)
        if callable(invalidate):
            for token in tokens:
                invalidate(token)
        return True

    def set_protection_notifier(self, callback: Callable[..., object] | None) -> None:
        """Attach the two-channel (feishu + xiaoai) protection notifier."""

        self._protection_notifier = callback

    def _publish_prepared_inputs(
        self,
        catalog: Mapping[str, object],
        metadata: Mapping[str, object],
        *,
        state: str,
        exclusion_revision: int | None = None,
        generation: int | None = None,
    ) -> bool:
        raw_markets = catalog.get("markets")
        if (
            isinstance(raw_markets, (list, tuple, LPReadRows))
            and not raw_markets
            and not (
                catalog.get("state") == "known"
                and catalog.get("complete") is True
            )
        ):
            return False
        # Private copies preserve the exact generation and receipt stamps, but
        # do not keep the whole universe's detailed Python objects resident.
        # Encode before the publication lock so readers never wait on disk I/O.
        prepared = {
            "catalog": MappingProxyType({
                **deepcopy({key: value for key, value in catalog.items() if key != "markets"}),
                "markets": deepcopy(raw_markets) if isinstance(raw_markets, LPReadRows)
                else LPReadRows(row for row in (raw_markets or ()) if isinstance(row, Mapping)),
            }),
            "metadata": deepcopy(metadata) if isinstance(metadata, LPReadScratch)
                else LPReadScratch(metadata),
            "state": state,
            "preparation_generation": generation,
        }
        with self._candidate_state_lock:
            global_fence = self.preparation_snapshot().get("global_recovery_generation") if generation is not None else None
            if type(global_fence) is int and generation is not None and global_fence > generation:
                return False
            if self.exclusions_enabled and exclusion_revision != self._candidate_exclusion_revision:
                return False
            self._prepared_inputs = prepared
            # Issue #157: prepared inputs changed — the cached exploration
            # queues and direction facts are stale and get rebuilt lazily.
            self._prepared_inputs_version += 1
            self._candidate_queue_state = None
            self._evict_excluded_candidates(prepared=True)

        return True

    def _prepared_input_snapshot(self) -> dict[str, object] | None:
        with self._candidate_state_lock:
            prepared = self._prepared_inputs
            if isinstance(prepared, Mapping) and prepared.get("preparation_generation") is not None:
                global_fence = self.preparation_snapshot().get("global_recovery_generation")
                if type(global_fence) is int and global_fence > prepared["preparation_generation"]:
                    return None
            return {**prepared, "metadata": MappingProxyType(prepared["metadata"])} if isinstance(prepared, Mapping) else None

    def _preparation_priority_order(
        self, condition_ids: Sequence[str]
    ) -> tuple[str, ...]:
        """Order preparation from durable/session exposure to background."""

        ordered = tuple(
            dict.fromkeys(
                str(value).strip() for value in condition_ids if str(value).strip()
            )
        )
        if not ordered:
            return ()
        rank = {condition_id: 2 for condition_id in ordered}
        position_markers = (
            "position",
            "position_size",
            "open_order",
            "open_orders",
            "open_order_count",
            "exposure",
            "in_position",
            "has_open_orders",
        )
        with self._candidate_state_lock:
            snapshot = deepcopy(self._candidate_snapshot)
            facts = deepcopy(self._candidate_qualification_facts)
        active_session_conditions: set[str] = set()
        active_sessions_reader = getattr(self.store, "lp_active_sessions", None)
        if callable(active_sessions_reader):
            try:
                active_sessions = active_sessions_reader()
            except Exception:
                active_sessions = None
            if isinstance(active_sessions, (list, tuple)):
                for active_session in active_sessions:
                    if not isinstance(active_session, Mapping):
                        continue
                    raw_condition = active_session.get("condition_id")
                    if not isinstance(raw_condition, str):
                        payload = active_session.get("payload")
                        if isinstance(payload, Mapping):
                            raw_condition = payload.get("condition_id")
                    if isinstance(raw_condition, str) and raw_condition.strip() in rank:
                        active_session_conditions.add(raw_condition.strip())
        pool_rows: tuple[Mapping[str, object], ...] = tuple()
        with self._candidate_state_lock:
            pool_rows = tuple(
                row
                for row in self._candidate_pool.values()
                if isinstance(row, Mapping)
            )
        for field in ("selected_results", "recommendations", "candidates"):
            rows: object = snapshot.get(field)
            if field == "candidates" and pool_rows:
                # Issue #157: the rolling pool is the live row source; its
                # rows join the persisted selected_results for ranking.
                rows = pool_rows
            if not isinstance(rows, (list, tuple)):
                continue
            for row in rows:
                if not isinstance(row, Mapping):
                    continue
                condition_id = str(row.get("condition_id") or "").strip()
                if condition_id not in rank:
                    continue
                if any(
                    key in row
                    and row.get(key) not in (None, False, 0, "", (), [], {})
                    for key in position_markers
                ):
                    rank[condition_id] = 0
                elif rank[condition_id] > 1:
                    rank[condition_id] = 1
        if isinstance(facts, Mapping):
            for condition_id, fact in facts.items():
                condition = str(condition_id).strip()
                if condition not in rank or not isinstance(fact, Mapping):
                    continue
                account = fact.get("account")
                if not isinstance(account, Mapping):
                    continue
                positions = account.get("positions")
                open_orders = account.get("open_orders")
                if (
                    isinstance(positions, (list, tuple))
                    and positions
                    or isinstance(open_orders, (list, tuple))
                    and open_orders
                ):
                    rank[condition] = 0
        for active_session_condition in active_session_conditions:
            rank[active_session_condition] = 0
        order_index = {condition_id: index for index, condition_id in enumerate(ordered)}
        return tuple(
            sorted(ordered, key=lambda condition_id: (rank[condition_id], order_index[condition_id]))
        )

    @staticmethod
    def _new_preparation_state() -> dict[str, object]:
        return {
            "state": "idle",
            "stage": "history",
            "generation": 1,
            "attempt": 0,
            "failure_count": 0,
            "paused": False,
            "alert_attempted": False,
            "alert_state": None,
            "last_attempt_at": None,
            "last_success_at": None,
            "last_failure_at": None,
            "last_progress_at": None,
            "next_retry_at": None,
            "next_probe_at": None,
            "last_probe_at": None,
            "last_probe_state": None,
            "last_probe_stage": None,
            "probe_states": {},
            "probe_cursor": 0,
            "retry_after_seconds": None,
            "last_error_chain": (),
            "last_error_status": None,
            "last_error_category": None,
            "fault_started_at": None,
            "fault_alert_attempts": 0,
            "fault_alert_state": None,
            "fault_alert_next_at": None,
            "fault_alert_sent_at": None,
            "recovery_alert_state": None,
            "recovery_alert_attempts": 0,
            "recovery_alert_next_at": None,
            "recovery_alert_claimed_at": None,
            "recovery_alert_sent_at": None,
            "completed_count": 0,
            "total_count": 0,
            "metadata_completed_count": 0,
            "metadata_total_count": 0,
            "last_error": None,
        }

    def _restore_preparation(self) -> None:
        reader = getattr(self.store, "lp_preparation", None)
        saved: object = None
        if callable(reader):
            try:
                saved = reader()
            except Exception:
                saved = None
        with self._preparation_lock:
            if isinstance(saved, Mapping):
                state = self._new_preparation_state()
                state.update(deepcopy(dict(saved)))
                self._preparation = state
            else:
                self._preparation = self._new_preparation_state()

    def preparation_snapshot(self) -> dict[str, object]:
        """Return the small durable preparation projection."""

        reader = getattr(self.store, "lp_preparation", None)
        saved: object = None
        if callable(reader):
            try:
                saved = reader()
            except Exception:
                saved = None
        with self._preparation_lock:
            if isinstance(saved, Mapping):
                state = self._new_preparation_state()
                state.update(deepcopy(dict(saved)))
                self._preparation = state
            result = deepcopy(self._preparation or self._new_preparation_state())
        summary_reader = getattr(self.store, "lp_preparation_item_summary", None)
        if callable(summary_reader):
            try:
                summary = summary_reader(limit=5)
            except Exception:
                summary = None
            if isinstance(summary, Mapping):
                result.update(deepcopy(dict(summary)))
        return result

    def _save_preparation(
        self,
        updates: Mapping[str, object],
        *,
        expected_generation: int | None = None,
    ) -> dict[str, object]:
        with self._preparation_lock:
            current = self.preparation_snapshot()
            merged = {**current, **dict(updates)}
            if expected_generation is not None and "generation" not in updates:
                merged["generation"] = expected_generation
            writer = getattr(self.store, "lp_save_preparation", None)
            reader = getattr(self.store, "lp_preparation", None)
            existing = reader() if callable(reader) else None
            store_expected = (
                expected_generation if isinstance(existing, Mapping) else None
            )
            saved = (
                writer(merged, expected_generation=store_expected)
                if callable(writer)
                else merged
            )
            if isinstance(saved, Mapping):
                self._preparation = deepcopy(dict(saved))
                return deepcopy(dict(saved))
            latest = self.preparation_snapshot()
            self._preparation = latest
            return latest

    def _claim_fault_alert_if_due(
        self, state: Mapping[str, object]
    ) -> dict[str, object] | None:
        """Claim one delayed transient-fault notification for this episode."""

        if state.get("fault_alert_state") in {"claimed", "sent"}:
            return None
        started = state.get("fault_started_at")
        try:
            started_at = _timestamp(started, name="fault_started_at")
        except ValueError:
            return None
        try:
            next_at = _timestamp(
                state.get("fault_alert_next_at"), name="fault_alert_next_at"
            )
        except ValueError:
            next_at = started_at + timedelta(seconds=300)
        now = self._now().astimezone(UTC)
        if now < next_at:
            return None
        generation = state.get("generation")
        if type(generation) is not int or generation < 1:
            generation = 1
        attempts = state.get("fault_alert_attempts")
        attempts = attempts if type(attempts) is int and attempts >= 0 else 0
        claimed = self._save_preparation(
            {
                "fault_alert_attempts": attempts + 1,
                "fault_alert_state": "claimed",
                "fault_alert_next_at": None,
            },
            expected_generation=generation,
        )
        if claimed.get("generation") != generation or claimed.get("fault_alert_state") != "claimed":
            return None
        claimed["fault_alert_claimed_now"] = True
        return claimed

    def _claim_recovery_alert_if_validated(
        self,
        state: Mapping[str, object],
        *,
        outcome: str,
    ) -> dict[str, object] | None:
        """Claim recovery notification only after an affected full read wins."""

        if outcome != "success" or state.get("state") != "ready":
            return None
        if state.get("fault_alert_state") != "sent":
            return None
        if state.get("recovery_alert_state") in {"claimed", "sent"}:
            return None
        try:
            fault_started = _timestamp(
                state.get("fault_started_at"), name="fault_started_at"
            )
            last_success = _timestamp(
                state.get("last_success_at"), name="last_success_at"
            )
        except ValueError:
            return None
        if last_success < fault_started:
            return None
        if state.get("recovery_alert_state") == "failed":
            try:
                next_at = _timestamp(
                    state.get("recovery_alert_next_at"), name="recovery_alert_next_at"
                )
            except ValueError:
                next_at = None
            if next_at is not None and self._now().astimezone(UTC) < next_at:
                return None
        generation = state.get("generation")
        if type(generation) is not int or generation < 1:
            generation = 1
        attempts = state.get("recovery_alert_attempts")
        attempts = attempts if type(attempts) is int and attempts >= 0 else 0
        claimed = self._save_preparation(
            {
                "recovery_alert_attempts": attempts + 1,
                "recovery_alert_state": "claimed",
                "recovery_alert_next_at": None,
                "recovery_alert_claimed_at": self._now().astimezone(UTC),
            },
            expected_generation=generation,
        )
        if claimed.get("generation") != generation or claimed.get("recovery_alert_state") != "claimed":
            return None
        claimed["recovery_alert_claimed_now"] = True
        return claimed

    def claim_due_preparation_recovery_alert(self) -> dict[str, object] | None:
        """Claim a due validated recovery notice without reading the exchange."""

        state = self.preparation_snapshot()
        if state.get("recovery_alert_state") != "failed":
            return None
        claimed = self._claim_recovery_alert_if_validated(state, outcome="success")
        if not isinstance(claimed, Mapping):
            return None
        return self._preparation_result(
            claimed,
            outcome="success",
            display_state="ready",
        )

    def _preparation_result(
        self,
        state: Mapping[str, object],
        *,
        outcome: str,
        reason: str | None = None,
        display_state: str | None = None,
        alert_pending: bool = False,
    ) -> dict[str, object]:
        claimed_fault = self._claim_fault_alert_if_due(state)
        if isinstance(claimed_fault, Mapping):
            state = claimed_fault
            alert_pending = True
        claimed_recovery = self._claim_recovery_alert_if_validated(
            state, outcome=outcome
        )
        if isinstance(claimed_recovery, Mapping):
            state = claimed_recovery
        result: dict[str, object] = {
            "state": display_state or str(state.get("state") or "unknown"),
            "preparation_outcome": outcome,
            "preparation": deepcopy(dict(state)),
            "target_count": int(state.get("total_count") or 0),
            "updated_count": 0,
            "unknown_count": 0,
            "request_count": 0,
        }
        summary_reader = getattr(self.store, "lp_preparation_item_summary", None)
        if callable(summary_reader):
            try:
                summary = summary_reader(limit=5)
            except Exception:
                summary = None
            if isinstance(summary, Mapping):
                result["preparation"].update(deepcopy(dict(summary)))
        if reason:
            result["reason"] = reason
        if alert_pending or state.get("fault_alert_claimed_now") is True:
            result["alert_pending"] = True
        if state.get("recovery_alert_claimed_now") is True:
            result["recovery_alert_pending"] = True
        return result

    @staticmethod
    def _safe_error_type(value: object) -> str:
        text = str(value or "unknown_error")
        return text if text.replace("_", "").isalnum() and text[0:1].isalpha() else "unknown_error"

    @classmethod
    def _preparation_error_details(
        cls, value: object
    ) -> tuple[str, bool, tuple[str, ...], int | None, str]:
        """Normalize safe adapter facts for retry policy and operator status."""

        raw_chain: list[object] = []
        status: int | None = None
        if isinstance(value, BaseException):
            value = {
                "error_type": type(value).__name__,
                "error_chain": _safe_read_error_chain(value),
                **_safe_sqlite_error_facts(value),
            }
        if isinstance(value, Mapping):
            raw_chain_value = value.get("error_chain", value.get("error_types"))
            if isinstance(raw_chain_value, Sequence) and not isinstance(
                raw_chain_value, (str, bytes)
            ):
                raw_chain.extend(raw_chain_value)
            raw_chain.append(
                value.get("error_type", value.get("error", value.get("reason")))
            )
            raw_status = value.get("status")
            if type(raw_status) is int and 100 <= raw_status <= 599:
                status = raw_status
            elif isinstance(raw_status, str) and raw_status.isdigit():
                parsed_status = int(raw_status)
                if 100 <= parsed_status <= 599:
                    status = parsed_status
        else:
            raw_chain.append(value)

        chain_values: list[str] = []
        for raw in raw_chain:
            safe = cls._safe_error_type(raw)
            if safe != "unknown_error" and safe not in chain_values:
                chain_values.append(safe)
        chain = tuple(chain_values)
        if not chain:
            chain = ("unknown_error",)
        joined = " ".join(chain).casefold()
        operator_markers = (
            "auth",
            "cert",
            "ssl",
            "credential",
            "config",
            "schema",
            "forbidden",
            "unauthor",
            "requestrejected",
            "invalid",
        )
        operator_blocker = any(marker in joined for marker in operator_markers)
        automatically_recoverable = False
        # A successful header does not make a later body/page timeout permanent.
        if status is not None and not 200 <= status < 300:
            if status in {401, 403} or 400 <= status < 500 and status != 429:
                operator_blocker = True
            elif status == 429 or 500 <= status <= 599:
                automatically_recoverable = True
            else:
                automatically_recoverable = False
        else:
            code = chain[0].casefold()
            automatically_recoverable = code in {
                "timeout",
                "timeouterror",
                "transporterror",
                "connectionerror",
                "connectionreseterror",
                "readerror",
                "incompleteread",
                "proxyerror",
                "network",
                "unavailable",
                "ratelimiterror",
                "http429",
                "status429",
                "http500",
                "http502",
                "http503",
                "http504",
                "history_catalog_incomplete",
            } or code.startswith("market_read_") and any(
                marker in code
                for marker in (
                    "transport",
                    "timeout",
                    "connection",
                    "proxy",
                    "readerror",
                    "ratelimit",
                    "status5",
                    "http5",
                )
            )
        sqlite_code = _safe_sqlite_error_facts(value).get("sqlite_errorcode")
        if sqlite_code is not None:
            automatically_recoverable = (sqlite_code & 0xff) in {
                sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED
            }
        elif any(name in chain for name in ("OperationalError", "DatabaseError", "IntegrityError")):
            automatically_recoverable = False
        automatically_recoverable = automatically_recoverable and not operator_blocker
        category = (
            "operator_attention"
            if operator_blocker or not automatically_recoverable
            else "transient"
        )
        return chain[0], automatically_recoverable, chain, status, category

    @classmethod
    def _automatic_recovery_error(cls, value: object) -> bool:
        """Return whether a safe read result can be retried automatically."""

        return cls._preparation_error_details(value)[1]

    @classmethod
    def _raise_preparation_database_failure(cls, value: object) -> None:
        error, _, chain, status, _ = cls._preparation_error_details(value)
        sqlite_facts = _safe_sqlite_error_facts(value)
        if sqlite_facts or any(name in chain for name in (
            "OperationalError", "DatabaseError", "IntegrityError"
        )):
            raise _PreparationDatabaseFailure({
                "error_type": error, "error_chain": chain, "status": status,
                **sqlite_facts,
            })

    @staticmethod
    def _retry_after_deadline(
        now: datetime, value: object
    ) -> tuple[datetime | None, int | float | None]:
        """Convert safe adapter pacing facts into a durable absolute deadline."""

        retry_seconds: int | float | None = None
        retry_at: datetime | None = None
        if isinstance(value, Mapping):
            raw_seconds = value.get("retry_after_seconds")
            if isinstance(raw_seconds, (int, float)) and not isinstance(
                raw_seconds, bool
            ) and math.isfinite(float(raw_seconds)) and raw_seconds >= 0:
                retry_seconds = raw_seconds
            if retry_seconds is None and value.get("retry_after_at") is not None:
                try:
                    retry_at = _timestamp(
                        value.get("retry_after_at"), name="retry_after_at"
                    )
                except ValueError:
                    retry_at = None
        if retry_seconds is not None:
            return now + timedelta(seconds=float(retry_seconds)), retry_seconds
        if retry_at is not None and retry_at >= now:
            delta = max(0.0, (retry_at - now).total_seconds())
            return retry_at, int(delta) if delta.is_integer() else delta
        return None, None

    def _run_preparation_probe(
        self,
        now: datetime,
        preparation: Mapping[str, object],
        *,
        stop_event: threading.Event | None = None,
        stage: str | None = None,
        condition_ids: Sequence[str] = (),
    ) -> tuple[dict[str, object], bool]:
        """Run one bounded dependency probe when its durable deadline is due.

        The boolean reports a healthy transition from an unhealthy probe.  A
        transition may wake one full preparation attempt before its normal
        backoff deadline, while repeated healthy probes leave that deadline
        intact so a failing catalog cannot turn into a scan loop.
        """

        try:
            next_probe_at = _timestamp(
                preparation.get("next_probe_at"), name="next_probe_at"
            )
        except ValueError:
            next_probe_at = now
        if now < next_probe_at:
            return deepcopy(dict(preparation)), False

        generation = preparation.get("generation")
        generation = generation if type(generation) is int and generation >= 1 else 1
        scoped_condition_ids = tuple(
            str(value).strip() for value in condition_ids if str(value).strip()
        )
        probe_condition_ids = self._candidate_conditions(tuple(
            str(value).strip() for value in condition_ids if str(value).strip()
        ), now=now)
        if self.exclusions_enabled and condition_ids and not probe_condition_ids:
            return deepcopy(dict(preparation)), False
        next_probe_cursor = preparation.get("probe_cursor")
        if type(next_probe_cursor) is not int or next_probe_cursor < 0:
            next_probe_cursor = 0
        if stage == "history" and probe_condition_ids:
            selected_index = next_probe_cursor % len(probe_condition_ids)
            probe_condition_ids = (probe_condition_ids[selected_index],)
            next_probe_cursor = (selected_index + 1) % len(scoped_condition_ids)
        selected_condition_id = (
            probe_condition_ids[0] if len(probe_condition_ids) == 1 else None
        )
        raw_probe_states = preparation.get("probe_states")
        probe_states: dict[str, dict[str, str]] = {}
        if isinstance(raw_probe_states, Mapping):
            for raw_stage, raw_states in raw_probe_states.items():
                if not isinstance(raw_stage, str) or not isinstance(raw_states, Mapping):
                    continue
                probe_states[raw_stage] = {
                    str(condition_id): str(state)
                    for condition_id, state in raw_states.items()
                    if str(condition_id).strip() and isinstance(state, str)
                }
        probe_stage = str(stage or preparation.get("stage") or "unknown")
        if selected_condition_id is not None:
            previous_probe_state = probe_states.get(probe_stage, {}).get(
                selected_condition_id, ""
            )
        else:
            previous_probe_state = str(preparation.get("last_probe_state") or "")
        reader = getattr(self.exchange, "lp_preparation_probe", None)
        probe: Mapping[str, object]
        if not callable(reader):
            probe = {"state": "unsupported", "complete": False}
        else:
            try:
                try:
                    value = reader(
                        stop_event=stop_event,
                        stage=stage,
                        condition_ids=probe_condition_ids,
                    )
                except TypeError:
                    # Existing exchange doubles and adapters may still expose
                    # the original rewards-only probe signature.
                    value = reader(stop_event=stop_event)
                probe = value if isinstance(value, Mapping) else {}
            except Exception as exc:
                probe = {
                    "state": "unknown",
                    "complete": False,
                    "error_type": type(exc).__name__,
                }

        healthy = probe.get("state") == "healthy" and probe.get("complete") is True
        probe_state = "healthy" if healthy else str(probe.get("state") or "unknown")
        healthy_transition = healthy and previous_probe_state != "healthy"
        retry_after = probe.get("retry_after_seconds")
        retry_after_seconds: int | float | None = None
        if isinstance(retry_after, (int, float)) and not isinstance(retry_after, bool):
            if retry_after >= 0 and math.isfinite(float(retry_after)):
                retry_after_seconds = retry_after
        if retry_after_seconds is None:
            try:
                retry_at = _timestamp(
                    probe.get("retry_after_at"), name="retry_after_at"
                )
            except ValueError:
                retry_at = None
            if retry_at is not None:
                retry_delta = (retry_at - now).total_seconds()
                if retry_delta >= 0 and math.isfinite(retry_delta):
                    retry_after_seconds = retry_delta
        probe_interval = max(60, int(retry_after_seconds or 0))
        updates: dict[str, object] = {
            "last_probe_at": now,
            "last_probe_state": probe_state,
            "last_probe_stage": stage or preparation.get("stage"),
            "probe_cursor": next_probe_cursor,
            "next_probe_at": now + timedelta(seconds=probe_interval),
            "retry_after_seconds": retry_after_seconds,
        }
        if selected_condition_id is not None:
            stage_states = dict(probe_states.get(probe_stage, {}))
            if scoped_condition_ids:
                allowed_condition_ids = set(scoped_condition_ids)
                stage_states = {
                    condition_id: state
                    for condition_id, state in stage_states.items()
                    if condition_id in allowed_condition_ids
                }
            stage_states[selected_condition_id] = probe_state
            probe_states[probe_stage] = stage_states
            updates["probe_states"] = probe_states
        if retry_after_seconds is not None:
            try:
                retry_at = _timestamp(
                    preparation.get("next_retry_at"), name="next_retry_at"
                )
            except ValueError:
                retry_at = now
            retry_after_at = now + timedelta(seconds=retry_after_seconds)
            if retry_after_at > retry_at:
                # Server pacing applies to full reads as well as cheap probes;
                # retain the existing backoff when it is already later.
                updates["next_retry_at"] = retry_after_at
        if healthy_transition:
            if retry_after_seconds is None:
                updates["next_retry_at"] = now
            updates["state"] = "waiting_retry"
            updates["paused"] = False
            waker = getattr(self.store, "lp_wake_preparation_retries", None)
            if callable(waker) and probe_condition_ids:
                try:
                    waker(
                        condition_ids=probe_condition_ids,
                        stage=stage,
                        now=now,
                        generation=generation,
                    )
                except Exception:
                    # A probe must never turn into a data-path failure merely
                    # because durable wake-up is unavailable.
                    pass
        saved = self._save_preparation(updates, expected_generation=generation)
        return saved, healthy_transition

    @classmethod
    def _safe_selected_reward_reasons(
        cls, value: Mapping[str, object]
    ) -> list[str]:
        """Keep upstream selected-reward provenance without raw transport text."""

        reasons: list[str] = []
        raw_codes = value.get("reason_codes")
        if isinstance(raw_codes, str):
            raw_codes = (raw_codes,)
        if isinstance(raw_codes, Sequence) and not isinstance(raw_codes, (str, bytes)):
            for raw_code in raw_codes:
                code = cls._safe_error_type(raw_code)
                if code != "unknown_error" and code not in reasons:
                    reasons.append(code)
        error_type = value.get("error_type")
        if error_type is not None:
            safe_error = cls._safe_error_type(error_type)
            if safe_error != "unknown_error":
                code = f"reward_error_{safe_error}"
                if code not in reasons:
                    reasons.append(code)
        status = value.get("status")
        if type(status) is int and 100 <= status <= 599:
            code = f"reward_http_status_{status}"
            if code not in reasons:
                reasons.append(code)
        elif isinstance(status, str):
            safe_status = cls._safe_error_type(status)
            if safe_status != "unknown_error":
                code = f"reward_status_{safe_status}"
                if code not in reasons:
                    reasons.append(code)
        return reasons

    def _begin_preparation(self, now: datetime, *, generation: int) -> dict[str, object]:
        current = self.preparation_snapshot()
        global_fence = current.get("global_recovery_generation")
        if type(global_fence) is int and global_fence > generation:
            return current
        attempt = current.get("attempt")
        attempt = attempt if type(attempt) is int and attempt >= 0 else 0
        failures = current.get("failure_count")
        failures = failures if type(failures) is int and failures >= 0 else 0
        return self._save_preparation(
            {
                "state": "preparing",
                "stage": "catalog",
                "attempt": attempt + 1,
                "last_attempt_at": now,
                "next_retry_at": None,
                "next_probe_at": None,
                "last_error": None,
                "alert_attempted": False,
                "alert_state": None,
            },
            expected_generation=generation,
        )

    def _preparation_failure(
        self,
        now: datetime,
        *,
        stage: str,
        error_type: object,
        expected_generation: int | None = None,
    ) -> dict[str, object]:
        current = self.preparation_snapshot()
        global_fence = current.get("global_recovery_generation")
        if type(global_fence) is int and expected_generation is not None and global_fence > expected_generation:
            return current
        generation = current.get("generation")
        generation = generation if type(generation) is int and generation >= 1 else 1
        failures = current.get("failure_count")
        failures = failures if type(failures) is int and failures >= 0 else 0
        failures += 1
        safe_error, recoverable, error_chain, error_status, error_category = (
            self._preparation_error_details(error_type)
        )
        paused = not recoverable
        delay_index = min(
            max(failures - 1, 0), len(_LP_PREPARATION_RETRY_DELAYS_SECONDS) - 1
        )
        retry_at = (
            None
            if paused
            else now
            + timedelta(seconds=_LP_PREPARATION_RETRY_DELAYS_SECONDS[delay_index])
        )
        probe_at = (
            None if paused else now + timedelta(seconds=60)
        )
        retry_after_at, retry_after_seconds = self._retry_after_deadline(
            now, error_type
        )
        if not paused and retry_after_at is not None:
            retry_at = max(retry_at, retry_after_at)  # type: ignore[arg-type]
            probe_at = max(probe_at, retry_after_at)  # type: ignore[arg-type]
        fault_started_at: object = current.get("fault_started_at")
        fault_alert_state = current.get("fault_alert_state")
        try:
            prior_fault_started = _timestamp(
                fault_started_at, name="fault_started_at"
            )
        except ValueError:
            prior_fault_started = None
        try:
            prior_success = _timestamp(
                current.get("last_success_at"), name="last_success_at"
            )
        except ValueError:
            prior_success = None
        if prior_fault_started is None or (
            prior_success is not None and prior_success >= prior_fault_started
        ):
            fault_started_at = now
            fault_alert_state = None
            fault_alert_attempts = 0
            fault_alert_next_at: object = now + timedelta(seconds=300)
            fault_alert_sent_at: object = None
            recovery_alert_state: object = None
            recovery_alert_claimed_at: object = None
            recovery_alert_sent_at: object = None
        else:
            fault_alert_attempts = current.get("fault_alert_attempts")
            if type(fault_alert_attempts) is not int or fault_alert_attempts < 0:
                fault_alert_attempts = 0
            fault_alert_next_at = current.get("fault_alert_next_at")
            fault_alert_sent_at = current.get("fault_alert_sent_at")
            recovery_alert_state = current.get("recovery_alert_state")
            recovery_alert_claimed_at = current.get("recovery_alert_claimed_at")
            recovery_alert_sent_at = current.get("recovery_alert_sent_at")
        state = self._save_preparation(
            {
                "state": "paused" if paused else "waiting_retry",
                "stage": stage,
                "failure_count": failures,
                "paused": paused,
                "last_failure_at": now,
                "last_error": safe_error,
                "last_error_chain": error_chain,
                "last_error_status": error_status,
                "last_error_category": error_category,
                "last_sqlite_errorcode": _safe_sqlite_error_facts(error_type).get("sqlite_errorcode"),
                "last_sqlite_errorname": _safe_sqlite_error_facts(error_type).get("sqlite_errorname"),
                "next_retry_at": retry_at,
                "next_probe_at": probe_at,
                "retry_after_seconds": retry_after_seconds,
                "fault_started_at": fault_started_at,
                "fault_alert_attempts": fault_alert_attempts,
                "fault_alert_state": fault_alert_state,
                "fault_alert_next_at": fault_alert_next_at,
                "fault_alert_sent_at": fault_alert_sent_at,
                "recovery_alert_state": recovery_alert_state,
                "recovery_alert_claimed_at": recovery_alert_claimed_at,
                "recovery_alert_sent_at": recovery_alert_sent_at,
                "alert_attempted": False if not paused else current.get("alert_attempted") is True,
                "alert_state": None if not paused else current.get("alert_state"),
            },
            expected_generation=generation,
        )
        if paused and state.get("alert_attempted") is not True:
            claimer = getattr(self.store, "lp_claim_preparation_alert", None)
            claimed = claimer(expected_generation=generation) if callable(claimer) else state
            if isinstance(claimed, Mapping):
                with self._preparation_lock:
                    self._preparation = deepcopy(dict(claimed))
                state = deepcopy(dict(claimed))
        return state

    def _ensure_fault_episode(self, now: datetime) -> dict[str, object]:
        """Start a coalesced fault episode for persistent market failures."""

        current = self.preparation_snapshot()
        try:
            started = _timestamp(
                current.get("fault_started_at"), name="fault_started_at"
            )
        except ValueError:
            started = None
        try:
            succeeded = _timestamp(
                current.get("last_success_at"), name="last_success_at"
            )
        except ValueError:
            succeeded = None
        if started is not None and (succeeded is None or succeeded < started):
            return {}
        return {
            "fault_started_at": now,
            "fault_alert_attempts": 0,
            "fault_alert_state": None,
            "fault_alert_next_at": now + timedelta(seconds=300),
            "fault_alert_sent_at": None,
            "recovery_alert_state": None,
            "recovery_alert_attempts": 0,
            "recovery_alert_next_at": None,
            "recovery_alert_claimed_at": None,
            "recovery_alert_sent_at": None,
        }

    def _clear_unacknowledged_fault_episode(self) -> dict[str, object]:
        """Drop a transient fault that recovered before its notice was sent."""

        current = self.preparation_snapshot()
        if current.get("fault_alert_state") in {"sent", "claimed", "failed"}:
            return {}
        return {
            "fault_started_at": None,
            "fault_alert_attempts": 0,
            "fault_alert_state": None,
            "fault_alert_next_at": None,
            "fault_alert_sent_at": None,
            "recovery_alert_state": None,
            "recovery_alert_attempts": 0,
            "recovery_alert_next_at": None,
            "recovery_alert_claimed_at": None,
            "recovery_alert_sent_at": None,
        }

    def recover_preparation(
        self, *, scope: str = "all", expected_generation: int | None = None
    ) -> dict[str, object]:
        """Explicitly re-arm a paused preparation cycle."""

        if not isinstance(scope, str) or scope not in {"all", "global"}:
            raise ValueError("preparation recovery scope must be all or global")
        if scope == "global" and (
            type(expected_generation) is not int or expected_generation < 1
        ):
            raise ValueError("positive expected preparation generation required")
        if scope == "all" and expected_generation is not None:
            raise ValueError("expected generation requires global recovery scope")
        current = self.preparation_snapshot()
        item_recoverer = getattr(self.store, "lp_recover_preparation_items", None)
        if scope == "global":
            if not callable(item_recoverer):
                raise RuntimeError("durable preparation recovery is unavailable")
            with self._candidate_state_lock:
                item_recoverer((), expected_generation=expected_generation)
                self._prepared_inputs = None
                self._prepared_inputs_version += 1
                self._candidate_queue_state = None
            return {**self.preparation_snapshot(), "recovered_condition_ids": []}
        recovered_items = item_recoverer() if callable(item_recoverer) else ()
        recovered_condition_ids = [
            str(item.get("condition_id"))
            for item in recovered_items
            if isinstance(item, Mapping)
            and str(item.get("condition_id") or "").strip()
        ]
        if current.get("paused") is not True and not recovered_condition_ids:
            return {**current, "recovered_condition_ids": []}
        generation = current.get("generation")
        generation = generation if type(generation) is int and generation >= 1 else 1
        recovered_state = (
            "partial"
            if recovered_condition_ids and current.get("state") != "paused"
            else "ready"
        )
        state = self._save_preparation(
            {
                "state": recovered_state,
                "stage": "catalog",
                "generation": generation + 1,
                "attempt": 0,
                "failure_count": 0,
                "paused": False,
                "alert_attempted": False,
                "alert_state": None,
                "last_error": None,
                "next_retry_at": None,
                "next_probe_at": None,
                "last_probe_at": None,
                "last_probe_state": None,
                "retry_after_seconds": None,
                "fault_started_at": None,
                "fault_alert_attempts": 0,
                "fault_alert_state": None,
                "fault_alert_next_at": None,
                "fault_alert_sent_at": None,
                "recovery_alert_state": None,
                "recovery_alert_attempts": 0,
                "recovery_alert_next_at": None,
                "recovery_alert_claimed_at": None,
                "recovery_alert_sent_at": None,
            },
            expected_generation=generation,
        )
        state["recovered_condition_ids"] = recovered_condition_ids
        return state

    def _claim_preparation_item_alerts(self) -> dict[str, object] | None:
        claimer = getattr(self.store, "lp_claim_preparation_item_alerts", None)
        if not callable(claimer):
            return None
        try:
            claimed = claimer(limit=5)
        except Exception:
            return None
        return dict(claimed) if isinstance(claimed, Mapping) else None

    def finish_preparation_alert(self, *, generation: int, success: bool) -> dict[str, object] | None:
        """Record the result of the already-claimed operator notification."""

        current = self.preparation_snapshot()
        if current.get("generation") != generation:
            return current
        if current.get("fault_alert_state") == "claimed":
            attempts = current.get("fault_alert_attempts")
            attempts = attempts if type(attempts) is int and attempts >= 1 else 1
            if success:
                updates = {
                    "fault_alert_state": "sent",
                    "fault_alert_next_at": None,
                    "fault_alert_sent_at": self._now().astimezone(UTC),
                    # Wake one affected full read so a validated recovery
                    # notice can follow this incident delivery.
                    "next_probe_at": self._now().astimezone(UTC)
                    + timedelta(seconds=60),
                }
            else:
                delay = _LP_PREPARATION_RETRY_DELAYS_SECONDS[
                    min(attempts - 1, len(_LP_PREPARATION_RETRY_DELAYS_SECONDS) - 1)
                ]
                updates = {
                    "fault_alert_state": "failed",
                    "fault_alert_next_at": self._now().astimezone(UTC)
                    + timedelta(seconds=delay),
                }
            saved_fault = self._save_preparation(
                updates, expected_generation=generation
            )
            if isinstance(saved_fault, Mapping):
                return dict(saved_fault)

        item_finisher = getattr(self.store, "lp_finish_preparation_item_alerts", None)
        if callable(item_finisher):
            try:
                item_finisher(success=success)
            except Exception:
                pass
        writer = getattr(self.store, "lp_finish_preparation_alert", None)
        if not callable(writer):
            return None
        saved = writer(generation=generation, success=success)
        if isinstance(saved, Mapping):
            with self._preparation_lock:
                self._preparation = deepcopy(dict(saved))
            return dict(saved)
        return None

    def finish_preparation_recovery(
        self, *, generation: int, success: bool
    ) -> dict[str, object] | None:
        """Record delivery of one validated recovery notification."""

        current = self.preparation_snapshot()
        if current.get("generation") != generation:
            return current
        if current.get("recovery_alert_state") != "claimed":
            return current
        attempts = current.get("recovery_alert_attempts")
        attempts = attempts if type(attempts) is int and attempts >= 1 else 1
        if success:
            next_at: object = None
        else:
            delay = _LP_PREPARATION_RETRY_DELAYS_SECONDS[
                min(attempts - 1, len(_LP_PREPARATION_RETRY_DELAYS_SECONDS) - 1)
            ]
            next_at = self._now().astimezone(UTC) + timedelta(seconds=delay)
        saved = self._save_preparation(
            {
                "recovery_alert_state": "sent" if success else "failed",
                "recovery_alert_next_at": next_at,
                "recovery_alert_sent_at": self._now().astimezone(UTC)
                if success
                else current.get("recovery_alert_sent_at"),
            },
            expected_generation=generation,
        )
        return saved if isinstance(saved, Mapping) else None

    def _lp_history_fact(
        self,
        condition_id: object,
        token_id: object,
        *,
        now: datetime,
    ) -> tuple[Mapping[str, object] | None, str | None]:
        """Read and judge one persisted history fact without network work."""

        from .polymarket_lp_views import lp_history_eligibility

        condition = str(condition_id or "").strip()
        token = str(token_id or "").strip()
        if not condition or not token:
            return None, "history_identity_mismatch"
        reader = getattr(self.store, "lp_price_history_summary", None)
        if not callable(reader):
            return None, "history_summary_unknown"
        try:
            summary = reader(condition, token, now=now)
        except TypeError:
            try:
                summary = reader(condition, token)
            except Exception:
                return None, "history_summary_unknown"
        except Exception:
            return None, "history_summary_unknown"
        reason = lp_history_eligibility(
            summary,
            now=now,
            condition_id=condition,
            token_id=token,
        )
        return (
            dict(summary) if isinstance(summary, Mapping) else None,
            reason,
        )

    def _candidate_history_reason(
        self, row: Mapping[str, object], *, now: datetime
    ) -> str | None:
        selected = row.get("selected_direction")
        if not isinstance(selected, Mapping):
            return None
        return self._lp_history_fact(
            row.get("condition_id"), selected.get("token_id"), now=now
        )[1]

    def _require_lp_history(
        self, request: Mapping[str, object], *, now: datetime
    ) -> None:
        """Fail closed on the one selected token's persisted history fact."""

        _summary, reason = self._lp_history_fact(
            request.get("condition_id"), request.get("token_id"), now=now
        )
        if reason is not None:
            raise ValueError(reason)

    def set_candidate_buy_price_level_reader(self, reader: Callable[[], int]) -> None:
        """Use the effective persisted Auto quote level for strategy estimates."""
        self._candidate_buy_price_level_reader = reader

    def _candidate_buy_price_level(self) -> int | None:
        reader = self._candidate_buy_price_level_reader
        if reader is None:
            return 1
        try:
            level = reader()
        except Exception:
            return None
        return level if type(level) is int and level in (1, 2) else None

    @staticmethod
    def _candidate_strategy_projection(
        row: Mapping[str, object], bid_level: int | None
    ) -> dict[str, object]:
        projected = deepcopy(dict(row))
        # Before level-aware estimates, all saved candidate estimates used
        # buy one. Preserve that provenance rather than relabeling on reload.
        estimated_level = row.get("estimate_buy_price_level", 1)
        if (bid_level is not None and type(estimated_level) is int
                and estimated_level == bid_level):
            return projected
        _apply_row_estimate_fields(projected, None)
        projected.update(state="unknown", verification="pending",
                         selected_direction=None, directions={},
                         estimate_reason_codes=["strategy_level_pending"])
        for field in ("realtime_price", "realtime_capital", "realtime_checked_at",
                      "estimated_exit_loss", "estimated_exit_loss_ratio"):
            projected[field] = None
        return projected

    def candidate_snapshot(self) -> dict[str, object]:
        """Project the rolling candidate pool without external reads.

        Issue #157: every valid pool row is one successful estimate with a
        five-minute validity computed against the current clock; rows are
        never degraded or cleared because a whole snapshot aged.  The top
        ten by the yield ranking key are published and the head is always
        the current recommendation — when it leaves the pool the next row
        takes its place automatically.
        """

        self._evict_excluded_candidates()
        bid_level = self._candidate_buy_price_level()
        with self._candidate_state_lock:
            pool = deepcopy(self._candidate_pool)
            snapshot = deepcopy(self._candidate_snapshot)
            funnel = deepcopy(self._candidate_funnel_totals)
            queue_funnel = deepcopy(self._candidate_queue_funnel)
            queue_condition_ids = self._candidate_queue_condition_ids
            rotation = deepcopy(self._candidate_rotation)
        with self._competition_lock:
            competition_state = {
                "state": self._competition_state.get("state"),
                "not_updated": list(self._competition_state.get("not_updated") or ()),
            }
        from .polymarket_lp_views import LP_TRIAL_CANDIDATE_LIMIT

        now = self._now()
        history_reasons: list[dict[str, object]] = []
        valid_rows: list[Mapping[str, object]] = []
        for row in pool.values():
            if not isinstance(row, Mapping) or _candidate_pool_row_expired(row, now):
                continue
            history_reason = self._candidate_history_reason(row, now=now)
            if history_reason is not None:
                history_reasons.append(
                    {
                        "market_id": str(row.get("market_id") or ""),
                        "condition_id": str(row.get("condition_id") or ""),
                        "code": history_reason,
                    }
                )
                continue
            valid_rows.append(self._candidate_strategy_projection(row, bid_level))
        valid_rows.sort(key=_candidate_yield_sort_key)
        published = []
        for row in valid_rows[:LP_TRIAL_CANDIDATE_LIMIT]:
            public_row = deepcopy(dict(row))
            public_row.pop("global_recovery_generation", None)
            published.append(public_row)
        valid_count = len(valid_rows)
        failed_count = sum(
            1 for row in valid_rows if row.get("refresh_failed") is True
        )
        # Issue #157 review R6: pending counts the current queue members
        # without a rotation attempt stamp directly.  The rotation outlives
        # the queue (markets leave, restarts restore it), so subtracting its
        # size from the queue total could underreport — even to zero — while
        # untried members remain.
        pending = 0
        for condition_id in queue_condition_ids:
            entry = rotation.get(condition_id)
            if (
                not isinstance(entry, Mapping)
                or entry.get("last_attempt_at") is None
            ):
                pending += 1
        # Scheduler hint for the exploration loop: zero while any queue
        # market is still untried or any tried market is out of backoff,
        # otherwise the seconds until the earliest backoff expiry.
        next_batch_wait = 0.0
        if pending <= 0:
            waits: list[float] = []
            for entry in rotation.values():
                if not isinstance(entry, Mapping):
                    continue
                failures = entry.get("failures")
                if not isinstance(failures, int) or failures <= 0:
                    waits = []
                    break
                last_attempt_at = _candidate_row_updated_at(
                    {"updated_at": entry.get("last_attempt_at")}
                )
                if last_attempt_at is None:
                    waits = []
                    break
                backoff = _CANDIDATE_MAINTENANCE_BACKOFF_SECONDS[
                    min(
                        failures - 1,
                        len(_CANDIDATE_MAINTENANCE_BACKOFF_SECONDS) - 1,
                    )
                ]
                remaining = (
                    last_attempt_at
                    + timedelta(seconds=float(backoff))
                    - now
                ).total_seconds()
                waits.append(max(0.0, remaining))
            if waits:
                next_batch_wait = min(waits)
        base_state = str(snapshot.get("state") or "")
        if snapshot.get("scanning") is True:
            snapshot_state = "scanning"
        elif base_state in {"ready", "incomplete"}:
            snapshot_state = base_state
        elif published or snapshot.get("last_success_at"):
            # A healthy rolling pool that simply has no valid rows right
            # now stays ready with an honestly empty table.
            snapshot_state = "ready"
        else:
            snapshot_state = "unknown"
        last_success_at = snapshot.get("last_success_at")
        funnel_view = {
            # Structural defaults first, so a not-yet-built queue funnel
            # still publishes the shape Hermes and the page expect.
            "reasons": {"read": [], "base": [], "sort": [], "trial": []},
            "budget": {"available_capital": None},
            "excluded": {"competition_empty": 0, "over_available": 0},
            **queue_funnel,
            **funnel,
            "trial": valid_count,
            "unchecked": pending,
            "stop_reason": snapshot.get("stop_reason"),
            "gap_reason": None,
            "conditions": _lp_funnel_conditions(),
            "competition_state": competition_state.get("state") or "unknown",
            "competition_not_updated": list(
                competition_state.get("not_updated") or ()
            ),
        }
        reasons_view = funnel_view.get("reasons")
        if isinstance(reasons_view, Mapping):
            trial_reasons = reasons_view.get("trial")
            if isinstance(trial_reasons, list):
                trial_reasons.extend(history_reasons)
        projection = {
            "buy_price_level": bid_level,
            "state": snapshot_state,
            "complete": snapshot.get("complete") is True,
            "scanning": snapshot.get("scanning") is True,
            "candidates": published,
            "recommendations": [deepcopy(published[0])] if published else [],
            "selected_results": deepcopy(published),
            # Published stamps keep the durable (ISO string) shape that the
            # whole-snapshot contract always had via its store round trip.
            "checked_at": _pool_published_value(snapshot.get("checked_at")),
            "last_success_at": _pool_published_value(last_success_at),
            "last_attempt_at": _pool_published_value(
                snapshot.get("last_attempt_at")
            ),
            "candidate_rows_fresh": bool(published),
            "missing_metadata_condition_ids": snapshot.get(
                "missing_metadata_condition_ids", []
            ),
            "missing_book_token_ids": snapshot.get("missing_book_token_ids", []),
            "catalog_complete": snapshot.get("catalog_complete") is True,
            "event_end_confirmations": snapshot.get("event_end_confirmations", {}),
            "retention_reason": snapshot.get("retention_reason"),
            "funnel": funnel_view,
            "selected_market_ids": [
                str(row.get("market_id") or "") for row in published
            ],
            "candidate_retention_reason": "background_candidates_retired",
            "candidate_valid_count": valid_count,
            "candidate_pending_count": pending,
            "candidate_failed_recent_count": failed_count,
            "next_batch_wait_seconds": next_batch_wait,
            "stale": False,
            "maintenance_consecutive_failures": snapshot.get(
                "maintenance_consecutive_failures", 0
            ),
            "maintenance_next_attempt_at": snapshot.get(
                "maintenance_next_attempt_at"
            ),
            "maintenance_diagnostics": snapshot.get(
                "maintenance_diagnostics"
            ),
        }
        # Keep preparation lifecycle state adjacent to the cached candidate
        # projection.  It is a small durable row, so readers can show a
        # pending/retry/paused reason without re-running the external funnel.
        projection["preparation"] = self.preparation_snapshot()
        if self.exclusions_enabled:
            projection["candidate_exclusions"] = self.store.lp_market_exclusion_counts(now=now)
        return projection

    def candidate_maintenance_wait_seconds(self) -> float | None:
        """Return seconds until maintenance may run again (issue #146).

        Inside a failure backoff window this is the remaining backoff;
        otherwise it is the time until the oldest head source reaches the
        30-second lead. Every numeric result clamps to [1.0, 300.0] so the
        scheduler can never spin; ``None`` means there is nothing to
        maintain (no head, no facts, or no source stamps).
        """

        with self._candidate_state_lock:
            global_recovery_generation = self._current_candidate_global_generation()
            qualification_facts = {
                condition_id: deepcopy(facts)
                for condition_id, facts in self._candidate_qualification_facts.items()
                if isinstance(facts, Mapping)
                and global_recovery_generation is not None
                and self._candidate_global_generation(
                    facts.get("global_recovery_generation")
                )
                == global_recovery_generation
            }
            failures = self._candidate_maintenance_failures
            global_failure = self._candidate_maintenance_global_failure
            last_finished_at = self._candidate_maintenance_last_finished_at
            pool = deepcopy(self._candidate_pool)
        now = self._now()
        floor = _CANDIDATE_SCHEDULER_WAIT_FLOOR_SECONDS
        ceiling = _CANDIDATE_SCHEDULER_WAIT_CEILING_SECONDS

        if global_failure and failures > 0 and last_finished_at is not None:
            backoff = _CANDIDATE_MAINTENANCE_BACKOFF_SECONDS[
                min(failures - 1, 2)
            ]
            remaining = (
                last_finished_at + timedelta(seconds=float(backoff)) - now
            ).total_seconds()
            if remaining > 0:
                return min(max(remaining, floor), ceiling)
        # Issue #157: the maintained rows are the valid pool rows (the
        # currently displayed top ten), not a stored whole-snapshot table.
        valid_rows = [
            row
            for row in pool.values()
            if isinstance(row, Mapping) and not _candidate_pool_row_expired(row, now)
        ]
        ordered = sorted(valid_rows, key=_candidate_yield_sort_key)
        ready, waiting = [], []
        for row in ordered:
            target = ready if self._candidate_rotation_due(
                str(row.get("condition_id") or ""), now=now) else waiting
            if len(target) < _LP_CANDIDATE_BATCH_SIZE:
                target.append(row)
        selected_rows = ready + waiting
        if not selected_rows:
            return None
        waits: list[float] = []
        for row in selected_rows:
            condition_id = str(row.get("condition_id") or "").strip()
            entry = self._candidate_rotation_entry(condition_id)
            failures = entry.get("failures")
            attempted = _candidate_row_updated_at({"updated_at": entry.get("last_attempt_at")})
            if isinstance(failures, int) and failures > 0 and attempted is not None:
                backoff = _CANDIDATE_MAINTENANCE_BACKOFF_SECONDS[min(failures - 1, 2)]
                waits.append((attempted + timedelta(seconds=float(backoff)) - now).total_seconds())
                continue
            cached = qualification_facts.get(condition_id)
            if not isinstance(cached, Mapping):
                continue
            times, expired = _candidate_head_source_times(cached, now)
            if expired or not times:
                waits.append(floor)
            else:
                waits.append((min(times) + timedelta(
                    seconds=float(LP_RECOMMENDATION_REFRESH_LEAD_SECONDS)) - now).total_seconds())
        return min(max(min(waits), floor), ceiling) if waits else None

    def _publish_sample_targets(
        self, targets: Sequence[tuple[str, str]]
    ) -> None:
        unique = tuple(dict.fromkeys(targets))
        with self._sample_target_lock:
            if unique != self._sample_targets:
                self._sample_targets = unique
                self._sample_target_version += 1

    def sample_candidate_books(
        self, *, stop_event: threading.Event | None = None
    ) -> dict[str, object]:
        """Persist one receipt-stamped BBO sample for every observed reward token."""

        with self._sample_target_lock:
            targets = self._sample_targets
            version = self._sample_target_version
        original_targets = targets
        exclusion_revision = self._candidate_exclusion_revision
        targets = self._candidate_allowed(targets)
        if stop_event is not None and stop_event.is_set():
            return {"state": "cancelled", "sampled_count": 0}
        if not targets:
            return {"state": "unknown", "sampled_count": 0}

        reader = getattr(self.exchange, "lp_order_books", None)
        if not callable(reader):
            return {"state": "unknown", "sampled_count": 0}
        token_ids = tuple(dict.fromkeys(token_id for _, token_id in targets))
        batches = tuple(
            token_ids[offset : offset + _LP_BOOK_SAMPLE_BATCH_SIZE]
            for offset in range(0, len(token_ids), _LP_BOOK_SAMPLE_BATCH_SIZE)
        )
        books: dict[str, object] = {}
        if len(batches) == 1:
            try:
                result = reader(batches[0], stop_event=stop_event)
            except Exception:
                return {"state": "unknown", "sampled_count": 0}
            if isinstance(result, Mapping):
                books.update(
                    (token, book)
                    for token, book in result.items()
                    if isinstance(token, str)
                )
        else:
            from concurrent.futures import ThreadPoolExecutor, as_completed

            with ThreadPoolExecutor(
                max_workers=min(_LP_BOOK_SAMPLE_MAX_CONCURRENCY, len(batches)),
                thread_name_prefix="prediction-lp-book-sampler",
            ) as executor:
                futures = {
                    executor.submit(reader, batch, stop_event=stop_event): batch
                    for batch in batches
                }
                for future in as_completed(futures):
                    try:
                        result = future.result()
                    except Exception:
                        continue
                    if isinstance(result, Mapping):
                        books.update(
                            (token, book)
                            for token, book in result.items()
                            if isinstance(token, str)
                        )
        if stop_event is not None and stop_event.is_set():
            return {"state": "cancelled", "sampled_count": 0}

        now = self._now()
        samples: list[dict[str, object]] = []
        for condition_id, token_id in targets:
            book = books.get(token_id)
            if not isinstance(book, Mapping) or book.get("token_id") != token_id:
                continue
            observed_condition = book.get("condition_id")
            if observed_condition not in (None, "", condition_id):
                continue
            try:
                received_at = _timestamp(
                    book.get("received_at"), name="book_received_at"
                )
                bids = _levels(book.get("bids"), "bids")
                asks = _levels(book.get("asks"), "asks")
            except ValueError:
                continue
            if received_at > now or not bids or not asks:
                continue
            bid_price, bid_size = max(bids, key=lambda level: level[0])
            ask_price, ask_size = min(asks, key=lambda level: level[0])
            if bid_price >= ask_price or ask_price > Decimal("1"):
                continue
            samples.append(
                {
                    "condition_id": condition_id,
                    "token_id": token_id,
                    "received_at": received_at,
                    "source_timestamp": book.get("source_timestamp"),
                    "best_bid_price": bid_price,
                    "best_bid_size": bid_size,
                    "best_ask_price": ask_price,
                    "best_ask_size": ask_size,
                }
            )

        if self.exclusions_enabled and exclusion_revision != self._candidate_exclusion_revision:
            return {"state": "superseded", "sampled_count": 0}
        with self._sample_target_lock:
            if version != self._sample_target_version or original_targets != self._sample_targets:
                return {"state": "superseded", "sampled_count": 0}
        if stop_event is not None and stop_event.is_set():
            return {"state": "cancelled", "sampled_count": 0}
        recorder = getattr(self.store, "lp_record_book_samples", None)
        if not callable(recorder):
            return {"state": "unknown", "sampled_count": 0}
        allowed = set(self._candidate_allowed(tuple((row["condition_id"], row["token_id"]) for row in samples), now=now))
        samples = [row for row in samples if (row["condition_id"], row["token_id"]) in allowed]
        try:
            recorded = recorder(samples, now=now)
        except Exception:
            return {"state": "unknown", "sampled_count": 0}
        return {
            "state": "recorded" if recorded else "unknown",
            "sampled_count": recorded,
            "target_count": len(targets),
        }

    def refresh_price_history(
        self,
        *,
        stop_event: threading.Event | None = None,
        manual_recovery: bool = False,
    ) -> dict[str, object]:
        """Refresh bounded 24-hour price summaries for the light-screen range.

        This hourly path prepares history only. Candidate refreshes consume the
        stored summaries and never call the history endpoint themselves.
        Network work is issued in batches of twenty with at most four active
        requests, and each completed batch is persisted before the next group
        is allowed to retain its response.
        """

        if type(manual_recovery) is not bool:
            raise ValueError("manual_recovery must be a boolean")
        generation: int | None = None
        if not self._price_history_refresh_lock.acquire(blocking=False):
            return self._preparation_result(
                self.preparation_snapshot(), outcome="busy", display_state="busy"
            )
        preparation_owner_acquired = False
        try:
            # Pin the attempt before any owner, item, or initial writer can fail.
            preparation = self.preparation_snapshot()
            generation = preparation.get("generation")
            generation = generation if type(generation) is int and generation >= 1 else 1
            owner_acquirer = getattr(
                self.store, "lp_try_acquire_preparation_owner", None
            )
            owner_releaser = getattr(
                self.store, "lp_release_preparation_owner", None
            )
            if callable(owner_acquirer):
                preparation_owner_acquired = bool(owner_acquirer())
                if not preparation_owner_acquired:
                    return self._preparation_result(
                        self.preparation_snapshot(),
                        outcome="busy",
                        display_state="busy",
                    )
            interrupted_normalizer = getattr(
                self.store, "lp_normalize_interrupted_preparation_items", None
            )
            if callable(interrupted_normalizer):
                try:
                    interrupted_normalizer()
                except Exception:
                    pass
            now = self._now().astimezone(UTC)
            preparation_exclusion_revision = self._candidate_exclusion_revision
            preparation = self.preparation_snapshot()
            legacy_migrator = getattr(
                self.store, "lp_migrate_legacy_preparation", None
            )
            if callable(legacy_migrator):
                try:
                    migrated = legacy_migrator()
                except Exception:
                    migrated = None
                if isinstance(migrated, Mapping):
                    restored = self._new_preparation_state()
                    restored.update(deepcopy(dict(migrated)))
                    with self._preparation_lock:
                        self._preparation = restored
                    preparation = self.preparation_snapshot()
            preparation_item_reader = getattr(self.store, "lp_preparation_items", None)
            existing_preparation_items = (
                preparation_item_reader()
                if callable(preparation_item_reader)
                else ()
            )
            has_partial_items = any(
                isinstance(item, Mapping)
                and str(item.get("condition_id") or "").strip()
                for item in existing_preparation_items
            )
            # Reclassify the persisted catalog pause produced by the old 2xx
            # precedence, keeping the original failure and its retry deadline.
            status = preparation.get("last_error_status")
            if (
                not manual_recovery
                and preparation.get("paused") is True
                and preparation.get("stage") == "catalog"
                and type(status) is int
                and 200 <= status < 300
                and self._automatic_recovery_error({
                    "error_type": preparation.get("last_error"),
                    "error_chain": preparation.get("last_error_chain"),
                    "status": status,
                })
            ):
                try:
                    failed_at = _timestamp(
                        preparation.get("last_failure_at"), name="last_failure_at"
                    )
                except ValueError:
                    failed_at = now
                failures = preparation.get("failure_count")
                failures = failures if type(failures) is int else 1
                delay_index = min(
                    max(failures - 1, 0), len(_LP_PREPARATION_RETRY_DELAYS_SECONDS) - 1
                )
                retry_at = failed_at + timedelta(
                    seconds=_LP_PREPARATION_RETRY_DELAYS_SECONDS[delay_index]
                )
                probe_at = now + timedelta(seconds=60)
                retry_after_at, _ = self._retry_after_deadline(failed_at, preparation)
                if retry_after_at is not None:
                    retry_at = max(retry_at, retry_after_at)
                    probe_at = max(probe_at, retry_after_at)
                preparation = self._save_preparation({
                    "state": "waiting_retry", "paused": False,
                    "last_error_category": "transient",
                    "next_retry_at": max(now, retry_at),
                    "next_probe_at": probe_at,
                }, expected_generation=preparation.get("generation"))
            if manual_recovery:
                if preparation.get("paused") is not True:
                    return self._preparation_result(
                        preparation, outcome="ignored", display_state="unknown"
                    )
                preparation = self.recover_preparation()
                generation = preparation.get("generation")
                generation = generation if type(generation) is int and generation >= 1 else 1
            elif preparation.get("paused") is True:
                return self._preparation_result(
                    preparation,
                    outcome="paused",
                    reason="preparation_paused",
                    display_state="unknown",
                )
            elif has_partial_items and preparation.get("next_retry_at") is not None:
                waiting_items = [
                    item
                    for item in existing_preparation_items
                    if isinstance(item, Mapping)
                    and str(item.get("condition_id") or "").strip()
                    and item.get("state") == "waiting_retry"
                    and item.get("paused") is not True
                ]
                retry_times: list[datetime] = []
                for item in waiting_items:
                    try:
                        retry_at = _timestamp(
                            item.get("next_retry_at"), name="next_retry_at"
                        )
                    except ValueError:
                        continue
                    retry_times.append(retry_at)
                retry_at = min(retry_times) if retry_times else now
                if waiting_items and now < retry_at:
                    probe_stage = str(
                        waiting_items[0].get("stage")
                        or preparation.get("last_probe_stage")
                        or preparation.get("stage")
                        or "history"
                    )
                    probe_ids = tuple(
                        str(item.get("condition_id"))
                        for item in waiting_items
                        if str(item.get("condition_id") or "").strip()
                    )
                    preparation, probe_recovered = self._run_preparation_probe(
                        now,
                        preparation,
                        stop_event=stop_event,
                        stage=probe_stage,
                        condition_ids=probe_ids,
                    )
                    if not probe_recovered:
                        return self._preparation_result(
                            preparation,
                            outcome="waiting_retry",
                            reason="retry_not_due",
                            display_state="partial",
                        )
            elif (
                not has_partial_items
                and (
                    preparation.get("state") == "waiting_retry"
                    or preparation.get("next_retry_at") is not None
                )
            ):
                try:
                    retry_at = _timestamp(
                        preparation.get("next_retry_at"), name="next_retry_at"
                    )
                except ValueError:
                    retry_at = now
                if now < retry_at:
                    preparation, probe_recovered = self._run_preparation_probe(
                        now, preparation, stop_event=stop_event
                    )
                    if probe_recovered:
                        try:
                            retry_at = _timestamp(
                                preparation.get("next_retry_at"),
                                name="next_retry_at",
                            )
                        except ValueError:
                            retry_at = now
                    else:
                        return self._preparation_result(
                            preparation,
                            outcome="waiting_retry",
                            reason="retry_not_due",
                            display_state="unknown",
                        )
                else:
                    preparation, _ = self._run_preparation_probe(
                        now, preparation, stop_event=stop_event
                    )
                if now < retry_at:
                    return self._preparation_result(
                        preparation,
                        outcome="waiting_retry",
                        reason="retry_not_due",
                        display_state="unknown",
                    )
            # Recovery decisions are complete; none of these rows is needed
            # by catalog, metadata, or history preparation.
            existing_preparation_items = ()
            waiting_items = ()
            item = None
            preparation = self._begin_preparation(now, generation=generation)
            global_fence = preparation.get("global_recovery_generation")
            if type(global_fence) is int and global_fence > generation:
                return self._preparation_result(
                    preparation, outcome="superseded", reason="preparation_generation_changed",
                    display_state="unknown",
                )
            if preparation.get("state") == "paused":
                return self._preparation_result(
                preparation,
                outcome="paused",
                reason="preparation_attempt_budget_exhausted",
                display_state="unknown",
                alert_pending=preparation.get("alert_claimed_now") is True,
            )
            preparation_retry_claimer = getattr(
                self.store, "lp_claim_preparation_retries", None
            )
            preparation_failure_writer = getattr(
                self.store, "lp_record_preparation_failure", None
            )
            preparation_clearer = getattr(self.store, "lp_clear_preparation_items", None)
            claimed_condition_ids: set[str] = set()
            preparation_items: dict[str, Mapping[str, object]] = {}
            if callable(preparation_item_reader):
                preparation_items = {
                    str(item.get("condition_id")): item
                    for item in preparation_item_reader()
                    if isinstance(item, Mapping)
                    and str(item.get("condition_id") or "").strip()
                }
            window_end = now.replace(second=0, microsecond=0)
            window_start = window_end - _LP_PRICE_HISTORY_WINDOW
            end_ts = int(window_end.timestamp())
            catalog_reader = getattr(self.exchange, "lp_reward_catalog", None)
            metadata_reader = getattr(self.exchange, "lp_market_metadata", None)
            history_reader = getattr(self.exchange, "lp_price_history", None)
            if not callable(catalog_reader):
                failed = self._preparation_failure(
                    self._now(), expected_generation=generation, stage="catalog", error_type="history_readers_unavailable"
                )
                return self._preparation_result(
                    failed,
                    outcome="failure",
                    reason="history_readers_unavailable",
                    display_state="unknown",
                    alert_pending=failed.get("alert_claimed_now") is True,
                )
            if stop_event is not None and stop_event.is_set():
                return self._preparation_result(
                    preparation, outcome="cancelled", display_state="cancelled"
                )

            catalog_failure: tuple[str, str] | None = None
            catalog_failure_error: object | None = None
            try:
                catalog = catalog_reader(stop_event=stop_event)
                if stop_event is not None and stop_event.is_set():
                    return self._preparation_result(
                        preparation, outcome="cancelled", display_state="cancelled"
                    )
                if not isinstance(catalog, Mapping):
                    catalog_failure_error = "history_catalog_unknown"
                    raise ValueError("history_catalog_unknown")
                safe_catalog_error = self._safe_error_type(catalog.get("error_type"))
                if safe_catalog_error == "unknown_error":
                    safe_catalog_error = "history_catalog_unknown"
                catalog_error_details: dict[str, object] = {
                    "error_type": safe_catalog_error
                }
                for field in (
                    "error_chain",
                    "error_types",
                    "sqlite_errorcode",
                    "sqlite_errorname",
                    "status",
                    "retry_after_seconds",
                    "retry_after_at",
                ):
                    value = catalog.get(field)
                    if value is not None:
                        catalog_error_details[field] = value
                raw_markets = catalog.get("markets")
                if not isinstance(raw_markets, (list, tuple, LPReadRows)):
                    catalog_failure_error = catalog_error_details
                    raise ValueError("history_catalog_unknown")
                if catalog.get("state") != "known":
                    catalog_failure_error = catalog_error_details
                    raise ValueError("history_catalog_unknown")
                market_rows = LPReadRows(row for row in raw_markets if isinstance(row, Mapping))
                catalog = {**catalog, "markets": market_rows}
                del raw_markets
                if catalog.get("complete") is not True:
                    if not market_rows:
                        catalog_failure_error = catalog_error_details
                        raise ValueError("history_catalog_unknown")
                    catalog_failure = (
                        "catalog",
                        safe_catalog_error
                        if safe_catalog_error != "history_catalog_unknown"
                        else "history_catalog_incomplete",
                    )
                condition_ids = tuple(
                    dict.fromkeys(
                        str(row.get("condition_id") or "").strip()
                        for row in market_rows
                        if str(row.get("condition_id") or "").strip()
                    )
                )
                if self.exclusions_enabled:
                    self.store.lp_prune_market_exclusions(now=now)
                    initially_allowed = set(self._candidate_conditions(condition_ids, now=now))
                    for row in market_rows:
                        cid = str(row.get("condition_id") or "")
                        ended = self._observe_ended_candidate_market(cid, row, checked_at=now)
                        if ended:
                            preparation_exclusion_revision = self._candidate_exclusion_revision
                        if not ended and cid in initially_allowed:
                            reason = self._candidate_market_rejection(row, {}, now=now)
                            if reason:
                                if self._exclude_candidate(cid, "", reason, checked_at=now,
                                        exclusion_revision=preparation_exclusion_revision):
                                    preparation_exclusion_revision = self._candidate_exclusion_revision
                    allowed = set(self._candidate_conditions(condition_ids, now=now))
                    market_rows = LPReadRows(row for row in market_rows if str(row.get("condition_id") or "") in allowed)
                    catalog = {**catalog, "markets": market_rows}
                priority_condition_ids = self._preparation_priority_order(tuple(
                    str(row.get("condition_id") or "") for row in market_rows))
                priority_index = {
                    condition_id: index
                    for index, condition_id in enumerate(priority_condition_ids)
                }
                metadata_condition_ids: list[str] = []
                for condition_id in priority_condition_ids:
                    item = preparation_items.get(condition_id)
                    if item is None:
                        metadata_condition_ids.append(condition_id)
                        continue
                    item_state = str(item.get("state") or "")
                    if bool(item.get("paused")) or (
                        item_state == "retrying"
                        and condition_id not in claimed_condition_ids
                    ):
                        continue
                    item_retry_at = item.get("next_retry_at")
                    if item_state == "waiting_retry" and item_retry_at:
                        try:
                            if now < _timestamp(item_retry_at, name="next_retry_at"):
                                continue
                        except ValueError:
                            continue
                    metadata_condition_ids.append(condition_id)
                metadata_condition_ids_tuple = tuple(metadata_condition_ids)
                if catalog_failure is not None and not condition_ids:
                    catalog_failure_error = catalog_error_details
                    raise ValueError("history_catalog_unknown")
                if callable(preparation_retry_claimer):
                    retryable_conditions = tuple(
                        dict.fromkeys(
                            str(item.get("condition_id") or "")
                            for item in preparation_items.values()
                            if isinstance(item, Mapping)
                            and str(item.get("condition_id") or "").strip()
                            and item.get("stage") == "metadata"
                            and str(item.get("condition_id") or "") in condition_ids
                            and item.get("state") == "waiting_retry"
                            and item.get("next_retry_at") is not None
                            and _timestamp(
                                item.get("next_retry_at"), name="next_retry_at"
                            )
                            <= now
                        )
                    )
                    claimed_condition_ids = {
                        str(item.get("condition_id"))
                        for item in preparation_retry_claimer(
                            now=now, condition_ids=retryable_conditions
                        )
                        if isinstance(item, Mapping)
                        and str(item.get("condition_id") or "").strip()
                    }
                    if callable(preparation_item_reader):
                        preparation_items = {
                            str(item.get("condition_id")): item
                            for item in preparation_item_reader()
                            if isinstance(item, Mapping)
                            and str(item.get("condition_id") or "").strip()
                        }
            except Exception as exc:
                error_type = catalog_failure_error or exc
                failed = self._preparation_failure(
                    self._now(), expected_generation=generation, stage="catalog", error_type=error_type
                )
                return self._preparation_result(
                    failed,
                    outcome="failure",
                    reason=str(failed.get("last_error") or "unknown_error"),
                    display_state="unknown",
                    alert_pending=failed.get("alert_claimed_now") is True,
                )
            metadata_batch_reader = getattr(
                self.exchange, "lp_market_metadata_batch", None
            )
            if not callable(metadata_reader) and not callable(metadata_batch_reader):
                failed = self._preparation_failure(
                    self._now(), expected_generation=generation, stage="metadata", error_type="history_readers_unavailable"
                )
                return self._preparation_result(
                    failed,
                    outcome="failure",
                    reason="history_readers_unavailable",
                    display_state="unknown",
                    alert_pending=failed.get("alert_claimed_now") is True,
                )
            metadata_value: Mapping[str, object] | None = None
            metadata_confirmed_absent: set[str] = set()
            metadata_failures: dict[str, str] = {}
            metadata_failure_facts: dict[str, Mapping[str, object]] = {}
            successful_metadata_retry_conditions: set[str] = set()
            if callable(metadata_batch_reader):
                metadata_by_condition: MutableMapping[str, object] = LPReadScratch()
                self._save_preparation(
                    {
                        "stage": "metadata",
                        "metadata_completed_count": 0,
                        "metadata_total_count": len(metadata_condition_ids_tuple),
                    },
                    expected_generation=generation,
                )

                def batch_failure_code(value: object) -> str:
                    if isinstance(value, Mapping):
                        raw_status = value.get("status")
                        if type(raw_status) is int:
                            return f"status{raw_status}"
                        raw_chain = value.get("error_chain", value.get("error_types"))
                        if isinstance(raw_chain, Sequence) and not isinstance(
                            raw_chain, (str, bytes)
                        ):
                            for chain_value in raw_chain:
                                code = self._safe_error_type(chain_value)
                                if any(
                                    marker in code.casefold()
                                    for marker in ("cert", "ssl", "auth", "forbidden")
                                ):
                                    return code
                        for field in (
                            "error_type",
                            "error",
                            "reason",
                            "code",
                            "type",
                        ):
                            if field in value:
                                return self._safe_error_type(value.get(field))
                        return "metadata_batch_failed"
                    return self._safe_error_type(value)

                for offset in range(
                    0, len(metadata_condition_ids_tuple), _LP_METADATA_BATCH_SIZE
                ):
                    if stop_event is not None and stop_event.is_set():
                        return self._preparation_result(
                            self.preparation_snapshot(),
                            outcome="cancelled",
                            display_state="cancelled",
                        )
                    metadata_batch_ids = metadata_condition_ids_tuple[
                        offset : offset + _LP_METADATA_BATCH_SIZE
                    ]
                    try:
                        batch_value = metadata_batch_reader(
                            metadata_batch_ids, stop_event=stop_event
                        )
                    except Exception as exc:
                        if isinstance(exc, sqlite3.Error):
                            raise
                        error_type = self._safe_error_type(type(exc).__name__)
                        metadata_failures.update(
                            {
                                condition_id: error_type
                                for condition_id in metadata_batch_ids
                            }
                        )
                        self._save_preparation(
                            {
                                "stage": "metadata",
                                "metadata_completed_count": len(
                                    (
                                        set(metadata_by_condition)
                                        - set(metadata_failures)
                                    )
                                    | metadata_confirmed_absent
                                ),
                                "metadata_total_count": len(metadata_condition_ids_tuple),
                                "last_progress_at": self._now(),
                            },
                            expected_generation=generation,
                        )
                        continue
                    if stop_event is not None and stop_event.is_set():
                        return self._preparation_result(
                            self.preparation_snapshot(),
                            outcome="cancelled",
                            display_state="cancelled",
                        )
                    if not isinstance(batch_value, Mapping):
                        metadata_failures.update(
                            {
                                condition_id: "metadata_batch_unknown"
                                for condition_id in metadata_batch_ids
                            }
                        )
                        del batch_value
                        continue
                    if str(batch_value.get("state") or "").lower() in {
                        "cancelled",
                        "canceled",
                    }:
                        return self._preparation_result(
                            self.preparation_snapshot(),
                            outcome="cancelled",
                            display_state="cancelled",
                        )
                    raw_markets = batch_value.get("markets")
                    if not isinstance(raw_markets, Mapping):
                        metadata_failures.update(
                            {
                                condition_id: "metadata_batch_unknown"
                                for condition_id in metadata_batch_ids
                            }
                        )
                        del batch_value, raw_markets
                        continue
                    requested = set(metadata_batch_ids)
                    returned_markets = {
                        str(key): value
                        for key, value in raw_markets.items()
                        if str(key) in requested and isinstance(value, Mapping)
                    }
                    raw_absent = batch_value.get("confirmed_absent_ids")
                    confirmed_absent = {
                        str(value)
                        for value in raw_absent
                        if isinstance(value, str) and value in requested
                    } if isinstance(raw_absent, Sequence) and not isinstance(raw_absent, (str, bytes)) else set()
                    raw_failed = batch_value.get("failed_ids")
                    if isinstance(raw_failed, Mapping):
                        failed_ids = {
                            str(key): value
                            for key, value in raw_failed.items()
                            if str(key) in requested
                        }
                    elif isinstance(raw_failed, Sequence) and not isinstance(raw_failed, (str, bytes)):
                        failed_ids = {str(value): "metadata_batch_failed" for value in raw_failed if str(value) in requested}
                    else:
                        failed_ids = {}
                    raw_failure_facts = batch_value.get("failure_facts")
                    raw_deferred = batch_value.get("deferred_ids")
                    deferred_ids = {
                        str(value)
                        for value in raw_deferred
                        if isinstance(value, str) and value in requested
                    } if isinstance(raw_deferred, Sequence) and not isinstance(raw_deferred, (str, bytes)) else set()
                    for condition_id, failure in failed_ids.items():
                        facts = (
                            raw_failure_facts.get(condition_id)
                            if isinstance(raw_failure_facts, Mapping)
                            else None
                        )
                        failure_value = facts if isinstance(facts, Mapping) else failure
                        self._raise_preparation_database_failure(failure_value)
                        metadata_failures[condition_id] = batch_failure_code(
                            failure_value
                        )
                        if isinstance(failure_value, Mapping):
                            metadata_failure_facts[condition_id] = dict(failure_value)
                    for condition_id in deferred_ids:
                        metadata_failures[condition_id] = "metadata_deferred"
                    resolved = (
                        set(returned_markets)
                        | confirmed_absent
                        | set(failed_ids)
                        | deferred_ids
                    )
                    metadata_confirmed_absent.update(
                        confirmed_absent - set(failed_ids) - deferred_ids
                    )
                    for condition_id in requested - resolved:
                        metadata_failures[condition_id] = "metadata_batch_incomplete"
                    metadata_by_condition.update(returned_markets)
                    # Scratch owns serialized facts now; release the HTTP batch
                    # before progress writes, the next batch, or history reads.
                    del batch_value, raw_markets, returned_markets
                    del raw_absent, raw_failed, raw_failure_facts, raw_deferred
                    self._save_preparation(
                        {
                            "stage": "metadata",
                            "metadata_completed_count": len(
                                (
                                    set(metadata_by_condition)
                                    - set(metadata_failures)
                                )
                                | metadata_confirmed_absent
                            ),
                            "metadata_total_count": len(metadata_condition_ids_tuple),
                            "last_progress_at": self._now(),
                        },
                        expected_generation=generation,
                    )
                metadata_value = metadata_by_condition
                if metadata_failures and callable(preparation_failure_writer):
                    failed_at = self._now().astimezone(UTC)
                    for condition_id, error_type in metadata_failures.items():
                        preparation_failure_writer(
                            condition_id,
                            generation=generation,
                            stage="metadata",
                            error=error_type,
                            failed_at=failed_at,
                            retry_after_seconds=(
                                metadata_failure_facts.get(condition_id, {}).get(
                                    "retry_after_seconds"
                                )
                            ),
                            retry_after_at=(
                                metadata_failure_facts.get(condition_id, {}).get(
                                    "retry_after_at"
                                )
                            ),
                        )
                    if callable(preparation_item_reader):
                        preparation_items = {
                            str(item.get("condition_id")): item
                            for item in preparation_item_reader()
                            if isinstance(item, Mapping)
                            and str(item.get("condition_id") or "").strip()
                        }
            else:
                try:
                    metadata_value = metadata_reader(
                        metadata_condition_ids_tuple, stop_event=stop_event
                    )  # type: ignore[misc]
                except Exception as exc:
                    failed = self._preparation_failure(
                        self._now(), expected_generation=generation, stage="metadata", error_type=exc
                    )
                    return self._preparation_result(
                        failed,
                        outcome="failure",
                        reason=self._safe_error_type(type(exc).__name__),
                        display_state="unknown",
                        alert_pending=failed.get("alert_claimed_now") is True,
                    )
            if not isinstance(metadata_value, Mapping):
                failed = self._preparation_failure(
                    self._now(), expected_generation=generation, stage="metadata", error_type="history_metadata_unknown"
                )
                return self._preparation_result(
                    failed,
                    outcome="failure",
                    reason="history_metadata_unknown",
                    display_state="unknown",
                    alert_pending=failed.get("alert_claimed_now") is True,
                )
            if self.exclusions_enabled and preparation_exclusion_revision != self._candidate_exclusion_revision:
                return self._preparation_result(self.preparation_snapshot(),
                    outcome="superseded", reason="candidate_exclusions_changed", display_state="partial")
            if not isinstance(metadata_value, LPReadScratch):
                metadata_value = LPReadScratch(metadata_value)
            metadata_retry_completion_candidates = set(claimed_condition_ids)
            metadata_retry_completion_candidates.update(
                condition_id
                for condition_id, item in preparation_items.items()
                if item.get("state") == "waiting_retry"
                and item.get("retry_used") is False
                and item.get("paused") is False
            )
            successful_metadata_retry_conditions.update(
                condition_id
                for condition_id in metadata_retry_completion_candidates
                if condition_id in metadata_value
                and condition_id not in metadata_failures
                and isinstance(metadata_value[condition_id], Mapping)
                and metadata_value[condition_id].get("accepting_orders") is False
            )
            if not callable(history_reader):
                failed = self._preparation_failure(
                    self._now(), expected_generation=generation, stage="history", error_type="history_readers_unavailable"
                )
                return self._preparation_result(
                    failed,
                    outcome="failure",
                    reason="history_readers_unavailable",
                    display_state="unknown",
                    alert_pending=failed.get("alert_claimed_now") is True,
                )

            if self.exclusions_enabled:
                for reward_market in market_rows:
                    cid = str(reward_market.get("condition_id") or "")
                    market = metadata_value.get(cid)
                    if isinstance(market, Mapping):
                        ended = self._observe_ended_candidate_market(cid, market, checked_at=now)
                        if ended:
                            preparation_exclusion_revision = self._candidate_exclusion_revision
                        reason = None if ended else self._candidate_market_rejection(reward_market, market, now=now)
                        if reason:
                            if self._exclude_candidate(cid, "", reason, checked_at=now, market=market,
                                    exclusion_revision=preparation_exclusion_revision):
                                preparation_exclusion_revision = self._candidate_exclusion_revision
                allowed = set(self._candidate_conditions(tuple(metadata_value), now=now))
                market_rows = LPReadRows(row for row in market_rows if str(row.get("condition_id") or "") in allowed)
                catalog = {**catalog, "markets": market_rows}
            targets: list[tuple[str, str]] = []
            for reward_market in market_rows:
                if reward_market.get("reward_active") is not True:
                    continue
                pool = _maybe_decimal(reward_market.get("daily_pool_usd"))
                if pool is None or pool <= 0:
                    continue
                condition_id = str(reward_market.get("condition_id") or "").strip()
                market = metadata_value.get(condition_id)
                if not isinstance(market, Mapping) or market.get("accepting_orders") is not True:
                    continue
                outcomes = market.get("outcomes")
                if not isinstance(outcomes, Mapping):
                    continue
                for raw_outcome in outcomes.values():
                    if not isinstance(raw_outcome, Mapping):
                        continue
                    token_id = str(raw_outcome.get("token_id") or "").strip()
                    if token_id:
                        targets.append((condition_id, token_id))
            targets = list(self._candidate_allowed(tuple(dict.fromkeys(targets)), now=now))
            targets.sort(
                key=lambda identity: priority_index.get(identity[0], len(priority_index))
            )
            eligible_targets = tuple(targets)
            active_targets: list[tuple[str, str]] = []
            for identity in targets:
                condition_id = identity[0]
                item = preparation_items.get(condition_id)
                if item is None:
                    active_targets.append(identity)
                    continue
                state = str(item.get("state") or "")
                if bool(item.get("paused")) or (
                    state == "retrying" and condition_id not in claimed_condition_ids
                ):
                    continue
                next_retry_at = item.get("next_retry_at")
                if state == "waiting_retry" and next_retry_at:
                    try:
                        if now < _timestamp(next_retry_at, name="next_retry_at"):
                            continue
                    except ValueError:
                        continue
                active_targets.append(identity)
            targets = active_targets
            # Retain identities and decisions, not the consumed retry snapshot.
            preparation_items.clear()
            item = None
            current_items = (
                preparation_item_reader()
                if callable(preparation_item_reader)
                else ()
            )
            catalog_confirmed_absent: set[str] = set()
            if catalog.get("state") == "known" and catalog.get("complete") is True:
                catalog_condition_ids = set(condition_ids)
                catalog_confirmed_absent = {
                    str(item.get("condition_id"))
                    for item in current_items
                    if isinstance(item, Mapping)
                    and str(item.get("condition_id") or "").strip()
                    and str(item.get("condition_id")) not in catalog_condition_ids
                    and item.get("state") == "waiting_retry"
                    and item.get("retry_used") is False
                    and item.get("paused") is False
                }
            clearable_condition_ids = (
                set(metadata_confirmed_absent)
                | catalog_confirmed_absent
                | successful_metadata_retry_conditions
            )
            if callable(preparation_clearer) and clearable_condition_ids:
                preparation_clearer(
                    clearable_condition_ids,
                    generation=generation,
                )
                current_items = (
                    preparation_item_reader()
                    if callable(preparation_item_reader)
                    else ()
                )
            if not targets:
                prepared_state = (
                    "known"
                    if catalog.get("state") == "known"
                    and catalog.get("complete") is True
                    else "partial"
                )
                if not self._publish_prepared_inputs(
                    catalog,
                    metadata_value,
                    state=prepared_state,
                    exclusion_revision=preparation_exclusion_revision, generation=generation,
                ):
                    return self._preparation_result(self.preparation_snapshot(),
                        outcome="superseded", reason="candidate_exclusions_changed", display_state="partial")
                if catalog_failure is not None:
                    failed = self._preparation_failure(
                        self._now(),
                        expected_generation=generation,
                        stage=catalog_failure[0],
                        error_type=catalog_failure[1],
                    )
                    result = self._preparation_result(
                        failed,
                        outcome="failure",
                        reason=catalog_failure[1],
                        display_state=prepared_state,
                        alert_pending=failed.get("alert_claimed_now") is True,
                    )
                    result.update(
                        {
                            "checked_at": now,
                            "target_count": 0,
                            "updated_count": 0,
                            "unknown_count": 0,
                            "request_count": 0,
                        }
                    )
                    return result
                active_items = [
                    item
                    for item in current_items
                    if isinstance(item, Mapping)
                    and str(item.get("condition_id") or "").strip()
                ]
                if active_items:
                    retry_times: list[datetime] = []
                    waiting_retry = False
                    for item in active_items:
                        if item.get("state") != "waiting_retry":
                            continue
                        retry_at = item.get("next_retry_at")
                        if not retry_at:
                            continue
                        try:
                            retry_timestamp = _timestamp(
                                retry_at, name="next_retry_at"
                            )
                        except ValueError:
                            continue
                        retry_times.append(retry_timestamp)
                        waiting_retry = waiting_retry or now < retry_timestamp
                    next_retry_at = min(retry_times) if retry_times else None
                    probe_stage = next(
                        (
                            str(item.get("stage") or "history")
                            for item in active_items
                            if item.get("state") == "waiting_retry"
                        ),
                        None,
                    )
                    last_error = next(
                        (
                            str(item.get("error"))
                            for item in active_items
                            if item.get("error")
                        ),
                        None,
                    )
                    completed = self._save_preparation(
                        {
                            "state": "partial",
                            "stage": "metadata",
                            "failure_count": 0,
                            "paused": False,
                            "attempt": 0,
                            "last_success_at": None,
                            "last_progress_at": now,
                            "completed_count": 0,
                            "total_count": 0,
                            "next_retry_at": next_retry_at,
                            "next_probe_at": (
                                now + timedelta(seconds=60)
                                if waiting_retry
                                else None
                            ),
                            "last_probe_stage": probe_stage,
                            "last_error": last_error,
                            **self._ensure_fault_episode(now),
                        },
                        expected_generation=generation,
                    )
                    result = self._preparation_result(
                        completed,
                        outcome="waiting_retry" if waiting_retry else "failure",
                        reason=last_error,
                        display_state="partial",
                    )
                    result.update(
                        {
                            "checked_at": now,
                            "target_count": 0,
                            "updated_count": 0,
                            "unknown_count": 0,
                            "request_count": 0,
                            "errors": {
                                str(item.get("condition_id")): str(item.get("error"))
                                for item in active_items
                                if item.get("error")
                            },
                        }
                    )
                    item_alert = self._claim_preparation_item_alerts()
                    if item_alert is not None and item_alert.get("alert_pending") is True:
                        result["alert_pending"] = True
                        result["preparation"].update(deepcopy(dict(item_alert)))
                    return result
                completed = self._save_preparation(
                    {
                        "state": "ready",
                        "stage": "complete",
                        "failure_count": 0,
                        "paused": False,
                        "attempt": 0,
                        "last_success_at": now,
                        "last_progress_at": now,
                        "completed_count": 0,
                        "total_count": 0,
                        "next_retry_at": None,
                        "last_error": None,
                        **self._clear_unacknowledged_fault_episode(),
                    },
                    expected_generation=generation,
                )
                result = self._preparation_result(
                    completed, outcome="success", display_state=prepared_state
                )
                result.update(
                    {
                        "checked_at": now,
                        "target_count": 0,
                        "updated_count": 0,
                        "unknown_count": 0,
                        "request_count": 0,
                    }
                )
                return result

            current_items = ()
            item = None
            if not self._publish_prepared_inputs(
                catalog, metadata_value, state="preparing",
                exclusion_revision=preparation_exclusion_revision, generation=generation,
            ):
                return self._preparation_result(self.preparation_snapshot(),
                    outcome="superseded", reason="candidate_exclusions_changed", display_state="partial")
            self._save_preparation(
                {
                    "stage": "history",
                    "completed_count": 0,
                    "total_count": len(targets),
                    "last_progress_at": now,
                },
                expected_generation=generation,
            )

            summary_reader = getattr(self.store, "lp_price_history_summaries", None)
            sample_reader = getattr(self.store, "lp_price_history_samples_batch", None)
            summary_one = getattr(self.store, "lp_price_history_summary", None)
            samples_one = getattr(self.store, "lp_price_history_samples", None)
            batch_writer = getattr(self.store, "lp_save_price_history_batch", None)
            one_writer = getattr(self.store, "lp_save_price_history", None)
            identity_batches = tuple(
                tuple(targets[offset : offset + _LP_PRICE_HISTORY_BATCH_SIZE])
                for offset in range(0, len(targets), _LP_PRICE_HISTORY_BATCH_SIZE)
            )

            def history_summary_reusable(
                summary: Mapping[str, object] | None,
            ) -> bool:
                if not (
                    summary
                    and str(summary.get("state") or "").lower()
                    in {"known", "ready", "eligible"}
                    and summary.get("checked_at") is not None
                ):
                    return False
                if self.exclusions_enabled:
                    from .polymarket_lp_views import lp_history_eligibility
                    if lp_history_eligibility(summary, now=now) == "history_amplitude_exceeded":
                        return False
                if summary.get("last_error") not in (None, ""):
                    return False
                try:
                    checked_at = _timestamp(
                        summary.get("checked_at"), name="history_checked_at"
                    )
                    last_attempt_at = summary.get("last_attempt_at")
                    if last_attempt_at is not None and _timestamp(
                        last_attempt_at, name="history_last_attempt_at"
                    ) > checked_at:
                        return False
                except (TypeError, ValueError):
                    return False
                return True

            def cached_facts(
                identities: tuple[tuple[str, str], ...],
            ) -> tuple[dict[tuple[str, str], Mapping[str, object]], dict[tuple[str, str], list[dict[str, object]]]]:
                summaries: dict[tuple[str, str], Mapping[str, object]] = {}
                samples: dict[tuple[str, str], list[dict[str, object]]] = {}

                if callable(summary_reader):
                    try:
                        value = summary_reader(identities, now=now)
                        if isinstance(value, Mapping):
                            summaries.update(
                                (key, item)
                                for key, item in value.items()
                                if isinstance(key, tuple) and isinstance(item, Mapping)
                            )
                    except Exception:
                        pass
                elif callable(summary_one):
                    for identity in identities:
                        try:
                            value = summary_one(*identity, now=now)
                        except Exception:
                            value = None
                        if isinstance(value, Mapping):
                            summaries[identity] = value
                sample_identities = tuple(
                    identity
                    for identity in identities
                    if not history_summary_reusable(summaries.get(identity))
                )
                if callable(sample_reader) and sample_identities:
                    try:
                        value = sample_reader(sample_identities)
                        if isinstance(value, Mapping):
                            samples.update(
                                (key, [dict(item) for item in rows if isinstance(item, Mapping)])
                                for key, rows in value.items()
                                if isinstance(key, tuple) and isinstance(rows, (list, tuple))
                            )
                    except Exception:
                        pass
                elif callable(samples_one):
                    for identity in sample_identities:
                        try:
                            value = samples_one(*identity)
                        except Exception:
                            value = []
                        if isinstance(value, (list, tuple)):
                            samples[identity] = [dict(item) for item in value if isinstance(item, Mapping)]
                return summaries, samples

            def request_batch(
                identities: tuple[tuple[str, str], ...],
                start_ts: int,
            ) -> tuple[tuple[tuple[str, str], ...], object, str | None]:
                identities = self._candidate_allowed(identities)
                token_ids = tuple(token for _, token in identities)
                if not token_ids:
                    return identities, {"state": "known", "history": {}}, None
                if stop_event is not None and stop_event.is_set():
                    return identities, None, "cancelled"
                try:
                    value = history_reader(
                        token_ids,
                        start_ts=start_ts,
                        end_ts=end_ts,
                        fidelity=1,
                        stop_event=stop_event,
                    )
                    return identities, value, None
                except Exception as exc:
                    if isinstance(exc, sqlite3.Error):
                        raise
                    return identities, None, type(exc).__name__

            def parse_samples(
                rows: object,
            ) -> tuple[dict[int, dict[str, object]], str | None]:
                if not isinstance(rows, (list, tuple)):
                    return {}, "history_missing"
                parsed: dict[int, dict[str, object]] = {}
                for row in rows:
                    if not isinstance(row, Mapping):
                        return {}, "history_values_invalid"
                    stamp = row.get("t", row.get("timestamp"))
                    price = _maybe_decimal(row.get("p", row.get("price")))
                    if type(stamp) is not int or price is None or price < 0 or price > 1:
                        return {}, "history_values_invalid"
                    parsed[stamp] = {"t": stamp, "p": price}
                return parsed, None

            def write_rows(rows: list[dict[str, object]]) -> None:
                nonlocal preparation_exclusion_revision
                if not rows:
                    return
                if callable(batch_writer):
                    written = batch_writer(rows, generation=generation)
                    if written:
                        with self._candidate_state_lock:
                            self._candidate_history_version += 1
                    if self.exclusions_enabled:
                        for row in rows:
                            if self._lp_history_fact(row["condition_id"], row["token_id"], now=self._now())[1] == "history_amplitude_exceeded":
                                if self._exclude_candidate(row["condition_id"], row["token_id"], "history_amplitude_exceeded",
                                        checked_at=now, exclusion_revision=preparation_exclusion_revision):
                                    preparation_exclusion_revision = self._candidate_exclusion_revision
                    return
                if callable(one_writer):
                    for row in rows:
                        one_writer(
                            str(row["condition_id"]),
                            str(row["token_id"]),
                            row["samples"],
                            row["summary"],
                        )
                    with self._candidate_state_lock:
                        self._candidate_history_version += 1

            updated_count = 0
            unknown_count = 0
            request_count = 0
            errors: dict[str, str] = {}
            operational_failure: tuple[str, str] | None = None
            history_retry_deadline: datetime | None = None
            market_failures: dict[
                str, tuple[str, str, str | None, Mapping[str, object] | None]
            ] = {}
            recorded_failure_conditions: set[str] = set()
            successful_conditions: set[str] = set(metadata_confirmed_absent)
            benign_history_errors = {
                "cancelled",
                "history_insufficient",
                "history_missing",
                "history_values_unknown",
                "history_window_incomplete",
            }
            completed_identities: set[tuple[str, str]] = set()
            successful_identities: set[tuple[str, str]] = set()
            updated_identities: set[tuple[str, str]] = set()
            unknown_identities: set[tuple[str, str]] = set()
            target_identities_by_condition_lists: dict[str, list[tuple[str, str]]] = {}
            for identity in eligible_targets:
                target_identities_by_condition_lists.setdefault(identity[0], []).append(identity)
            target_identities_by_condition = {
                condition_id: tuple(identities)
                for condition_id, identities in target_identities_by_condition_lists.items()
            }
            queued_batches = list(identity_batches)

            def persist_new_market_failures() -> None:
                if not callable(preparation_failure_writer):
                    return
                failed_at = self._now().astimezone(UTC)
                for condition_id, (
                    stage,
                    error_type,
                    token_id,
                    retry_facts,
                ) in market_failures.items():
                    if condition_id in recorded_failure_conditions:
                        continue
                    preparation_failure_writer(
                        condition_id,
                        generation=generation,
                        stage=stage,
                        error=error_type,
                        failed_at=failed_at,
                        token_id=token_id,
                        retry_after_seconds=(
                            retry_facts.get("retry_after_seconds")
                            if isinstance(retry_facts, Mapping)
                            else None
                        ),
                        retry_after_at=(
                            retry_facts.get("retry_after_at")
                            if isinstance(retry_facts, Mapping)
                            else None
                        ),
                    )
                    recorded_failure_conditions.add(condition_id)

            def dispatch_due_metadata(
                condition_ids: tuple[str, ...],
            ) -> tuple[tuple[str, str], ...]:
                """Resolve due metadata before claiming its history retry."""

                nonlocal metadata_value
                requested = tuple(
                    dict.fromkeys(
                        condition_id
                        for condition_id in condition_ids
                        if condition_id
                    )
                )
                requested = tuple(
                    sorted(
                        requested,
                        key=lambda condition_id: priority_index.get(
                            condition_id, len(priority_index)
                        ),
                    )
                )
                if not requested:
                    return ()
                returned_markets: dict[str, Mapping[str, object]] = {}
                failed_ids: dict[str, object] = {}
                raw_failure_facts: object = None

                def failure_code(value: object) -> str:
                    if isinstance(value, Mapping):
                        raw_status = value.get("status")
                        if type(raw_status) is int:
                            return f"status{raw_status}"
                        raw_chain = value.get("error_chain", value.get("error_types"))
                        if isinstance(raw_chain, Sequence) and not isinstance(
                            raw_chain, (str, bytes)
                        ):
                            for chain_value in raw_chain:
                                code = self._safe_error_type(chain_value)
                                if any(
                                    marker in code.casefold()
                                    for marker in ("cert", "ssl", "auth", "forbidden")
                                ):
                                    return code
                        for field in (
                            "error_type",
                            "error",
                            "reason",
                            "code",
                            "type",
                        ):
                            if field in value:
                                return self._safe_error_type(value.get(field))
                        return "metadata_batch_failed"
                    return self._safe_error_type(value)
                try:
                    if callable(metadata_batch_reader):
                        batch_value = metadata_batch_reader(
                            requested, stop_event=stop_event
                        )
                        if not isinstance(batch_value, Mapping):
                            raise ValueError("metadata_batch_unknown")
                        raw_markets = batch_value.get("markets")
                        if isinstance(raw_markets, Mapping):
                            returned_markets = {
                                str(key): value
                                for key, value in raw_markets.items()
                                if str(key) in requested and isinstance(value, Mapping)
                            }
                        raw_failed = batch_value.get("failed_ids")
                        if isinstance(raw_failed, Mapping):
                            failed_ids.update(
                                {
                                    str(key): value
                                    for key, value in raw_failed.items()
                                    if str(key) in requested
                                }
                            )
                        elif isinstance(raw_failed, Sequence) and not isinstance(
                            raw_failed, (str, bytes)
                        ):
                            failed_ids.update(
                                {
                                    str(value): "metadata_batch_failed"
                                    for value in raw_failed
                                    if str(value) in requested
                                }
                            )
                        raw_failure_facts = batch_value.get("failure_facts")
                        raw_absent = batch_value.get("confirmed_absent_ids")
                        confirmed_absent = (
                            {
                                str(value)
                                for value in raw_absent
                                if isinstance(value, str) and value in requested
                            }
                            if isinstance(raw_absent, Sequence)
                            and not isinstance(raw_absent, (str, bytes))
                            else set()
                        )
                        confirmed_absent -= set(failed_ids)
                        successful_conditions.update(confirmed_absent)
                    elif callable(metadata_reader):
                        raw_value = metadata_reader(requested, stop_event=stop_event)
                        if isinstance(raw_value, Mapping):
                            returned_markets = {
                                str(key): value
                                for key, value in raw_value.items()
                                if str(key) in requested and isinstance(value, Mapping)
                            }
                    else:
                        failed_ids = {
                            condition_id: "history_readers_unavailable"
                            for condition_id in requested
                        }
                except Exception as exc:
                    self._raise_preparation_database_failure(exc)
                    failed_ids = {
                        condition_id: self._safe_error_type(type(exc).__name__)
                        for condition_id in requested
                    }

                retry_identities: list[tuple[str, str]] = []
                updated_metadata = deepcopy(metadata_value)
                requested_conditions = set(requested)
                reward_by_condition = {
                    str(row.get("condition_id") or ""): row
                    for row in market_rows
                    if isinstance(row, Mapping)
                    and str(row.get("condition_id") or "") in requested_conditions
                }
                for condition_id in requested:
                    failure = failed_ids.get(condition_id)
                    facts = (
                        raw_failure_facts.get(condition_id)
                        if isinstance(raw_failure_facts, Mapping)
                        else None
                    )
                    failure_value = facts if isinstance(facts, Mapping) else failure
                    self._raise_preparation_database_failure(failure_value)
                    if isinstance(failure_value, Mapping):
                        metadata_failure_facts[condition_id] = dict(failure_value)
                    market = returned_markets.get(condition_id)
                    if not isinstance(market, Mapping):
                        failed_ids.setdefault(
                            condition_id, "metadata_batch_incomplete"
                        )
                        failure_value = (
                            failed_ids[condition_id]
                            if failure_value is None
                            else failure_value
                        )
                        market_failures.setdefault(
                            condition_id,
                            (
                                "metadata",
                                failure_code(failure_value),
                                None,
                                (
                                    dict(failure_value)
                                    if isinstance(failure_value, Mapping)
                                    else None
                                ),
                            ),
                        )
                        continue
                    reward_market = reward_by_condition.get(condition_id)
                    pool = (
                        _maybe_decimal(reward_market.get("daily_pool_usd"))
                        if isinstance(reward_market, Mapping)
                        else None
                    )
                    outcomes = market.get("outcomes")
                    if (
                        not isinstance(reward_market, Mapping)
                        or reward_market.get("reward_active") is not True
                        or pool is None
                        or pool <= 0
                        or market.get("accepting_orders") is not True
                        or not isinstance(outcomes, Mapping)
                    ):
                        market_failures.setdefault(
                            condition_id,
                            (
                                "metadata",
                                "metadata_market_unusable",
                                None,
                                None,
                            ),
                        )
                        continue
                    identities = tuple(
                        (condition_id, str(raw_outcome.get("token_id") or "").strip())
                        for raw_outcome in outcomes.values()
                        if isinstance(raw_outcome, Mapping)
                        and str(raw_outcome.get("token_id") or "").strip()
                    )
                    if not identities:
                        market_failures.setdefault(
                            condition_id,
                            (
                                "metadata",
                                "metadata_market_unusable",
                                None,
                                None,
                            ),
                        )
                        continue
                    updated_metadata[condition_id] = market
                    target_identities_by_condition[condition_id] = identities
                    retry_identities.extend(identities)
                if retry_identities:
                    metadata_value = updated_metadata
                    if not self._publish_prepared_inputs(
                        catalog, metadata_value, state="preparing",
                        exclusion_revision=preparation_exclusion_revision, generation=generation,
                    ):
                        return self._preparation_result(self.preparation_snapshot(),
                            outcome="superseded", reason="candidate_exclusions_changed", display_state="partial")
                return tuple(retry_identities)

            while queued_batches:
                if stop_event is not None and stop_event.is_set():
                    break
                if callable(preparation_retry_claimer):
                    retry_now = self._now()
                    due_retries = preparation_retry_claimer(
                        now=retry_now,
                        condition_ids=target_identities_by_condition,
                        metadata_condition_ids=condition_ids,
                    )
                    due_metadata_ids = tuple(
                        str(item.get("condition_id") or "")
                        for item in due_retries
                        if isinstance(item, Mapping)
                        and item.get("stage") == "metadata"
                    )
                    metadata_retry_identities = dispatch_due_metadata(due_metadata_ids)
                    if metadata_retry_identities:
                        targets.extend(metadata_retry_identities)
                        targets[:] = list(dict.fromkeys(targets))
                        for offset in range(
                            0,
                            len(metadata_retry_identities),
                            _LP_PRICE_HISTORY_BATCH_SIZE,
                        ):
                            queued_batches.insert(
                                offset // _LP_PRICE_HISTORY_BATCH_SIZE,
                                tuple(
                                    metadata_retry_identities[
                                        offset : offset + _LP_PRICE_HISTORY_BATCH_SIZE
                                    ]
                                ),
                            )
                    retry_identities = tuple(
                        identity
                        for item in due_retries
                        if isinstance(item, Mapping)
                        and item.get("stage") != "metadata"
                        for identity in target_identities_by_condition.get(
                            str(item.get("condition_id") or ""), ()
                        )
                    )
                    if retry_identities:
                        targets.extend(retry_identities)
                        targets[:] = list(dict.fromkeys(targets))
                        retry_identity_set = set(retry_identities)
                        queued_batches = [
                            tuple(
                                identity
                                for identity in batch
                                if identity not in retry_identity_set
                            )
                            for batch in queued_batches
                        ]
                        queued_batches = [batch for batch in queued_batches if batch]
                        retry_batches = [
                            tuple(retry_identities[offset : offset + _LP_PRICE_HISTORY_BATCH_SIZE])
                            for offset in range(
                                0, len(retry_identities), _LP_PRICE_HISTORY_BATCH_SIZE
                            )
                        ]
                        queued_batches[0:0] = retry_batches
                        for item in due_retries:
                            if isinstance(item, Mapping):
                                recorded_failure_conditions.discard(
                                    str(item.get("condition_id") or "")
                                )
                batch_group = tuple(
                    queued_batches[:_LP_PRICE_HISTORY_MAX_CONCURRENCY]
                )
                del queued_batches[:_LP_PRICE_HISTORY_MAX_CONCURRENCY]
                cache_by_batch: dict[
                    tuple[tuple[str, str], ...],
                    tuple[
                        dict[tuple[str, str], Mapping[str, object]],
                        dict[tuple[str, str], list[dict[str, object]]],
                    ],
                ] = {}
                request_group: list[tuple[tuple[tuple[str, str], ...], int]] = []
                for identity_batch in batch_group:
                    summaries, cached_samples = cached_facts(identity_batch)
                    missing_identities: list[tuple[str, str]] = []
                    for identity in identity_batch:
                        summary = summaries.get(identity)
                        state = str(summary.get("state") or "").lower() if summary else ""
                        if history_summary_reusable(summary):
                            completed_identities.add(identity)
                            successful_identities.add(identity)
                        else:
                            missing_identities.append(identity)
                    completed_count = len(completed_identities)
                    if not missing_identities:
                        continue
                    request_identities = tuple(missing_identities)
                    cache_by_batch[request_identities] = (summaries, cached_samples)
                    starts: list[int] = []
                    for identity in request_identities:
                        rows = cached_samples.get(identity, [])
                        stamps = [
                            row.get("t")
                            for row in rows
                            if isinstance(row.get("t"), int)
                        ]
                        starts.append(
                            max(
                                int(window_start.timestamp()),
                                max(stamps) - int(_LP_PRICE_HISTORY_OVERLAP.total_seconds())
                                if stamps
                                else int(window_start.timestamp()),
                            )
                        )
                    request_group.append((request_identities, min(starts)))
                self._save_preparation(
                    {
                        "stage": "history",
                        "completed_count": completed_count,
                        "total_count": len(targets),
                        "last_progress_at": self._now(),
                    },
                    expected_generation=generation,
                )
                if not request_group:
                    continue
                with ThreadPoolExecutor(
                    max_workers=min(_LP_PRICE_HISTORY_MAX_CONCURRENCY, len(request_group)),
                    thread_name_prefix="prediction-lp-history",
                ) as executor:
                    futures = {
                        executor.submit(request_batch, identities, start_ts): (identities, start_ts)
                        for identities, start_ts in request_group
                    }
                    for future in as_completed(futures):
                        identities, start_ts = futures[future]
                        del start_ts
                        request_count += 1
                        try:
                            returned_identities, payload, error = future.result()
                        except Exception as exc:
                            if isinstance(exc, sqlite3.Error):
                                raise
                            returned_identities, payload, error = identities, None, type(exc).__name__
                        if self.exclusions_enabled and preparation_exclusion_revision != self._candidate_exclusion_revision:
                            return self._preparation_result(self.preparation_snapshot(),
                                outcome="superseded", reason="candidate_exclusions_changed", display_state="partial")
                        self._raise_preparation_database_failure(payload)
                        if error is not None and error != "cancelled":
                            operational_failure = (
                                "history", self._safe_error_type(error)
                            )
                        summaries, cached_samples = cache_by_batch[identities]
                        history_map = payload.get("history") if isinstance(payload, Mapping) else None
                        if not isinstance(history_map, Mapping):
                            history_map = {}
                        payload_errors = payload.get("errors") if isinstance(payload, Mapping) else None
                        if not isinstance(payload_errors, Mapping):
                            payload_errors = {}
                        retry_facts = (
                            {
                                field: payload[field]
                                for field in ("retry_after_seconds", "retry_after_at")
                                if isinstance(payload, Mapping)
                                and payload.get(field) is not None
                            }
                            if isinstance(payload, Mapping)
                            else {}
                        )
                        payload_retry_deadline, _ = self._retry_after_deadline(
                            now, payload
                        )
                        if payload_retry_deadline is not None and (
                            history_retry_deadline is None
                            or payload_retry_deadline > history_retry_deadline
                        ):
                            history_retry_deadline = payload_retry_deadline
                        for payload_error in payload_errors.values():
                            if (
                                isinstance(payload_error, str)
                                and payload_error not in benign_history_errors
                            ):
                                operational_failure = (
                                    "history",
                                    self._safe_error_type(payload_error),
                                )
                                break
                        rows_to_write: list[dict[str, object]] = []
                        for condition_id, token_id in returned_identities:
                            identity = (condition_id, token_id)
                            prior = dict(summaries.get(identity, {}))
                            previous_rows = cached_samples.get(identity, [])
                            raw_rows = history_map.get(token_id)
                            if error is None and isinstance(raw_rows, (list, tuple)):
                                new_points, parse_error = parse_samples(raw_rows)
                            else:
                                upstream_error = payload_errors.get(token_id)
                                parse_error = (
                                    upstream_error
                                    if isinstance(upstream_error, str) and upstream_error
                                    else error or "history_missing"
                                )
                                new_points = {}
                            merged, merge_error = parse_samples(previous_rows)
                            reason = parse_error or merge_error
                            failure_code: str | None = None
                            if error is not None and error != "cancelled":
                                failure_code = error
                            else:
                                payload_error = payload_errors.get(token_id)
                                if (
                                    isinstance(payload_error, str)
                                    and payload_error not in benign_history_errors
                                ):
                                    failure_code = payload_error
                                elif reason is not None and reason != "cancelled":
                                    # A missing or incomplete market history
                                    # is still an isolated market failure.  It
                                    # must return to its low-frequency retry
                                    # queue rather than leaving a claimed
                                    # owner lease in retrying forever.
                                    failure_code = reason
                            if failure_code is not None:
                                market_failures.setdefault(
                                    condition_id,
                                    (
                                        "history",
                                        self._safe_error_type(failure_code),
                                        token_id,
                                        retry_facts or None,
                                    ),
                                )
                            if reason is None:
                                merged.update(new_points)
                                bounded = {
                                    stamp: row
                                    for stamp, row in merged.items()
                                    if int(window_start.timestamp()) <= stamp <= end_ts
                                }
                                if len(bounded) < 2:
                                    reason = "history_insufficient"
                                else:
                                    first_stamp = min(bounded)
                                    last_stamp = max(bounded)
                                    if first_stamp > int(window_start.timestamp()) + 60 or last_stamp < end_ts - 60:
                                        reason = "history_window_incomplete"
                            if reason is None:
                                successful_identities.add(identity)
                                successful_conditions.add(condition_id)
                            if reason is None:
                                updated_identities.add(identity)
                                unknown_identities.discard(identity)
                                errors.pop(token_id, None)
                                prices = [row["p"] for row in bounded.values()]
                                latest_sample = bounded[max(bounded)]
                                summary: dict[str, object] = {
                                    "state": "known",
                                    "amplitude": max(prices) - min(prices),
                                    "checked_at": now,
                                    "window_start": window_start,
                                    "window_end": window_end,
                                "sample_count": len(bounded),
                                "latest_midpoint": latest_sample["p"],
                                "valid_until": now + timedelta(hours=24),
                                "last_attempt_at": now,
                                "preparation_generation": generation,
                            }
                                samples_for_store = [bounded[stamp] for stamp in sorted(bounded)]
                            else:
                                unknown_identities.add(identity)
                                updated_identities.discard(identity)
                                errors[token_id] = reason
                                samples_for_store = previous_rows
                                summary = prior
                                summary["last_attempt_at"] = now
                                summary["last_error"] = reason
                                if not summary:
                                    summary = {
                                        "state": "unknown",
                                        "checked_at": None,
                                        "last_attempt_at": now,
                                        "reason": reason,
                                    }
                                elif summary.get("checked_at") is None:
                                    summary["state"] = "unknown"
                                summary["preparation_generation"] = generation
                            rows_to_write.append(
                                {
                                    "condition_id": condition_id,
                                    "token_id": token_id,
                                    "samples": samples_for_store,
                                    "summary": summary,
                                }
                            )
                        write_rows(rows_to_write)
                        completed_identities.update(returned_identities)
                        completed_count = len(completed_identities)
                        updated_count = len(updated_identities)
                        unknown_count = len(unknown_identities)
                        self._save_preparation(
                            {
                                "stage": "history",
                                "completed_count": completed_count,
                                "total_count": len(targets),
                                "last_progress_at": self._now(),
                            },
                            expected_generation=generation,
                        )
                        del rows_to_write, payload, history_map, future
                persist_new_market_failures()
                for condition_id in tuple(market_failures):
                    if not any(
                        identity in unknown_identities
                        for identity in target_identities_by_condition.get(condition_id, ())
                    ):
                        market_failures.pop(condition_id, None)
                        recorded_failure_conditions.discard(condition_id)
                del cache_by_batch, request_group
            for condition_id, identities in target_identities_by_condition.items():
                if identities and all(
                    identity in successful_identities for identity in identities
                ):
                    successful_conditions.add(condition_id)
            persist_new_market_failures()
            if (
                operational_failure is not None
                and operational_failure[0] == "history"
                and not market_failures
                and not unknown_identities
            ):
                operational_failure = None
            if callable(preparation_clearer) and successful_conditions:
                preparation_clearer(
                    (
                        condition_id
                        for condition_id in successful_conditions
                        if condition_id not in market_failures
                    ),
                    generation=generation,
                )
            if stop_event is not None and stop_event.is_set():
                return self._preparation_result(
                    self.preparation_snapshot(),
                    outcome="cancelled",
                    display_state="cancelled",
                )
            usable_identities = successful_identities - unknown_identities
            unresolved_identities = unknown_identities - successful_identities
            state = (
                "known"
                if usable_identities and not unresolved_identities
                else "partial"
                if usable_identities
                else "unknown"
            )
            if not self._publish_prepared_inputs(catalog, metadata_value, state=state,
                    exclusion_revision=preparation_exclusion_revision, generation=generation):
                return self._preparation_result(self.preparation_snapshot(),
                    outcome="superseded", reason="candidate_exclusions_changed", display_state="partial")
            if operational_failure is None:
                operational_failure = catalog_failure
            if operational_failure is not None:
                stage, error_type = operational_failure
                if market_failures and callable(preparation_item_reader):
                    current_items = preparation_item_reader()
                    retry_times = [
                        item.get("next_retry_at")
                        for item in current_items
                        if isinstance(item, Mapping) and item.get("next_retry_at")
                    ]
                    probe_stage = next(
                        (
                            str(item.get("stage") or stage)
                            for item in current_items
                            if isinstance(item, Mapping)
                            and item.get("state") == "waiting_retry"
                        ),
                        stage,
                    )
                    partial = self._save_preparation(
                        {
                            "state": "partial",
                            "stage": stage,
                            "failure_count": 0,
                            "paused": False,
                            "attempt": 0,
                            "last_success_at": None,
                            "last_progress_at": self._now(),
                            "completed_count": completed_count,
                            "total_count": len(targets),
                            "next_retry_at": min(retry_times) if retry_times else None,
                            "next_probe_at": max(
                                self._now() + timedelta(seconds=60),
                                history_retry_deadline
                                if history_retry_deadline is not None
                                else self._now() + timedelta(seconds=60),
                            ),
                            "last_probe_stage": probe_stage,
                            "last_error": error_type,
                            **self._ensure_fault_episode(self._now().astimezone(UTC)),
                        },
                        expected_generation=generation,
                    )
                    result = self._preparation_result(
                        partial,
                        outcome="failure",
                        reason=error_type,
                        display_state=state,
                    )
                    result.update(
                        {
                            "target_count": len(targets),
                            "updated_count": updated_count,
                            "unknown_count": unknown_count,
                            "request_count": request_count,
                            "checked_at": now,
                            "errors": errors,
                        }
                    )
                    item_alert = self._claim_preparation_item_alerts()
                    if item_alert is not None and item_alert.get("alert_pending") is True:
                        result["alert_pending"] = True
                        result["preparation"].update(deepcopy(dict(item_alert)))
                    return result
                failed = self._preparation_failure(
                    self._now(), expected_generation=generation, stage=stage, error_type=error_type
                )
                result = self._preparation_result(
                    failed,
                    outcome="failure",
                    reason=error_type,
                    display_state=state,
                    alert_pending=failed.get("alert_claimed_now") is True,
                )
                result.update(
                    {
                        "target_count": len(targets),
                        "updated_count": updated_count,
                        "unknown_count": unknown_count,
                        "request_count": request_count,
                        "checked_at": now,
                        "errors": errors,
                    }
                )
                return result
            remaining_items = (
                preparation_item_reader() if callable(preparation_item_reader) else []
            )
            final_state = "partial" if remaining_items else "ready"
            waiting_retry = False
            next_retry_at: object | None = None
            probe_stage: str | None = None
            for item in remaining_items:
                if not isinstance(item, Mapping) or item.get("state") != "waiting_retry":
                    continue
                if probe_stage is None:
                    probe_stage = str(item.get("stage") or "history")
                retry_at = item.get("next_retry_at")
                if retry_at:
                    try:
                        retry_timestamp = _timestamp(retry_at, name="next_retry_at")
                        waiting_retry = now < retry_timestamp
                        if waiting_retry and (
                            next_retry_at is None
                            or retry_timestamp < _timestamp(
                                next_retry_at, name="next_retry_at"
                            )
                        ):
                            next_retry_at = retry_timestamp
                    except ValueError:
                        waiting_retry = True
            completed = self._save_preparation(
                {
                    "state": final_state,
                    "stage": "complete",
                    "failure_count": 0,
                    "paused": False,
                    "attempt": 0,
                    "last_progress_at": now,
                    "completed_count": len(targets),
                    "total_count": len(targets),
                    "next_retry_at": next_retry_at,
                    "next_probe_at": (
                        now + timedelta(seconds=60) if waiting_retry else None
                    ),
                    "last_probe_stage": probe_stage,
                    "last_error": None,
                    **({"last_success_at": now} if final_state == "ready" else {}),
                    **(
                        self._clear_unacknowledged_fault_episode()
                        if final_state == "ready"
                        else {}
                    ),
                    **(
                        self._ensure_fault_episode(now)
                        if final_state == "partial"
                        else {}
                    ),
                },
                expected_generation=generation,
            )
            result = self._preparation_result(
                completed,
                outcome="waiting_retry" if waiting_retry else "success",
                reason="retry_not_due" if waiting_retry else None,
                display_state=state if final_state == "ready" else final_state,
            )
            result.update(
                {
                    "target_count": len(targets),
                    "updated_count": updated_count,
                    "unknown_count": unknown_count,
                    "request_count": request_count,
                    "checked_at": now,
                    "errors": errors,
                }
            )
            return result
        except (sqlite3.Error, _PreparationDatabaseFailure) as exc:
            current = self.preparation_snapshot()
            failed = self._preparation_failure(
                self._now(), stage=str(current.get("stage") or "catalog"),
                error_type=exc.facts if isinstance(exc, _PreparationDatabaseFailure) else exc,
                expected_generation=generation,
            )
            return self._preparation_result(
                failed, outcome="failure", reason=str(failed.get("last_error") or "unknown_error"),
                display_state="unknown", alert_pending=failed.get("alert_claimed_now") is True,
            )
        finally:
            if preparation_owner_acquired:
                owner_releaser = getattr(
                    self.store, "lp_release_preparation_owner", None
                )
                if callable(owner_releaser):
                    owner_releaser()
            self._price_history_refresh_lock.release()

    def _restore_candidate_snapshot(
        self, saved: Mapping[str, object] | None = None
    ) -> None:
        """Restore the rolling pool, rotation schedule, and confirmations.

        Issue #157: pool rows keep their original ``updated_at`` and
        ``expires_at``; reads judge expiry against the current clock, so a
        row saved before a restart ages out exactly when it would have
        without the restart, and reading never extends its validity.
        """

        if saved is None:
            reader = getattr(self.store, "lp_screening_snapshot", None)
            if not callable(reader):
                return
            try:
                saved = reader()
            except Exception:
                return
        if not isinstance(saved, Mapping):
            return
        current_global_generation = self._current_candidate_global_generation()
        if current_global_generation is None:
            return
        saved_global_generation = self._candidate_global_generation(
            saved.get("global_recovery_generation")
        )
        if current_global_generation > saved_global_generation:
            return
        pool = saved.get("pool")
        if not isinstance(pool, Mapping) or not pool:
            # Pre-pool snapshots carry whole-round rows without per-row
            # judgment times.  They cannot be presented as valid estimates
            # under the rolling contract, so the pool starts empty — but the
            # row metadata is still kept: preparation prioritization (issue
            # #152 era) consumes the persisted selected_results markers.
            with self._candidate_state_lock:
                self._candidate_attempted_at = None
                # state/complete are whole-round claims: a legacy snapshot
                # must not present itself as a valid result, so only the
                # prioritization inputs are restored.
                for key in (
                    "selected_results",
                    "recommendations",
                    "event_end_confirmations",
                ):
                    if key in saved:
                        self._candidate_snapshot[key] = deepcopy(saved[key])
                self._candidate_snapshot["scanning"] = False
            return
        restored_pool: dict[str, dict[str, object]] = {}
        for condition_id, row in pool.items():
            key = str(condition_id or "").strip()
            if key and isinstance(row, Mapping):
                restored_pool[key] = dict(row)
                restored_pool[key].setdefault(
                    "global_recovery_generation", saved_global_generation
                )
                if row.get('estimate_basis') != 'minimum_scoring_order':
                    # Do not relabel a prior release's 5% estimate. Keep its
                    # original validity times; refresh supplies the new basis.
                    _apply_row_estimate_fields(restored_pool[key], None)
        if self.exclusions_enabled:
            restored_pool = {cid: row for cid, row in restored_pool.items()
                if self._candidate_allowed(((cid, str((row.get("selected_direction") or {}).get("token_id") or "")),))}
        raw_rotation = saved.get("rotation")
        restored_rotation: dict[str, dict[str, object]] = {}
        if isinstance(raw_rotation, Mapping):
            for condition_id, entry in raw_rotation.items():
                key = str(condition_id or "").strip()
                if key and isinstance(entry, Mapping):
                    restored_rotation[key] = dict(entry)
        with self._candidate_state_lock:
            self._candidate_pool = restored_pool
            self._candidate_rotation = restored_rotation
            confirmations = saved.get("event_end_confirmations")
            if isinstance(confirmations, Mapping):
                self._candidate_snapshot["event_end_confirmations"] = deepcopy(
                    dict(confirmations)
                )
            self._candidate_snapshot["scanning"] = False
            self._candidate_snapshot["last_attempt_at"] = saved.get(
                "last_attempt_at"
            )
            try:
                self._candidate_attempted_at = _timestamp(
                    saved.get("last_attempt_at"), name="last_attempt_at"
                )
            except ValueError:
                self._candidate_attempted_at = None

    def _candidate_queue_state_build(
        self,
        *,
        stop_event: threading.Event | None = None,
        global_recovery_generation: int | None = None,
    ) -> dict[str, object] | None:
        """Build (or reuse) the exploration queues from prepared inputs.

        Issue #157: the base-filter queues and the direction facts behind
        them are cached in memory keyed by the prepared-inputs version and
        rebuilt only when those inputs change — batches rotate through the
        cached order without re-reading the catalog.  Returns ``None``
        while preparation is pending or the catalog is unusable.
        """

        expected_global_generation = (
            self._candidate_global_generation(global_recovery_generation)
            if type(global_recovery_generation) is int and global_recovery_generation >= 0
            else self._current_candidate_global_generation()
        )
        if not self._candidate_generation_allowed(expected_global_generation):
            return None
        # The available budget feeds the over-available exclusion, so the
        # reservation signature joins the cache key: a new active
        # reservation invalidates the cached queues.
        self._evict_excluded_candidates()
        reservations = self._candidate_reservations()
        reservation_signature = tuple(
            (str(entry.get("order_id")), str(entry.get("amount")))
            for entry in reservations
        )
        with self._competition_lock:
            competition_version = self._competition_version
        with self._candidate_state_lock:
            self._candidate_queue_build_sequence += 1
            build_sequence = self._candidate_queue_build_sequence
            version = self._prepared_inputs_version
            history_version = self._candidate_history_version
            cached = self._candidate_queue_state
        if (
            cached is not None
            and cached.get("version") == version
            and cached.get("history_version") == history_version
            and cached.get("competition_version") == competition_version
            and cached.get("reservation_signature") == reservation_signature
            and self._candidate_global_generation(
                cached.get("global_recovery_generation")
            )
            == expected_global_generation
        ):
            return cached
        prepared = self._prepared_input_snapshot()
        if not isinstance(prepared, Mapping):
            return None
        catalog = prepared.get("catalog")
        metadata_value = prepared.get("metadata")
        if not isinstance(catalog, Mapping):
            return None
        raw_markets = (
            catalog.get("markets") if isinstance(catalog, Mapping) else None
        )
        if not isinstance(raw_markets, (list, tuple, LPReadRows)):
            return None
        market_rows = raw_markets
        competition_metadata = {}
        competition = self._competition_entries(
            tuple(dict.fromkeys(str(row.get("condition_id") or "") for row in market_rows)),
            metadata=competition_metadata,
        )
        competition_version = competition_metadata["version"]
        if self.exclusions_enabled:
            allowed = set(self._candidate_conditions(tuple(str(r.get("condition_id") or "") for r in market_rows)))
            market_rows = LPReadRows(r for r in market_rows if str(r.get("condition_id") or "") in allowed)
        if not isinstance(metadata_value, Mapping):
            return None
        metadata_by_condition = metadata_value
        catalog_reader = getattr(self.exchange, "lp_reward_catalog", None)
        account_reader = getattr(
            self.exchange, "lp_account_snapshot_shared", None
        )
        if not callable(account_reader):
            account_reader = getattr(self.exchange, "lp_account_snapshot", None)
        if not callable(catalog_reader) or not callable(account_reader):
            return None
        condition_ids = tuple(
            dict.fromkeys(
                str(row.get("condition_id") or "").strip()
                for row in market_rows
                if str(row.get("condition_id") or "").strip()
            )
        )
        missing_metadata_condition_ids = tuple(
            condition_id
            for condition_id in condition_ids
            if not isinstance(metadata_by_condition.get(condition_id), Mapping)
        )
        build_revision = self._candidate_exclusion_revision
        account: Mapping[str, object] | None = None
        if market_rows:
            # An empty catalog needs no budget facts at all.
            try:
                account_value = account_reader()
            except Exception:
                account_value = None
            if (
                isinstance(account_value, Mapping)
                and account_value.get("authenticated") is True
            ):
                account = account_value
        checked_at = self._now()
        cache_batch_reader = getattr(
            self.store, "lp_price_history_summaries", None
        )
        cache_reader = getattr(self.store, "lp_price_history_summary", None)
        saved_screening = getattr(
            self.store, "lp_screening_snapshot", lambda: None
        )()
        saved_confirmations = (
            saved_screening.get("event_end_confirmations", {})
            if isinstance(saved_screening, Mapping)
            else {}
        )
        event_end_confirmations = (
            deepcopy(dict(saved_confirmations))
            if isinstance(saved_confirmations, Mapping)
            else {}
        )
        direction_facts = LPDirectionScratch(LPReadOverlay(metadata_by_condition))
        direction_keys: dict[str, list[str]] = {}
        direction_index = 0
        complete = (
            isinstance(catalog, Mapping)
            and catalog.get("state") == "known"
            and catalog.get("complete") is True
            and not missing_metadata_condition_ids
        )
        cache_identities = tuple(
            (
                condition_id,
                str(outcome.get("token_id") or "").strip(),
            )
            for reward_market in market_rows
            for condition_id in (
                str(reward_market.get("condition_id") or "").strip(),
            )
            for market_meta in (metadata_by_condition.get(condition_id),)
            if isinstance(market_meta, Mapping)
            and isinstance(market_meta.get("outcomes"), Mapping)
            for outcome in cast(
                Mapping[object, object], market_meta["outcomes"]
            ).values()
            if isinstance(outcome, Mapping)
            and str(outcome.get("token_id") or "").strip()
        )
        snapshot_reader = getattr(self.store, "lp_price_history_summary_batches", None)
        cached_summaries = LPReadScratch()
        if callable(snapshot_reader):
            from contextlib import closing
            try:
                with closing(snapshot_reader(cache_identities, now=checked_at)) as batches:
                    for summary_batch in batches:
                        cached_summaries.update((json.dumps(key), value) for key, value in summary_batch.items())
                        del summary_batch
            except Exception:
                cached_summaries.clear()
        elif callable(cache_batch_reader):
            try:
                batch_value = cache_batch_reader(cache_identities, now=checked_at)
            except Exception:
                batch_value = {}
            if isinstance(batch_value, Mapping):
                cached_summaries.update((json.dumps(key), value) for key, value in batch_value.items())
                del batch_value
        reward_market_by_condition = LPReadScratch()
        for reward_market in market_rows:
            condition_id = str(reward_market.get("condition_id") or "").strip()
            market_meta = metadata_by_condition.get(condition_id)
            if self.exclusions_enabled and isinstance(market_meta, Mapping):
                if self._observe_ended_candidate_market(
                    condition_id,
                    market_meta,
                    checked_at=checked_at,
                    global_recovery_generation=expected_global_generation,
                ):
                    build_revision = self._candidate_exclusion_revision
                reason = self._candidate_market_rejection(reward_market, market_meta, now=checked_at, competition=competition)
                if reason:
                    if self._exclude_candidate(condition_id, "", reason, checked_at=checked_at, market=market_meta,
                            exclusion_revision=build_revision,
                            global_recovery_generation=expected_global_generation):
                        build_revision = self._candidate_exclusion_revision
                    continue
            if not isinstance(market_meta, Mapping):
                complete = False
                continue
            raw_outcomes = market_meta.get("outcomes")
            if not isinstance(raw_outcomes, Mapping):
                complete = False
                continue
            reward_minimum, reward_spread = _lp_reward_terms(
                market_meta,
                reward_market,
            )
            if reward_minimum is None or reward_spread is None:
                complete = False
            confirmation = event_end_confirmations.get(condition_id)
            reward_deadline = self._reward_guidance_deadline(reward_market)
            reward_market_by_condition[condition_id] = reward_market
            for outcome_key, raw_outcome in raw_outcomes.items():
                if str(outcome_key).lower() not in {"yes", "no"} or not isinstance(
                    raw_outcome, Mapping
                ):
                    continue
                token_id = str(raw_outcome.get("token_id") or "").strip()
                if not token_id:
                    complete = False
                    continue
                if not self._candidate_allowed(((condition_id, token_id),), now=checked_at):
                    continue
                summary: Mapping[str, object] | None = None
                cache_key = (condition_id, token_id)
                cached_summary = cached_summaries.get(json.dumps(cache_key))
                if isinstance(cached_summary, Mapping):
                    summary = cached_summary
                elif not callable(cache_batch_reader) and callable(cache_reader):
                    try:
                        cached = cache_reader(
                            condition_id, token_id, now=checked_at
                        )
                    except Exception:
                        cached = None
                    if isinstance(cached, Mapping):
                        summary = cached
                if self.exclusions_enabled:
                    from .polymarket_lp_views import lp_history_eligibility
                    if lp_history_eligibility(summary, now=checked_at, condition_id=condition_id, token_id=token_id) == "history_amplitude_exceeded":
                        if self._exclude_candidate(condition_id, token_id, "history_amplitude_exceeded",
                                checked_at=_timestamp(summary["checked_at"], name="history_checked_at"),
                                exclusion_revision=build_revision,
                                global_recovery_generation=expected_global_generation):
                            build_revision = self._candidate_exclusion_revision
                        if not self._candidate_allowed(((condition_id, token_id),), now=checked_at):
                            continue
                direction_facts[str(direction_index)] = _lp_direction_fact(
                    market_meta,
                    reward_market,
                    condition_id=condition_id,
                    token_id=token_id,
                    outcome=str(raw_outcome.get("label") or outcome_key).upper(),
                    reward_checked_at=catalog.get("checked_at"),
                    reward_guidance_deadline=reward_deadline,
                    event_end_confirmation=confirmation,
                    history_summary=summary,
                    account=account,
                    compact_market=True,
                )
                direction_keys.setdefault(condition_id, []).append(str(direction_index))
                direction_index += 1
        del cached_summaries

        from .polymarket_lp_views import lp_trial_candidates

        available_facts: dict[str, object] = {}
        if account is not None:
            adjusted_account = _account_after_reservations(
                account, self._candidate_reservations()
            )
            if isinstance(adjusted_account, Mapping):
                adjusted_balance = _maybe_decimal(
                    adjusted_account.get("balance")
                )
                adjusted_allowance = _maybe_decimal(
                    adjusted_account.get("allowance")
                )
                if adjusted_balance is not None and adjusted_allowance is not None:
                    available_facts["available_capital"] = min(
                        adjusted_balance, adjusted_allowance
                    )
        trial = lp_trial_candidates(
            direction_facts.values(),
            competition=competition,
            account_budget_facts=available_facts,
            now=checked_at,
            competition_round_checked_at=(
                competition_metadata.get("round_checked_at")
            ),
        )
        queue_normal = [
            dict(row)
            for row in (trial.get("queue_normal") or ())
            if isinstance(row, Mapping)
        ]
        queue_backup = [
            dict(row)
            for row in (trial.get("queue_backup") or ())
            if isinstance(row, Mapping)
        ]
        trial_funnel = dict(trial.get("funnel") or {})
        queue_funnel = {
            key: deepcopy(trial_funnel.get(key))
            for key in (
                "read",
                "base",
                "sort",
                "competition_known",
                "competition_unknown",
                "excluded",
                "competition_light",
                "competition_mid",
                "competition_round_checked_at",
                "normal_queue_count",
                "backup_queue_count",
                "reference_price_unknown",
                "compared_range",
                "reasons",
                "budget",
            )
            if key in trial_funnel
        }
        queue_funnel["compared_range"] = deepcopy(
            trial.get("compared_range") or {}
        )
        queue_funnel["queue_total"] = len(queue_normal) + len(queue_backup)
        queue_condition_ids: dict[str, None] = {}
        for candidate in (*queue_normal, *queue_backup):
            if not isinstance(candidate, Mapping):
                continue
            condition_id = str(candidate.get("condition_id") or "").strip()
            if condition_id:
                queue_condition_ids[condition_id] = None
        # Keep the published (JSON-like) funnel shape, as the whole-scan
        # snapshot did through its durable-store round trip.
        queue_funnel = _pool_published_value(queue_funnel)
        for cid in tuple(reward_market_by_condition):
            if cid not in queue_condition_ids:
                del reward_market_by_condition[cid]
        state = {
            "version": version,
            "history_version": history_version,
            "competition_version": competition_version,
            "build_sequence": build_sequence,
            "reservation_signature": reservation_signature,
            "queue_normal": queue_normal,
            "queue_backup": queue_backup,
            "directions_by_condition": LPDirectionIndex(
                direction_facts, {cid: direction_keys[cid] for cid in queue_condition_ids}
            ),
            "metadata_by_condition": LPReadOverlay(metadata_by_condition, queue_condition_ids),
            "reward_market_by_condition": reward_market_by_condition,
            "catalog_checked_at": catalog.get("checked_at"),
            "catalog_is_known": (
                isinstance(catalog, Mapping)
                and catalog.get("state") == "known"
            ),
            "catalog_complete": (
                isinstance(catalog, Mapping)
                and catalog.get("complete") is True
            ),
            "complete": complete,
            "event_end_confirmations": event_end_confirmations,
            "missing_metadata_condition_ids": missing_metadata_condition_ids,
            "queue_funnel": queue_funnel,
            "compared_range": dict(trial.get("compared_range") or {}),
            "evaluation_account": deepcopy(dict(account))
            if isinstance(account, Mapping)
            else None,
            "built_at": checked_at,
            "global_recovery_generation": expected_global_generation,
        }
        with self._candidate_state_lock:
            if version != self._prepared_inputs_version:
                return None
            if not self._candidate_generation_allowed(expected_global_generation):
                return None
            if self.exclusions_enabled and build_revision != self._candidate_exclusion_revision:
                return None
            current = self._candidate_queue_state
            if current is not None and (
                current.get("competition_version", 0) > competition_version
                or current.get("build_sequence", 0) > build_sequence
            ):
                return current
            self._candidate_queue_state = state
            self._candidate_queue_funnel = dict(queue_funnel)
            self._candidate_queue_condition_ids = tuple(queue_condition_ids)
            self._evict_excluded_candidates()
            return self._candidate_queue_state or state

    def _candidate_rotation_entry(
        self, condition_id: str
    ) -> dict[str, object]:
        with self._candidate_state_lock:
            entry = self._candidate_rotation.get(condition_id)
        if isinstance(entry, Mapping):
            return dict(entry)
        return {"last_attempt_at": None, "failures": 0}

    def _candidate_rotation_due(
        self, condition_id: str, *, now: datetime
    ) -> bool:
        """Whether a tried market's failure backoff has elapsed (issue #157).

        The ladder stays 60/120/300 seconds per market and a success resets
        it; deterministic rejections and successes never wait.
        """

        entry = self._candidate_rotation_entry(condition_id)
        failures = entry.get("failures")
        last_attempt_at = _candidate_row_updated_at(
            {"updated_at": entry.get("last_attempt_at")}
        )
        if last_attempt_at is None:
            return True
        if not isinstance(failures, int) or failures <= 0:
            return True
        backoff = _CANDIDATE_MAINTENANCE_BACKOFF_SECONDS[
            min(failures - 1, len(_CANDIDATE_MAINTENANCE_BACKOFF_SECONDS) - 1)
        ]
        return now >= last_attempt_at + timedelta(seconds=float(backoff))

    def _select_candidate_batch(
        self,
        queue_state: Mapping[str, object],
        *,
        now: datetime,
    ) -> list[tuple[Mapping[str, object], str]]:
        """Pick the next exploration batch (issue #157 rotation order).

        Markets never tried come first in the base queue order (normal then
        backup); the rest follow by oldest attempt time with markets inside
        their failure backoff skipped.  The batch never exceeds
        ``_LP_CANDIDATE_BATCH_SIZE`` markets.
        """

        ordered: list[tuple[Mapping[str, object], str]] = []
        seen: set[str] = set()
        for queue in ("queue_normal", "queue_backup"):
            for candidate in queue_state.get(queue) or ():
                if not isinstance(candidate, Mapping):
                    continue
                condition_id = str(
                    candidate.get("condition_id") or ""
                ).strip()
                if not condition_id or condition_id in seen:
                    continue
                seen.add(condition_id)
                ordered.append((candidate, condition_id))
        untried: list[tuple[Mapping[str, object], str]] = []
        due: list[tuple[datetime, Mapping[str, object], str]] = []
        with self._candidate_state_lock:
            rotation = deepcopy(self._candidate_rotation)
        for candidate, condition_id in ordered:
            entry = rotation.get(condition_id)
            last_attempt_at = (
                _candidate_row_updated_at(
                    {"updated_at": (entry or {}).get("last_attempt_at")}
                )
                if isinstance(entry, Mapping)
                else None
            )
            if last_attempt_at is None:
                untried.append((candidate, condition_id))
                continue
            if not self._candidate_rotation_due(condition_id, now=now):
                continue
            due.append((last_attempt_at, candidate, condition_id))
        due.sort(key=lambda item: item[0])
        batch = [*untried, *[(candidate, cid) for _, candidate, cid in due]]
        return batch[:_LP_CANDIDATE_BATCH_SIZE]

    def _renew_batch_shared_facts(
        self,
        queue_state: MutableMapping[str, object],
        condition_ids: tuple[str, ...],
        *,
        stop_event: threading.Event | None,
        global_recovery_generation: int | None = None,
    ) -> Mapping[str, object] | None:
        """Renew expired shared facts for one batch (issue #143 repair 2).

        The shared facts (metadata+fees, reward catalog, account) come from
        the cached queue state, but a rolling batch runs long after that
        build, so every batch re-checks their age on its own clock and
        renews each expired class once — targeted at that batch's
        conditions only.  A failed renewal keeps the previous facts and is
        not retried within the batch.
        """

        if not self._candidate_generation_allowed(global_recovery_generation):
            return None

        directions_by_condition = cast(
            MutableMapping[str, list[Mapping[str, object]]],
            queue_state["directions_by_condition"],
        )
        metadata_by_condition = cast(
            MutableMapping[str, Mapping[str, object]],
            queue_state["metadata_by_condition"],
        )
        reward_market_by_condition = cast(
            MutableMapping[str, Mapping[str, object]],
            queue_state["reward_market_by_condition"],
        )
        evaluation_account = queue_state.get("evaluation_account")
        evaluation_account = (
            deepcopy(dict(evaluation_account))
            if isinstance(evaluation_account, Mapping)
            else None
        )
        now = self._now()
        condition_ids = self._candidate_conditions(condition_ids, now=now)
        fresh_metadata: dict[str, Mapping[str, object]] = {}
        fresh_rewards: dict[str, Mapping[str, object]] = {}
        fresh_reward_stamps: dict[str, object] = {}
        sources = ("reward", "metadata") if self.exclusions_enabled else ("metadata", "reward")
        renewal_revision = self._candidate_exclusion_revision
        for source in sources:
            stage_revision = renewal_revision
            if source == "metadata":
                stale_metadata_ids = _lp_metadata_stale_conditions(
                    directions_by_condition, condition_ids, now
                )
                if stale_metadata_ids:
                    reader = getattr(self.exchange, "lp_market_metadata_fresh", None)
                    if not callable(reader):
                        reader = getattr(self.exchange, "lp_market_metadata", None)
                    raw_metadata: object = None
                    if callable(reader):
                        try:
                            raw_metadata = reader(
                                stale_metadata_ids, stop_event=stop_event
                            )
                        except TypeError:
                            try:
                                raw_metadata = reader(stale_metadata_ids)
                            except Exception:
                                raw_metadata = None
                        except Exception:
                            raw_metadata = None
                    metadata_rows = (
                        raw_metadata if isinstance(raw_metadata, Mapping) else {}
                    )
                    for condition_id in stale_metadata_ids:
                        row = metadata_rows.get(condition_id)
                        if not isinstance(row, Mapping):
                            continue
                        observed_at = self._now()
                        if _candidate_source_expired(
                            row.get("metadata_checked_at"), observed_at
                        ) or _candidate_source_expired(
                            row.get("fees_checked_at"), observed_at
                        ):
                            continue
                        fresh_metadata[condition_id] = row
                    with self._candidate_state_lock:
                        metadata_by_condition.update({cid: row for cid, row in fresh_metadata.items()
                            if cid in metadata_by_condition and self._candidate_conditions((cid,))})

            else:
                stale_reward_ids = _lp_reward_stale_conditions(
                    directions_by_condition, condition_ids, now
                )
                if stale_reward_ids:
                    catalog_reader = getattr(self.exchange, "lp_reward_catalog", None)
                    raw_reward: object = None
                    if callable(catalog_reader):
                        try:
                            raw_reward = catalog_reader(
                                condition_ids=stale_reward_ids, stop_event=stop_event
                            )
                        except TypeError:
                            try:
                                raw_reward = catalog_reader(
                                    condition_ids=stale_reward_ids
                                )
                            except Exception:
                                raw_reward = None
                        except Exception:
                            raw_reward = None
                    raw_rows = (
                        raw_reward.get("markets")
                        if isinstance(raw_reward, Mapping)
                        else None
                    )
                    reward_rows_by_id: dict[str, Mapping[str, object]] = {}
                    if isinstance(raw_rows, Mapping):
                        reward_rows_by_id = {
                            str(key): value
                            for key, value in raw_rows.items()
                            if isinstance(value, Mapping)
                        }
                    elif isinstance(raw_rows, (list, tuple)):
                        for row in raw_rows:
                            if isinstance(row, Mapping):
                                reward_rows_by_id.setdefault(
                                    str(row.get("condition_id") or ""), row
                                )
                    observed_at = self._now()
                    for condition_id in stale_reward_ids:
                        row = reward_rows_by_id.get(condition_id)
                        if (
                            not isinstance(row, Mapping)
                            or row.get("state") == "unknown"
                        ):
                            continue
                        reward_stamp = row.get("reward_checked_at")
                        if reward_stamp is None and isinstance(raw_reward, Mapping):
                            reward_stamp = raw_reward.get("checked_at")
                        if _candidate_source_expired(reward_stamp, observed_at):
                            continue
                        fresh_rewards[condition_id] = row
                        fresh_reward_stamps[condition_id] = reward_stamp

            if self.exclusions_enabled:
                with self._candidate_state_lock:
                    reward_market_by_condition.update({cid: row for cid, row in fresh_rewards.items()
                        if cid in reward_market_by_condition and self._candidate_conditions((cid,))})
                renewal_revision = self._screen_candidate_batch(
                    queue_state,
                    condition_ids,
                    checked_at=now,
                    exclusion_revision=stage_revision,
                    global_recovery_generation=global_recovery_generation,
                )
                condition_ids = self._candidate_conditions(condition_ids)

        account_reader = getattr(
            self.exchange, "lp_account_snapshot_shared", None
        )
        if not callable(account_reader):
            account_reader = getattr(self.exchange, "lp_account_snapshot", None)
        if evaluation_account is None or _candidate_source_expired(
            evaluation_account.get("checked_at"), now
        ):
            if callable(account_reader):
                try:
                    refreshed_account = account_reader()
                except Exception:
                    refreshed_account = None
                if (
                    isinstance(refreshed_account, Mapping)
                    and refreshed_account.get("authenticated") is True
                    and not _candidate_source_expired(
                        refreshed_account.get("checked_at"), self._now()
                    )
                ):
                    evaluation_account = deepcopy(dict(refreshed_account))
        if self.exclusions_enabled:
            queue_state["candidate_read_revision"] = renewal_revision
        queue_state["evaluation_account"] = (
            deepcopy(dict(evaluation_account))
            if isinstance(evaluation_account, Mapping)
            else None
        )

        renewed_ids = tuple(dict.fromkeys((*fresh_metadata, *fresh_rewards)))
        for condition_id in renewed_ids:
            market_meta = (
                fresh_metadata[condition_id]
                if condition_id in fresh_metadata
                else metadata_by_condition.get(condition_id)
            )
            reward_row = (
                fresh_rewards[condition_id]
                if condition_id in fresh_rewards
                else reward_market_by_condition.get(condition_id)
            )
            if (
                not isinstance(market_meta, Mapping)
                or not isinstance(reward_row, Mapping)
            ):
                continue
            reward_deadline = self._reward_guidance_deadline(reward_row)
            rebuilt: list[Mapping[str, object]] = []
            for direction in directions_by_condition.get(condition_id, ()):
                if not isinstance(direction, Mapping):
                    continue
                market = direction.get("market")
                if not isinstance(market, Mapping):
                    continue
                outcome = str(market.get("outcome") or "").upper()
                token_id = str(market.get("token_id") or "").strip()
                if outcome not in {"YES", "NO"} or not token_id:
                    continue
                rebuilt.append(
                    _lp_direction_fact(
                        market_meta,
                        reward_row,
                        condition_id=condition_id,
                        token_id=token_id,
                        outcome=outcome,
                        reward_checked_at=(
                            fresh_reward_stamps[condition_id]
                            if condition_id in fresh_reward_stamps
                            else direction.get("reward_checked_at")
                        ),
                        reward_guidance_deadline=reward_deadline,
                        event_end_confirmation=direction.get(
                            "event_end_confirmation"
                        ),
                        history_summary=direction.get("history_summary"),
                        account=evaluation_account,
                    )
                )
            if rebuilt:
                with self._candidate_state_lock:
                    if condition_id in directions_by_condition and self._candidate_conditions((condition_id,)):
                        directions_by_condition[condition_id] = rebuilt
        return evaluation_account

    def _screen_candidate_histories(
        self,
        directions,
        *,
        checked_at,
        exclusion_revision,
        global_recovery_generation=None,
    ):
        if not self._candidate_generation_allowed(global_recovery_generation):
            return exclusion_revision
        for direction in tuple(directions):
            market = direction.get("market", {})
            cid, token = str(market.get("condition_id") or ""), str(market.get("token_id") or "")
            if not self._candidate_allowed(((cid, token),)):
                continue
            summary, reason = self._lp_history_fact(cid, token, now=checked_at)
            if reason == "history_amplitude_exceeded" and isinstance(summary, Mapping):
                if self._exclude_candidate(cid, token, reason,
                        checked_at=_timestamp(summary["checked_at"], name="history_checked_at"),
                        exclusion_revision=exclusion_revision,
                        global_recovery_generation=global_recovery_generation):
                    exclusion_revision = self._candidate_exclusion_revision
        return exclusion_revision

    def _screen_candidate_batch(
        self,
        queue_state,
        condition_ids,
        *,
        checked_at,
        exclusion_revision=None,
        global_recovery_generation=None,
    ):
        if not self.exclusions_enabled:
            return
        if not self._candidate_generation_allowed(global_recovery_generation):
            return exclusion_revision
        for cid in condition_ids:
            market = queue_state.get("metadata_by_condition", {}).get(cid, {})
            reward = queue_state.get("reward_market_by_condition", {}).get(cid, {})
            if not self._candidate_conditions((cid,)):
                continue
            if self._observe_ended_candidate_market(
                cid,
                market,
                checked_at=checked_at,
                global_recovery_generation=global_recovery_generation,
            ):
                continue
            reason = self._candidate_market_rejection(reward, market, now=checked_at)
            if reason:
                if self._exclude_candidate(cid, "", reason, checked_at=checked_at, market=market,
                        exclusion_revision=exclusion_revision,
                        global_recovery_generation=global_recovery_generation):
                    exclusion_revision = self._candidate_exclusion_revision
            else:
                exclusion_revision = self._screen_candidate_histories(
                    queue_state.get("directions_by_condition", {}).get(cid, ()),
                    checked_at=checked_at,
                    exclusion_revision=exclusion_revision,
                    global_recovery_generation=global_recovery_generation,
                )
        return exclusion_revision

    def _candidate_pool_record_success(
        self,
        condition_id: str,
        row: Mapping[str, object],
        *,
        judged_at: datetime,
        facts: Mapping[str, object] | None = None,
        exclusion_revision: int | None = None,
        global_recovery_generation: int | None = None,
    ) -> bool:
        """Store one successful estimate in the pool (issue #157).

        One-line write protection: the new result wins only when its
        judgment time is at or after the stored row's ``updated_at`` — a
        late-arriving older evaluation never overwrites a newer one.  A
        success also resets the market's rotation failure ladder.
        """

        stored = _pool_published_value(dict(row))
        stored["updated_at"] = _iso(judged_at)
        stored["expires_at"] = _iso(
            judged_at
            + timedelta(seconds=float(LP_CANDIDATE_VALIDITY_SECONDS))
        )
        stored["refresh_failed"] = False
        with self._candidate_state_lock:
            expected_global_generation = (
                self._candidate_global_generation(global_recovery_generation)
                if type(global_recovery_generation) is int
                and global_recovery_generation >= 0
                else self._current_candidate_global_generation()
            )
            if not self._candidate_generation_allowed(expected_global_generation):
                return False
            stored["global_recovery_generation"] = expected_global_generation
            selected = row.get("selected_direction") or {}
            if self.exclusions_enabled and (
                (exclusion_revision is not None and exclusion_revision != self._candidate_exclusion_revision)
                or not self._candidate_allowed(((condition_id, str(selected.get("token_id") or "")),))
            ):
                return False
            existing = self._candidate_pool.get(condition_id)
            if existing is not None:
                existing_updated = _candidate_row_updated_at(existing)
                if existing_updated is not None and existing_updated > judged_at:
                    return False
            self._candidate_pool[condition_id] = stored
            if facts is not None:
                stored_facts = deepcopy(dict(facts))
                stored_facts["global_recovery_generation"] = expected_global_generation
                self._candidate_qualification_facts[condition_id] = stored_facts
            entry = self._candidate_rotation.get(condition_id)
            rotation = dict(entry) if isinstance(entry, Mapping) else {}
            rotation["last_attempt_at"] = _iso(judged_at)
            rotation["failures"] = 0
            self._candidate_rotation[condition_id] = rotation
        return True

    def _candidate_pool_record_failure(
        self,
        condition_id: str,
        *,
        attempted_at: datetime,
        global_recovery_generation: int | None = None,
    ) -> None:
        """Keep the stored row on a failed re-estimate (issue #157).

        The row keeps its values until its original ``expires_at``, is
        marked ``refresh_failed``, and its ``updated_at`` never moves; the
        market's rotation failure ladder advances (60/120/300s).  A failure
        judged before the stored row's ``updated_at`` is a late arrival: it
        neither mislabels the newer row nor advances the ladder (issue #157
        review R4).
        """

        with self._candidate_state_lock:
            expected_global_generation = (
                self._candidate_global_generation(global_recovery_generation)
                if type(global_recovery_generation) is int
                and global_recovery_generation >= 0
                else self._current_candidate_global_generation()
            )
            if not self._candidate_generation_allowed(expected_global_generation):
                return
            if not self._candidate_conditions((condition_id,)):
                return
            existing = self._candidate_pool.get(condition_id)
            if existing is not None:
                existing_updated = _candidate_row_updated_at(existing)
                if (
                    existing_updated is not None
                    and existing_updated > attempted_at
                ):
                    return
                existing["refresh_failed"] = True
            entry = self._candidate_rotation.get(condition_id)
            rotation = dict(entry) if isinstance(entry, Mapping) else {}
            rotation["last_attempt_at"] = _iso(attempted_at)
            failures = rotation.get("failures")
            rotation["failures"] = (
                failures + 1 if isinstance(failures, int) else 1
            )
            self._candidate_rotation[condition_id] = rotation

    def _candidate_pool_record_rejection(
        self,
        condition_id: str,
        *,
        judged_at: datetime,
        global_recovery_generation: int | None = None,
    ) -> None:
        """Remove a deterministically rejected market from the pool and put
        it back at the rotation tail (issue #157).

        A rejection judged before the stored row's ``updated_at`` is a late
        arrival: the newer row keeps its place in the pool (issue #157
        review R4)."""

        with self._candidate_state_lock:
            expected_global_generation = (
                self._candidate_global_generation(global_recovery_generation)
                if type(global_recovery_generation) is int
                and global_recovery_generation >= 0
                else self._current_candidate_global_generation()
            )
            if not self._candidate_generation_allowed(expected_global_generation):
                return
            if not self._candidate_conditions((condition_id,)):
                return
            existing = self._candidate_pool.get(condition_id)
            if existing is not None:
                existing_updated = _candidate_row_updated_at(existing)
                if (
                    existing_updated is not None
                    and existing_updated > judged_at
                ):
                    return
            self._candidate_pool.pop(condition_id, None)
            entry = self._candidate_rotation.get(condition_id)
            rotation = dict(entry) if isinstance(entry, Mapping) else {}
            rotation["last_attempt_at"] = _iso(judged_at)
            rotation["failures"] = 0
            self._candidate_rotation[condition_id] = rotation

    def _candidate_pool_prune_expired_locked(
        self, now: datetime
    ) -> list[str]:
        """Evict expired pool rows with their qualification facts (R5).

        Called with ``_candidate_state_lock`` held from the publication
        path: every publish drops the rows the current clock has expired so
        the in-memory pool, its persisted payload, and a restart restore
        cannot grow without bound.  Reads stay read-only and never mutate
        the pool.  Returns the evicted condition ids.
        """

        expired = [
            condition_id
            for condition_id, row in self._candidate_pool.items()
            if _candidate_pool_row_expired(row, now)
        ]
        for condition_id in expired:
            self._candidate_pool.pop(condition_id, None)
            self._candidate_qualification_facts.pop(condition_id, None)
        return expired

    def _save_candidate_pool(
        self,
        *,
        force: bool = False,
        global_recovery_generation: int | None = None,
    ) -> None:
        """Persist the pool with the five-second save throttle (issue #157).

        The payload carries the pool rows with their original timestamps,
        the rotation schedule, and the event-end confirmations.  The save
        arbiter keeps the newest ``scan_started_at``, which for pool saves
        is the publish time.
        """

        writer = getattr(self.store, "lp_save_screening_snapshot", None)
        if not callable(writer):
            return
        expected_global_generation = (
            self._candidate_global_generation(global_recovery_generation)
            if type(global_recovery_generation) is int
            and global_recovery_generation >= 0
            else self._current_candidate_global_generation()
        )
        if not self._candidate_generation_allowed(expected_global_generation):
            return
        now = self._now()
        with self._candidate_state_lock:
            if not self._candidate_generation_allowed(expected_global_generation):
                return
            last = self._candidate_pool_last_saved_at
            if not force and last is not None and Decimal(
                str((now - last).total_seconds())
            ) < _LP_CANDIDATE_SNAPSHOT_SAVE_MIN_INTERVAL_SECONDS:
                return
            snapshot = deepcopy(self._candidate_snapshot)
            payload = {
                "pool_version": 2,
                "scan_started_at": _iso(now),
                "state": "ready" if self._candidate_pool else "unknown",
                "complete": True,
                "pool": deepcopy(self._candidate_pool),
                "rotation": deepcopy(self._candidate_rotation),
                "event_end_confirmations": deepcopy(
                    self._candidate_snapshot.get(
                        "event_end_confirmations", {}
                    )
                ),
                "last_attempt_at": snapshot.get("last_attempt_at"),
                "checked_at": snapshot.get("checked_at"),
                "last_success_at": snapshot.get("last_success_at"),
                "global_recovery_generation": expected_global_generation,
            }
            self._candidate_pool_last_saved_at = now
        try:
            saved = writer(payload)
            if saved is None:
                with self._candidate_state_lock:
                    self._candidate_pool_last_saved_at = None
        except Exception:
            with self._candidate_state_lock:
                self._candidate_pool_last_saved_at = None

    def _finish_candidate_scan(
        self,
        *,
        attempted_at: datetime | None = None,
        checked_at: datetime | None = None,
        success: bool = False,
        scanning: bool = False,
        complete: bool | None = None,
        state: str | None = None,
        notes: Mapping[str, object] | None = None,
        missing_book_token_ids: Sequence[str] | None = None,
        global_recovery_generation: int | None = None,
    ) -> dict[str, object]:
        """Publish the rolling pool incrementally and persist it (issue #157).

        Shared by the exploration and maintenance paths: the pool rows were
        already rewritten one by one, so this only refreshes the published
        metadata, reprojects the snapshot, and saves through the throttled
        pool writer.
        """

        now = self._now()
        attempted = attempted_at or now
        with self._candidate_state_lock:
            if not self._candidate_generation_allowed(global_recovery_generation):
                return self.candidate_snapshot()
            # Issue #157 review R5: a publication first evicts every row the
            # current clock has expired, together with its qualification
            # facts, before the refreshed metadata is published and saved.
            self._candidate_pool_prune_expired_locked(now)
            snapshot = deepcopy(self._candidate_snapshot)
            if type(global_recovery_generation) is int and global_recovery_generation >= 0:
                snapshot["global_recovery_generation"] = global_recovery_generation
            snapshot["scanning"] = scanning
            snapshot["last_attempt_at"] = attempted
            if checked_at is not None:
                snapshot["checked_at"] = checked_at
            if success:
                snapshot["last_success_at"] = checked_at or attempted
            if complete is not None:
                snapshot["complete"] = complete
            if state is not None:
                snapshot["state"] = state
            if notes:
                for key, value in notes.items():
                    snapshot[key] = deepcopy(value)
            # Issue #157 review R3/R7: a publication always carries its own
            # batch's semantics — a batch without a stop note or retention
            # reason clears any stale one instead of reporting it forever.
            snapshot["stop_reason"] = (
                deepcopy(notes.get("stop_reason")) if notes else None
            )
            snapshot["retention_reason"] = (
                deepcopy(notes.get("retention_reason")) if notes else None
            )
            if missing_book_token_ids is not None:
                snapshot["missing_book_token_ids"] = list(
                    dict.fromkeys(missing_book_token_ids)
                )
            self._candidate_snapshot = snapshot
        projection = self.candidate_snapshot()
        self._save_candidate_pool(
            global_recovery_generation=global_recovery_generation
        )
        return projection

    def refresh_candidates(
        self,
        *,
        stop_event: threading.Event | None = None,
        force: bool = False,
    ) -> dict[str, object]:
        """Process one rolling exploration batch (issue #157).

        Each call picks the next batch from the base-filter queues — markets
        never tried come first in queue order, the rest rotate by oldest
        attempt — reads the whole batch's books in one call (at most ten
        markets / 20 tokens), qualifies every market in both directions on
        the batch's renewed shared facts, and publishes the batch's results
        into the pool incrementally.  There is no round window, market cap,
        or whole-table publication anymore; a concurrent call returns the
        current snapshot with ``scanning`` set.
        """

        del force  # force only skips the runtime scheduler's wait now.
        if not self._candidate_scan_lock.acquire(blocking=False):
            snapshot = self.candidate_snapshot()
            snapshot["scanning"] = True
            return snapshot
        global_recovery_generation: int | None = None
        try:
            attempted_at = self._now()
            bid_level = self._candidate_buy_price_level()
            global_recovery_generation = self._current_candidate_global_generation()
            if global_recovery_generation is None:
                return self._finish_candidate_scan(
                    attempted_at=attempted_at,
                    global_recovery_generation=global_recovery_generation,
                    notes={"retention_reason": "recovery_generation_unknown"},
                )
            if self.exclusions_enabled:
                self.store.lp_prune_market_exclusions(now=attempted_at)
            with self._candidate_state_lock:
                self._candidate_attempted_at = attempted_at
                self._candidate_snapshot = {
                    **self._candidate_snapshot,
                    "scanning": True,
                    "last_attempt_at": attempted_at,
                }
            if stop_event is not None and stop_event.is_set():
                return self._finish_candidate_scan(
                    attempted_at=attempted_at,
                    global_recovery_generation=global_recovery_generation,
                    notes={"stop_reason": "scan_cancelled"},
                )
            queue_state = self._candidate_queue_state_build(
                stop_event=stop_event,
                global_recovery_generation=global_recovery_generation,
            )
            if queue_state is None:
                return self._finish_candidate_scan(
                    attempted_at=attempted_at,
                    global_recovery_generation=global_recovery_generation,
                    notes={
                        "stop_reason": "preparation_pending",
                        "retention_reason": "catalog_preparation_pending",
                    },
                )
            batch = self._select_candidate_batch(
                queue_state, now=self._now()
            )
            if not batch:
                queue_total = (queue_state.get("queue_funnel") or {}).get(
                    "queue_total"
                )
                if queue_total == 0:
                    # A complete catalog whose base filter keeps nothing is
                    # a valid, honestly empty pool.
                    return self._finish_candidate_scan(
                        attempted_at=attempted_at,
                        global_recovery_generation=global_recovery_generation,
                        complete=queue_state.get("complete") is True,
                        state=(
                            "ready"
                            if queue_state.get("complete") is True
                            else "incomplete"
                        ),
                    )
                return self._finish_candidate_scan(
                    attempted_at=attempted_at,
                    global_recovery_generation=global_recovery_generation,
                )
            books_reader = getattr(self.exchange, "lp_order_books", None)
            batch_tokens: list[str] = []
            directions_by_condition = cast(
                MutableMapping[str, list[Mapping[str, object]]],
                queue_state["directions_by_condition"],
            )
            for _candidate, condition_id in batch:
                for direction in directions_by_condition.get(condition_id, ()):
                    if (
                        isinstance(direction, Mapping)
                        and isinstance(direction.get("market"), Mapping)
                        and str(
                            direction["market"].get("outcome") or ""
                        ).upper()
                        in {"YES", "NO"}
                    ):
                        market = direction["market"]
                        token_id = str(market.get("token_id") or "").strip()
                        if token_id and token_id not in batch_tokens:
                            batch_tokens.append(token_id)
            # Issue #143 decision 5 (kept for #157): without a usable
            # account fact the batch is not consumed at all — zero book
            # reads, the stored rows stay for read-only display, and the
            # next batch or a manual refresh retries.
            evaluation_account = queue_state.get("evaluation_account")
            if not isinstance(evaluation_account, Mapping) or (
                _candidate_source_expired(
                    evaluation_account.get("checked_at"), self._now()
                )
            ):
                account_reader = getattr(
                    self.exchange, "lp_account_snapshot_shared", None
                )
                if not callable(account_reader):
                    account_reader = getattr(
                        self.exchange, "lp_account_snapshot", None
                    )
                refreshed_account: object = None
                if callable(account_reader):
                    try:
                        refreshed_account = account_reader()
                    except Exception:
                        refreshed_account = None
                if (
                    isinstance(refreshed_account, Mapping)
                    and refreshed_account.get("authenticated") is True
                    and not _candidate_source_expired(
                        refreshed_account.get("checked_at"), self._now()
                    )
                ):
                    evaluation_account = refreshed_account
                    queue_state["evaluation_account"] = deepcopy(
                        dict(refreshed_account)
                    )
                else:
                    evaluation_account = None
                    return self._finish_candidate_scan(
                        attempted_at=attempted_at,
                        global_recovery_generation=global_recovery_generation,
                        notes={
                            "stop_reason": "account_unavailable",
                            "retention_reason": "account_unavailable",
                        },
                    )
            exclusion_revision = self._candidate_exclusion_revision
            if self.exclusions_enabled:
                evaluation_account = self._renew_batch_shared_facts(
                    queue_state,
                    tuple(cid for _c, cid in batch),
                    stop_event=stop_event,
                    global_recovery_generation=global_recovery_generation,
                )
                batch = [(c, cid) for c, cid in batch if self._candidate_conditions((cid,))]
                batch_tokens = [str(d["market"].get("token_id") or "") for _c, cid in batch
                    for d in directions_by_condition.get(cid, ()) if self._candidate_allowed(((cid, str(d["market"].get("token_id") or "")),))]
                exclusion_revision = queue_state.get("candidate_read_revision", exclusion_revision)
            try:
                candidate_books = (
                    books_reader(tuple(batch_tokens), stop_event=stop_event)
                    if callable(books_reader)
                    else {}
                )
            except Exception:
                candidate_books = {}
            if not self.exclusions_enabled:
                evaluation_account = self._renew_batch_shared_facts(
                    queue_state,
                    tuple(dict.fromkeys(cid for _c, cid in batch)),
                    stop_event=stop_event,
                    global_recovery_generation=global_recovery_generation,
                )
            # Issue #157: the batch judgment time is captured before the
            # reservations read — the last read between the renewed facts
            # and publication — so a publication that interleaves here with
            # a later judgment time wins the one-line write protection.
            evaluation_now = self._now()
            reservations = self._candidate_reservations()
            totals = deepcopy(self._candidate_funnel_totals)
            queue_funnel = deepcopy(
                queue_state.get("queue_funnel") or {}
            )
            missing_book_token_ids: list[str] = []
            unknown_reasons: list[dict[str, object]] = []
            checked = passed = rejected = unknown = 0
            backup_read = 0
            for candidate, condition_id in batch:
                checked += 1
                if candidate.get("queue") == "backup":
                    backup_read += 1
                market_directions = [
                    direction
                    for direction in directions_by_condition.get(
                        condition_id, ()
                    )
                    if isinstance(direction, Mapping)
                    and isinstance(direction.get("market"), Mapping)
                    and str(direction["market"].get("outcome") or "").upper()
                    in {"YES", "NO"}
                ]
                direction_results: dict[str, dict[str, object]] = {}
                eligible_directions: list[dict[str, object]] = []
                qualified_directions: list[dict[str, object]] = []
                for direction in market_directions:
                    market = direction.get("market")
                    if not isinstance(market, Mapping):
                        continue
                    outcome = str(market.get("outcome") or "").upper()
                    token_id = str(market.get("token_id") or "").strip()
                    book = (
                        candidate_books.get(token_id)
                        if isinstance(candidate_books, Mapping)
                        else None
                    )
                    qualified_direction = {**dict(direction)}
                    if isinstance(book, Mapping):
                        qualified_direction["book"] = deepcopy(dict(book))
                    history_summary, history_reason = self._lp_history_fact(
                        condition_id, token_id, now=evaluation_now
                    )
                    if history_summary is not None:
                        qualified_direction["history_summary"] = history_summary
                    if history_reason is not None:
                        evaluated: Mapping[str, object] = {
                            "state": "rejected",
                            "reason_codes": [history_reason],
                            "guidance": None,
                        }
                    elif not isinstance(book, Mapping):
                        missing_book_token_ids.append(token_id)
                        evaluated: Mapping[str, object] = {
                            "state": "unknown",
                            "reason_codes": ["book_unknown"],
                            "guidance": None,
                        }
                    else:
                        evaluated = evaluate_lp_entry(
                            qualified_direction,
                            account=evaluation_account or {},
                            now=evaluation_now,
                            reservations=reservations,
                            candidate=True,
                            bid_level=bid_level,
                        )
                    qualified_directions.append(qualified_direction)
                    result = {
                        "token_id": token_id,
                        "outcome": outcome,
                        "state": evaluated.get("state", "unknown"),
                        "eligible": evaluated.get("state") == "eligible",
                        "reason_codes": list(
                            evaluated.get("reason_codes", ())
                        ),
                        "guidance": evaluated.get("guidance"),
                    }
                    if isinstance(result["guidance"], Mapping):
                        for field in (
                            "price",
                            "quantity",
                            "required_capital",
                            "estimated_exit_loss",
                            "estimated_exit_loss_ratio",
                            "checked_at",
                        ):
                            if field in result["guidance"]:
                                result[field] = result["guidance"][field]
                    direction_results[outcome] = result
                    if result["eligible"] is True:
                        eligible_directions.append(result)
                        if isinstance(result["guidance"], Mapping):
                            result["estimate"] = _lp_direction_estimate(
                                qualified_direction,
                                result["guidance"],
                                now=evaluation_now,
                            )

                def _direction_yield_key(
                    result: Mapping[str, object]
                ) -> tuple[Decimal, str]:
                    raw = _direction_estimate_raw(result)
                    return (
                        -(
                            raw
                            if raw is not None
                            else Decimal("-Infinity")
                        ),
                        str(result.get("token_id") or ""),
                    )

                selected_direction = (
                    min(eligible_directions, key=_direction_yield_key)
                    if eligible_directions
                    else None
                )
                row_state = (
                    "eligible"
                    if selected_direction is not None
                    else "unknown"
                    if any(
                        result.get("state") == "unknown"
                        for result in direction_results.values()
                    )
                    else "rejected"
                )
                if row_state == "eligible":
                    passed += 1
                elif row_state == "rejected":
                    rejected += 1
                else:
                    unknown += 1
                    unknown_code = next(
                        (
                            str(code)
                            for result in direction_results.values()
                            if result.get("state") == "unknown"
                            for code in (
                                result.get("reason_codes") or ()
                            )
                            if str(code)
                        ),
                        "candidate_unknown",
                    )
                    unknown_reasons.append(
                        {
                            "market_id": str(
                                candidate.get("market_id") or ""
                            ),
                            "condition_id": condition_id,
                            "code": unknown_code,
                        }
                    )
                if row_state == "rejected":
                    self._candidate_pool_record_rejection(
                        condition_id,
                        judged_at=evaluation_now,
                        global_recovery_generation=global_recovery_generation,
                    )
                    continue
                if row_state == "unknown":
                    self._candidate_pool_record_failure(
                        condition_id,
                        attempted_at=evaluation_now,
                        global_recovery_generation=global_recovery_generation,
                    )
                    continue
                row = dict(candidate)
                row["estimate_buy_price_level"] = bid_level
                row["directions"] = direction_results
                row["selected_direction"] = selected_direction
                row["state"] = row_state
                # Issue 158: publish the review deadline on the row so the
                # dashboard's LP entry modal can pass it through unchanged.
                from .polymarket_lp_views import _next_review_at

                row["review_at"] = _iso(_next_review_at(evaluation_now))
                row["verification"] = (
                    "verified"
                    if direction_results
                    and all(
                        result.get("state") in {"eligible", "rejected"}
                        for result in direction_results.values()
                    )
                    else "partial"
                )
                if isinstance(selected_direction, Mapping):
                    guidance = selected_direction.get("guidance")
                    if isinstance(guidance, Mapping):
                        row["realtime_price"] = guidance.get("price")
                        row["realtime_capital"] = guidance.get(
                            "required_capital"
                        )
                        row["realtime_checked_at"] = guidance.get(
                            "checked_at"
                        )
                        row["estimated_exit_loss"] = guidance.get(
                            "estimated_exit_loss"
                        )
                        row["estimated_exit_loss_ratio"] = guidance.get(
                            "estimated_exit_loss_ratio"
                        )
                selected_estimate = (
                    selected_direction.get("estimate")
                    if isinstance(selected_direction, Mapping)
                    else None
                )
                _apply_row_estimate_fields(row, selected_estimate)
                self._candidate_pool_record_success(
                    condition_id,
                    row,
                    judged_at=evaluation_now,
                    facts={
                        "directions": deepcopy(qualified_directions),
                        "account": deepcopy(dict(evaluation_account))
                        if isinstance(evaluation_account, Mapping)
                        else None,
                        "reservations": deepcopy(reservations),
                        "checked_at": queue_state.get("built_at"),
                    },
                    exclusion_revision=exclusion_revision,
                    global_recovery_generation=global_recovery_generation,
                )
            with self._candidate_state_lock:
                if self._candidate_generation_allowed(global_recovery_generation):
                    funnel_totals = deepcopy(self._candidate_funnel_totals)
                    funnel_totals["checked"] = (
                        int(funnel_totals.get("checked") or 0) + checked
                    )
                    funnel_totals["passed"] = (
                        int(funnel_totals.get("passed") or 0) + passed
                    )
                    funnel_totals["rejected"] = (
                        int(funnel_totals.get("rejected") or 0) + rejected
                    )
                    funnel_totals["unknown"] = (
                        int(funnel_totals.get("unknown") or 0) + unknown
                    )
                    funnel_totals["batches"] = (
                        int(funnel_totals.get("batches") or 0) + 1
                    )
                    funnel_totals["backup_read"] = (
                        int(funnel_totals.get("backup_read") or 0) + backup_read
                    )
                    self._candidate_funnel_totals = funnel_totals
                    queue_funnel_state = deepcopy(self._candidate_queue_funnel)
                    if unknown_reasons:
                        reasons = queue_funnel_state.get("reasons")
                        if (
                            isinstance(reasons, Mapping)
                            and isinstance(reasons.get("trial"), list)
                        ):
                            reasons["trial"].extend(deepcopy(unknown_reasons))
                        self._candidate_queue_funnel = queue_funnel_state
            if self._candidate_generation_allowed(global_recovery_generation):
                self._publish_sample_targets(())
            return self._finish_candidate_scan(
                attempted_at=attempted_at,
                checked_at=evaluation_now,
                global_recovery_generation=global_recovery_generation,
                success=passed > 0,
                complete=queue_state.get("complete") is True,
                state="ready" if queue_state.get("complete") is True else "incomplete",
                notes={
                    "catalog_complete": queue_state.get(
                        "catalog_complete"
                    ) is True,
                    "missing_metadata_condition_ids": list(
                        queue_state.get("missing_metadata_condition_ids")
                        or ()
                    ),
                },
                missing_book_token_ids=missing_book_token_ids,
            )
        except Exception:
            # Issue #157 review R3: a mid-batch failure publishes honestly —
            # the stuck ``scanning`` flag is cleared, the pool rows stay for
            # read-only display, and the failure carries the retention
            # reason the whole-scan path used to publish.  The next batch
            # retries from the unchanged rotation.
            logger.exception("candidate_refresh_failed")
            return self._finish_candidate_scan(
                global_recovery_generation=global_recovery_generation,
                notes={"retention_reason": "candidate_refresh_failed"},
            )
        finally:
            with self._candidate_state_lock:
                if (
                    self._candidate_snapshot.get("scanning") is True
                    and not self._candidate_generation_allowed(
                        global_recovery_generation
                    )
                ):
                    self._candidate_snapshot = {
                        **self._candidate_snapshot,
                        "scanning": False,
                    }
            self._candidate_scan_lock.release()

    def refresh_candidate_recommendations(
        self, *, stop_event: threading.Event | None = None,
        condition_ids: Sequence[str] | None = None,
        refresh_priorities: Mapping[str, Decimal | None] | None = None,
    ) -> dict[str, object]:
        """Refresh the displayed pool rows on one batch book read (issue #157).

        The maintenance thread keeps the issue-#146 trigger — the oldest
        source age across the displayed rows with a 30-second lead, plus
        an independent 60/120/300s retry per failed market — and the batch read
        framework (one batched book read plus one account, metadata, and
        targeted reward read per due source class).  Publication rewrites
        pool rows one by one. Account uncertainty or a failed entire book
        read retains the account/source-wide backoff. A refreshed row re-enters with its new
        judgment time, a failed row keeps its values marked
        ``refresh_failed`` until its original expiry, and a deterministic
        rejection leaves the pool at once.
        """

        self._evict_excluded_candidates()
        if not self._candidate_maintenance_lock.acquire(blocking=False):
            snapshot = self.candidate_snapshot()
            snapshot["scanning"] = True
            return snapshot
        try:
            now = self._now()
            bid_level = self._candidate_buy_price_level()
            global_recovery_generation = self._current_candidate_global_generation()
            if global_recovery_generation is None:
                return self.candidate_snapshot()
            exclusion_revision = self._candidate_exclusion_revision
            with self._candidate_state_lock:
                failures = self._candidate_maintenance_failures
                global_failure = self._candidate_maintenance_global_failure
                last_finished_at = self._candidate_maintenance_last_finished_at
                cached_facts = {
                    condition_id: deepcopy(facts)
                    for condition_id, facts in self._candidate_qualification_facts.items()
                    if isinstance(facts, Mapping)
                    and self._candidate_global_generation(
                        facts.get("global_recovery_generation")
                    )
                    == global_recovery_generation
                }
                pool = {
                    condition_id: deepcopy(row)
                    for condition_id, row in self._candidate_pool.items()
                    if isinstance(row, Mapping)
                    and self._candidate_global_generation(
                        row.get("global_recovery_generation")
                    )
                    == global_recovery_generation
                }
            # Background maintenance retains its displayed-head selection.
            # Automatic requalification targets the stale rows that triggered
            # it, so a fresh stored-yield prefix cannot hide a level-specific
            # winner. Both paths share the same ten-market bound and retries.
            requested = set(condition_ids) if condition_ids is not None else None
            valid_rows = [
                self._candidate_strategy_projection(row, bid_level)
                for cid, row in pool.items()
                if isinstance(row, Mapping)
                and (requested is None or cid in requested)
                and not _candidate_pool_row_expired(row, now)
            ]
            if refresh_priorities is None:
                valid_rows.sort(key=_candidate_yield_sort_key)
            else:
                def refresh_key(row):
                    hint = _maybe_decimal(refresh_priorities.get(str(row.get("condition_id") or "")))
                    return (hint is None, -(hint if hint is not None else Decimal(0)),
                            *_candidate_yield_sort_key(row))
                valid_rows.sort(key=refresh_key)
            selected_rows = [
                row for row in valid_rows
                if self._candidate_rotation_due(str(row.get("condition_id") or ""), now=now)
            ][:_LP_CANDIDATE_BATCH_SIZE]
            if not selected_rows:
                return self.candidate_snapshot()

            def live_directions(
                cached: Mapping[str, object],
            ) -> list[Mapping[str, object]]:
                return [
                    direction
                    for direction in cached.get("directions", ())
                    if isinstance(direction, Mapping)
                    and isinstance(direction.get("market"), Mapping)
                    and self._candidate_allowed(((str(direction["market"].get("condition_id") or ""), str(direction["market"].get("token_id") or "")),))
                    and str(direction["market"].get("outcome") or "").upper()
                    in {"YES", "NO"}
                ]

            # Rows without cached qualification facts cannot be refreshed
            # this round: they keep their published values and rank behind
            # every refreshed row.
            row_facts: list[
                tuple[Mapping[str, object], Mapping[str, object] | None]
            ] = []
            for row in selected_rows:
                condition_id = str(row.get("condition_id") or "").strip()
                cached = cached_facts.get(condition_id)
                row_facts.append(
                    (row, cached if isinstance(cached, Mapping) else None)
                )
            refreshable = [
                (row, cached) for row, cached in row_facts if cached is not None
            ]
            if not refreshable:
                return self.candidate_snapshot()

            def row_account(cached: Mapping[str, object]) -> Mapping[str, object]:
                raw_account = cached.get("account")
                return raw_account if isinstance(raw_account, Mapping) else {}

            account_due = any(
                _candidate_source_due(row_account(cached).get("checked_at"), now)
                for _row, cached in refreshable
            )
            reward_due = any(
                _candidate_source_due(direction.get("reward_checked_at"), now)
                for _row, cached in refreshable
                for direction in live_directions(cached)
            )
            metadata_due = any(
                isinstance(direction.get("market"), Mapping)
                and (
                    _candidate_source_due(
                        direction["market"].get("metadata_checked_at"), now
                    )
                    or _candidate_source_due(
                        direction["market"].get("fees_checked_at"), now
                    )
                )
                for _row, cached in refreshable
                for direction in live_directions(cached)
            )
            token_ids = tuple(
                dict.fromkeys(
                    token
                    for _row, cached in refreshable
                    for token in (
                        str(direction["market"].get("token_id") or "").strip()
                        for direction in live_directions(cached)
                    )
                    if token
                )
            )
            book_due = any(
                _candidate_source_due(
                    direction.get("book", {}).get("received_at")
                    if isinstance(direction.get("book"), Mapping)
                    else None,
                    now,
                )
                for _row, cached in refreshable
                for direction in live_directions(cached)
            )
            source_times: list[datetime] = []
            source_expired = False
            for _row, cached in refreshable:
                times, expired = _candidate_head_source_times(cached, now)
                source_times.extend(times)
                source_expired = source_expired or expired
            # Issue #146 + #138: fire on the oldest source age across every
            # published row (30-second lead) or any already-expired source.
            lead_due = bool(source_times) and min(source_times) + timedelta(
                seconds=float(LP_RECOMMENDATION_REFRESH_LEAD_SECONDS)
            ) <= now
            level_changed = any(
                row.get("estimate_buy_price_level", 1) != bid_level
                for row in selected_rows
            )
            if global_failure and failures > 0 and last_finished_at is not None:
                # Issue #146: a failed maintenance attempt suppresses further
                # reads until its backoff window (60/120/300s, counted from
                # the attempt's finish) has elapsed.
                backoff = _CANDIDATE_MAINTENANCE_BACKOFF_SECONDS[
                    min(failures - 1, 2)
                ]
                if (
                    Decimal(str((now - last_finished_at).total_seconds()))
                    < backoff
                ):
                    return self.candidate_snapshot()
            if not lead_due and not source_expired and not level_changed:
                return self.candidate_snapshot()
            if stop_event is not None and stop_event.is_set():
                return self.candidate_snapshot()

            # Issue #146: expose how long each source read took so the
            # operator can see which source drove a refresh.
            batch_id = uuid.uuid4().hex
            def market_key(condition_id: str) -> str:
                return hashlib.sha256(condition_id.encode()).hexdigest()[:16]

            _lp_candidate_maintenance_log("begin", {
                "batch_id": batch_id, "started_at": now.isoformat(),
                "markets": [market_key(str(row.get("condition_id") or "")) for row, _ in row_facts],
            })
            source_causes: dict[str, str] = {}
            reward_causes: dict[str, str] = {}
            metadata_causes: dict[str, str] = {}
            read_seconds: dict[str, float] = {
                "account": 0.0,
                "metadata": 0.0,
                "reward": 0.0,
                "books": 0.0,
            }
            account_error: str | None = None
            account: Mapping[str, object] = {}
            if account_due:
                account_reader = getattr(
                    self.exchange, "lp_account_snapshot_shared", None
                )
                if not callable(account_reader):
                    account_reader = getattr(
                        self.exchange, "lp_account_snapshot", None
                    )
                read_started_at = self._now()
                try:
                    refreshed_account = (
                        account_reader() if callable(account_reader) else None
                    )
                except Exception as exc:
                    source_causes["account"] = self._safe_error_type(type(exc).__name__)
                    refreshed_account = None
                read_seconds["account"] = float(
                    (self._now() - read_started_at).total_seconds()
                )
                if (
                    isinstance(refreshed_account, Mapping)
                    and not _candidate_source_expired(
                        refreshed_account.get("checked_at"), self._now()
                    )
                ):
                    account = deepcopy(dict(refreshed_account))
                else:
                    account_error = "account_unknown"
            else:
                # Every row shares the account-wide fact; reuse the freshest
                # cached receipt (not due means at least one is inside its
                # freshness window).
                for _row, cached in refreshable:
                    candidate_account = row_account(cached)
                    if candidate_account.get("checked_at"):
                        account = deepcopy(dict(candidate_account))
                        break
                if not account:
                    account_error = "account_unknown"

            refresh_conditions = tuple(
                dict.fromkeys(
                    str(row.get("condition_id") or "").strip()
                    for row, _cached in refreshable
                    if str(row.get("condition_id") or "").strip()
                )
            )
            def read_rewards():
                reward_errors: dict[str, str] = {}
                refreshed_rewards: dict[str, Mapping[str, object]] = {}
                raw_reward: Mapping[str, object] | None = None
                if reward_due:
                    reward_reader = getattr(self.exchange, "lp_reward_catalog", None)
                    read_started_at = self._now()
                    try:
                        raw_reward = (
                            reward_reader(
                                condition_ids=refresh_conditions,
                                stop_event=stop_event,
                            )
                            if callable(reward_reader)
                            else None
                        )
                    except TypeError:
                        try:
                            raw_reward = (
                                reward_reader(condition_ids=refresh_conditions)
                                if callable(reward_reader)
                                else None
                            )
                        except Exception as exc:
                            source_causes["reward"] = self._safe_error_type(type(exc).__name__)
                            raw_reward = None
                    except Exception as exc:
                        source_causes["reward"] = self._safe_error_type(type(exc).__name__)
                        raw_reward = None
                    reward_rows = (
                        raw_reward.get("markets")
                        if isinstance(raw_reward, Mapping)
                        else None
                    )
                    diagnostic_rewards = reward_rows.values() if isinstance(reward_rows, Mapping) else reward_rows
                    if isinstance(diagnostic_rewards, (list, tuple)) or isinstance(reward_rows, Mapping):
                        for reward_row in diagnostic_rewards:
                            if isinstance(reward_row, Mapping) and reward_row.get("error_type"):
                                reward_causes[str(reward_row.get("condition_id") or "")] = self._safe_error_type(reward_row["error_type"])
                    if isinstance(reward_rows, Mapping):
                        for condition_id in refresh_conditions:
                            candidate_reward = reward_rows.get(condition_id)
                            if isinstance(candidate_reward, Mapping) and (
                                candidate_reward.get("state") != "unknown"
                            ):
                                refreshed_rewards[condition_id] = candidate_reward
                    elif isinstance(reward_rows, (list, tuple)):
                        for reward_row in reward_rows:
                            if not isinstance(reward_row, Mapping):
                                continue
                            row_condition = str(reward_row.get("condition_id") or "")
                            if row_condition in refresh_conditions and reward_row.get(
                                "state"
                            ) != "unknown":
                                refreshed_rewards[row_condition] = reward_row
                    for condition_id in refresh_conditions:
                        refreshed_reward_row = refreshed_rewards.get(condition_id)
                        reward_checked_at = (
                            refreshed_reward_row.get("reward_checked_at")
                            if isinstance(refreshed_reward_row, Mapping)
                            else None
                        )
                        if reward_checked_at is None and isinstance(raw_reward, Mapping):
                            reward_checked_at = raw_reward.get("checked_at")
                        if refreshed_reward_row is None or _candidate_source_expired(
                            reward_checked_at, self._now()
                        ):
                            reward_errors[condition_id] = "reward_unknown"
                    read_seconds["reward"] = float(
                        (self._now() - read_started_at).total_seconds()
                    )

                return reward_errors, refreshed_rewards, raw_reward

            if self.exclusions_enabled:
                reward_errors, refreshed_rewards, raw_reward = read_rewards()
                for row, cached in refreshable:
                    cid = str(row.get("condition_id") or "")
                    directions = live_directions(cached)
                    market = directions[0]["market"] if directions and not metadata_due else {}
                    reward = refreshed_rewards.get(cid, {}) if reward_due else (
                        {**directions[0], "condition_id": cid} if directions else {})
                    reason = self._candidate_market_rejection(reward, market, now=self._now())
                    if reason:
                        if self._exclude_candidate(cid, "", reason, checked_at=now, market=market,
                                exclusion_revision=exclusion_revision,
                                global_recovery_generation=global_recovery_generation):
                            exclusion_revision = self._candidate_exclusion_revision
                refresh_conditions = self._candidate_conditions(refresh_conditions)

            metadata_errors: dict[str, str] = {}
            refreshed_metadata: dict[str, Mapping[str, object]] = {}
            if metadata_due and refresh_conditions:
                metadata_reader = getattr(
                    self.exchange, "lp_market_metadata_fresh", None
                )
                if not callable(metadata_reader):
                    metadata_reader = getattr(
                        self.exchange, "lp_market_metadata", None
                    )
                read_started_at = self._now()
                try:
                    options = {"stop_event": stop_event}
                    if getattr(metadata_reader, "__func__", None) is PolymarketTradingClient.lp_market_metadata_fresh:
                        options["include_diagnostics"] = True
                    raw_metadata = (
                        metadata_reader(refresh_conditions, **options)
                        if callable(metadata_reader) else None
                    )
                except TypeError:
                    try:
                        raw_metadata = (
                            metadata_reader(refresh_conditions)
                            if callable(metadata_reader)
                            else None
                        )
                    except Exception as exc:
                        source_causes["metadata"] = self._safe_error_type(type(exc).__name__)
                        raw_metadata = None
                except Exception as exc:
                    source_causes["metadata"] = self._safe_error_type(type(exc).__name__)
                    raw_metadata = None
                if isinstance(raw_metadata, Mapping):
                    failure_facts = raw_metadata.get("failure_facts")
                    if isinstance(failure_facts, Mapping):
                        for condition_id in refresh_conditions:
                            failure = failure_facts.get(condition_id)
                            if isinstance(failure, Mapping) and failure.get("error_type"):
                                metadata_causes[condition_id] = self._safe_error_type(failure["error_type"])
                metadata_rows = (
                    raw_metadata.get("markets")
                    if isinstance(raw_metadata, Mapping)
                    and isinstance(raw_metadata.get("markets"), Mapping)
                    else raw_metadata
                )
                if isinstance(metadata_rows, Mapping):
                    for condition_id in refresh_conditions:
                        candidate_market = metadata_rows.get(condition_id)
                        if isinstance(candidate_market, Mapping):
                            refreshed_metadata[condition_id] = candidate_market
                metadata_checked_now = self._now()
                for condition_id in refresh_conditions:
                    market_row = refreshed_metadata.get(condition_id)
                    if not isinstance(market_row, Mapping) or _candidate_source_expired(
                        market_row.get("metadata_checked_at"), metadata_checked_now
                    ):
                        metadata_errors[condition_id] = "market_metadata_unknown"
                    elif _candidate_source_expired(
                        market_row.get("fees_checked_at"), metadata_checked_now
                    ):
                        metadata_errors[condition_id] = "market_fees_unknown"
                read_seconds["metadata"] = float(
                    (self._now() - read_started_at).total_seconds()
                )

            if not self.exclusions_enabled:
                reward_errors, refreshed_rewards, raw_reward = read_rewards()

            if self.exclusions_enabled:
                for row, cached in refreshable:
                    cid = str(row.get("condition_id") or "")
                    if not self._candidate_conditions((cid,)):
                        continue
                    directions = live_directions(cached)
                    market = refreshed_metadata.get(cid, {}) if metadata_due else (directions[0]["market"] if directions else {})
                    reward = refreshed_rewards.get(cid, {}) if reward_due else ({**directions[0], "condition_id": cid} if directions else {})
                    ended = self._observe_ended_candidate_market(
                        cid,
                        market,
                        checked_at=now,
                        global_recovery_generation=global_recovery_generation,
                    )
                    reason = None if ended else self._candidate_market_rejection(reward, market, now=self._now())
                    if reason:
                        if self._exclude_candidate(cid, "", reason, checked_at=now, market=market,
                                exclusion_revision=exclusion_revision,
                                global_recovery_generation=global_recovery_generation):
                            exclusion_revision = self._candidate_exclusion_revision
                for row, cached in refreshable:
                    exclusion_revision = self._screen_candidate_histories(
                        live_directions(cached),
                        checked_at=self._now(),
                        exclusion_revision=exclusion_revision,
                        global_recovery_generation=global_recovery_generation,
                    )
                token_ids = tuple(token for token in token_ids if any(
                    self._candidate_allowed(((str(row.get("condition_id") or ""), token),))
                    for row, cached in refreshable
                    if any(str(d["market"].get("token_id") or "") == token for d in live_directions(cached))))

            books: Mapping[str, object] = {}
            books_failed = False
            missing_book_token_ids: list[str] = []
            if book_due and token_ids:
                books_reader = getattr(self.exchange, "lp_order_books", None)
                read_started_at = self._now()
                try:
                    raw_books = (
                        books_reader(token_ids, stop_event=stop_event)
                        if callable(books_reader)
                        else None
                    )
                except TypeError:
                    try:
                        raw_books = (
                            books_reader(token_ids)
                            if callable(books_reader)
                            else None
                        )
                    except Exception as exc:
                        source_causes["books"] = self._safe_error_type(type(exc).__name__)
                        raw_books = None
                except Exception as exc:
                    source_causes["books"] = self._safe_error_type(type(exc).__name__)
                    raw_books = None
                read_seconds["books"] = float(
                    (self._now() - read_started_at).total_seconds()
                )
                if isinstance(raw_books, Mapping) and raw_books:
                    books = raw_books
                else:
                    books_failed = True

            reservations = self._candidate_reservations()
            # Account uncertainty remains account-wide. Market source gaps
            # retain only that market's old facts and its own retry deadline.
            round_failed = account_error is not None or books_failed

            def evaluate_row(
                row: Mapping[str, object],
                cached: Mapping[str, object],
                evaluation_now: datetime,
            ) -> tuple[dict[str, object] | None, dict[str, object] | None]:
                """Re-qualify one published row with this round's sources.

                Returns ``(new_row, facts)`` when the row was refreshed, or
                ``(None, None)`` when the row must keep its published values
                (all of its books are missing this round).
                """

                condition_id = str(row.get("condition_id") or "").strip()
                if condition_id in metadata_errors or condition_id in reward_errors:
                    return None, None
                directions = live_directions(cached)
                updated_directions: list[Mapping[str, object]] = []
                direction_results: dict[str, dict[str, object]] = {}
                eligible_directions: list[dict[str, object]] = []
                row_missing_books = 0
                row_directions = 0
                history_rejections = 0
                for direction in directions:
                    market_value = direction.get("market")
                    if not isinstance(market_value, Mapping):
                        continue
                    row_directions += 1
                    maintenance_direction = deepcopy(dict(direction))
                    market = dict(market_value)
                    outcome = str(market.get("outcome") or "").upper()
                    token_id = str(market.get("token_id") or "").strip()
                    refreshed_market = refreshed_metadata.get(condition_id)
                    if (
                        metadata_due
                        and isinstance(refreshed_market, Mapping)
                        and condition_id not in metadata_errors
                    ):
                        market = {
                            **dict(refreshed_market),
                            "condition_id": condition_id,
                            "token_id": token_id,
                            "outcome": outcome,
                        }
                        if market.get("reward_min_size") is not None:
                            market["_metadata_reward_min_size"] = market.get(
                                "reward_min_size"
                            )
                        if market.get("reward_max_spread") is not None:
                            market["_metadata_reward_max_spread"] = market.get(
                                "reward_max_spread"
                            )
                    if (
                        (
                            metadata_due
                            and isinstance(refreshed_market, Mapping)
                            and condition_id not in metadata_errors
                        )
                        or (
                            reward_due
                            and condition_id in refreshed_rewards
                            and condition_id not in reward_errors
                        )
                    ):
                        reward_source: dict[str, object] = {}
                        # Reuse cached reward rules only while their reward
                        # read remains valid.  Once reward facts expire, a
                        # response that omits the rules cannot renew those
                        # old values.
                        if not reward_due:
                            cached_minimum = market_value.get(
                                "_reward_catalog_min_size"
                            )
                            cached_spread = _maybe_decimal(
                                market_value.get("_reward_catalog_max_spread")
                            )
                            if cached_minimum is not None:
                                reward_source["rewards_min_size"] = cached_minimum
                            if cached_spread is not None:
                                reward_source["rewards_max_spread"] = cached_spread
                        refreshed_reward_row = refreshed_rewards.get(condition_id)
                        if isinstance(refreshed_reward_row, Mapping):
                            reward_source.update(dict(refreshed_reward_row))
                        market_for_rules = dict(market)
                        if not metadata_due:
                            # Normalized fields can have come from the prior
                            # reward read.  Reuse only rules proven to
                            # originate in the still-fresh metadata source.
                            market_for_rules.pop("reward_min_size", None)
                            market_for_rules.pop("reward_max_spread", None)
                            metadata_minimum = market.get(
                                "_metadata_reward_min_size"
                            )
                            metadata_spread = market.get(
                                "_metadata_reward_max_spread"
                            )
                            if metadata_minimum is not None:
                                market_for_rules["reward_min_size"] = (
                                    metadata_minimum
                                )
                            if metadata_spread is not None:
                                market_for_rules["reward_max_spread"] = (
                                    metadata_spread
                                )
                        reward_minimum, reward_spread = _lp_reward_terms(
                            market_for_rules, reward_source
                        )
                        market["reward_min_size"] = reward_minimum
                        market["reward_max_spread"] = reward_spread
                    maintenance_direction["market"] = market
                    refreshed_reward_row = refreshed_rewards.get(condition_id)
                    if (
                        reward_due
                        and isinstance(refreshed_reward_row, Mapping)
                        and condition_id not in reward_errors
                    ):
                        maintenance_direction["reward_active"] = (
                            refreshed_reward_row.get("reward_active")
                        )
                        maintenance_direction["daily_pool_usd"] = (
                            refreshed_reward_row.get("daily_pool_usd")
                        )
                        maintenance_direction["reward_checked_at"] = (
                            refreshed_reward_row.get("reward_checked_at")
                            or raw_reward.get("checked_at")
                            if isinstance(raw_reward, Mapping)
                            else refreshed_reward_row.get("checked_at")
                        )
                        maintenance_direction[
                            "reward_guidance_deadline"
                        ] = self._reward_guidance_deadline(refreshed_reward_row)
                    book = (
                        books.get(token_id)
                        if book_due
                        else maintenance_direction.get("book")
                    )
                    if isinstance(book, Mapping):
                        maintenance_direction["book"] = dict(book)
                    history_summary, history_reason = self._lp_history_fact(
                        condition_id, token_id, now=evaluation_now
                    )
                    if history_summary is not None:
                        maintenance_direction["history_summary"] = history_summary
                    if history_reason is not None:
                        history_rejections += 1
                        evaluated: Mapping[str, object] = {
                            "state": "rejected",
                            "reason_codes": [history_reason],
                            "guidance": None,
                        }
                    if history_reason is None and not isinstance(book, Mapping):
                        row_missing_books += 1
                        missing_book_token_ids.append(token_id)
                        evaluated: Mapping[str, object] = {
                            "state": "unknown",
                            "reason_codes": ["book_unknown"],
                            "guidance": None,
                        }
                    elif history_reason is None:
                        if _candidate_source_expired(
                            market.get("metadata_checked_at"), evaluation_now
                        ) or _candidate_source_expired(
                            market.get("fees_checked_at"), evaluation_now
                        ):
                            evaluated = {
                                "state": "unknown",
                                "reason_codes": ["market_metadata_stale"],
                                "guidance": None,
                            }
                        elif _candidate_source_expired(
                            maintenance_direction.get("reward_checked_at"),
                            evaluation_now,
                        ):
                            evaluated = {
                                "state": "unknown",
                                "reason_codes": ["reward_data_stale"],
                                "guidance": None,
                            }
                        else:
                            evaluated = evaluate_lp_entry(
                                maintenance_direction,
                                account=account,
                                now=evaluation_now,
                                reservations=reservations,
                                candidate=True,
                                bid_level=bid_level,
                            )
                    updated_directions.append(maintenance_direction)
                    result: dict[str, object] = {
                        "token_id": token_id,
                        "outcome": outcome,
                        "state": evaluated.get("state", "unknown"),
                        "eligible": evaluated.get("state") == "eligible",
                        "reason_codes": list(evaluated.get("reason_codes", ())),
                        "guidance": evaluated.get("guidance"),
                    }
                    if isinstance(result["guidance"], Mapping):
                        for field in (
                            "price",
                            "quantity",
                            "required_capital",
                            "estimated_exit_loss",
                            "estimated_exit_loss_ratio",
                            "checked_at",
                        ):
                            if field in result["guidance"]:
                                result[field] = result["guidance"][field]
                    if result["eligible"] is True and isinstance(
                        result["guidance"], Mapping
                    ):
                        # Issue #138 round 2: every eligible direction
                        # carries its minimum-order estimate for the
                        # yield comparison.
                        result["estimate"] = _lp_direction_estimate(
                            maintenance_direction,
                            result["guidance"],
                            now=evaluation_now,
                        )
                    direction_results[outcome] = result
                    if result["eligible"] is True:
                        eligible_directions.append(result)

                if row_directions == 0 or (
                    row_missing_books == row_directions and history_rejections == 0
                ):
                    # None of the row's directions could be re-read: the row
                    # keeps its published values this round.
                    return None, None

                def _row_yield_key(
                    result: Mapping[str, object],
                ) -> tuple[Decimal, str]:
                    estimate = result.get("estimate")
                    raw = (
                        estimate.get("yield_pct_per_hour")
                        if isinstance(estimate, Mapping)
                        and estimate.get("state") == "known"
                        else None
                    )
                    parsed = _maybe_decimal(raw)
                    return (
                        -(parsed if parsed is not None else Decimal("-Infinity")),
                        str(result.get("token_id") or ""),
                    )

                selected_direction = (
                    min(eligible_directions, key=_row_yield_key)
                    if eligible_directions
                    else None
                )
                new_row = dict(row)
                new_row["estimate_buy_price_level"] = bid_level
                new_row.pop("estimate_reason_codes", None)
                new_row["directions"] = direction_results
                new_row["selected_direction"] = selected_direction
                new_row["state"] = (
                    "eligible"
                    if selected_direction is not None
                    else "unknown"
                    if any(
                        result.get("state") == "unknown"
                        for result in direction_results.values()
                    )
                    else "rejected"
                )
                # Issue 158: keep the review deadline current on re-qualified
                # rows (same projection as the scan publication).
                from .polymarket_lp_views import _next_review_at

                new_row["review_at"] = _iso(_next_review_at(evaluation_now))
                new_row["verification"] = (
                    "verified"
                    if direction_results
                    and all(
                        result.get("state") in {"eligible", "rejected"}
                        for result in direction_results.values()
                    )
                    else "partial"
                )
                for key in (
                    "realtime_price",
                    "realtime_capital",
                    "realtime_checked_at",
                ):
                    new_row.pop(key, None)
                if isinstance(selected_direction, Mapping):
                    guidance = selected_direction.get("guidance")
                    if isinstance(guidance, Mapping):
                        new_row["realtime_price"] = guidance.get("price")
                        new_row["realtime_capital"] = guidance.get(
                            "required_capital"
                        )
                        new_row["realtime_checked_at"] = guidance.get("checked_at")
                selected_estimate = (
                    selected_direction.get("estimate")
                    if isinstance(selected_direction, Mapping)
                    else None
                )
                _apply_row_estimate_fields(new_row, selected_estimate)
                facts = {
                    "directions": deepcopy(updated_directions),
                    "account": deepcopy(account)
                    if isinstance(account, Mapping)
                    else None,
                    "reservations": deepcopy(reservations),
                    "checked_at": self._now(),
                }
                return new_row, facts

            evaluation_now = self._now()
            def age(value: object) -> float | None:
                try:
                    return (evaluation_now - _timestamp(value, name="source_at")).total_seconds()
                except ValueError:
                    return None

            try:
                for source, due in (("account", account_due), ("metadata", metadata_due),
                                    ("fees", metadata_due), ("reward", reward_due), ("books", book_due)):
                    markets = []
                    for row, cached in row_facts:
                        cid = str(row.get("condition_id") or "")
                        directions = live_directions(cached) if cached else []
                        values = []
                        failed = cached is None
                        cause = "unknown"
                        if source == "account":
                            values = [account.get("checked_at") if not account_error else row_account(cached or {}).get("checked_at")]
                            failed = failed or account_error is not None
                            cause = source_causes.get("account", "unknown")
                        elif source in {"metadata", "fees"}:
                            stamp = "metadata_checked_at" if source == "metadata" else "fees_checked_at"
                            failed = failed or cid in metadata_errors or (due and cid not in refreshed_metadata)
                            values = [refreshed_metadata[cid].get(stamp)] if due and not failed else [d["market"].get(stamp) for d in directions]
                            cause = metadata_causes.get(cid, source_causes.get("metadata", "unknown"))
                        elif source == "reward":
                            failed = failed or cid in reward_errors
                            reward = refreshed_rewards.get(cid, {})
                            values = [reward.get("reward_checked_at") or (raw_reward or {}).get("checked_at")] if due and not failed else [d.get("reward_checked_at") for d in directions]
                            cause = reward_causes.get(cid, source_causes.get("reward", "unknown"))
                        else:
                            values = [(books.get(str(d["market"].get("token_id") or "")) if due else d.get("book")) for d in directions]
                            failed = failed or books_failed or not values or any(not isinstance(v, Mapping) for v in values)
                            values = [v.get("received_at") if isinstance(v, Mapping) else None for v in values]
                            cause = source_causes.get("books", "unknown")
                        ages = [age(value) for value in values]
                        markets.append({"market": market_key(cid),
                            "outcome": "failed" if failed else "refreshed" if due else "reused",
                            "cause": cause if failed else None,
                            "age_seconds": max(ages) if ages and all(v is not None for v in ages) else None})
                    _lp_candidate_maintenance_log("source", {"batch_id": batch_id,
                        "source": source, "used_at": evaluation_now.isoformat(), "markets": markets,
                        "read_seconds": read_seconds["metadata" if source == "fees" else source]})
            except Exception:
                pass  # Diagnostics never change qualification or publication.
            row_outcomes: dict[str, str] = {}
            # Issue #157: publication rewrites pool rows one by one.  A
            # refreshed row re-enters with its new judgment time, a failed
            # row keeps its values marked refresh_failed until its original
            # expiry, and a deterministically rejected row leaves the pool
            # immediately.
            refreshed_any = False
            for row, cached in row_facts:
                condition_id = str(row.get("condition_id") or "").strip()
                new_row: dict[str, object] | None = None
                facts: dict[str, object] | None = None
                if cached is not None and not round_failed:
                    new_row, facts = evaluate_row(row, cached, evaluation_now)
                if new_row is None or new_row.get("state") == "unknown":
                    # Whole-round failure, missing cached facts, or a row
                    # whose re-read could not produce a verdict: keep the
                    # stored values until their original expiry and mark
                    # the row refresh_failed.
                    row_outcomes[condition_id] = "failed"
                    self._candidate_pool_record_failure(
                        condition_id,
                        attempted_at=evaluation_now,
                        global_recovery_generation=global_recovery_generation,
                    )
                    continue
                if new_row.get("state") == "rejected":
                    row_outcomes[condition_id] = "rejected"
                    self._candidate_pool_record_rejection(
                        condition_id,
                        judged_at=evaluation_now,
                        global_recovery_generation=global_recovery_generation,
                    )
                    continue
                # Issue #157 review R4: the write protection may reject this
                # write because a concurrent newer publication already holds
                # the line.  The row was refreshed either way, so a
                # guard-rejected success is not a round failure and must not
                # advance the 60/120/300s maintenance backoff.
                published = self._candidate_pool_record_success(
                    condition_id,
                    new_row,
                    judged_at=evaluation_now,
                    facts=facts,
                    exclusion_revision=exclusion_revision,
                    global_recovery_generation=global_recovery_generation,
                )
                row_outcomes[condition_id] = "refreshed" if published else "publication_guarded"
                refreshed_any = True
            # Issue #146: the maintenance attempt's backoff bookkeeping is
            # applied together with its publication.
            with self._candidate_state_lock:
                if not self._candidate_generation_allowed(global_recovery_generation):
                    return self.candidate_snapshot()
                maintenance_finished_at = self._now()
                self._candidate_maintenance_last_finished_at = (
                    maintenance_finished_at
                )
                self._candidate_maintenance_global_failure = round_failed
                if refreshed_any:
                    self._candidate_maintenance_failures = 0
                else:
                    self._candidate_maintenance_failures += 1
                failures_now = self._candidate_maintenance_failures
            try:
                diagnostic_markets = []
                for cid, outcome in row_outcomes.items():
                    entry = self._candidate_rotation_entry(cid)
                    count = entry.get("failures")
                    attempted = _candidate_row_updated_at({"updated_at": entry.get("last_attempt_at")})
                    backoff = float(_CANDIDATE_MAINTENANCE_BACKOFF_SECONDS[min(count - 1, 2)]) if type(count) is int and count > 0 and attempted else 0
                    diagnostic_markets.append({"market": market_key(cid), "outcome": outcome,
                        "backoff_seconds": backoff,
                        "next_attempt_at": (attempted + timedelta(seconds=backoff)).isoformat() if backoff else None})
                _lp_candidate_maintenance_log("end", {"batch_id": batch_id,
                    "finished_at": maintenance_finished_at.isoformat(), "markets": diagnostic_markets,
                    "global_backoff": round_failed, "consecutive_failures": failures_now})
            except Exception:
                pass  # Business retry state is independent of log construction.
            notes: dict[str, object] = {
                "maintenance_consecutive_failures": failures_now,
            }
            if failures_now > 0:
                next_backoff = _CANDIDATE_MAINTENANCE_BACKOFF_SECONDS[
                    min(failures_now - 1, 2)
                ]
                notes["maintenance_next_attempt_at"] = _iso(
                    maintenance_finished_at
                    + timedelta(seconds=float(next_backoff))
                )
            else:
                notes["maintenance_next_attempt_at"] = None
            notes["maintenance_diagnostics"] = {
                "started_at": _iso(now),
                "finished_at": _iso(evaluation_now),
                "read_seconds": read_seconds,
            }
            return self._finish_candidate_scan(
                attempted_at=now,
                checked_at=evaluation_now,
                global_recovery_generation=global_recovery_generation,
                success=refreshed_any,
                notes=notes,
                missing_book_token_ids=missing_book_token_ids,
            )
        finally:
            self._candidate_maintenance_lock.release()

    def refresh_competition_cache(
        self, stop_event: threading.Event | None = None, *, snapshot: bool = True
    ) -> dict[str, object] | None:
        """Refresh the in-memory competition cache (issue #157).

        Public entry point for the dedicated competition thread: candidate
        batch paths only read the cache and never block on this read.  The
        optional ``stop_event`` flows into the underlying read so a stopping
        runtime cancels an in-flight page pull cooperatively.
        The monitor passes ``snapshot=False`` because it discards the result.
        """

        return self._refresh_competition(stop_event, snapshot=snapshot)

    def _refresh_competition(
        self, stop_event: threading.Event | None, *, snapshot: bool = True
    ) -> dict[str, object] | None:
        """Publish only committed batches; a failed page is re-read next time."""
        reader = getattr(self.exchange, "lp_market_competitiveness", None)
        with self._competition_refresh_lock:
            if callable(reader):
                owned = getattr(reader, "__func__", None) is PolymarketTradingClient.lp_market_competitiveness
                with self._competition_lock:
                    cursor = self._competition_state.get("next_start_cursor")
                    previous = None if owned else deepcopy(self._competition_state.get("competitiveness") or {})
                    untouched = set(self._competition_state.get("competitiveness") or {}) if owned else None
                progress_reader = getattr(self.store, "lp_competitiveness_progress", None)
                if callable(progress_reader):
                    try:
                        progress = progress_reader()
                        if progress:
                            cursor = progress.get("next_start_cursor")
                    except Exception:
                        logger.warning("lp competition progress unavailable")
                        return self._competition_snapshot() if snapshot else None
                try:
                    options = {"stop_event": stop_event, "previous": previous, "start_cursor": cursor}
                    if owned:
                        def publish_batch(batch, **kwargs):
                            self._publish_competition_batch(batch, **kwargs)
                            untouched.difference_update(batch)
                        options.update(publish_batch=publish_batch, batch_size=_LP_COMPETITION_BATCH_SIZE)
                    result = reader(**options)
                    persisted = True
                    if not owned and isinstance(result, Mapping):
                        persisted = self._persist_competition(result, stop_event=stop_event, page_cursor=cursor)
                except Exception:
                    result, persisted = None, False
                    logger.warning("lp competition refresh failed", exc_info=True)
                if isinstance(result, Mapping):
                    if self.exclusions_enabled:
                        observed_at = result.get("checked_at")
                        if isinstance(observed_at, datetime):
                            for cid in result.get("ended_condition_ids", ()):
                                self._observe_ended_candidate_market(str(cid), {"closed": True}, checked_at=observed_at)
                    with self._competition_lock:
                        self._competition_state.update(
                            state=result.get("state", "unknown") if persisted else "partial",
                            complete=result.get("complete") is True and persisted,
                            round_checked_at=result.get("round_checked_at"),
                        )
                        if owned:
                            not_updated = sorted(untouched)
                            self._competition_state["not_updated"] = not_updated
                            if result.get("complete") is True and cursor is None and not_updated:
                                # Completed non-resumed walks keep absent facts in SQLite, not the live cache.
                                for cid in not_updated:
                                    self._competition_state["competitiveness"].pop(cid, None)
                                self._competition_version += 1
                        elif persisted:
                            self._competition_state["not_updated"] = list(result.get("not_updated") or ())
                            if result.get("complete") is True and cursor is None:
                                raw = result.get("competitiveness") or {}
                                absent = [cid for cid in self._competition_state.get("competitiveness", {}) if cid not in raw]
                                for cid in absent:
                                    self._competition_state["competitiveness"].pop(cid, None)
                                if absent:
                                    self._competition_version += 1
        return self._competition_snapshot() if snapshot else None

    def _competition_snapshot(self):
        with self._competition_lock:
            return deepcopy(self._competition_state)

    def _publish_competition_batch(
        self, batch, *, page_cursor, resume_cursor, checked_at, stop_event
    ):
        """Keep BEGIN/body outside the read lock; fence COMMIT and publication."""
        upsert = getattr(self.store, "lp_competitiveness_upsert", None)
        if not callable(upsert):
            raise RuntimeError("competition_store_unavailable")
        progress = {"next_start_cursor": resume_cursor}

        @contextmanager
        def commit_guard():
            with self._competition_lock:
                if stop_event is not None and stop_event.is_set():
                    raise RuntimeError("competition_cancelled")
                yield

        def publish():
            # Called after COMMIT while the short commit guard is still held.
            values = self._competition_state.setdefault("competitiveness", {})
            values.update(batch)
            self._competition_state.update(round_checked_at=checked_at, next_start_cursor=resume_cursor)
            if batch:
                self._competition_version += 1

        entries = ((cid, value, stamp) for cid, (value, stamp) in batch.items())
        parameters = inspect.signature(upsert).parameters
        if "commit_guard" in parameters or any(p.kind == inspect.Parameter.VAR_KEYWORD for p in parameters.values()):
            upsert(entries, progress=progress, stop_event=stop_event, commit_guard=commit_guard(), after_commit=publish)
        else:
            # Compatibility stores do not expose SQLite/cache publication hooks.
            upsert(entries)
            with commit_guard():
                publish()
        pause = _LP_COMPETITION_BATCH_PAUSE_SECONDS
        if stop_event is not None:
            stop_event.wait(pause)
        elif pause:
            threading.Event().wait(pause)

    def _persist_competition(self, stored: Mapping[str, object], *, stop_event=None, page_cursor=None) -> bool:
        """Bound legacy result maps too; never publish a failed batch."""
        raw_map = stored.get("competitiveness")
        if not isinstance(raw_map, Mapping):
            return False
        batch = {}
        items = iter(raw_map.items())
        try:
            while True:
                final = False
                for _ in range(_LP_COMPETITION_BATCH_SIZE):
                    try:
                        condition_id, value = next(items)
                    except StopIteration:
                        final = True
                        break
                    if not isinstance(condition_id, str) or not condition_id.strip():
                        continue
                    if isinstance(value, tuple) and len(value) == 2:
                        entry_value, stamp = value
                    elif isinstance(value, Mapping):
                        entry_value, stamp = value.get("value"), value.get("checked_at")
                    else:
                        continue
                    if isinstance(entry_value, Decimal) and isinstance(stamp, datetime) and stamp.tzinfo is not None:
                        batch[condition_id] = (entry_value, stamp)
                # Legacy readers have no page boundary; re-read their start until all batches commit.
                self._publish_competition_batch(batch, page_cursor=page_cursor,
                    resume_cursor=stored.get("resume_cursor") if final else page_cursor,
                    checked_at=stored.get("round_checked_at"), stop_event=stop_event)
                batch = {}
                if final:
                    return True
                if stop_event is not None and stop_event.is_set():
                    return False
        except Exception:
            logger.warning("lp competition persistence failed", exc_info=True)
            return False

    def _competition_entries(
        self, condition_ids: Collection[str] | None = None, *, state: Mapping[str, object] | None = None, metadata=None
    ) -> dict[str, object]:
        """Project the competition map for the trial-candidate view (#181).

        Fresh cache entries (inside the competition freshness gate)
        win with ``source="fresh"``; everything else — a missing cache or an
        entry older than the gate — falls back to the last persisted round
        with ``source="store"`` and the store's own checked_at.  Conditions
        present in neither source are left out entirely: the view owns the
        missing-data exclusion and there is no cold-start exemption.
        A caller can scope this projection to its complete required identity set.
        """

        now = self.clock()
        with ExitStack() as stack:
            with self._competition_lock:
                state = self._competition_state if state is None else state
                raw = state.get("competitiveness")
                raw = raw if isinstance(raw, Mapping) else {}
                state = {"round_checked_at": state.get("round_checked_at"),
                         "competitiveness": dict(raw) if condition_ids is None else
                         {cid: raw.get(cid) for cid in condition_ids}}
                if metadata is not None:
                    metadata.update(version=self._competition_version, round_checked_at=state.get("round_checked_at"))
                if condition_ids is not None:
                    entries = self._competition_projection(condition_ids, state=state, connection=None, read_store=False, now=now)
                    if all(cid in entries for cid in condition_ids):
                        return entries
                reader = getattr(self.store, "lp_competitiveness_map", None)
                snapshot_reader = getattr(self.store, "lp_competitiveness_snapshot", None)
                try:
                    parameter = inspect.signature(reader).parameters.get("connection")
                    shared_snapshot = (
                        parameter is not None
                        and parameter.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
                        and callable(snapshot_reader)
                    )
                except (TypeError, ValueError):
                    shared_snapshot = False
                if not shared_snapshot:
                    # Legacy readers reopen SQLite: fence their fallback read with cache capture.
                    return self._competition_projection(condition_ids, state=state, connection=None, read_store=True, now=now)
                try:
                    connection = stack.enter_context(snapshot_reader())
                except Exception:
                    logger.warning("lp competition snapshot unavailable")
                    connection = None
                if connection is None:
                    return self._competition_projection(condition_ids, state=state, connection=None, read_store=True, now=now)
            return self._competition_projection(condition_ids, state=state, connection=connection, read_store=True, now=now)

    def _competition_projection(self, condition_ids, *, state, connection, read_store, now):
        from .polymarket_lp_views import LP_COMPETITION_MAX_AGE
        round_checked_at = state.get("round_checked_at")
        entries: dict[str, object] = {}
        raw_map = state.get("competitiveness")
        if isinstance(raw_map, Mapping):
            requested = (raw_map.items() if condition_ids is None else
                         ((cid, raw_map.get(cid)) for cid in condition_ids))
            for condition_id, value in requested:
                if not isinstance(condition_id, str):
                    continue
                if isinstance(value, tuple) and len(value) == 2:
                    entry_value, checked_at = value
                elif isinstance(value, Mapping):
                    entry_value = value.get("value")
                    checked_at = value.get("checked_at")
                else:
                    continue
                fresh = False
                if isinstance(checked_at, datetime) and checked_at.tzinfo is not None:
                    age = (now - checked_at).total_seconds()
                    fresh = 0 <= age < LP_COMPETITION_MAX_AGE.total_seconds()
                if not fresh:
                    continue
                entries[condition_id] = {
                    "value": entry_value,
                    "checked_at": checked_at,
                    "updated": (
                        checked_at >= round_checked_at
                        if isinstance(checked_at, datetime)
                        and isinstance(round_checked_at, datetime)
                        else None
                    ),
                    "source": "fresh",
                }
        missing = None if condition_ids is None else tuple(cid for cid in condition_ids if cid not in entries)
        store_map = self._competition_store_map(missing, connection=connection) if read_store and (missing is None or missing) else {}
        if store_map:
            for condition_id, (value, checked_at) in store_map.items():
                if condition_id in entries:
                    continue
                entries[condition_id] = {
                    "value": value,
                    "checked_at": checked_at,
                    "updated": None,
                    "source": "store",
                }
        return entries

    def _competition_store_map(
        self, condition_ids: Collection[str] | None = None, *, connection=None
    ) -> dict[str, tuple[Decimal, datetime]]:
        """Read the persisted competition map, tolerating store failures."""

        reader = getattr(self.store, "lp_competitiveness_map", None)
        if not callable(reader):
            return {}
        try:
            options = {} if condition_ids is None else {"condition_ids": condition_ids}
            if connection is not None:
                options["connection"] = connection
            try:
                inspect.signature(reader).bind(**options)
            except (TypeError, ValueError):
                if connection is not None:
                    raise
                options = {}
            store_map = reader(**options)
        except Exception:
            logger.warning("lp competition store read failed")
            return {}
        if not isinstance(store_map, dict):
            return {}
        return store_map if condition_ids is None else {
            cid: store_map[cid] for cid in condition_ids if cid in store_map
        }

    def _candidate_reservations(self, *, ignore_session_id=None) -> tuple[dict[str, object], ...]:
        reservations: list[dict[str, object]] = []
        account_id = str(getattr(getattr(self.exchange, "config", None), "wallet_address", "") or "").strip().casefold()
        for session in self.store.lp_active_sessions():
            if session.get("session_id") == ignore_session_id:
                continue
            if reservation_is_released(session, account_id):
                # The original entry request remains an UNKNOWN audit record,
                # its temporary hold was replaced by account facts or waived locally.
                # Candidate account snapshots already count actual open IDs.
                # A later independent BUY must never inherit entry coverage.
                for action in self.store.lp_actions(str(session["session_id"])):
                    if (unresolved_buy_action(action) and submission_action_kind(action) != 'entry'
                            and not buy_action_is_covered(session, action)):
                        reservations.append({
                            "order_id": str(action.get("order_id") or f"lp-action:{action['action_id']}"),
                            "amount": None,
                        })
                continue
            order_id = str(session.get("entry_order_id") or "").strip()
            if not order_id:
                actions = self.store.lp_actions(str(session["session_id"]))
                history = self._order_history(session)
                has_buy = any(str(record.get("side") or "").upper() == "BUY"
                              for record in history.values()) or any(
                                  unresolved_buy_action(action)
                                  and not buy_action_is_covered(session, action)
                                  for action in actions)
                has_sell = bool(session.get("passive_exit_order_id")) or any(
                    str(record.get("side") or "").upper() == "SELL"
                    for record in history.values())
                if has_sell and not has_buy:
                    # A SELL-only imported or manual session has no BUY
                    # principal to reserve against candidate admission.
                    continue
                order_id = f"lp-session:{session.get('session_id', '')}"
            history = self._order_history(session)
            if str(history.get(order_id, {}).get("status") or "").upper() in TERMINAL_ORDER_STATES:
                continue
            price = _maybe_decimal(session.get("price"))
            quantity = _maybe_decimal(session.get("quantity"))
            filled = _maybe_decimal(session.get("buy_filled_quantity")) or Decimal("0")
            amount = (
                price * max(Decimal("0"), quantity - filled)
                if price is not None and quantity is not None
                else None
            )
            reservations.append({"order_id": order_id, "amount": amount})

        control_reader = getattr(self.store, "n_leg_control", None)
        batch_reader = getattr(self.store, "n_leg_batch", None)
        unknown = {"order_id": "n-leg-reservation:unknown", "amount": None}
        if not callable(control_reader) or not callable(batch_reader):
            reservations.append(unknown)
            return tuple(reservations)
        try:
            control = control_reader()
        except Exception:
            reservations.append(unknown)
            return tuple(reservations)
        if not isinstance(control, Mapping):
            reservations.append(unknown)
            return tuple(reservations)
        batch_id = control.get("active_batch_id")
        if batch_id is None:
            return tuple(reservations)
        if not isinstance(batch_id, str) or not batch_id.strip():
            reservations.append(unknown)
            return tuple(reservations)
        try:
            batch = batch_reader(batch_id)
        except Exception:
            reservations.append(unknown)
            return tuple(reservations)
        if (
            not isinstance(batch, Mapping)
            or batch.get("execution_batch_id") != batch_id
            or batch.get("state") == "INCIDENT_ACKNOWLEDGED"
            or bool(batch.get("unresolved_conflicts"))
            or batch.get("capital_exposure_unknown") is True
        ):
            reservations.append(unknown)
            return tuple(reservations)

        legs = batch.get("legs")
        receipts = batch.get("receipts")
        rows = batch.get("reservations")
        if (
            not isinstance(legs, Sequence)
            or isinstance(legs, (str, bytes))
            or not legs
            or not isinstance(receipts, Mapping)
            or not isinstance(rows, Sequence)
            or isinstance(rows, (str, bytes))
            or not rows
        ):
            reservations.append(unknown)
            return tuple(reservations)

        terminal_states = {"FILLED", "REJECTED", "CANCELLED"}
        for leg in legs:
            if not isinstance(leg, Mapping):
                reservations.append(unknown)
                return tuple(reservations)
            if any(
                not isinstance(leg.get(field), str) or not str(leg[field]).strip()
                for field in ("client_order_id", "venue_id", "account_id")
            ):
                reservations.append(unknown)
                return tuple(reservations)
            receipt = leg.get("receipt")
            if not isinstance(receipt, Mapping) or receipt.get("state") not in terminal_states:
                reservations.append(unknown)
                return tuple(reservations)
            receipt_id = receipt.get("receipt_id")
            if (
                not isinstance(receipt_id, str)
                or receipts.get(receipt_id) != receipt
                or receipt.get("execution_batch_id") != batch_id
                or any(
                    receipt.get(field) != leg.get(field)
                    for field in ("client_order_id", "venue_id", "account_id")
                )
            ):
                reservations.append(unknown)
                return tuple(reservations)

        native_key = ("polymarket", "catalog-v2", "usd-micro")
        native_remaining: int | None = None
        native_found = False
        for row in rows:
            if not isinstance(row, Mapping):
                reservations.append(unknown)
                return tuple(reservations)
            key_values = tuple(
                row.get(field)
                for field in ("venue_id", "account_id", "settlement_asset_id")
            )
            if any(not isinstance(value, str) or not value for value in key_values):
                reservations.append(unknown)
                return tuple(reservations)
            key = cast(tuple[str, str, str], key_values)
            if key == native_key:
                remaining = row.get("remaining_units")
                if (
                    native_found
                    or type(remaining) is not int
                    or remaining < 0
                ):
                    reservations.append(unknown)
                    return tuple(reservations)
                native_found = True
                native_remaining = remaining
        if native_found:
            reservations.append(
                {
                    "order_id": f"n-leg-reservation:{batch_id}:polymarket:usd-micro",
                    "amount": Decimal(cast(int, native_remaining)) / Decimal("1000000"),
                }
            )
        return tuple(reservations)

    @staticmethod
    def _reward_guidance_deadline(
        reward_market: Mapping[str, object],
    ) -> datetime | None:
        pool = _maybe_decimal(reward_market.get("daily_pool_usd"))
        if pool is None or pool <= 0:
            return None
        from .polymarket_trading import (
            LP_REWARD_ASSET_USD_ADDRESSES,
            _reward_date,
        )

        end_dates: list[date] = []
        config_fields = (
            ("combined_reward_configs",)
            if "combined_reward_configs" in reward_market
            else ("native_reward_configs", "sponsored_reward_configs")
        )
        for field in config_fields:
            configs = reward_market.get(field)
            if not isinstance(configs, Sequence) or isinstance(configs, (str, bytes)):
                continue
            for config in configs:
                if not isinstance(config, Mapping):
                    continue
                asset = _text(config.get("asset_address"))
                rate = _maybe_decimal(config.get("rate_per_day"))
                if (
                    asset is None
                    or asset.casefold() not in LP_REWARD_ASSET_USD_ADDRESSES
                    or rate is None
                    or rate <= 0
                ):
                    continue
                end_date = _reward_date(config.get("end_date"))
                if end_date is None:
                    return None
                end_dates.append(end_date)
        if not end_dates:
            return None
        return datetime.combine(min(end_dates) + timedelta(days=1), time.min, UTC)

    @staticmethod
    def _observe_event_end(
        condition_id: str,
        market: Mapping[str, object],
        *,
        existing: object,
        observed_at: datetime,
    ) -> dict[str, object] | None:
        if market.get("event_ended") is not True or market.get("event_finished_at") is not None:
            return None
        game_id = str(market.get("game_id") or "").strip()
        event_id = str(market.get("event_id") or "").strip()
        has_timing = any(
            market.get(field) is not None
            for field in ("game_start_time", "event_start_time")
        )
        if not game_id and not has_timing:
            return None

        if isinstance(existing, Mapping):
            previous_game_id = str(existing.get("game_id") or "").strip()
            previous_event_id = str(existing.get("event_id") or "").strip()
            matches = bool(game_id or event_id)
            if game_id:
                matches = matches and previous_game_id == game_id
            if event_id:
                matches = matches and previous_event_id == event_id
            try:
                _timestamp(
                    existing.get("confirmed_end_at"),
                    name="confirmed_end_at",
                )
            except ValueError:
                matches = False
            if matches:
                return dict(existing)

        return {
            "condition_id": condition_id,
            "game_id": game_id or None,
            "event_id": event_id or None,
            "confirmed_end_at": _iso(observed_at),
        }

    def _read_candidate_facts(
        self, identity: Mapping[str, object], *, wait_for_capacity: bool = False, account=None, candidate=False
    ) -> dict[str, object]:
        """Read market facts shared by entry qualification and resting BUY ranking."""

        return self._market_read(
            identity,
            lambda: self._fetch_candidate_facts(identity, account=account, candidate=candidate),
            wait_for_capacity=wait_for_capacity,
        )

    def _fetch_candidate_facts(self, identity, *, account=None, candidate=False):
        if account is None:
            reader = getattr(self.exchange, "lp_account_snapshot", None)
            if not callable(reader):
                raise ValueError("candidate_readers_unavailable")
            try:
                account = reader()
            except Exception as exc:
                raise ValueError("account_unknown") from exc
        if not isinstance(account, Mapping):
            raise ValueError("account_unknown")
        return {"account": dict(account),
                "direction": self._fetch_market_direction(identity, candidate=candidate)}

    def _fetch_market_direction(self, identity, *, candidate=False):
        condition_id = str(identity.get("condition_id") or "").strip()
        token_id = str(identity.get("token_id") or "").strip()
        outcome = str(identity.get("outcome") or "").upper()
        if not condition_id or not token_id or outcome not in {"YES", "NO"}:
            raise ValueError("candidate_identity_unknown")
        metadata_reader = getattr(self.exchange, "lp_market_metadata_fresh", None)
        reward_reader = getattr(self.exchange, "lp_reward_catalog", None)
        books_reader = getattr(self.exchange, "lp_order_books", None)
        if not all(
            callable(reader)
            for reader in (metadata_reader, reward_reader, books_reader)
        ):
            raise ValueError("candidate_readers_unavailable")
        def read_reward():
            try:
                try:
                    raw_catalog = reward_reader(
                        condition_ids=(condition_id,), stop_event=None
                    )
                except TypeError:
                    raw_catalog = reward_reader(condition_ids=(condition_id,))
            except Exception as exc:
                raise ValueError("candidate_reward_unknown") from exc
            if not isinstance(raw_catalog, Mapping):
                raise ValueError("candidate_reward_unknown")
            reward_market = next(
                (
                    row
                    for row in _items(raw_catalog.get("markets"))
                    if isinstance(row, Mapping)
                    and str(row.get("condition_id") or "") == condition_id
                ),
                None,
            )
            if not isinstance(reward_market, Mapping):
                raise ValueError("candidate_reward_unknown")
            if reward_market.get("state") == "unknown":
                reasons = reward_market.get("reason_codes")
                reason = (
                    str(reasons[0])
                    if isinstance(reasons, Sequence)
                    and not isinstance(reasons, (str, bytes))
                    and reasons
                    else "candidate_reward_unknown"
                )
                raise ValueError(reason)
            return raw_catalog, reward_market

        read_started = self._now()
        exclusion_revision = self._candidate_exclusion_revision
        if candidate and self.exclusions_enabled:
            raw_catalog, reward_market = read_reward()
            reason = self._candidate_market_rejection(reward_market, {}, now=read_started)
            if reason:
                self._exclude_candidate(condition_id, "", reason, checked_at=read_started,
                    exclusion_revision=exclusion_revision)
                raise ValueError(reason)
        try:
            try:
                raw_metadata = metadata_reader((condition_id,), stop_event=None)
            except TypeError:
                raw_metadata = metadata_reader((condition_id,))
        except Exception as exc:
            raise ValueError("candidate_market_unknown") from exc
        metadata = (
            raw_metadata.get("markets")
            if isinstance(raw_metadata, Mapping)
            and isinstance(raw_metadata.get("markets"), Mapping)
            else raw_metadata
        )
        market_metadata = (
            metadata.get(condition_id)
            if isinstance(metadata, Mapping)
            else None
        )
        if not isinstance(market_metadata, Mapping):
            raise ValueError("candidate_market_unknown")
        self._observe_ended_candidate_market(condition_id, market_metadata, checked_at=self._now())
        if not candidate or not self.exclusions_enabled:
            raw_catalog, reward_market = read_reward()
        if candidate and self.exclusions_enabled:
            reason = self._candidate_market_rejection(reward_market, market_metadata, now=self._now())
            if reason:
                self._exclude_candidate(condition_id, "", reason, checked_at=read_started, market=market_metadata,
                    exclusion_revision=exclusion_revision)
                raise ValueError(reason)
        raw_outcomes = market_metadata.get("outcomes")
        if not isinstance(raw_outcomes, Mapping):
            raise ValueError("candidate_market_rules_unknown")
        selected_outcome = next(
            (
                value
                for value in raw_outcomes.values()
                if isinstance(value, Mapping)
                and str(value.get("token_id") or "") == token_id
                and str(value.get("label") or "").upper() == outcome
            ),
            None,
        )
        if not isinstance(selected_outcome, Mapping):
            raise ValueError("candidate_identity_mismatch")
        reward_minimum, reward_spread = _lp_reward_terms(
            market_metadata, reward_market
        )
        if reward_minimum is None or reward_spread is None:
            raise ValueError("candidate_market_rules_unknown")
        market = {
            **dict(market_metadata),
            "condition_id": condition_id,
            "token_id": token_id,
            "outcome": outcome,
            "reward_min_size": reward_minimum,
            "reward_max_spread": reward_spread,
        }
        # Issue #143: the preview re-check reads both token books of the
        # selected market in one call, separate from the scan's round budget.
        outcome_token_ids = [
            str(value.get("token_id") or "").strip()
            for value in raw_outcomes.values()
            if isinstance(value, Mapping) and str(value.get("token_id") or "").strip()
        ]
        preview_token_ids = tuple(dict.fromkeys(outcome_token_ids)) or (token_id,)
        if candidate:
            preview_token_ids = tuple(token for _cid, token in self._candidate_allowed(
                tuple((condition_id, token) for token in preview_token_ids)))
        try:
            try:
                raw_books = books_reader(preview_token_ids, stop_event=None)
            except TypeError:
                raw_books = books_reader(preview_token_ids)
        except Exception as exc:
            raise ValueError("book_unknown") from exc
        book = raw_books.get(token_id) if isinstance(raw_books, Mapping) else None
        if not isinstance(book, Mapping):
            raise ValueError("book_unknown")
        direction = {
            "market": market,
            "book": book,
            "reward_active": reward_market.get("reward_active"),
            "daily_pool_usd": reward_market.get("daily_pool_usd"),
            "reward_checked_at": reward_market.get(
                "reward_checked_at", reward_market.get("checked_at", raw_catalog.get("checked_at"))
            ),
            "reward_guidance_deadline": self._reward_guidance_deadline(reward_market),
        }
        return direction

    def _read_plan_market_snapshot(self, identity):
        """Read execution eligibility without financial qualification or repricing."""
        if not self._candidate_allowed(((str(identity.get('condition_id') or ''),
                                         str(identity.get('token_id') or '')),)):
            raise ValueError('candidate_cooling_down')
        revision = self._candidate_exclusion_revision
        direction = self._market_read(identity,
            lambda: self._fetch_market_direction(identity, candidate=True))
        if self.exclusions_enabled and revision != self._candidate_exclusion_revision:
            raise ValueError('candidate_exclusions_changed')
        market, book = direction['market'], direction['book']
        now = self._now()
        for value, age, reason in (
            (market.get('metadata_checked_at'), _MARKET_METADATA_MAX_AGE_SECONDS, 'market_metadata'),
            (market.get('fees_checked_at'), _MARKET_METADATA_MAX_AGE_SECONDS, 'market_fees'),
            (direction.get('reward_checked_at'), 60, 'reward_data'),
        ):
            _freshness(value, now, reason, max_age=age)
        deadline = direction.get('reward_guidance_deadline')
        if deadline is not None and _timestamp(deadline) <= now:
            raise ValueError('reward_expired')
        event_state, event_reason, _, _ = _event_window_check(direction, market, now)
        if event_state is not None:
            raise ValueError(event_reason or 'event_timing_unknown')
        if direction.get('reward_active') is not True:
            raise ValueError('reward_inactive' if direction.get('reward_active') is False else 'reward_status_unknown')
        reward = _maybe_decimal(direction.get('daily_pool_usd'))
        if reward is None or reward <= 0:
            raise ValueError('reward_pool_unknown' if reward is None else 'reward_pool_empty')
        if (str(book.get('condition_id', book.get('market'))) != str(identity['condition_id'])
                or str(book.get('token_id', book.get('asset_id'))) != str(identity['token_id'])):
            raise ValueError('book_identity_mismatch')
        return {'market': market, 'book': book, 'candidate_direction': direction}

    def _read_candidate_snapshot(
        self, identity: Mapping[str, object], *, now: datetime, ignore_session_id=None,
        account=None, bid_level=None,
    ) -> dict[str, object]:
        if not self._candidate_allowed(((str(identity.get("condition_id") or ""), str(identity.get("token_id") or "")),)):
            raise ValueError("candidate_cooling_down")
        exclusion_revision = self._candidate_exclusion_revision
        facts = self._read_candidate_facts(identity, account=account, candidate=True)
        if self.exclusions_enabled and exclusion_revision != self._candidate_exclusion_revision:
            raise ValueError("candidate_exclusions_changed")
        account, direction = facts["account"], facts["direction"]
        if bid_level is None:
            bid_level = identity.get("candidate_bid_level", identity.get("bid_level", 1))
        evaluation_now = self._now()
        evaluated = evaluate_lp_entry(
            direction,
            account=account,
            now=evaluation_now,
            reservations=self._candidate_reservations(ignore_session_id=ignore_session_id),
            candidate=True,
            bid_level=bid_level,
        )
        if evaluated.get("state") != "eligible":
            reasons = evaluated.get("reason_codes")
            reason = (
                str(reasons[0])
                if isinstance(reasons, Sequence)
                and not isinstance(reasons, (str, bytes))
                and reasons
                else "candidate_not_eligible"
            )
            raise ValueError(reason)
        return {
            "account": dict(account),
            "market": direction["market"],
            "book": dict(direction["book"]),
            "candidate_evaluation": evaluated,
            "candidate_direction": direction,
        }


    def _fresh_candidate_row(
        self,
        identity: Mapping[str, object],
        snapshot: Mapping[str, object],
        *,
        now: datetime,
    ) -> Mapping[str, object]:
        """Return the same shared candidate qualification used by refresh."""

        if not self._candidate_allowed(((str(identity.get("condition_id") or ""), str(identity.get("token_id") or "")),)):
            raise ValueError("candidate_cooling_down")
        evaluated = snapshot.get("candidate_evaluation")
        if not isinstance(evaluated, Mapping) or evaluated.get("state") != "eligible":
            snapshot = self._read_candidate_snapshot(
                identity,
                now=now,
                bid_level=identity.get("candidate_bid_level", identity.get("bid_level", 1)),
            )
            evaluated = snapshot.get("candidate_evaluation")
        guidance = evaluated.get("guidance") if isinstance(evaluated, Mapping) else None
        if not isinstance(guidance, Mapping) or not _lp_guidance_is_usable(guidance):
            raise ValueError("candidate_not_eligible")
        return {
            **dict(identity),
            **dict(guidance),
            "state": "eligible",
            "reason_codes": list(evaluated.get("reason_codes", ()))
            if isinstance(evaluated, Mapping)
            else [],
        }

    def _mutation_allowed(self, action: str = "submit") -> bool:
        owner = self.owner_lock
        if owner is not None:
            held = getattr(owner, "held", None)
            if held is False:
                return False
        guard = self._mutation_guard
        if guard is None:
            return True
        try:
            return guard(action) is True
        except TypeError:
            try:
                return guard() is True
            except Exception:
                return False
        except Exception:
            return False

    def _require_mutation(self) -> None:
        if not self._mutation_allowed("submit"):
            raise _MutationBlocked("mutation_blocked")

    @staticmethod
    def _action_key(session_id: str, role: str, order_id: str | None = None) -> str:
        suffix = f":{order_id}" if order_id else ""
        return f"{session_id}:{role}{suffix}"

    def _now(self) -> datetime:
        value = self.clock()
        if not isinstance(value, datetime) or value.tzinfo is None:
            raise ValueError("clock_invalid")
        return value.astimezone(UTC)

    def preview(self, request: Mapping[str, object]) -> dict[str, object]:
        """Fetch independent exchange facts and return a short-lived preview."""

        try:
            normalized = self._normalize_request(request)
            snapshot = self._read_snapshot(normalized)
            facts = self._validate_snapshot(
                normalized, snapshot, now=self._now(),
                reservations=self._candidate_reservations(),
            )
        except ValueError as exc:
            return {"state": "rejected", "reason": str(exc)}
        expires_at = self._now() + timedelta(seconds=PREVIEW_TTL_SECONDS)
        payload = {**normalized, "preflight": facts}
        preview_id = self.store.create_preview(
            payload,
            expires_at=_iso(expires_at),
            created_at=_iso(self._now()),
        )
        return {
            "state": "previewed",
            "preview_id": preview_id,
            "expires_at": _iso(expires_at),
            "request": normalized,
            "preflight": facts,
            "queue_protection_estimate": self._queue_protection_preview_estimate(
                normalized, snapshot
            ),
        }

    def preview_candidate(self, candidate: Mapping[str, object]) -> dict[str, object]:
        """Build a fresh candidate preview from the server-observed best bid."""

        if not isinstance(candidate, Mapping):
            return {"state": "rejected", "reason": "candidate_invalid"}
        identity: dict[str, object] = {}
        for key in ("market_id", "condition_id", "token_id"):
            value = _text(candidate.get(key))
            if value is None:
                return {"state": "rejected", "reason": f"{key}_invalid"}
            identity[key] = value
        outcome = _text(candidate.get("outcome"))
        if outcome is None or outcome.upper() not in {"YES", "NO"}:
            return {"state": "rejected", "reason": "outcome_invalid"}
        identity["outcome"] = outcome.upper()

        try:
            now = self._now()
            snapshot = self._read_candidate_snapshot(identity, now=now)
            now = self._now()
            from .polymarket_lp_views import _next_review_at

            review_at = _next_review_at(now)
            expiration_for_review(review_at, now=now)
            eligible = self._fresh_candidate_row(identity, snapshot, now=now)
            price = _decimal(eligible.get("price"), "candidate_price")
            quantity = _decimal(eligible.get("quantity"), "candidate_quantity")
            request = self._normalize_request(
                {
                    **identity,
                    "price": price,
                    "quantity": quantity,
                    "review_at": review_at,
                    "candidate_policy": "best_bid_minimum",
                    "candidate_bid_level": eligible.get("bid_level", 1),
                }
            )
            facts = self._validate_snapshot(
                request, snapshot, now=now,
                reservations=self._candidate_reservations(),
            )
        except ValueError as exc:
            return {"state": "rejected", "reason": str(exc)}

        expires_at = now + timedelta(seconds=PREVIEW_TTL_SECONDS)
        preview_id = self.store.create_preview(
            {**request, "preflight": facts},
            expires_at=_iso(expires_at),
            created_at=_iso(now),
        )
        return {
            "state": "previewed",
            "preview_id": preview_id,
            "expires_at": _iso(expires_at),
            "request": request,
            "preflight": facts,
            "queue_protection_estimate": self._queue_protection_preview_estimate(
                request, snapshot
            ),
        }

    @staticmethod
    def _session_augment_own_order_ids(session: Mapping[str, object]) -> list[str]:
        """Own resting order ids an augment re-check must tolerate."""

        ids: list[str] = []
        entry_id = str(session.get("entry_order_id") or "")
        if entry_id:
            ids.append(entry_id)
        for value in _items(session.get("augment_order_ids")):
            augment_id = str(value or "")
            if augment_id:
                ids.append(augment_id)
        return ids

    def _augment_merge_estimate(
        self,
        request: Mapping[str, object],
        snapshot: Mapping[str, object],
    ) -> dict[str, object]:
        """Issue 158 merged share estimate for one augment.

        ``front`` is the same-price level minus the session's own remaining
        BUY size; the projected ratio is front/(front+own+quantity) so the
        new order's share is judged on the merged protection umbrella.
        """

        price = cast(Decimal, request["price"])
        quantity = cast(Decimal, request["quantity"])
        token_id = str(request["token_id"])
        level_total = self._queue_baseline_front(snapshot, price)
        own_remaining = self._own_queue_remaining(
            snapshot, token_id=token_id, price=price
        )
        if own_remaining is None:
            return {
                "baseline_front": None,
                "own_remaining": None,
                "projected_ratio": None,
            }
        front = level_total - own_remaining
        if front < 0:
            front = Decimal("0")
        denominator = front + own_remaining + quantity
        projected = (
            front / denominator if denominator > 0 else Decimal("0")
        )
        return {
            "baseline_front": front,
            "own_remaining": own_remaining,
            "projected_ratio": projected,
        }

    def _augment_session(
        self, session_id: str
    ) -> tuple[dict[str, object] | None, str | None]:
        """Load the augment target session or the rejection reason.

        Issue 166: an augment only lands on ``entry_open``.  Terminal states
        keep the ``session_not_active`` reason; every other non-terminal
        state maps through the shared table to its real reason, so the
        single-shot and two-phase augment paths reject with one voice.
        """

        session = self.store.lp_session(str(session_id))
        if session is None:
            return None, "session_not_found"
        if self.store.lp_auto_owns_session(session_id):
            return None, "automatic_session_augmentation_disabled"
        state = str(session.get("state"))
        if state in {"complete", "entry_rejected"}:
            return None, "session_not_active"
        block = _LP_AUGMENT_STATE_BLOCKS.get(state)
        if block is not None:
            return None, block
        return session, None

    def augment_preview(self, request: Mapping[str, object]) -> dict[str, object]:
        """Build a short-lived augment preview for one price level.

        Issue 167: the optional ``price`` unlocks the level (default = the
        group price); the shared gate rejects a level that still carries an
        own resting BUY and a price above the snapshot's best bid.  The
        estimate projects the chosen level's fresh depth (the issue 158
        merged same-price basis is retired).
        """

        if not isinstance(request, Mapping):
            return {"state": "rejected", "reason": "request_invalid"}
        session_id = _text(request.get("session_id"))
        if session_id is None:
            return {"state": "rejected", "reason": "session_id_invalid"}
        quantity = _maybe_decimal(request.get("quantity"))
        if quantity is None or quantity <= 0:
            return {"state": "rejected", "reason": "quantity_invalid"}
        session, rejection = self._augment_session(session_id)
        if session is None:
            return {"state": "rejected", "reason": rejection or "session_not_active"}
        price = _maybe_decimal(session.get("price"))
        if request.get("price") is not None:
            requested_price = _maybe_decimal(request.get("price"))
            if requested_price is None or requested_price <= 0:
                return {"state": "rejected", "reason": "price_invalid"}
            price = requested_price
        if price is None or price <= 0:
            return {"state": "rejected", "reason": "entry_price_unknown"}
        identity: dict[str, object] = {}
        for key in ("market_id", "condition_id", "token_id"):
            value = _text(session.get(key))
            if value is None:
                return {"state": "rejected", "reason": f"{key}_invalid"}
            identity[key] = value
        outcome = _text(session.get("outcome"))
        if outcome is None or outcome.upper() not in {"YES", "NO"}:
            return {"state": "rejected", "reason": "outcome_invalid"}
        identity["outcome"] = outcome.upper()
        if session.get("review_at") is None:
            return {"state": "rejected", "reason": "review_at_unknown"}
        try:
            augment_request = self._normalize_request(
                {**identity, "price": price, "quantity": quantity,
                 "review_at": session.get("review_at")}
            )
            snapshot = self._read_snapshot(augment_request)
            # Issue 176: the validation clock is taken after the snapshot read
            # completes; received_at is stamped at read time, so a pre-read
            # clock yields a negative age and a deterministic stale rejection.
            now = self._now()
            price_rejection = self._augment_price_rejection(session, snapshot, price)
            if price_rejection is not None:
                return {"state": "rejected", "reason": price_rejection}
            facts = self._validate_snapshot(
                augment_request,
                snapshot,
                now=now,
                allowed_open_order_ids=self._session_augment_own_order_ids(session),
                reservations=self._candidate_reservations(),
            )
        except ValueError as exc:
            return {"state": "rejected", "reason": str(exc)}
        expires_at = now + timedelta(seconds=PREVIEW_TTL_SECONDS)
        payload = {**augment_request, "session_id": session_id, "preflight": facts}
        preview_id = self.store.create_preview(
            payload,
            expires_at=_iso(expires_at),
            created_at=_iso(now),
        )
        return {
            "state": "previewed",
            "preview_id": preview_id,
            "expires_at": _iso(expires_at),
            "request": {"session_id": session_id, "quantity": quantity},
            "price": price,
            "preflight": facts,
            "queue_protection_estimate": self._queue_protection_preview_estimate(
                augment_request, snapshot
            ),
        }

    def _augment_recorded_result(
        self, session_id: str, key: str
    ) -> dict[str, object] | None:
        """Return the durable result of a prior augment with the same key.

        Issue 158: idempotent replays resolve here before any preview read,
        fresh-facts re-check, or best-bid comparison can run again.
        """

        intent_key = self._action_key(session_id, f"augment-submit:{key}")
        for action in self.store.lp_actions(session_id):
            if str(action.get("action_key") or "") != intent_key:
                continue
            state = str(action.get("state") or "")
            order_id = str(action.get("order_id") or "")
            if state == "accepted":
                session = self.store.lp_session(session_id)
                result = (
                    self._status_payload(session)
                    if session is not None
                    else {"state": "none", "session_id": session_id}
                )
                result["augment_order_id"] = order_id
                return result
            if state == "rejected":
                return {
                    "state": "rejected",
                    "reason": "augment_submit_rejected",
                    "session_id": session_id,
                    "order_id": order_id,
                }
            return {
                "state": "needs_attention",
                "session_id": session_id,
                "reason": "augment_submit_unknown",
            }
        return None

    def augment(
        self,
        session_id: str,
        preview_id: str,
        idempotency_key: str | None = None,
    ) -> dict[str, object]:
        """Revalidate an augment preview, then submit exactly one more BUY."""

        key = (idempotency_key or "").strip()
        if not key:
            return {"state": "rejected", "reason": "idempotency_key_required"}
        with self._mutex:
            session, rejection = self._augment_session(str(session_id))
            if session is None:
                return {"state": "rejected", "reason": rejection or "session_not_active"}
            session_id_str = str(session["session_id"])
            recorded = self._augment_recorded_result(session_id_str, key)
            if recorded is not None:
                return recorded
            if not self._mutation_allowed("submit"):
                return {"state": "locked", "reason": "mutation_blocked"}
            preview = self.store.lp_preview(preview_id)
            if preview is None:
                return {"state": "rejected", "reason": "preview_not_found"}
            try:
                expires_at = _timestamp(preview["expires_at"], name="preview_expiry")
                if self._now() >= expires_at:
                    raise ValueError("preview_expired")
                if str(preview.get("session_id") or "") != session_id_str:
                    raise ValueError("preview_session_mismatch")
                request = self._normalize_request(preview)
                snapshot = self._read_snapshot(request)
                # Issue 176: validation clock taken after the read completes
                # (received_at stamps at read time — a pre-read clock goes
                # deterministically stale).
                now = self._now()
                # Issue 167: shared augment price gate on the fresh snapshot
                # (level-active first, then the best-bid ceiling).
                price_rejection = self._augment_price_rejection(
                    session, snapshot, cast(Decimal, request["price"])
                )
                if price_rejection is not None:
                    return {"state": "rejected", "reason": price_rejection}
                facts = self._validate_snapshot(
                    request,
                    snapshot,
                    now=now,
                    allowed_open_order_ids=self._session_augment_own_order_ids(session),
                    reservations=self._candidate_reservations(),
                )
                self._require_lp_history(request, now=now)
                # Issue 158: same submit-time best-bid re-check as start.
                credential_preflight = preview.get("preflight")
                credential_best_bid = (
                    _maybe_decimal(credential_preflight.get("best_bid"))
                    if isinstance(credential_preflight, Mapping)
                    else None
                )
                if (
                    credential_best_bid is not None
                    and credential_best_bid != facts["best_bid"]
                ):
                    raise ValueError("best_bid_changed")
                expiration = expiration_for_review(
                    _timestamp(request["review_at"], name="review_at"), now=now
                )
            except ValueError as exc:
                if str(exc).startswith("history_"):
                    try:
                        self.store.consume_lp_preview(preview_id)
                    except ValueError:
                        pass
                return {"state": "rejected", "reason": str(exc)}
            try:
                self.store.consume_lp_preview(preview_id)
            except ValueError as exc:
                return {"state": "rejected", "reason": str(exc)}
            return self._augment_execute(
                session=session,
                session_id=session_id_str,
                request=request,
                snapshot=snapshot,
                now=now,
                key=key,
                expiration=expiration,
            )

    def _augment_execute(
        self,
        *,
        session: Mapping[str, object],
        session_id: str,
        request: Mapping[str, object],
        snapshot: Mapping[str, object],
        now: datetime,
        key: str,
        expiration: int,
    ) -> dict[str, object]:
        """Record the augment intent and submit exactly one more BUY.

        Shared tail of the two-phase ``augment`` (issue 158) and the
        single-shot ``submit_augment`` (issue 163): the caller has already
        validated fresh facts against the session's own resting orders;
        this helper owns the action rows, the exchange post, the appended
        order history, and the #152 baseline re-anchor.
        """

        price = cast(Decimal, request["price"])
        quantity = cast(Decimal, request["quantity"])
        action_base: dict[str, object] = {
            "role": "augment",
            "side": "BUY",
            "token_id": str(request["token_id"]),
            "idempotency_key": key,
            "price": price,
            "quantity": quantity,
            "expiration": expiration,
            "submit_requested_at": _iso(now),
        }
        intent_key = self._action_key(session_id, f"augment-submit:{key}")
        self.store.lp_upsert_action(
            session_id,
            intent_key,
            state="pending",
            payload={**action_base},
        )
        try:
            signed = self._create_limit(
                token_id=str(request["token_id"]),
                price=price,
                quantity=quantity,
                side="BUY",
                post_only=True,
                expiration=expiration,
            )
            response = self._post_limit(signed, side="BUY")
        except Exception as exc:
            self.store.lp_upsert_action(
                session_id,
                intent_key,
                state="unknown",
                payload={**action_base, "error": type(exc).__name__},
            )
            return {
                "state": "needs_attention",
                "session_id": session_id,
                "reason": "augment_submit_unknown",
                "error": type(exc).__name__,
            }
        accepted, order_id = self._order_response(response)
        if not accepted:
            self.store.lp_upsert_action(
                session_id,
                intent_key,
                state="rejected",
                payload={
                    **action_base,
                    "order_id": order_id or "",
                    "error": "augment_submit_rejected",
                },
            )
            return {
                "state": "rejected",
                "reason": "augment_submit_rejected",
                "session_id": session_id,
                "order_id": order_id or "",
            }
        if not order_id:
            self.store.lp_upsert_action(
                session_id,
                intent_key,
                state="unknown",
                payload={**action_base, "error": "accepted_without_order_id"},
            )
            return {
                "state": "needs_attention",
                "session_id": session_id,
                "reason": "augment_submit_unknown",
            }
        self.store.lp_upsert_action(
            session_id,
            self._action_key(session_id, f"augment-submit:{order_id}"),
            state="accepted",
            payload={
                **action_base,
                "order_id": order_id,
                "submit_receipt_at": _iso(self._now()),
            },
        )
        self.store.lp_upsert_action(
            session_id,
            intent_key,
            state="accepted",
            payload={**action_base, "order_id": order_id},
        )
        # The venue post can overlap an off-lock queue-protection cancel.
        # Re-read after the post so the session merge starts from the latest
        # durable A/B state instead of the pre-submit snapshot.
        session = self.store.lp_session(session_id) or session
        registered_session, receipt_changed = self._register_direct_receipt(
            session,
            order_id=order_id,
            response=response,
            side="BUY",
            price=price,
            quantity=quantity,
            expiration=expiration,
        )
        if str(registered_session.get("session_id") or "") != session_id:
            return {
                **self._status_payload(session),
                "reason": "receipt_owned_by_other_session",
            }
        session = registered_session
        # A replayed receipt that was already adopted by sync has no new
        # lifecycle and must never re-anchor its existing protection.
        protection_payload = None
        if receipt_changed:
            raw_protection = session.get("queue_protection")
            levels = _queue_protection_level_buckets(
                raw_protection,
                default_order_id=str(session.get("entry_order_id") or ""),
            )
            bucket: dict[str, object] = {
                "order_id": order_id,
                **self._queue_protection_baseline(request, snapshot),
                "baseline_version": 1,
                "threshold": LP_QUEUE_PROTECTION_THRESHOLD,
                "state": "registered",
                "notification_sent": False,
                "blocked_notified": False,
                "cancel_scope": "own_buys_at_level",
                "cancel_targets": [],
                "canceled_order_ids": [],
                "cancel_target_remaining": {},
                "canceled_remaining": None,
                "partially_filled_quantity": None,
                "reason_codes": [],
            }
            levels[format(price, "f")] = bucket
            protection_payload = {
                "version": 2,
                "data_failures": _queue_group_failures_int(
                    raw_protection.get("data_failures")
                    if isinstance(raw_protection, Mapping)
                    else None
                ),
                "levels": levels,
            }
        session_patch = {
            "augment_order_id": order_id,
            "augment_quantity": quantity,
        }
        merger = getattr(self.store, "lp_merge_queue_protection", None)
        if protection_payload is None:
            updated = self.store.lp_update_session(session_id, patch=session_patch)
        elif callable(merger):
            updated = merger(
                session_id,
                queue_protection=protection_payload,
                patch=session_patch,
            )
        else:
            updated = self.store.lp_update_session(
                session_id,
                patch={**session_patch, "queue_protection": protection_payload},
            )
        return self._status_payload(updated)

    def _session_price_level_active(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        price: Decimal,
    ) -> bool:
        """Issue 167 D1-c: an own non-terminal BUY still rests at this price.

        Evidence sources mirror ``_session_augment_own_order_ids``: the
        durable order history first, then the snapshot receipts/account rows.
        An order whose status is unreadable counts as alive (never proven
        terminal); an order whose price is unreadable cannot be attributed
        to any level and does not block.
        """

        history = self._order_history(session)
        rows_by_id = self._queue_level_rows(snapshot)
        for order_id in self._session_augment_own_order_ids(session):
            record = history.get(order_id)
            row = rows_by_id.get(order_id)
            source = (
                record
                if isinstance(record, Mapping) and record.get("status")
                else row
            )
            if source is None:
                continue
            status = str(_field(source, "status", "") or "").upper()
            if status and status in TERMINAL_ORDER_STATES:
                continue
            order_price = _maybe_decimal(_field(source, "price"))
            if order_price is not None and order_price == price:
                return True
        return False

    def _augment_price_rejection(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        price: Decimal,
    ) -> str | None:
        """Issue 167 D1-c/D2: shared augment price gate for both paths.

        Fixed order: a level with a resting own BUY rejects first (one
        resting order per price level), then the best-bid ceiling (a price
        above the same snapshot's top bid can never rest).  An empty bid
        side has no provable ceiling and rejects too.
        """

        if self._session_price_level_active(session, snapshot, price):
            return "price_level_active"
        book = snapshot.get("book")
        bids: list[tuple[Decimal, Decimal]] = []
        if isinstance(book, Mapping):
            try:
                bids = self._levels(book.get("bids"), "bids")
            except ValueError:
                bids = []
        best_bid = max((row_price for row_price, _ in bids), default=None)
        if best_bid is None or price > best_bid:
            return "price_above_best_bid"
        return None

    def submit_augment(
        self,
        session_id: str,
        quantity: str,
        idempotency_key: str | None = None,
        price: str | Decimal | None = None,
    ) -> dict[str, object]:
        """Issue 163: single-shot augment bound to one named session.

        The target session is explicit — the request can never land on
        "whatever session is currently active".  Replays resolve from the
        recorded action row before any fresh-facts read; the one snapshot
        read tolerates only this session's own resting orders, and the
        review deadline stays the session's original one (no re-timer).
        Issue 167: the optional ``price`` unlocks the augment price level
        (default = the group price); the shared gate rejects a level that
        still carries an own resting BUY and a price above the best bid.
        """

        key = (idempotency_key or "").strip()
        if not key:
            return {"state": "rejected", "reason": "idempotency_key_required"}
        with self._mutex:
            session, rejection = self._augment_session(str(session_id))
            if session is None:
                return {"state": "rejected", "reason": rejection or "session_not_active"}
            session_id_str = str(session["session_id"])
            recorded = self._augment_recorded_result(session_id_str, key)
            if recorded is not None:
                return recorded
            if not self._mutation_allowed("submit"):
                return {"state": "locked", "reason": "mutation_blocked"}
            quantity_d = _maybe_decimal(quantity)
            if quantity_d is None or quantity_d <= 0:
                return {"state": "rejected", "reason": "quantity_invalid"}
            price_d = _maybe_decimal(session.get("price"))
            if price is not None:
                requested_price = _maybe_decimal(price)
                if requested_price is None or requested_price <= 0:
                    return {"state": "rejected", "reason": "price_invalid"}
                price_d = requested_price
            if price_d is None or price_d <= 0:
                return {"state": "rejected", "reason": "entry_price_unknown"}
            identity: dict[str, object] = {}
            for identity_key in ("market_id", "condition_id", "token_id"):
                value = _text(session.get(identity_key))
                if value is None:
                    return {"state": "rejected", "reason": f"{identity_key}_invalid"}
                identity[identity_key] = value
            outcome = _text(session.get("outcome"))
            if outcome is None or outcome.upper() not in {"YES", "NO"}:
                return {"state": "rejected", "reason": "outcome_invalid"}
            identity["outcome"] = outcome.upper()
            if session.get("review_at") is None:
                return {"state": "rejected", "reason": "review_at_unknown"}
            try:
                request = self._normalize_request(
                    {**identity, "price": price_d, "quantity": quantity_d,
                     "review_at": session.get("review_at")}
                )
                snapshot = self._read_snapshot(request)
                # Issue 176: validation clock taken after the read completes
                # (received_at stamps at read time — a pre-read clock goes
                # deterministically stale).
                now = self._now()
                price_rejection = self._augment_price_rejection(
                    session, snapshot, price_d
                )
                if price_rejection is not None:
                    return {"state": "rejected", "reason": price_rejection}
                facts = self._validate_snapshot(
                    request,
                    snapshot,
                    now=now,
                    allowed_open_order_ids=self._session_augment_own_order_ids(session),
                    reservations=self._candidate_reservations(),
                )
                self._require_lp_history(request, now=now)
                expiration = expiration_for_review(
                    _timestamp(request["review_at"], name="review_at"), now=now
                )
            except ValueError as exc:
                return {"state": "rejected", "reason": str(exc)}
            return self._augment_execute(
                session=session,
                session_id=session_id_str,
                request=request,
                snapshot=snapshot,
                now=now,
                key=key,
                expiration=expiration,
            )

    def _queue_baseline_front(
        self, snapshot: Mapping[str, object], price: Decimal
    ) -> Decimal:
        """Sum the price level's size in a validated book; a missing level is 0.

        Registration never rejects on the level: validation already proved the
        session owns no order on the token, so any level size present here is
        queue ahead.  An empty level registers a zero baseline by explicit
        decision (first tick with any depth then estimates A = 0% and cancels).
        """

        book = snapshot.get("book")
        if not isinstance(book, Mapping):
            return Decimal("0")
        try:
            bids = self._levels(book.get("bids"), "bids")
        except ValueError:
            return Decimal("0")
        return sum(
            (size for row_price, size in bids if row_price == price),
            Decimal("0"),
        )

    def _queue_protection_baseline(
        self, request: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> dict[str, object]:
        """Build the durable baseline facts recorded at the submit boundary."""

        book = snapshot.get("book")
        book_mapping = book if isinstance(book, Mapping) else None
        return {
            "baseline_front": self._queue_baseline_front(
                snapshot, cast(Decimal, request["price"])
            ),
            "baseline_price": request["price"],
            "baseline_source": "submit",
            "baseline_book_received_at": (
                book_mapping.get("received_at") if book_mapping else None
            ),
            "baseline_source_timestamp": (
                book_mapping.get("source_timestamp") if book_mapping else None
            ),
            "baseline_book_hash": book_mapping.get("hash") if book_mapping else None,
        }

    def _queue_protection_preview_estimate(
        self, request: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> dict[str, object]:
        """Project the post-submit share of the same-price level (A estimate)."""

        baseline_front = self._queue_baseline_front(
            snapshot, cast(Decimal, request["price"])
        )
        quantity = cast(Decimal, request["quantity"])
        projected = (
            baseline_front / (baseline_front + quantity)
            if baseline_front + quantity > 0
            else Decimal("0")
        )
        return {"baseline_front": baseline_front, "projected_ratio": projected}

    def _queue_baseline_book_sample(
        self, request: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> dict[str, object] | None:
        """Build one BBO receipt row mirroring sample_candidate_books."""

        book = snapshot.get("book")
        if not isinstance(book, Mapping) or book.get("received_at") is None:
            return None
        try:
            received_at = _timestamp(book.get("received_at"), name="book_received_at")
            bids = self._levels(book.get("bids"), "bids")
            asks = self._levels(book.get("asks"), "asks")
        except ValueError:
            return None
        if not bids or not asks:
            return None
        bid_price, bid_size = max(bids, key=lambda level: level[0])
        ask_price, ask_size = min(asks, key=lambda level: level[0])
        return {
            "condition_id": str(request["condition_id"]),
            "token_id": str(request["token_id"]),
            "received_at": received_at,
            "source_timestamp": book.get("source_timestamp"),
            "best_bid_price": bid_price,
            "best_bid_size": bid_size,
            "best_ask_price": ask_price,
            "best_ask_size": ask_size,
        }

    def _first_seen_book_sample(
        self,
        *,
        condition_id: str,
        token_id: str,
        book: Mapping[str, object],
    ) -> dict[str, object] | None:
        """Build one BBO receipt row for a first-seen registration."""

        if book.get("received_at") is None:
            return None
        try:
            received_at = _timestamp(book.get("received_at"), name="book_received_at")
            bids = self._levels(book.get("bids"), "bids")
            asks = self._levels(book.get("asks"), "asks")
        except ValueError:
            return None
        if not bids or not asks:
            return None
        bid_price, bid_size = max(bids, key=lambda level: level[0])
        ask_price, ask_size = min(asks, key=lambda level: level[0])
        return {
            "condition_id": condition_id,
            "token_id": token_id,
            "received_at": received_at,
            "source_timestamp": book.get("source_timestamp"),
            "best_bid_price": bid_price,
            "best_bid_size": bid_size,
            "best_ask_price": ask_price,
            "best_ask_size": ask_size,
        }

    @staticmethod
    def _owned_sync_order_rows(
        raw_trades: object, wallet_address: str
    ) -> list[dict[str, object]]:
        """Project only account-owned fills absent from an open-order list."""

        # Key by (trade_id, order_id), so a paginated/repeated fill is
        # idempotent while a contradictory page is a hard fact conflict.
        fills: dict[str, dict[str, tuple[Decimal, Decimal]]] = {}
        identities: dict[str, tuple[str, str, str]] = {}

        def record(
            *,
            order_id: str,
            condition_id: object,
            token_id: object,
            side: object,
            price: object,
            quantity: object,
            trade_id: str,
        ) -> None:
            identity = (
                str(condition_id or ""),
                str(token_id or ""),
                str(side or "").upper(),
            )
            known_identity = identities.setdefault(order_id, identity)
            if known_identity != identity:
                raise ValueError("order_identity_conflict")
            parsed_price = _maybe_decimal(price)
            parsed_quantity = _maybe_decimal(quantity)
            if parsed_price is None or parsed_price <= 0 or parsed_quantity is None or parsed_quantity <= 0:
                raise ValueError("trade_fill_unknown")
            notional = parsed_price * parsed_quantity
            trades = fills.setdefault(order_id, {})
            previous = trades.get(trade_id)
            if previous is not None:
                if previous != (parsed_quantity, notional):
                    raise ValueError("trade_fill_conflict")
                return
            trades[trade_id] = (parsed_quantity, notional)

        for raw in _items(raw_trades):
            trade = _lp_trade(raw)
            if trade is None:
                raise ValueError("trade_fact_invalid")
            trade_id = str(trade.get("id") or "")
            condition_id = trade.get("condition_id", trade.get("market"))
            if trade.get("status") not in {"CONFIRMED", "MATCHED", "FILLED"}:
                continue
            if (
                trade.get("trader_side") == "TAKER"
                and trade.get("taker_order_id")
            ):
                record(
                    order_id=str(trade["taker_order_id"]),
                    condition_id=condition_id,
                    token_id=trade.get("token_id", trade.get("asset_id")),
                    side=trade.get("side"),
                    price=trade.get("price"),
                    quantity=trade.get("size"),
                    trade_id=trade_id,
                )
            for maker in _items(trade.get("maker_orders", ())):
                if not isinstance(maker, Mapping):
                    continue
                maker_id = str(maker.get("order_id") or "")
                if not maker_id or not _lp_maker_order_is_self(maker, wallet_address):
                    continue
                record(
                    order_id=maker_id,
                    condition_id=condition_id,
                    token_id=maker.get("token_id", maker.get("asset_id")),
                    side=maker.get("side"),
                    price=maker.get("price"),
                    quantity=maker.get("matched_amount"),
                    trade_id=trade_id,
                )

        rows: list[dict[str, object]] = []
        for order_id in sorted(fills):
            condition_id, token_id, side = identities[order_id]
            trades = fills[order_id]
            quantity = sum((amount for amount, _ in trades.values()), Decimal("0"))
            notional = sum((amount for _, amount in trades.values()), Decimal("0"))
            average_price = notional / quantity
            rows.append(
                {
                    "order_id": order_id,
                    "condition_id": condition_id,
                    "token_id": token_id,
                    "side": side,
                    "price": average_price,
                    "average_price": average_price,
                    # Fills prove volume, not the original order size or
                    # terminal lifecycle.  The existing lp_snapshot get_order
                    # path supplies those facts through exact order IDs.
                    "original_size": None,
                    "quantity": None,
                    "remaining_size": None,
                    "size_matched": quantity,
                    "status": "UNKNOWN",
                    "fills": tuple(
                        {
                            "trade_id": trade_id,
                            "quantity": amount,
                            "price": amount_price,
                            "notional": amount_notional,
                        }
                        for trade_id, (amount, amount_notional) in trades.items()
                        for amount_price in [amount_notional / amount]
                    ),
                }
            )
        return rows

    @staticmethod
    def _sync_order_history_row(row: Mapping[str, object]) -> dict[str, object]:
        order_id = str(_field(row, "order_id", _field(row, "id", "")) or "")
        return {
            "order_id": order_id,
            "token_id": str(_field(row, "token_id", _field(row, "asset_id", "")) or ""),
            "side": str(_field(row, "side", "") or "").upper(),
            "status": str(_field(row, "status", "") or "").upper(),
            "price": _maybe_decimal(_field(row, "price")),
            "quantity": _maybe_decimal(_field(row, "original_size", _field(row, "size"))),
            "size_matched": _maybe_decimal(_field(row, "size_matched", _field(row, "matched_amount"))),
            "average_price": _maybe_decimal(_field(row, "average_price")),
            "order_type": _field(row, "order_type"),
            "expiration": _field(row, "expiration", _field(row, "expires_at")),
            "created_at": _field(row, "created_at"),
        }

    def _existing_token_session(self, token_id: str) -> Mapping[str, object] | None:
        account_id = str(
            getattr(getattr(self.exchange, "config", None), "wallet_address", "") or ""
        ).strip().casefold()
        return next(
            (
                session
                for session in self.store.lp_active_sessions()
                if str(session.get("token_id") or "") == token_id
                and str(session.get("account_id") or "").strip().casefold() == account_id
            ),
            None,
        )

    def _prepare_sync_queue_baselines(
        self, token_id: str, rows: list[Mapping[str, object]]
    ) -> None:
        """Attach one fresh first-observation baseline per resting BUY level."""

        resting = [
            row
            for row in rows
            if str(_field(row, "side", "") or "").upper() == "BUY"
            and str(_field(row, "status", "") or "").upper()
            in {"LIVE", "OPEN", "ACCEPTED", "PENDING"}
            and (_maybe_decimal(_field(row, "remaining_size", _field(row, "size"))) or Decimal("0")) > 0
        ]
        if not resting:
            return
        existing = self._existing_token_session(token_id)
        if existing is not None:
            buckets = _queue_protection_level_buckets(existing.get("queue_protection"))
            prices = {
                _maybe_decimal(_field(row, "price"))
                for row in resting
            } - {None}
            known_prices = {
                _maybe_decimal(bucket.get("baseline_price"))
                for bucket in buckets.values()
                if isinstance(bucket, Mapping)
                and bucket.get("state") not in {None, "", "unknown"}
            }
            if prices <= known_prices:
                return
        reader = getattr(self.exchange, "lp_order_books", None)
        if not callable(reader):
            return
        try:
            books = reader((token_id,))
        except Exception:
            return
        book = books.get(token_id) if isinstance(books, Mapping) else None
        if not isinstance(book, Mapping) or not book.get("received_at"):
            return
        try:
            _freshness(book.get("received_at"), self._now(), "book_freshness")
        except ValueError:
            return
        grouped: dict[Decimal, list[Mapping[str, object]]] = {}
        for row in resting:
            price = _maybe_decimal(_field(row, "price"))
            if price is not None:
                grouped.setdefault(price, []).append(row)
        for price, level_rows in grouped.items():
            own_remaining = Decimal("0")
            own_remaining_known = True
            for row in level_rows:
                remaining = _maybe_decimal(
                    _field(row, "remaining_size", _field(row, "size"))
                )
                if remaining is None:
                    own_remaining_known = False
                    break
                own_remaining += remaining
            baseline = first_observation_baseline(
                book,
                price=price,
                own_remaining=own_remaining if own_remaining_known else None,
            )
            if baseline.get("state") != "known":
                continue
            for row in level_rows:
                # Mappings are immutable only by convention here; sync owns
                # this freshly constructed row list before registration.
                row["queue_baseline"] = {
                    **baseline,
                    "baseline_source_timestamp": book.get("source_timestamp"),
                }

    def _join_token_session(
        self,
        session: Mapping[str, object],
        rows: list[Mapping[str, object]],
    ) -> dict[str, object]:
        configured = str(
            getattr(getattr(self.exchange, "config", None), "wallet_address", "") or ""
        ).strip().casefold()
        result = self.store.lp_register_exchange_orders(
            str(session.get("account_id") or configured),
            str(session.get("token_id") or ""),
            rows,
        )
        return result["session"]

    def _register_direct_receipt(
        self,
        session: Mapping[str, object],
        *,
        order_id: str,
        response: Mapping[str, object],
        side: str,
        price: object,
        quantity: object,
        expiration: object = None,
        order_type: str | None = None,
    ) -> tuple[dict[str, object], bool]:
        """Adopt one accepted exchange receipt through the shared Store seam."""

        configured = str(
            getattr(getattr(self.exchange, "config", None), "wallet_address", "") or ""
        ).strip().casefold()
        record = {
            "order_id": order_id,
            "token_id": session.get("token_id"),
            "side": side,
            "status": str(_field(response, "status", "LIVE") or "LIVE").upper(),
            "price": price,
            "original_size": quantity,
            "size_matched": _field(response, "size_matched"),
            "expiration": expiration,
            "order_type": _field(response, "order_type") or order_type or (
                "GTD" if expiration is not None else None
            ),
        }
        result = self.store.lp_register_exchange_orders(
            str(session.get("account_id") or configured),
            str(session.get("token_id") or ""),
            [record],
            session=session,
        )
        return result["session"], bool(result["changed"])

    def _register_account_snapshot(self, snapshot: Mapping[str, object], *, _planning_only=False,
                                   _automatic_observation=False) -> dict[str, object]:
        """Register every account-owned order in one complete sync bundle.

        One LP session owns one token; a newly discovered SELL joins that
        session instead of creating a second seller for the same inventory.
        """

        prepared_at = monotonic()
        diagnostics = {}
        if not isinstance(snapshot, Mapping) or snapshot.get("authenticated") is not True:
            return {"state": "skipped", "reason": "account_snapshot_unknown"}
        required = (
            "balance_complete", "open_orders_complete",
            "positions_complete", *(("current_pagination_complete",) if _planning_only
                                    else ("trades_complete", "pagination_complete")),
        )
        if any(snapshot.get(key) is not True for key in required):
            return {"state": "skipped", "reason": "account_snapshot_incomplete"}
        wallet = str(snapshot.get("wallet_address") or "").strip()
        config = getattr(self.exchange, "config", None)
        configured = str(getattr(config, "wallet_address", "") or "").strip()
        snapshot_account = str(snapshot.get("account_id") or "").strip()
        if (
            not wallet
            or not configured
            or not snapshot_account
            or wallet.casefold() != configured.casefold()
            or snapshot_account.casefold() != configured.casefold()
        ):
            return {"state": "skipped", "reason": "account_identity_mismatch"}
        account_id = snapshot_account.casefold()
        if not str(snapshot.get("wallet_address") or "").strip() or not snapshot.get("read_started_at") or not snapshot.get("read_ended_at"):
            return {"state": "skipped", "reason": "account_snapshot_incomplete"}
        generation = snapshot.get("trade_generation")
        generation_reader = getattr(self.store, "lp_trade_generation", None)
        if (
            not isinstance(generation, int)
            or isinstance(generation, bool)
            or not callable(generation_reader)
            or generation != generation_reader()
        ):
            return {"state": "skipped", "reason": "account_round_invalid"}
        try:
            read_started = _timestamp(snapshot["read_started_at"], name="read_started_at")
            read_ended = _timestamp(snapshot["read_ended_at"], name="read_ended_at")
            checked_at = _timestamp(snapshot["checked_at"], name="checked_at")
            if read_started > read_ended:
                raise ValueError("account_read_order_invalid")
            if not read_started <= checked_at <= read_ended:
                raise ValueError("account_read_order_invalid")
            _freshness(read_ended, self._now(), "account_freshness")
            _freshness(checked_at, self._now(), "account_freshness")
        except ValueError:
            return {"state": "skipped", "reason": "account_snapshot_stale"}
        open_orders = snapshot.get("open_orders")
        if not isinstance(open_orders, (list, tuple)):
            return {"state": "failed", "reason": "account_open_orders_unknown"}
        for row in open_orders:
            if (
                not isinstance(row, Mapping)
                or not _field(row, "order_id", _field(row, "id", ""))
                or not _field(row, "token_id", _field(row, "asset_id", ""))
            ):
                return {
                    "state": "failed",
                    "reason": "account_order_identity_unknown",
                }
        if not _planning_only and ("raw_trades" not in snapshot or not isinstance(snapshot["raw_trades"], (list, tuple))):
            return {"state": "failed", "reason": "account_raw_trades_unknown"}
        raw_orders = [row for row in open_orders if isinstance(row, Mapping)]
        owned_fills = ([] if _planning_only else self._owned_sync_order_rows(snapshot["raw_trades"], wallet))
        known_ids = {
            str(_field(row, "order_id", _field(row, "id", "")) or "") for row in raw_orders
        }
        rows = [*raw_orders, *(row for row in owned_fills if str(row.get("order_id")) not in known_ids)]
        diagnostics["account_input_rows"] = len(rows)
        groups: dict[str, list[Mapping[str, object]]] = {}
        for row in rows:
            token = str(_field(row, "token_id", _field(row, "asset_id", "")) or "")
            if not token:
                return {"state": "failed", "reason": "account_order_identity_unknown"}
            groups.setdefault(token, []).append(row)

        def revisions(connection):
            # Preparing baselines can perform network reads. Fence any changed
            # ownership/trading state before the single account-wide commit.
            scanned = connection.execute(
                "SELECT session_id,json_extract(payload,'$._lp_trade_revision') AS revision "
                "FROM lp_sessions WHERE lower(trim(coalesce(json_extract(payload,'$.account_id'),''))) IN ('',?)",
                (account_id,),
            ).fetchall()
            diagnostics["session_scan_calls"] = diagnostics.get("session_scan_calls", 0) + 1
            diagnostics["session_rows_scanned"] = diagnostics.get("session_rows_scanned", 0) + len(scanned)
            return {str(row["session_id"]): int(row["revision"] or 0) for row in scanned}

        with self.store._read_connection() as connection:
            expected_revisions = revisions(connection)
        prepared = []
        owned_sessions = self.store.lp_sessions()
        diagnostics["session_scan_calls"] = diagnostics.get("session_scan_calls", 0) + 1
        diagnostics["session_rows_scanned"] = diagnostics.get("session_rows_scanned", 0) + len(owned_sessions)
        owned_ids = {
            order_id
            for session in owned_sessions
            if str(session.get("account_id") or "").strip().casefold() in {"", account_id}
            for order_id in self._session_order_ids(session)
        }
        try:
            for token, token_rows in groups.items():
                self._prepare_sync_queue_baselines(token, token_rows)
                existing = self._existing_token_session(token)
                candidate = None
                unknown_rows = [
                    row for row in token_rows
                    if str(_field(row, "order_id", _field(row, "id", "")) or "") not in owned_ids
                ]
                episode = next(
                    (item for item in self.store.lp_active_first_seen_episodes()
                     if str(item.get("token_id") or "") == token), None,
                )
                if existing is None and unknown_rows:
                    candidate = self._create_sync_session(snapshot, token, unknown_rows, episode)
                    if candidate is None:
                        raise ValueError("baseline_unknown")
                elif existing is not None and episode is not None:
                    candidate = {"session_id": existing["session_id"],
                                 "_first_seen_episode_id": episode["episode_id"]}
                prepared.append((token, token_rows, candidate))

            # Validate current exposure before publication. Historical report
            # gaps cannot veto API positions or create additional reservations.
            builder = build_planning_account_facts if _planning_only else build_account_financial_facts
            financial_facts = builder(
                snapshot, now=self._now(), expected_account_id=account_id,
            )
            token_results = []
            registered_sessions = {}
            created = joined = 0
            prepare_seconds = monotonic() - prepared_at
            _lp_causal_event("account_publish_ready", account=snapshot, prepare_seconds=prepare_seconds)
            lock_started = monotonic()
            with _lp_read_lock(self._first_seen_apply_lock, "account_registration_apply_lock_wait"):
                diagnostics["apply_lock_wait_seconds"] = round(monotonic() - lock_started, 3)
                with self.store._transaction(prepare_seconds=prepare_seconds, diagnostics=diagnostics) as connection:
                    _lp_causal_event("account_publish_begin", account=snapshot, prepare_seconds=prepare_seconds)
                    observed = connection.execute(
                        "SELECT generation FROM lp_trade_generation WHERE singleton=1"
                    ).fetchone()
                    current_revisions = revisions(connection)
                    if observed is None:
                        raise LpObservationWait("account_round_invalid")
                    current_generation = int(observed['generation'])
                    if current_generation != generation or current_revisions != expected_revisions:
                        if not _automatic_observation or current_generation != generation:
                            raise LpObservationWait("account_round_invalid")
                        # Monitoring may publish the very IDs in this read.
                        # Accept that narrow change only after checking every
                        # changed owner and actual new BUY request/exposure.
                        buys = {buy['order_id']: buy for buy in financial_facts['buys']}
                        positions = {position['token_id']: position for position in financial_facts['positions']}
                        fills = financial_facts.get('order_fills') or {}
                        owned_fill_rows = {str(fill['order_id']): fill for fill in owned_fills}
                        for sid in expected_revisions.keys() | current_revisions.keys():
                            if expected_revisions.get(sid) == current_revisions.get(sid):
                                continue
                            row = connection.execute('SELECT * FROM lp_sessions WHERE session_id=?', (sid,)).fetchone()
                            session = self.store._lp_row_result(row) if row else None
                            if not session or session.get('order_identity_conflict'):
                                raise LpObservationWait('account_round_invalid')
                            for audit in self.store.lp_actions(sid, connection=connection):
                                stamp = audit.get('submit_requested_at') or audit.get('submit_post_started_at')
                                if (submission_action_kind(audit) in ('entry', 'augment')
                                        and audit.get('side') == 'BUY' and stamp
                                        and _timestamp(stamp, name='submit_requested_at') >= read_started
                                        and audit.get('state') in ('pending', 'accepted', 'unknown')):
                                    raise LpObservationWait('account_round_invalid')
                            for oid, fact in self._order_history(session).items():
                                if fact.get('side') != 'BUY':
                                    continue
                                buy = buys.get(oid)
                                matched = _maybe_decimal(fact.get('size_matched'))
                                if (fact.get('status') == 'LIVE' or buy is not None) and (
                                        not buy or fact.get('status') != 'LIVE'
                                        or str(buy['token_id']) != str(session['token_id'])
                                        or str(fact.get('token_id')) != str(buy['token_id'])
                                        or _maybe_decimal(fact.get('price')) != _maybe_decimal(buy['price'])
                                        or _maybe_decimal(fact.get('original_size', fact.get('quantity'))) != _maybe_decimal(buy['original_quantity'])
                                        or matched != _maybe_decimal(buy['filled_quantity'])
                                        or _maybe_decimal(fact.get('remaining_size')) != _maybe_decimal(buy['quantity'])):
                                    raise LpObservationWait('account_round_invalid')
                                if matched is None or matched < Decimal('0'):
                                    raise LpObservationWait('account_round_invalid')
                                if matched > Decimal('0'):
                                    fill = owned_fill_rows.get(oid, {})
                                    position = positions.get(str(session['token_id']), {})
                                    quantity = _maybe_decimal(fact.get('original_size', fact.get('quantity')))
                                    remaining = _maybe_decimal(fact.get('remaining_size'))
                                    average = _maybe_decimal(fact.get('average_price'))
                                    if (fill.get('side') != 'BUY'
                                            or str(fill.get('token_id')) != str(session['token_id'])
                                            or str(fill.get('condition_id')) != str(session.get('condition_id'))
                                            or _maybe_decimal(fills.get(oid)) != matched
                                            or _maybe_decimal(fill.get('size_matched')) != matched
                                            or average is None or average <= Decimal('0')
                                            or _maybe_decimal(fill.get('average_price')) != average
                                            or quantity is None or quantity < matched
                                            or remaining is None or remaining != quantity - matched
                                            or str(fact.get('token_id')) != str(session['token_id'])
                                            or (_maybe_decimal(fact.get('price')) or Decimal('0')) <= Decimal('0')
                                            or _maybe_decimal(position.get('quantity')) != _maybe_decimal(session.get('residual_quantity'))
                                            or _maybe_decimal(position.get('inventory_cost_usd')) is None
                                            or _maybe_decimal(position['inventory_cost_usd']) != _maybe_decimal(session.get('buy_cost'))):
                                        raise LpObservationWait('account_round_invalid')
                    _freshness(read_ended, self._now(), "account_freshness")
                    pool_row = connection.execute('SELECT payload FROM lp_auto_pool WHERE singleton=1').fetchone()
                    published = (json.loads(pool_row['payload']).get('account_financial_facts') or {}) if pool_row else {}
                    capture_only = _automatic_observation and any(
                        published.get(key) and _timestamp(published[key], name=key) > _timestamp(financial_facts[key], name=key)
                        for key in ('read_started_at', 'read_ended_at', 'checked_at'))
                    session_cache = {}
                    for token, token_rows, candidate in prepared:
                        result = self.store.lp_register_exchange_orders(
                            account_id, token, token_rows, session=candidate,
                            expected_generation=generation, connection=connection, diagnostics=diagnostics,
                            _session_cache=session_cache,
                        )
                        state = "created" if result["created"] else "joined"
                        created += int(result["created"])
                        joined += int(not result["created"])
                        token_results.append({"token_id": token, "state": state,
                                              "session_id": result["session"]["session_id"]})
                        registered_sessions[token] = result['session']
                    # The empty-account case uses the same fenced transaction:
                    # it is evidence of zero occupancy, not an early return.
                    if _planning_only or capture_only:
                        # Register proven current IDs, without account-wide
                        # coverage, historical conclusions or full publication.
                        for buy in financial_facts['buys']:
                            session = registered_sessions[buy['token_id']]
                            buy['session_id'] = session['session_id']
                            for key in ('condition_id', 'market_id', 'outcome'):
                                if not buy.get(key):
                                    buy[key] = session.get(key)
                    else:
                        self.store.lp_publish_account_financial_facts(
                            financial_facts, connection=connection,
                            expected_generation=generation, diagnostics=diagnostics,
                        )
                    # Carry this transaction's exact source through the public
                    # registration return. A later publisher is not its owner.
                    row = connection.execute('SELECT payload FROM lp_auto_pool WHERE singleton=1').fetchone()
                    planning_document = json.loads(row['payload']) if row else {}
                    if _planning_only or capture_only:
                        sessions = [self.store._lp_row_result(row) for row in
                            connection.execute('SELECT * FROM lp_sessions ORDER BY session_id').fetchall()]
                        holds = project_planning_buy_holds(sessions,
                            {s['session_id']: self.store.lp_actions(s['session_id'], connection=connection)
                             for s in sessions}, planning_document.get('intents') or {}, financial_facts['buys'],
                            account_id=financial_facts['account_id'], checked_at=financial_facts['checked_at'],
                            read_started_at=_timestamp(financial_facts['read_started_at'], name='read_started_at'))
                        financial_facts.update({key: holds[key] for key in
                            ('pending_buy_actions', 'independent_sell_unknown')})
                        if holds['account_send_inflight']:
                            financial_facts['financial_status'] = 'unknown'
                            financial_facts['reason_codes'] = sorted(set(financial_facts.get('reason_codes') or ())
                                | {'account_send_inflight'})
                        planning_document['_planning_buy_isolation'] = holds['isolation']
                        planning_document['account_financial_facts'] = deepcopy(financial_facts)
                    planning_capture = dict(document=planning_document, validated_at=self._now(),
                        validated_generation=generation)
            return {"state": "registered", "tokens": token_results,
                    "created": created, "joined": joined,
                    '_planning_capture': planning_capture,
                    **({'planning_facts': financial_facts} if _planning_only else {})}
        except ValueError as exc:
            if isinstance(exc, LpObservationWait):
                return {"state": "skipped", "reason": "account_round_invalid",
                        "wait_reason": str(exc), "tokens": [], "created": 0, "joined": 0}
            return {"state": "failed", "reason": str(exc),
                    "tokens": [], "created": 0, "joined": 0}

    def _register_planning_account_snapshot(self, snapshot):
        """Current-only registration cannot clear or replace full-publication diagnostics."""
        _lp_causal_event('account_publish_wait', account=snapshot)
        outcome = 'failed'
        try:
            result = self._register_account_snapshot(snapshot,
                _planning_only=snapshot.get('trades_complete') is not True,
                _automatic_observation=True)
            outcome = result.get('state', 'failed')
            return result
        except LpAccountRoundInvalid:
            outcome = 'skipped'
            raise
        finally:
            _lp_causal_event('account_publish_end', account=snapshot, outcome=outcome)

    def register_account_snapshot(
        self, snapshot: Mapping[str, object]
    ) -> dict[str, object]:
        """Publish the latest completed account-registration outcome."""

        _lp_causal_event("account_publish_wait", account=snapshot)
        with self._first_seen_apply_lock:
            self._account_registration_attempt += 1
            attempt = self._account_registration_attempt

        try:
            with _lp_read_task("account_registration"), _lp_read_stage("account_registration"):
                result = self._register_account_snapshot(snapshot)
        except LpAccountRoundInvalid:
            _lp_causal_event("account_publish_end", account=snapshot, outcome="skipped")
            raise
        except Exception:
            _lp_causal_event("account_publish_end", account=snapshot, outcome="failed")
            with self._first_seen_apply_lock:
                if self._account_registration_attempt == attempt:
                    self._account_order_sync_error = "account_order_sync_unknown"
            raise
        with self._first_seen_apply_lock:
            if (result.get("state") == "registered"
                    and snapshot.get("trade_generation") != self.store.lp_trade_generation()):
                result = {"state": "skipped", "reason": "account_round_invalid"}
            invalid = result.get("reason") == "account_round_invalid" or any(
                item.get("reason") == "account_round_invalid"
                for item in result.get("tokens", ()) if isinstance(item, Mapping)
            )
            if self._account_registration_attempt == attempt:
                if invalid:
                    # A generation race is #209 waiting evidence, not a new
                    # mutation-blocking registration fault.
                    pass
                elif result.get("state") == "registered":
                    self._account_order_sync_error = None
                else:
                    self._account_order_sync_error = "account_order_sync_unknown"
        _lp_causal_event("account_publish_end", account=snapshot, outcome=result.get("state"))
        return result

    def _create_sync_session(
        self,
        snapshot: Mapping[str, object],
        token_id: str,
        rows: list[Mapping[str, object]],
        protection: Mapping[str, object] | None,
    ) -> Mapping[str, object] | None:
        condition_id = str(_field(rows[0], "condition_id", "") or "")
        market_id = str(_field(rows[0], "market_id", "") or "")
        outcome = str(_field(rows[0], "outcome", "") or "").upper()
        if condition_id:
            metadata_reader = getattr(self.exchange, "lp_market_metadata", None)
            metadata = metadata_reader((condition_id,)) if callable(metadata_reader) else {}
            market = metadata.get(condition_id) if isinstance(metadata, Mapping) else None
            if isinstance(market, Mapping):
                market_id = market_id or str(market.get("market_id") or "")
                outcomes = market.get("outcomes")
                if isinstance(outcomes, Mapping):
                    metadata_outcome: str | None = None
                    for direction in ("YES", "NO"):
                        leg = outcomes.get(direction.lower())
                        if (
                            isinstance(leg, Mapping)
                            and str(leg.get("token_id") or "") == token_id
                        ):
                            metadata_outcome = direction
                            break
                    if outcome and metadata_outcome and outcome != metadata_outcome:
                        raise ValueError("order_identity_conflict")
                    outcome = metadata_outcome or outcome
        if not condition_id or not market_id or outcome not in {"YES", "NO"}:
            raise ValueError("order_identity_unknown")
        buys = [row for row in rows if str(_field(row, "side", "") or "").upper() == "BUY"]
        sells = [row for row in rows if str(_field(row, "side", "") or "").upper() == "SELL"]
        entry = buys[0] if buys else None
        passive = sells[0] if sells else None
        price = _maybe_decimal(_field((entry or passive or rows[0]), "price"))
        if price is None:
            raise ValueError("price_unknown")
        payload_marker: dict[str, object] = {}
        resting_buys = [
            row
            for row in buys
            if str(_field(row, "status", "") or "").upper()
            in {"LIVE", "OPEN", "ACCEPTED", "PENDING"}
            and (_maybe_decimal(_field(row, "remaining_size", _field(row, "size"))) or Decimal("0")) > 0
        ]
        if protection is None:
            levels: dict[str, object] = {}
            for row in resting_buys:
                row_price = _maybe_decimal(_field(row, "price"))
                key = format(row_price, "f") if row_price is not None else "unknown"
                if key in levels:
                    continue
                baseline = row.get("queue_baseline")
                remaining = _maybe_decimal(
                    _field(row, "remaining_size", _field(row, "size"))
                )
                if isinstance(baseline, Mapping) and baseline.get("state") == "known":
                    bucket = {
                        **baseline,
                        "baseline_source": "first_observation",
                        "baseline_version": 1,
                        "threshold": LP_QUEUE_PROTECTION_THRESHOLD,
                        "state": "registered",
                        "notification_sent": False,
                        "cancel_scope": "own_buys_at_level",
                    }
                else:
                    bucket = {
                        "state": "unknown",
                        "baseline_price": row_price,
                        "baseline_source": "account_sync",
                        "own_remaining": remaining,
                        "reason_codes": ["baseline_unknown"],
                        "notification_sent": False,
                        "cancel_scope": "own_buys_at_level",
                    }
                levels[key] = {
                    **bucket,
                    "order_id": _field(row, "order_id", ""),
                }
            # Fill evidence alone does not prove a resting order; do not
            # invent a queue position for it.
            queue_protection = {
                "version": 2,
                "data_failures": 0,
                "levels": levels,
            }
        else:
            queue_protection = dict(protection or {})
            if protection and protection.get("episode_id"):
                payload_marker["_first_seen_episode_id"] = protection["episode_id"]
        history: dict[str, dict[str, object]] = {}
        owned: list[str] = []
        buy_filled = Decimal("0")
        sold_quantity = Decimal("0")
        for row in rows:
            order_id = str(_field(row, "order_id", "") or "")
            if not order_id:
                raise ValueError("order_identity_unknown")
            record = self._sync_order_history_row(row)
            queue_baseline = row.get("queue_baseline")
            if isinstance(queue_baseline, Mapping):
                record["queue_baseline"] = dict(queue_baseline)
            history[order_id] = record
            owned.append(order_id)
            matched = _maybe_decimal(record.get("size_matched")) or Decimal("0")
            side = str(record.get("side") or "").upper()
            if side == "BUY":
                buy_filled += matched
            elif side == "SELL":
                sold_quantity += matched
        positions = [
            row for row in _items(snapshot.get("positions"))
            if isinstance(row, Mapping)
            and str(_field(row, "token_id", _field(row, "asset_id", "")) or "") == token_id
        ]
        residual = _maybe_decimal(_field(positions[0], "size")) if positions else Decimal("0")
        if residual is None:
            raise ValueError("position_quantity_unknown")
        session_id = uuid.uuid4().hex
        augment = [order_id for order_id in owned[1:] if order_id != str(entry and _field(entry, "order_id", ""))]
        payload: dict[str, object] = {
            "account_id": str(snapshot.get("account_id") or ""),
            "source": "account_sync",
            "sync_read_started_at": snapshot.get("read_started_at"),
            "sync_read_ended_at": snapshot.get("read_ended_at"),
            "market_id": market_id,
            "condition_id": condition_id,
            "token_id": token_id,
            "outcome": outcome,
            "question": str(_field(rows[0], "market_title", "") or ""),
            "market_url": str(_field(rows[0], "market_url", "") or ""),
            "price": price,
            "quantity": sum((_maybe_decimal(_field(row, "original_size", _field(row, "size"))) or Decimal("0") for row in rows), Decimal("0")),
            "review_at": None,
            "preflight": {},
            "entry_order_id": str(_field(entry, "order_id", "")) if entry else None,
            "entry_expiration": _field(entry, "expiration") if entry else None,
            "entry_cancel_requested": False,
            "buy_filled_quantity": buy_filled,
            "buy_cost": None,
            "sold_quantity": sold_quantity,
            "sold_revenue": None,
            "residual_quantity": residual,
            "residual_exit_value": Decimal("0") if residual == 0 else None,
            "fees": None,
            "fee_status": "unknown",
            "opening_loss": None,
            "position_reconciled": False,
            "account_checked_at": snapshot.get("checked_at"),
            "book_checked_at": None,
            "stop_loss_latched": False,
            "stop_loss_triggered_at": None,
            "stop_loss_triggered_loss": None,
            "scoring_status": "unknown",
            "scoring_checked_at": None,
            "scoring_order_id": None,
            "scoring_order_role": None,
            "scoring_lost_at": None,
            "passive_exit_order_id": str(_field(passive, "order_id", "")) if passive else None,
            "passive_exit_price": _maybe_decimal(_field(passive, "price")) if passive else None,
            "passive_cancel_requested": False,
            "passive_exit_attempt_key": None,
            "passive_exit_attempt_state": None,
            "passive_exit_retryable": False,
            "protected_exit_order_id": None,
            "protected_exit_attempt_key": None,
            "protected_exit_attempt_state": None,
            "protected_exit_retryable": False,
            "protected_exit_submit_quantity": None,
            "protected_exit_submit_sold_quantity": None,
            "protected_exit_submit_residual_quantity": None,
            "owned_order_ids": owned,
            "augment_order_ids": [order_id for order_id in augment if order_id],
            "order_history": history,
            "orders_terminal": all(str(record.get("status") or "").upper() in TERMINAL_ORDER_STATES for record in history.values()),
            "reward_date": self._now().date().isoformat(),
            "reward_status": "unknown",
            "trade_pnl": None,
            "total_pnl": None,
            "queue_protection": queue_protection,
        }
        payload["session_id"] = session_id
        payload["idempotency_key"] = f"lp-sync:{session_id}"
        payload["state"] = "entry_open"
        payload.update(payload_marker)
        return payload

    def register_first_seen_candidates(
        self, rows: object, *, now: datetime
    ) -> dict[str, object]:
        """Register first-seen baseline episodes for web-manual BUYs (issue 159).

        ``rows`` are one token's newly diff-detected own BUY rows (order id,
        price, remaining, venue created_at, first-seen stamp).  The anchor is
        the earliest first-seen BUY (ties by venue created_at, then order
        id); the anchor price's book level minus the own remaining at that
        price becomes the fallback baseline.  A book that cannot be read or
        a baseline that cannot be resolved fails the registration so the
        caller keeps the candidates pending — there is deliberately no time
        limit on that retry.
        """

        candidates = [row for row in _items(rows) if isinstance(row, Mapping)]
        if not candidates:
            return {"state": "skipped", "reason": "no_candidates"}
        token_id = str(candidates[0].get("token_id") or "").strip()
        condition_id = str(candidates[0].get("condition_id") or "").strip()
        if not token_id or not condition_id:
            return {"state": "skipped", "reason": "identity_unknown"}
        if any(
            str(row.get("token_id") or "").strip() != token_id for row in candidates
        ):
            return {"state": "skipped", "reason": "mixed_tokens"}
        with self._mutex:
            for episode in self.store.lp_active_first_seen_episodes():
                if str(episode.get("token_id") or "") == token_id:
                    return {"state": "skipped", "reason": "episode_exists"}
            ordered = sorted(
                candidates,
                key=lambda row: (
                    _first_seen_stamp_key(row.get("first_seen_at")),
                    _first_seen_stamp_key(row.get("created_at")),
                    str(row.get("order_id") or ""),
                ),
            )
            anchor = ordered[0]
            anchor_price = _maybe_decimal(anchor.get("price"))
            if anchor_price is None:
                return {
                    "state": "registration_failed",
                    "reason_codes": ["price_unknown"],
                    "token_id": token_id,
                }
            level_rows = [
                row
                for row in ordered
                if _maybe_decimal(row.get("price")) == anchor_price
            ]
            own_remaining = Decimal("0")
            for row in level_rows:
                remaining = _maybe_decimal(row.get("remaining"))
                if remaining is None:
                    own_remaining = None
                    break
                own_remaining += remaining
            book = self._read_first_seen_book(token_id)
            baseline = first_observation_baseline(
                book,
                price=anchor_price,
                own_remaining=own_remaining,
            )
            if baseline["state"] != "known":
                return {
                    "state": "registration_failed",
                    "reason_codes": list(baseline["reason_codes"]),
                    "token_id": token_id,
                }
            anchor_order_ids = [
                str(row.get("order_id") or "") for row in level_rows
            ]
            anchor_order_ids = [order_id for order_id in anchor_order_ids if order_id]
            first_seen_at = _first_seen_stamp_value(
                anchor.get("first_seen_at"), default=now
            )
            order_placement_times: dict[str, object] = {}
            placement_datetimes: list[datetime] = []
            for row in level_rows:
                order_id = str(row.get("order_id") or "")
                if not order_id:
                    continue
                try:
                    placement = _timestamp(
                        row.get("created_at"), name="venue_created_at"
                    )
                except ValueError:
                    order_placement_times[order_id] = None
                else:
                    order_placement_times[order_id] = _iso(placement)
                    placement_datetimes.append(placement)

            def first_text(key: str) -> str | None:
                for row in ordered:
                    value = _text(row.get(key))
                    if value is not None:
                        return value
                return None

            market_id = first_text("market_id")
            market_title = first_text("market_title")
            market_url = first_text("market_url")
            outcome = first_text("outcome")
            received_at = _timestamp(
                baseline["baseline_book_received_at"], name="book_received_at"
            )
            registration_delay = (received_at - first_seen_at).total_seconds()
            episode_id = uuid.uuid4().hex
            payload: dict[str, object] = {
                "token_id": token_id,
                "condition_id": condition_id,
                "anchor_order_ids": anchor_order_ids,
                "anchor_price": str(anchor_price),
                "baseline_front": baseline["baseline_front"],
                "baseline_price": baseline["baseline_price"],
                "baseline_book_received_at": baseline["baseline_book_received_at"],
                "baseline_book_hash": baseline["baseline_book_hash"],
                "baseline_source": "first_observation",
                "baseline_version": 1,
                "threshold": LP_QUEUE_PROTECTION_THRESHOLD,
                "first_seen_at": _iso(first_seen_at),
                "venue_created_at": (
                    _iso(min(placement_datetimes)) if placement_datetimes else None
                ),
                "order_placement_times": order_placement_times,
                "market_id": market_id,
                "market_title": market_title,
                "market_url": market_url,
                "outcome": outcome,
                "registration_delay": registration_delay,
                "data_failures": 0,
                "state": "monitoring",
                "notification_sent": False,
                "blocked_notified": False,
                "cancel_scope": "own_buys_at_level",
                "cancel_targets": [],
                "canceled_order_ids": [],
                "cancel_target_remaining": {},
                "canceled_remaining": None,
                "partially_filled_quantity": None,
                "cancel_requested_at": None,
                "cancel_reason": None,
                "reason_codes": [],
            }
            episode = self.store.lp_create_first_seen_episode(
                episode_id,
                token_id=token_id,
                condition_id=condition_id,
                state="monitoring",
                payload=payload,
            )
            recorder = getattr(self.store, "lp_record_book_samples", None)
            if callable(recorder):
                sample = self._first_seen_book_sample(
                    condition_id=condition_id, token_id=token_id, book=book
                )
                if sample is not None:
                    try:
                        recorder([sample], now=now)
                    except Exception:
                        pass
            return {
                "state": "registered",
                "episode_id": episode_id,
                "episode": episode,
                "token_id": token_id,
                "anchor_price": str(anchor_price),
                "baseline_front": baseline["baseline_front"],
            }

    def _read_first_seen_book(self, token_id: str) -> Mapping[str, object] | None:
        """Read one token's book through the bounded SDK batch adapter."""

        books_reader = getattr(self.exchange, "lp_order_books", None)
        if not callable(books_reader):
            return None
        try:
            try:
                raw_books = books_reader((token_id,), stop_event=None)
            except TypeError:
                raw_books = books_reader((token_id,))
        except Exception:
            return None
        if not isinstance(raw_books, Mapping):
            return None
        book = raw_books.get(token_id)
        return book if isinstance(book, Mapping) else None

    def start(
        self,
        preview_id: str,
        idempotency_key: str | None = None,
        *,
        idempotency_identity: str | None = None,
    ) -> dict[str, object]:
        """Revalidate a preview, persist intent, then submit exactly one BUY."""

        key = (idempotency_key or idempotency_identity or "").strip()
        if not key:
            return {"state": "rejected", "reason": "idempotency_key_required"}
        with self._mutex:
            existing = self.store.lp_session_by_idempotency(key)
            if existing is not None:
                return self._status_payload(existing)
            # The preview is read-only, but consuming it and creating the
            # durable submit intent must still happen under the same guard as
            # the eventual exchange write.  Otherwise a breaker opened after
            # preview could leave a phantom session or race another writer.
            if not self._mutation_allowed("submit"):
                return {"state": "locked", "reason": "mutation_blocked"}
            preview = self.store.lp_preview(preview_id)
            if preview is None:
                return {"state": "rejected", "reason": "preview_not_found"}
            try:
                expires_at = _timestamp(preview["expires_at"], name="preview_expiry")
                if self._now() >= expires_at:
                    raise ValueError("preview_expired")
                request = self._normalize_request(preview)
                read_started = self._now()
                snapshot = (
                    self._read_candidate_snapshot(request, now=read_started)
                    if request.get("candidate_policy") == "best_bid_minimum"
                    else self._read_snapshot(request)
                )
                # Issue 176: the validation clock is taken unconditionally
                # after the snapshot read completes (received_at stamps at
                # read time — a pre-read clock goes deterministically stale).
                now = self._now()
                if request.get("candidate_policy") == "best_bid_minimum":
                    eligible = self._fresh_candidate_row(request, snapshot, now=now)
                    if (
                        _decimal(eligible.get("price"), "candidate_price")
                        != request["price"]
                        or _decimal(eligible.get("quantity"), "candidate_quantity")
                        != request["quantity"]
                    ):
                        raise ValueError("candidate_changed")
                facts = self._validate_snapshot(
                    request, snapshot, now=now,
                    reservations=self._candidate_reservations(),
                )
                # Issue 166/R1: the submit path must honor the same
                # participation gate as the preview path — any account order
                # or position on this condition (either direction) rejects
                # here, so a same-condition opposite-direction group can only
                # ever be opened by #168 lifting this gate.  Idempotent
                # replays returned above and never reach this check, and the
                # augment paths tolerate their own group's orders because the
                # check is deliberately NOT inside _validate_snapshot.
                if _has_market_order(
                    cast(Mapping[str, object], snapshot.get("account")),
                    cast(Mapping[str, object], snapshot.get("market")),
                ):
                    raise ValueError("market_already_participating")
                self._require_lp_history(request, now=now)
                # Issue 158: submit-time re-check — the fresh best bid must
                # still equal the one recorded in the preview credential.
                # Idempotent replays returned above before this point, so a
                # retry can never fail here after its session already exists.
                credential_preflight = preview.get("preflight")
                credential_best_bid = (
                    _maybe_decimal(credential_preflight.get("best_bid"))
                    if isinstance(credential_preflight, Mapping)
                    else None
                )
                if (
                    credential_best_bid is not None
                    and credential_best_bid != facts["best_bid"]
                ):
                    raise ValueError("best_bid_changed")
                expiration = expiration_for_review(
                    _timestamp(request["review_at"], name="review_at"), now=now
                )
            except ValueError as exc:
                if str(exc).startswith("history_"):
                    try:
                        self.store.consume_lp_preview(preview_id)
                    except ValueError:
                        pass
                return {"state": "rejected", "reason": str(exc)}
            try:
                self.store.consume_lp_preview(preview_id)
            except ValueError as exc:
                return {"state": "rejected", "reason": str(exc)}
            return self._entry_execute(
                request=request,
                snapshot=snapshot,
                facts=facts,
                now=now,
                key=key,
                expiration=expiration,
            )

    def entry_send_inflight(self, session_id: str) -> bool:
        with self._entry_sends_lock:
            return session_id in self._entry_sends

    def drain_submissions(self, *, timeout: float = 5) -> None:
        """Shutdown closes the mutation guard before draining local senders."""
        # Manual entry/augment retain this mutex through receipt application.
        # Automatic entry can release it, so also check its existing live lanes.
        if not self._mutex.acquire(timeout=timeout):
            raise RuntimeError('prediction LP BUY sender did not stop')
        try:
            with self._entry_sends_lock:
                if self._entry_sends:
                    raise RuntimeError('prediction LP BUY sender did not stop')
                if self._cancel_sends:
                    raise RuntimeError('prediction LP cancel sender did not stop')
        finally:
            self._mutex.release()

    def _entry_execute(self, **kwargs) -> dict[str, object]:
        # A durable legacy "sending" field is not proof of a live process.
        # Track the real lane through receipt application and clean up on error.
        session_id = kwargs.get('session_id') or uuid.uuid4().hex
        kwargs['session_id'] = session_id
        with self._entry_sends_lock:
            self._entry_sends.add(session_id)
        try:
            return self._entry_execute_in_lane(**kwargs)
        finally:
            with self._entry_sends_lock:
                self._entry_sends.discard(session_id)

    def _entry_execute_in_lane(
        self,
        *,
        request: dict[str, object],
        snapshot: Mapping[str, object],
        facts: Mapping[str, object],
        now: datetime,
        key: str,
        expiration: int,
        session_id: str | None = None,
        post: Callable[[object, Callable[[], None]], object] | None = None,
        release_preparation_lock: Callable[[], None] | None = None,
        apply_lock: tuple[Callable[[], object | None], Callable[[object], None]] | None = None,
        plan_authorization=None,
    ) -> dict[str, object]:
        """Register the session and submit exactly one post-only BUY.

        Shared tail of the two-phase ``start`` (issue 158) and the
        single-shot ``submit_entry`` (issue 163): the caller has already
        validated fresh facts and bound the GTD expiration; this helper
        owns the #152 baseline registration, the durable session row, the
        exchange post, and every terminal state write.
        """

        configured_account = str(
            getattr(getattr(self.exchange, "config", None), "wallet_address", "") or ""
        ).strip().casefold()
        account = _field(_field(snapshot, "account"), "wallet_address")
        account_id = str(account or snapshot.get("wallet_address") or configured_account or "").strip().casefold()
        if not account_id:
            return {"state": "rejected", "reason": "account_identity_unknown"}
        # Issue 152: registration boundary.  Validation just proved the
        # session owns no order on the token, so the whole price level in
        # this validated snapshot is queue ahead of the entry order.
        queue_baseline = self._queue_protection_baseline(request, snapshot)
        recorder = getattr(self.store, "lp_record_book_samples", None)
        if callable(recorder):
            baseline_sample = self._queue_baseline_book_sample(request, snapshot)
            if baseline_sample is not None:
                try:
                    recorder([baseline_sample], now=now)
                except Exception:
                    pass
        queue_baseline_summary = {
            "baseline_front": queue_baseline["baseline_front"],
            "baseline_price": queue_baseline["baseline_price"],
        }
        entry_action_base = {
            "submit_requested_at": _iso(now),
            "submit_stage": "preparing",
            "post_started": False,
            "submit_post_started_at": None,
            "submit_finished_at": None,
            "submit_timeout": False,
            "queue_protection_baseline": queue_baseline_summary,
        }
        reward_date = self._now().date().isoformat()
        session_id = session_id or uuid.uuid4().hex
        intent: dict[str, object] = {
            **request,
            **(entry_action_base if plan_authorization is not None else {}),
            "account_id": account_id,
            "preflight": facts,
            "entry_order_id": None,
            "entry_expiration": expiration,
            "entry_cancel_requested": False,
            "buy_filled_quantity": Decimal("0"),
            "buy_cost": Decimal("0"),
            "sold_quantity": Decimal("0"),
            "sold_revenue": Decimal("0"),
            "residual_quantity": Decimal("0"),
            "residual_exit_value": Decimal("0"),
            "fees": Decimal("0"),
            "fee_status": "unknown",
            "opening_loss": None,
            "position_reconciled": False,
            "account_checked_at": None,
            "book_checked_at": None,
            "stop_loss_latched": False,
            "stop_loss_triggered_at": None,
            "stop_loss_triggered_loss": None,
            "scoring_status": "unknown",
            "scoring_checked_at": None,
            "scoring_order_id": None,
            "scoring_order_role": None,
            "scoring_lost_at": None,
            "passive_exit_order_id": None,
            "passive_exit_price": None,
            "passive_cancel_requested": False,
            "passive_exit_attempt_key": None,
            "passive_exit_attempt_state": None,
            "passive_exit_retryable": False,
            "protected_exit_order_id": None,
            "protected_exit_attempt_key": None,
            "protected_exit_attempt_state": None,
            "protected_exit_retryable": False,
            "protected_exit_submit_quantity": None,
            "protected_exit_submit_sold_quantity": None,
            "protected_exit_submit_residual_quantity": None,
            "owned_order_ids": [],
            "order_history": {},
            "orders_terminal": False,
            "reward_date": reward_date,
            "reward_status": "unknown",
            "trade_pnl": None,
            "total_pnl": None,
            "queue_protection": {
                **queue_baseline,
                "baseline_version": 1,
                "threshold": LP_QUEUE_PROTECTION_THRESHOLD,
                "data_failures": 0,
                "state": "registered",
                "notification_sent": False,
                "cancel_scope": "own_buys_at_level",
            },
        }
        try:
            session = self.store.lp_create_session(
                session_id,
                key,
                state="entry_submit_pending",
                payload=intent,
            )
        except ValueError as exc:
            return {"state": "rejected", "reason": str(exc)}
        entry_action_key = self._action_key(session_id, "entry-submit")
        try:
            self.store.lp_upsert_action(
                session_id,
                entry_action_key,
                state="pending",
                payload={
                    "role": "entry",
                    "side": "BUY",
                    "token_id": request["token_id"],
                    "expiration": expiration,
                    **entry_action_base,
                },
            )
        except sqlite3.Error as exc:
            if plan_authorization is None:
                raise
            # This boundary precedes signing and POST. The automatic caller
            # rechecks durable identity and the exited sender before cleanup.
            not_sent = AutoEntryNotSent('entry_audit_registration_failed')
            not_sent.error_type = type(exc).__name__
            not_sent.error_code = getattr(exc, 'sqlite_errorname', None)
            raise not_sent from exc
        if release_preparation_lock is not None:
            release_preparation_lock()
        post_started = False
        post_started_at = None
        send_receipt_base = dict(entry_action_base)
        if plan_authorization is not None:
            send_receipt_base.update({key: request[key] for key in
                ('market_id', 'condition_id', 'token_id', 'outcome', 'price', 'quantity')})
            send_receipt_base['expiration'] = expiration

        def mark_post_started() -> None:
            nonlocal post_started, post_started_at, send_receipt_base
            boundary_at = _iso(self._now())
            # Persist before the adapter call. A failed boundary write therefore
            # remains a provable pre-POST failure instead of a fabricated send.
            self.store.lp_update_session(session_id, patch={
                "submit_stage": "sending", "post_started": True,
                "submit_post_started_at": boundary_at,
            })
            post_started = True
            post_started_at = boundary_at
            send_receipt_base = {
                **send_receipt_base,
                "submit_stage": "sending",
                "post_started": True,
                "submit_post_started_at": boundary_at,
            }

        def execute_post(signed: object, *, side: str | None = None) -> object:
            if post is None:
                return self._post_limit(
                    signed, side=side, on_post_started=mark_post_started
                )
            return post(signed, mark_post_started)

        try:
            signed = self._create_limit(
                token_id=str(request["token_id"]),
                price=cast(Decimal, request["price"]),
                quantity=cast(Decimal, request["quantity"]),
                side="BUY",
                post_only=True,
                expiration=expiration,
                plan_authorization=plan_authorization,
            )
            submit_revision = self.store.lp_session_revision(session_id, trading=True)
            response = execute_post(signed, side="BUY")
        except AutoEntryNotSent as exc:
            stage = str(getattr(exc, "submit_stage", "pre_send_rejected"))
            failure = _submit_failure_facts(exc)
            finished_at = _iso(self._now())
            self.store.lp_upsert_action(session_id, entry_action_key, state="rejected",
                payload={
                    "role": "entry", "side": "BUY", "reason": str(exc),
                    **send_receipt_base, "submit_stage": stage,
                    "submit_finished_at": finished_at, **failure,
                })
            session = self.store.lp_update_session(session_id, state="entry_rejected",
                patch={
                    "submit_status": "rejected", "reason": str(exc),
                    **send_receipt_base, "submit_stage": stage,
                    "submit_finished_at": finished_at,
                    **failure,
                })
            return self._status_payload(session)
        except Exception as exc:
            if not post_started:
                failure = _submit_failure_facts(exc)
                self.store.lp_upsert_action(session_id, entry_action_key, state="rejected",
                    payload={
                        "role": "entry", "side": "BUY", "reason": "prepare_failed",
                        "error": type(exc).__name__, **send_receipt_base,
                        "submit_stage": "prepare_failed",
                        "submit_finished_at": _iso(self._now()), **failure,
                    })
                session = self.store.lp_update_session(session_id, state="entry_rejected",
                    patch={
                        "submit_status": "rejected", "reason": "prepare_failed",
                        **send_receipt_base, "submit_stage": "prepare_failed",
                        "submit_finished_at": _iso(self._now()), **failure,
                    })
                return self._status_payload(session)
            failure = _submit_failure_facts(exc)
            self.store.lp_upsert_action(
                session_id,
                entry_action_key,
                state="unknown",
                payload={
                    "role": "entry",
                    "side": "BUY",
                    "token_id": request["token_id"],
                    "expiration": expiration,
                    "error": type(exc).__name__,
                    **send_receipt_base, "submit_stage": "send_unknown",
                    "submit_finished_at": _iso(self._now()),
                    **failure,
                },
            )
            session = self.store.lp_update_session(
                session_id,
                state="needs_attention",
                patch={
                    "submit_status": "unknown",
                    "resume_state": "entry_submit_pending",
                    **send_receipt_base, "submit_stage": "send_unknown",
                    "submit_finished_at": _iso(self._now()),
                    **failure,
                },
            )
            return self._status_payload(session)
        accepted, order_id = self._order_response(response)
        response_at = _iso(self._now())
        opaque_plan_response = (plan_authorization is not None
            and _field(response, 'ok', None) is False
            and _field(response, 'code', None) == 'unknown'
            and _field(response, 'accepted', None) is None
            and not order_id)
        if not accepted and (opaque_plan_response or not (
            _field(response, "accepted", None) is False
            or _field(response, "ok", None) is False
            or str(_field(response, "status", "")).upper() in {"REJECTED", "FAILED"}
        )):
            self.store.lp_upsert_action(session_id, entry_action_key, state="unknown",
                payload={"role": "entry", "side": "BUY", "token_id": request["token_id"],
                         "expiration": expiration, **send_receipt_base,
                         "submit_stage": "send_unknown",
                         "submit_finished_at": response_at})
            session = self.store.lp_update_session(session_id, state="needs_attention",
                patch={"submit_status": "unknown", "resume_state": "entry_submit_pending",
                       **send_receipt_base, "submit_stage": "send_unknown",
                       "submit_finished_at": response_at})
            return self._status_payload(session)
        if not accepted:
            rejected_at = response_at
            rejection = {}
            if plan_authorization is not None:
                reason = _field(response, 'code', _field(response, 'reason',
                    _field(response, 'error_code', _field(response, 'errorMsg', None))))
                rejection['reason'] = str(reason)[:256] if reason else 'exchange_rejected'
                message = _field(response, 'message', None)
                if isinstance(message, str):
                    rejection['exchange_rejection_message'] = message[:256]
            self.store.lp_upsert_action(
                session_id,
                entry_action_key,
                state="rejected",
                payload={
                    **rejection,
                    "role": "entry",
                    "side": "BUY",
                    "token_id": request["token_id"],
                    "expiration": expiration,
                    "order_id": order_id or "",
                    **send_receipt_base,
                    "submit_stage": "exchange_rejected",
                    "submit_finished_at": rejected_at,
                    "submit_receipt_at": rejected_at,
                },
            )
            session = self.store.lp_update_session(
                session_id,
                state="entry_rejected",
                patch={**rejection, "entry_order_id": order_id, "submit_status": "rejected",
                       **send_receipt_base, "submit_stage": "exchange_rejected",
                       "submit_finished_at": rejected_at,
                       "submit_receipt_at": rejected_at},
            )
            return self._status_payload(session)
        self.store.lp_upsert_action(
            session_id,
            entry_action_key,
            state="accepted",
            payload={
                "role": "entry",
                "side": "BUY",
                "token_id": request["token_id"],
                "expiration": expiration,
                "order_id": order_id,
                **send_receipt_base,
                "submit_stage": "receipt_received",
                "submit_finished_at": response_at,
                "submit_receipt_at": response_at,
            },
        )
        if not order_id:
            session = self.store.lp_update_session(
                session_id,
                state="needs_attention",
                patch={
                    "submit_status": "accepted_without_order_id",
                    "resume_state": "entry_submit_pending",
                    **send_receipt_base,
                    "submit_stage": "receipt_received",
                    "submit_finished_at": response_at,
                    "submit_receipt_at": response_at,
                },
            )
            return self._status_payload(session)
        receipt_lock = apply_lock[0]() if apply_lock is not None else None
        if apply_lock is not None and receipt_lock is None:
            # The accepted action above durably holds the exact venue ID.
            # Reconciliation will apply it after the existing writer finishes.
            return {**self._status_payload(session), "reason": "receipt_apply_pending"}
        try:
            with self._mutex:
                session = self.store.lp_session(session_id) or session
                registration_before = self.store.lp_session_revision(
                    session_id, trading=True
                )
                preflight_reconciled = session.get("position_reconciled")
                registered_session, receipt_changed = self._register_direct_receipt(
                    session,
                    order_id=order_id,
                    response=response,
                    side="BUY",
                    price=request["price"],
                    quantity=request["quantity"],
                    expiration=expiration,
                )
                if str(registered_session.get("session_id") or "") != session_id:
                    return {
                        **self._status_payload(session),
                        "reason": "receipt_owned_by_other_session",
                    }
                session = registered_session
                # The accepted action advances this intent once. A concurrent
                # cancel/stop/submit must still require fresh account facts.
                receipt_patch = {}
                registration_after = self.store.lp_session_revision(
                    session_id, trading=True
                )
                own_registration = (
                    registration_before == submit_revision + 1
                    and registration_after == registration_before + int(receipt_changed)
                    and str(session.get("session_id") or "") == session_id
                    and str(session.get("state") or "") not in {"complete", "entry_rejected"}
                )
                if own_registration:
                    # This accepted-entry binding is the only write observed.
                    # Keep the pre-submit financial lease; account sync and any
                    # concurrent/cancel action retain the invalidation below.
                    receipt_patch["facts_error"] = None
                    if receipt_changed:
                        receipt_patch["position_reconciled"] = preflight_reconciled
                if str(session.get("state") or "") not in {"complete", "entry_rejected"}:
                    session = self.store.lp_update_session(
                        session_id,
                        state="review" if session.get("stop_requested") or session.get("entry_cancel_requested") else "entry_open",
                        patch={
                            **receipt_patch,
                            "submit_status": "accepted",
                            **send_receipt_base,
                            "submit_stage": "receipt_received",
                            "submit_finished_at": response_at,
                            "submit_receipt_at": response_at,
                        },
                    )
                return self._status_payload(session)
        finally:
            if apply_lock is not None and receipt_lock is not None:
                apply_lock[1](receipt_lock)

    def _lp_market_conflict(
        self, condition_id: object, outcome: object
    ) -> dict[str, object] | None:
        """Issue 166: the active group occupying the same (condition_id, outcome).

        ``None`` means the market is free and admission may proceed; the
        returned session is the conflict group named by the busy payload.
        """

        wanted_condition = str(condition_id or "").strip()
        wanted_outcome = str(outcome or "").strip().upper()
        if not wanted_condition or not wanted_outcome:
            return None
        for session in self.store.lp_active_sessions():
            if (
                str(session.get("condition_id") or "").strip() == wanted_condition
                and str(session.get("outcome") or "").strip().upper()
                == wanted_outcome
            ):
                return session
        return None

    def submit_entry(
        self,
        request: Mapping[str, object],
        idempotency_key: str | None = None,
    ) -> dict[str, object]:
        """Issue 163: single-shot entry — validate fresh facts, post one BUY.

        No preview session exists: the one fresh snapshot read and the one
        full validation happen here, under the same guard order as
        ``start`` (key replay first, then mutation, then facts).  A
        rejection never creates a session row and never posts.
        """

        key = (idempotency_key or "").strip()
        if not key:
            return {"state": "rejected", "reason": "idempotency_key_required"}
        with self._mutex:
            existing = self.store.lp_session_by_idempotency(key)
            if existing is not None:
                return self._status_payload(existing)
            if not self._mutation_allowed("submit"):
                return {"state": "locked", "reason": "mutation_blocked"}
            # The request body is operator input: normalization failures are
            # caller errors and surface as exceptions (HTTP 400), while every
            # fact-vs-plan mismatch below is a semantic rejection payload.
            normalized = self._normalize_request(request)
            # Issue 166: the only admission conflict is another active group
            # on the same (condition_id, outcome); other markets proceed to
            # the original gates downstream.
            conflict = self._lp_market_conflict(
                normalized.get("condition_id"), normalized.get("outcome")
            )
            if conflict is not None:
                return {
                    "state": "busy",
                    "reason": "lp_session_market_active",
                    "session_id": conflict.get("session_id"),
                }
            try:
                snapshot = self._read_snapshot(normalized)
                # Issue 176: validation clock taken after the read completes
                # (received_at stamps at read time — a pre-read clock goes
                # deterministically stale).
                now = self._now()
                facts = self._validate_snapshot(
                    normalized, snapshot, now=now,
                    reservations=self._candidate_reservations(),
                )
                # Issue 166/R1: same participation gate as the preview and
                # two-phase start paths (see start()) — an account order or
                # position anywhere on this condition blocks the new group.
                if _has_market_order(
                    cast(Mapping[str, object], snapshot.get("account")),
                    cast(Mapping[str, object], snapshot.get("market")),
                ):
                    raise ValueError("market_already_participating")
                self._require_lp_history(normalized, now=now)
            except ValueError as exc:
                # Issue 163: the single-shot trial anchor rejects with the
                # operator-facing reason instead of the internal candidate
                # mismatch name; freshness tolerance (60s) is preserved by
                # the candidate_policy passthrough above.
                if str(exc) == "candidate_best_bid_changed":
                    return {"state": "rejected", "reason": "best_bid_changed"}
                return {"state": "rejected", "reason": str(exc)}
            # Candidate submissions anchor to the selected configured bid level
            # from this one snapshot. Manual/custom plans do not anchor.
            if normalized.get("candidate_policy") == "best_bid_minimum":
                book = snapshot.get("book")
                bids = self._levels(book.get("bids"), "bids")
                try:
                    selected_bid, _selected_bid_size = _select_bid_level(
                        bids,
                        normalized.get(
                            "candidate_bid_level", normalized.get("bid_level", 1)
                        ),
                    )
                except ValueError as exc:
                    return {"state": "rejected", "reason": str(exc)}
                if cast(Decimal, normalized["price"]) != selected_bid:
                    return {
                        "state": "rejected",
                        "reason": "candidate_bid_level_changed",
                    }
            try:
                expiration = expiration_for_review(
                    _timestamp(normalized["review_at"], name="review_at"),
                    now=now,
                )
            except ValueError as exc:
                return {"state": "rejected", "reason": str(exc)}
            return self._entry_execute(
                request=normalized,
                snapshot=snapshot,
                facts=facts,
                now=now,
                key=key,
                expiration=expiration,
            )

    def refresh_rewards(
        self,
        session_id: str | None = None,
        *,
        stop_event: threading.Event | None = None,
    ) -> dict[str, object]:
        """Refresh the persisted platform-earnings observation for one session.

        Issue 165: with ``session_id=None`` the unique active session is
        refreshed (falling back to the newest historical session as a
        read-only projection); an explicit id that matches no row returns
        the none payload and never falls back to the active group.
        """

        with self._reward_refresh_lock:
            session = self._reward_session(session_id)
            if session is None:
                return {"state": "none", "session_id": None}
            now = self._now()
            if self._reward_after_review(session, now):
                return self._status_payload(session)
            reward_date = self._session_reward_date(session)
            condition_id = _text(session.get("condition_id"))
            previous = session.get("reward_observation")
            previous_observation = (
                dict(previous) if isinstance(previous, Mapping) else {}
            )
            try:
                if reward_date is None or condition_id is None:
                    raise ValueError("reward_identity_unknown")
                reader = getattr(self.exchange, "lp_reward_snapshot", None)
                if not callable(reader):
                    raise ValueError("reward_reader_unavailable")
                if stop_event is None:
                    snapshot = reader(reward_date, condition_id)
                else:
                    snapshot = reader(
                        reward_date,
                        condition_id,
                        stop_event=stop_event,
                    )
                observation = self._known_reward_observation(
                    snapshot,
                    reward_date=reward_date,
                    condition_id=condition_id,
                    checked_at=now,
                )
            except Exception as exc:
                observation = self._unknown_reward_observation(
                    previous_observation,
                    reward_date=reward_date,
                    condition_id=condition_id,
                    attempted_at=now,
                    reason=type(exc).__name__,
                )
            with self._mutex:
                current = self.store.lp_session(str(session["session_id"]))
                if current is None:
                    return {"state": "none", "session_id": session.get("session_id")}
                updated = self.store.lp_update_session(
                    str(session["session_id"]),
                    patch={"reward_observation": observation},
                )
            return self._status_payload(updated)

    @staticmethod
    def _reward_after_review(session: Mapping[str, object], now: datetime) -> bool:
        review_at = session.get("review_at")
        if review_at is None:
            return False
        try:
            review_boundary = _timestamp(review_at, name="review_at")
        except ValueError:
            return False
        if now < review_boundary:
            return False
        previous = session.get("reward_observation")
        if not isinstance(previous, Mapping):
            return False
        last_attempt_at = previous.get("last_attempt_at")
        if last_attempt_at is None:
            return False
        try:
            return _timestamp(last_attempt_at, name="last_attempt_at") >= review_boundary
        except ValueError:
            return False

    def _reward_session(self, session_id: str | None) -> dict[str, object] | None:
        if session_id:
            return self.store.lp_session(session_id)
        session = self.store.lp_active_session()
        if session is not None:
            return session
        latest = getattr(self.store, "lp_latest_session", None)
        return latest() if callable(latest) else None

    @staticmethod
    def _session_reward_date(session: Mapping[str, object]) -> str | None:
        value = _text(session.get("reward_date"))
        if value is not None:
            try:
                return datetime.fromisoformat(value).date().isoformat()
            except ValueError:
                pass
        created_at = session.get("created_at")
        try:
            return _timestamp(created_at, name="created_at").date().isoformat()
        except ValueError:
            return None

    @staticmethod
    def _known_reward_observation(
        snapshot: object,
        *,
        reward_date: str,
        condition_id: str,
        checked_at: datetime,
    ) -> dict[str, object]:
        if not isinstance(snapshot, Mapping):
            raise ValueError("reward_snapshot_unknown")
        partial_raw_read = (
            snapshot.get("state") == "unknown"
            and snapshot.get("reason") == "usd_value_unknown"
            and (
                _maybe_decimal(snapshot.get("market_amount_raw")) is not None
                or _maybe_decimal(snapshot.get("account_amount_raw")) is not None
                or bool(snapshot.get("market_accruals_raw"))
                or bool(snapshot.get("account_accruals_raw"))
            )
        )
        if snapshot.get("state") != "known" and not partial_raw_read:
            raise ValueError("reward_snapshot_unknown")
        if str(snapshot.get("reward_date") or "") != reward_date:
            raise ValueError("reward_date_mismatch")
        if str(snapshot.get("condition_id") or "") != condition_id:
            raise ValueError("reward_condition_mismatch")
        account_amount = _maybe_decimal(snapshot.get("account_amount"))
        market_amount = _maybe_decimal(snapshot.get("market_amount"))
        if snapshot.get("state") == "known" and (
            account_amount is None or market_amount is None
        ):
            raise ValueError("reward_amount_unknown")
        if account_amount is not None and account_amount < 0:
            raise ValueError("reward_amount_invalid")
        if market_amount is not None and market_amount < 0:
            raise ValueError("reward_amount_invalid")
        usd_known = account_amount is not None and market_amount is not None
        if usd_known:
            assert account_amount is not None and market_amount is not None
            gap = max(Decimal("0"), REWARD_THRESHOLD - account_amount)
            status = "met" if account_amount >= REWARD_THRESHOLD else "below"
        else:
            gap = None
            status = "unknown"
        account_amount_raw = _maybe_decimal(snapshot.get("account_amount_raw"))
        market_amount_raw = _maybe_decimal(snapshot.get("market_amount_raw"))
        if account_amount_raw is not None and account_amount_raw < 0:
            account_amount_raw = None
        if market_amount_raw is not None and market_amount_raw < 0:
            market_amount_raw = None
        checked = _iso(checked_at)
        return {
            "status": status,
            "threshold_status": status,
            "reward_date": reward_date,
            "condition_id": condition_id,
            "market_amount": market_amount,
            "account_amount": account_amount,
            "gap": gap,
            "market_amount_raw": market_amount_raw,
            "market_asset": _text(snapshot.get("market_asset")),
            "market_accruals_raw": _reward_accrual_rows(
                snapshot.get("market_accruals_raw")
            ),
            "account_amount_raw": account_amount_raw,
            "account_asset": _text(snapshot.get("account_asset")),
            "account_accruals_raw": _reward_accrual_rows(
                snapshot.get("account_accruals_raw")
            ),
            "usd_state": snapshot.get("usd_state", "known" if usd_known else "unknown"),
            "valuation_reason": snapshot.get("reason") if not usd_known else None,
            "checked_at": checked,
            "last_success_at": checked,
            "last_attempt_at": checked,
            "stale": False,
            "source": "platform_earnings",
            "currency": "USD",
            "paid": False,
        }

    @staticmethod
    def _unknown_reward_observation(
        previous: Mapping[str, object],
        *,
        reward_date: str | None,
        condition_id: str | None,
        attempted_at: datetime,
        reason: str,
    ) -> dict[str, object]:
        same_session = (
            previous.get("reward_date") == reward_date
            and previous.get("condition_id") == condition_id
        )
        retained = previous if same_session else {}
        return {
            "status": "unknown",
            "threshold_status": "unknown",
            "reward_date": reward_date,
            "condition_id": condition_id,
            "market_amount": retained.get("market_amount"),
            "account_amount": retained.get("account_amount"),
            "gap": retained.get("gap"),
            "market_amount_raw": retained.get("market_amount_raw"),
            "market_asset": retained.get("market_asset"),
            "market_accruals_raw": retained.get("market_accruals_raw"),
            "account_amount_raw": retained.get("account_amount_raw"),
            "account_asset": retained.get("account_asset"),
            "account_accruals_raw": retained.get("account_accruals_raw"),
            "usd_state": retained.get("usd_state", "unknown"),
            "checked_at": retained.get("checked_at"),
            "last_success_at": retained.get("last_success_at"),
            "last_attempt_at": _iso(attempted_at),
            "stale": True,
            "source": "platform_earnings",
            "currency": "USD",
            "paid": False,
            "error": reason,
        }

    def generate_due_report(self) -> dict[str, object]:
        """Persist the next completed Beijing 08:00 report from saved facts."""

        now = self._now()
        local_now = now.astimezone(_BEIJING)
        read_report = getattr(self.store, "lp_daily_report", None)
        save_report = getattr(self.store, "lp_save_daily_report", None)
        list_sessions = getattr(self.store, "lp_sessions", None)
        latest_report = getattr(self.store, "lp_latest_daily_report", None)
        if not all(
            callable(method)
            for method in (read_report, save_report, list_sessions, latest_report)
        ):
            return {"state": "unavailable"}
        with self._report_lock:
            sessions = list_sessions()
            if not isinstance(sessions, (list, tuple)):
                sessions = []
            today_boundary = datetime.combine(local_now.date(), time(8), tzinfo=_BEIJING)
            completed_date = (
                local_now.date()
                if local_now >= today_boundary
                else local_now.date() - timedelta(days=1)
            )
            latest = latest_report()
            if isinstance(latest, Mapping) and latest.get("report_date"):
                target_date = date.fromisoformat(str(latest["report_date"])) + timedelta(days=1)
            else:
                due_review_dates: list[date] = []
                for session in sessions:
                    if not isinstance(session, Mapping):
                        continue
                    try:
                        review_at = _timestamp(session.get("review_at"), name="review_at")
                    except ValueError:
                        continue
                    review_date = review_at.astimezone(_BEIJING).date()
                    if review_date <= completed_date and review_at <= now:
                        due_review_dates.append(review_date)
                target_date = min(due_review_dates) if due_review_dates else completed_date
            if target_date > completed_date:
                existing = read_report(completed_date.isoformat())
                return existing if isinstance(existing, Mapping) else {"state": "not_due"}

            report_date = target_date.isoformat()
            existing = read_report(report_date)
            if existing is not None:
                return existing
            period_end = datetime.combine(target_date, time(8), tzinfo=_BEIJING).astimezone(UTC)
            period_start = period_end - timedelta(days=1)
            session_reports: list[dict[str, object]] = []
            for session in sessions:
                if not isinstance(session, Mapping):
                    continue
                row, relevant = self._daily_report_session(
                    session,
                    period_start=period_start,
                    period_end=period_end,
                    generated_at=now,
                )
                if not relevant:
                    continue
                session_reports.append(row)
            realized_total = self._known_report_sum(
                session_reports, "realized_trade_pnl", empty=Decimal("0")
            )
            paid_total = self._known_report_sum(session_reports, "paid_rewards")
            net_total = (
                realized_total + paid_total
                if realized_total is not None and paid_total is not None
                else None
            )
            payload: dict[str, object] = {
                "state": "ready",
                "report_date": report_date,
                "period_start": _report_boundary_iso(period_start),
                "period_end": _report_boundary_iso(period_end),
                "generated_at": _report_boundary_iso(now),
                "observation_status": "late" if now > period_end else "on_time",
                "cutoff_market_data_status": "unknown" if now > period_end else "observed_at_generation",
                "sessions": session_reports,
                "totals": {
                    "realized_trade_pnl": realized_total,
                    "paid_rewards": paid_total,
                    "realized_net_pnl": net_total,
                },
            }
            saved = save_report(report_date, payload)
            return saved if isinstance(saved, Mapping) else payload

    @staticmethod
    def _known_report_sum(
        rows: Sequence[Mapping[str, object]],
        key: str,
        *,
        empty: Decimal | None = None,
    ) -> Decimal | None:
        if not rows:
            return empty
        values = [_maybe_decimal(row.get(key)) for row in rows]
        if any(value is None for value in values):
            return None
        return sum((value for value in values if value is not None), Decimal("0"))

    @staticmethod
    def _daily_report_session(
        session: Mapping[str, object],
        *,
        period_start: datetime,
        period_end: datetime,
        generated_at: datetime,
    ) -> tuple[dict[str, object], bool]:
        from .polymarket_lp_views import lp_report_totals

        # The reserved manual-cancel anchor session is audit bookkeeping,
        # never reportable LP activity; report it as irrelevant so the
        # caller's `if not relevant: continue` skips it.
        if session.get("session_id") == LP_RESERVED_MANUAL_SESSION_ID:
            return {"session_id": str(session.get("session_id") or "")}, False

        events_value = session.get("trade_events")
        events = _items(events_value)
        ledger_complete = isinstance(events_value, (list, tuple))
        normalized: list[dict[str, object]] = []
        seen: dict[tuple[str, str], dict[str, object]] = {}
        event_totals = {
            "buy_filled_quantity": Decimal("0"),
            "buy_cost": Decimal("0"),
            "sold_quantity": Decimal("0"),
            "sold_revenue": Decimal("0"),
        }
        for raw_event in events:
            if not isinstance(raw_event, Mapping):
                ledger_complete = False
                continue
            status = str(raw_event.get("status") or "").upper()
            if status == "FAILED":
                continue
            if status != "CONFIRMED":
                ledger_complete = False
                continue
            trade_id = str(raw_event.get("trade_id") or "")
            order_id = str(raw_event.get("order_id") or "")
            if not trade_id:
                ledger_complete = False
                continue
            identity = (trade_id, order_id)
            if identity in seen:
                if seen[identity] != dict(raw_event):
                    ledger_complete = False
                continue
            try:
                matched_at = _timestamp(raw_event.get("matched_at"))
            except ValueError:
                ledger_complete = False
                continue
            side = str(raw_event.get("side") or "").upper()
            quantity = _maybe_decimal(raw_event.get("quantity"))
            price = _maybe_decimal(raw_event.get("price"))
            fee = _maybe_decimal(raw_event.get("fee"))
            if (
                side not in {"BUY", "SELL"}
                or quantity is None
                or quantity <= 0
                or price is None
                or price <= 0
            ):
                ledger_complete = False
                continue
            event = {
                "trade_id": trade_id,
                "order_id": order_id,
                "matched_at": matched_at,
                "side": side,
                "quantity": quantity,
                "price": price,
                "fee": fee,
            }
            seen[identity] = dict(raw_event)
            normalized.append(event)
            quantity_key, value_key = (
                ("buy_filled_quantity", "buy_cost")
                if side == "BUY"
                else ("sold_quantity", "sold_revenue")
            )
            event_totals[quantity_key] += quantity
            event_totals[value_key] += quantity * price

        for key, event_total in event_totals.items():
            recorded = _maybe_decimal(session.get(key))
            if recorded is None or recorded != event_total:
                ledger_complete = False

        for side, field_name in (("BUY", "buy_fees"), ("SELL", "sell_fees")):
            side_events = [event for event in normalized if event["side"] == side]
            fees = [_maybe_decimal(event.get("fee")) for event in side_events]
            fee_total = (
                None
                if any(fee is None for fee in fees)
                else sum((fee for fee in fees if fee is not None), Decimal("0"))
            )
            recorded_fee = _maybe_decimal(session.get(field_name))
            if side_events and (fee_total is None or recorded_fee != fee_total):
                ledger_complete = False
            elif not side_events and recorded_fee not in (None, Decimal("0")):
                ledger_complete = False

        normalized.sort(key=lambda event: cast(datetime, event["matched_at"]))

        payment_events_value = session.get("verified_paid_reward_events")
        payment_events = _items(payment_events_value)
        payments_complete = isinstance(payment_events_value, (list, tuple)) and bool(
            payment_events
        )
        normalized_payments: list[tuple[datetime, Decimal]] = []
        for raw_payment in payment_events:
            if not isinstance(raw_payment, Mapping) or raw_payment.get("verified") is not True:
                payments_complete = False
                continue
            try:
                paid_at = _timestamp(raw_payment.get("paid_at"))
            except ValueError:
                payments_complete = False
                continue
            amount = _maybe_decimal(raw_payment.get("usd_amount"))
            if not raw_payment.get("payment_id") or amount is None or amount < 0:
                payments_complete = False
                continue
            normalized_payments.append((paid_at, amount))

        def cutoff_values(cutoff: datetime) -> tuple[dict[str, object], dict[str, object]]:
            selected = [
                event
                for event in normalized
                if cast(datetime, event["matched_at"]) < cutoff
            ]
            sums = {
                "buy_filled_quantity": Decimal("0"),
                "buy_cost": Decimal("0"),
                "sold_quantity": Decimal("0"),
                "sold_revenue": Decimal("0"),
            }
            cutoff_fees: dict[str, Decimal | None] = {}
            for event in selected:
                side = str(event["side"])
                quantity = cast(Decimal, event["quantity"])
                price = cast(Decimal, event["price"])
                quantity_key, value_key = (
                    ("buy_filled_quantity", "buy_cost")
                    if side == "BUY"
                    else ("sold_quantity", "sold_revenue")
                )
                sums[quantity_key] += quantity
                sums[value_key] += quantity * price
            for side, field_name in (("BUY", "buy_fees"), ("SELL", "sell_fees")):
                side_events = [event for event in selected if event["side"] == side]
                fees = [_maybe_decimal(event.get("fee")) for event in side_events]
                cutoff_fees[field_name] = (
                    None
                    if any(fee is None for fee in fees)
                    else sum((fee for fee in fees if fee is not None), Decimal("0"))
                )
            buy_quantity = sums["buy_filled_quantity"]
            sold_quantity = sums["sold_quantity"]
            residual_quantity = buy_quantity - sold_quantity
            if residual_quantity < 0:
                residual_quantity = None
            if not ledger_complete:
                cutoff_sums: dict[str, object] = {key: None for key in sums}
                cutoff_fees = {key: None for key in cutoff_fees}
                residual_quantity = None
            else:
                cutoff_sums = sums
            paid_total = (
                sum(
                    (amount for paid_at, amount in normalized_payments if paid_at < cutoff),
                    Decimal("0"),
                )
                if payments_complete
                else None
            )
            opening: dict[str, object] = {
                **cutoff_sums,
                **cutoff_fees,
                "residual_quantity": residual_quantity,
                "residual_exit_value": Decimal("0")
                if residual_quantity == 0
                else None,
                "projected_exit_fee": Decimal("0")
                if residual_quantity == 0
                else None,
            }
            return opening, lp_report_totals(opening, paid_rewards=paid_total)

        _, opening_projection = cutoff_values(period_start)
        closing_totals, closing_projection = cutoff_values(period_end)

        def difference(key: str) -> Decimal | None:
            opening_value = _maybe_decimal(opening_projection.get(key))
            closing_value = _maybe_decimal(closing_projection.get(key))
            if opening_value is None or closing_value is None:
                return None
            return closing_value - opening_value

        realized_value = difference("realized_trade_pnl")
        paid_rewards = difference("paid_rewards")
        realized_net = (
            realized_value + paid_rewards
            if realized_value is not None and paid_rewards is not None
            else None
        )
        inventory_at_end = closing_totals.get("residual_quantity")
        inventory_at_end = (
            cast(Decimal, inventory_at_end)
            if isinstance(inventory_at_end, Decimal)
            else None
        )

        residual_exit_at_end: Decimal | None = None
        quote_status = "unknown"
        if inventory_at_end == 0:
            residual_exit_at_end = Decimal("0")
            quote_status = "not_required"
        elif inventory_at_end is not None and generated_at <= period_end:
            try:
                book_checked_at = _timestamp(session.get("book_checked_at"))
            except ValueError:
                book_checked_at = None
            current_exit_value = _maybe_decimal(session.get("residual_exit_value"))
            if (
                book_checked_at is not None
                and abs((period_end - book_checked_at).total_seconds())
                <= float(BOOK_FRESHNESS_SECONDS)
                and current_exit_value is not None
            ):
                residual_exit_at_end = current_exit_value
                quote_status = "known"

        order_history = session.get("order_history")
        unresolved_orders: list[dict[str, object]] = []
        if isinstance(order_history, Mapping):
            for order_id, raw_order in order_history.items():
                if not isinstance(raw_order, Mapping):
                    continue
                status = str(raw_order.get("status") or "UNKNOWN").upper()
                if status not in TERMINAL_ORDER_STATES:
                    unresolved_orders.append({"order_id": str(order_id), "status": status})
        reward_observation = session.get("reward_observation")
        pending_rewards = (
            dict(reward_observation)
            if isinstance(reward_observation, Mapping)
            else None
        )
        current_inventory = _maybe_decimal(session.get("residual_quantity"))
        current_exit_value = _maybe_decimal(session.get("residual_exit_value"))
        stop_loss_at = session.get("stop_loss_triggered_at")
        stop_loss_value = _maybe_decimal(session.get("stop_loss_triggered_loss"))
        session_report = {
            "session_id": str(session.get("session_id") or ""),
            "market_id": session.get("market_id"),
            "condition_id": session.get("condition_id"),
            "market_title": session.get("market_title", session.get("question")),
            "market_url": session.get("market_url"),
            "outcome": session.get("outcome"),
            "session_state": session.get("state"),
            "period_start": _report_boundary_iso(period_start),
            "period_end": _report_boundary_iso(period_end),
            "realized_trade_pnl": realized_value,
            "realized_trade_pnl_status": "known" if realized_value is not None else "unknown",
            "paid_rewards": paid_rewards,
            "paid_rewards_status": "known" if paid_rewards is not None else "needs_verification",
            "realized_net_pnl": realized_net,
            "residual_quantity_at_period_end": inventory_at_end,
            "residual_exit_value_at_period_end": residual_exit_at_end,
            "residual_exit_estimate_status": quote_status,
            "current_residual_quantity": current_inventory,
            "current_residual_exit_value": current_exit_value,
            "current_inventory_checked_at": session.get("account_checked_at"),
            "current_exit_checked_at": session.get("book_checked_at"),
            "management_observed_at": _report_boundary_iso(generated_at),
            "stop_loss_triggered": stop_loss_at is not None or session.get("stop_loss_latched") is True,
            "stop_loss_triggered_at": stop_loss_at,
            "stop_loss_triggered_loss": stop_loss_value,
            "review_status": session.get("review_status"),
            "orders_terminal": session.get("orders_terminal"),
            "unresolved_orders": unresolved_orders,
            "reconciliation": session.get("reconciliation"),
            "pending_rewards": pending_rewards,
        }

        event_in_period = any(
            period_start <= cast(datetime, event["matched_at"]) < period_end
            for event in normalized
        )
        payment_in_period = any(
            period_start <= paid_at < period_end
            for paid_at, _amount in normalized_payments
        )
        try:
            review_at = _timestamp(session.get("review_at"), name="review_at")
        except ValueError:
            review_at = None
        review_in_period = review_at is not None and period_start < review_at <= period_end
        try:
            created_at = _timestamp(session.get("created_at"), name="created_at")
        except ValueError:
            created_at = None
        created_in_period = created_at is not None and period_start <= created_at < period_end
        active_at_observation = str(session.get("state") or "") not in {
            "complete",
            "entry_rejected",
        }
        existed_at_cutoff = created_at is not None and created_at <= period_end
        relevant = (
            event_in_period
            or payment_in_period
            or review_in_period
            or created_in_period
            or (inventory_at_end is not None and inventory_at_end > 0)
            or (active_at_observation and existed_at_cutoff)
        )
        return session_report, relevant

    def status(self, session_id: str | None = None) -> dict[str, object]:
        """Report one session; ``None`` targets the single active session.

        Issue 165: with ``session_id=None`` the unique active session is
        reported (falling back to the newest historical session as a
        read-only projection); an explicit id that matches no row returns
        the none payload and never falls back to the active group.
        """

        with self._mutex:
            session = (
                self.store.lp_session(session_id)
                if session_id
                else self.store.lp_active_session()
            )
            if session is None and not session_id:
                latest = getattr(self.store, "lp_latest_session", None)
                session = latest() if callable(latest) else None
            if session is None:
                return {"state": "none", "session_id": None}
            result = self._status_payload(session)
            checked_at = session.get("scoring_checked_at")
            if result.get("scoring_status") in {"true", "false"} and checked_at is not None:
                try:
                    age = (self._now() - _timestamp(checked_at, name="scoring_checked_at")).total_seconds()
                except ValueError:
                    age = float("inf")
                if age < 0 or age > float(SCORING_STALE_SECONDS):
                    result["scoring_status"] = "unknown"
            return result

    def stop(self, session_id: str | None = None) -> dict[str, object]:
        """Stop one session; ``None`` targets the single active session.

        Session selection is serialized, while the already-authorized cancel
        sweep and its receipts stay outside the common publication mutex.
        """
        with self._mutex:
            if session_id:
                session = self.store.lp_session(session_id)
            else:
                active = self.store.lp_active_sessions()
                if len(active) >= 2:
                    return {
                        "state": "rejected",
                        "reason": "session_ambiguous",
                        "session_ids": [row.get("session_id") for row in active],
                    }
                session = active[0] if active else None
            if session is None:
                return {"state": "none", "session_id": None}
            if str(session.get("state")) in {"complete", "entry_rejected", "review"}:
                return self._status_payload(session)
            if not session.get("stop_requested"):
                self.store.lp_register_trade_change(str(session["session_id"]))
                session = self.store.lp_update_session(
                    str(session["session_id"]), patch={"stop_requested": True}
                )
            session = dict(session)
        try:
            self._cancel_owned_orders(session)
        except Exception as exc:
            updated = self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch={
                    "stop_requested": True,
                    "reconciliation": f"stop_cancel_{type(exc).__name__}",
                    "resume_state": "review",
                    **self._needs_attention_notify_patch(session, self._now()),
                },
            )
            return self._status_payload(updated)
        updated = self.store.lp_update_session(
            str(session["session_id"]),
            state="review",
            patch={
                "stop_requested": True,
                "review_status": "awaiting_reconciliation",
                "needs_attention_since": None,
                "needs_attention_notified": False,
                "needs_attention_due": False,
                "needs_attention_channel_status": {},
                "needs_attention_send_error": None,
                "needs_attention_sending": False,
                "needs_attention_send_retry_at": None,
            },
        )
        return self._status_payload(updated)

    def _queue_protection_levels(
        self, session: Mapping[str, object]
    ) -> dict[str, dict[str, object]]:
        """All per-price protection buckets of one session (D6 read helper)."""

        return _queue_protection_level_buckets(
            session.get("queue_protection"),
            default_order_id=str(session.get("entry_order_id") or ""),
        )

    def _order_cancel_requested(
        self, session: Mapping[str, object], order_id: str
    ) -> bool:
        """True when a cancel was already requested for this own order."""

        if not order_id:
            return False
        if str(session.get("entry_order_id") or "") == order_id:
            return bool(session.get("entry_cancel_requested"))
        requested = {str(value) for value in _items(session.get("augment_cancel_requested"))}
        return order_id in requested

    def _bucket_protection_gate_open(
        self,
        session: Mapping[str, object],
        bucket: Mapping[str, object],
        rows_by_id: Mapping[str, object],
    ) -> bool:
        """Issue 167: a bucket is protected only while its own order is
        alive, not yet cancel-requested, and completely unfilled.

        Evidence order mirrors the runtime reads: the durable order history
        first, then the snapshot receipts.  An order with no readable
        status anywhere counts as alive (the pre-sync state).
        """

        order_id = str(bucket.get("order_id") or "")
        if not order_id:
            return False
        if self._order_cancel_requested(session, order_id):
            return False
        history = self._order_history(session)
        record = history.get(order_id)
        row = rows_by_id.get(order_id) if rows_by_id is not None else None
        source = (
            record
            if isinstance(record, Mapping) and record.get("status")
            else row
        )
        if source is None:
            return True
        status = str(_field(source, "status", "") or "").upper()
        if status and status in TERMINAL_ORDER_STATES:
            return False
        matched = _maybe_decimal(_field(source, "size_matched"))
        if matched is not None and matched > 0:
            return False
        return True

    def _queue_protection_gate_open(self, session: Mapping[str, object]) -> bool:
        """Issue 152/167: protection still applies to at least one bucket.

        Shared by the runtime evaluation, the data-outage counter, and the
        conservative cancel so the three can never drift apart.
        """

        buckets = self._queue_protection_levels(session)
        if not buckets:
            return False
        history = self._order_history(session)
        for bucket in buckets.values():
            if str(bucket.get("state")) in {"canceling", "canceled", "partially_filled"}:
                continue
            order_id = str(bucket.get("order_id") or "")
            if not order_id or self._order_cancel_requested(session, order_id):
                continue
            record = history.get(order_id, {})
            status = str(record.get("status") or "").upper()
            if status and status in TERMINAL_ORDER_STATES:
                continue
            matched = _maybe_decimal(record.get("size_matched"))
            if matched is not None and matched > 0:
                continue
            return True
        return False

    def _queue_protection_data_failure(
        self, session: Mapping[str, object], reason: str
    ) -> dict[str, object] | None:
        """Increment the durable group outage counter on data-outage exits."""

        protection = session.get("queue_protection")
        buckets = self._queue_protection_levels(session)
        if not isinstance(protection, Mapping) or not buckets:
            return None
        if reason not in _QUEUE_DATA_FAILURE_REASONS:
            return None
        if all(
            str(bucket.get("state")) in {"canceling", "canceled", "partially_filled"}
            for bucket in buckets.values()
        ):
            return None
        if not self._queue_protection_gate_open(session):
            # No bucket protects a live order anymore (filled, cancel
            # requested, terminal, or never submitted): an outage streak is
            # irrelevant, so the counter resets instead of accumulating
            # toward a stale conservative cancel.
            failures = 0
        else:
            failures = _queue_group_failures_int(protection.get("data_failures")) + 1
        return {
            "version": 2,
            "data_failures": failures,
            "levels": buckets,
        }

    def _conservative_protection_cancel(
        self,
        session: Mapping[str, object],
        failures: dict[str, object] | None,
    ) -> dict[str, object] | None:
        """Issue 152 D5 / 167 D4: cancel the whole group's own BUYs after
        ten data outages — one protection cancel per price bucket."""

        if failures is None:
            return None
        count = _maybe_decimal(failures.get("data_failures")) or Decimal("0")
        if count < LP_PROTECTION_DATA_FAILURE_LIMIT:
            return None
        if not self._queue_protection_gate_open(session):
            return None
        buckets = failures.get("levels")
        if not isinstance(buckets, Mapping) or not buckets:
            return None
        new_levels: dict[str, dict[str, object]] = {}
        session_patch: dict[str, object] = {}
        changed = False
        for key, bucket in buckets.items():
            if not isinstance(bucket, Mapping):
                new_levels[str(key)] = dict(bucket) if isinstance(bucket, Mapping) else {}
                continue
            bucket_dict = dict(bucket)
            if str(bucket_dict.get("state")) in {"canceling", "canceled", "partially_filled"}:
                new_levels[str(key)] = bucket_dict
                continue
            if not self._bucket_protection_gate_open(session, bucket_dict, {}):
                new_levels[str(key)] = bucket_dict
                continue
            new_bucket, patch = self._request_bucket_protection_cancel(
                session, None, bucket_dict, reason="book_unreliable",
                bucket_key=str(key),
            )
            new_levels[str(key)] = new_bucket
            for patch_key, patch_value in patch.items():
                if patch_key == "augment_cancel_requested":
                    merged = {
                        str(value)
                        for value in _items(session_patch.get(patch_key))
                    } | {str(value) for value in _items(patch_value)}
                    session_patch[patch_key] = sorted(merged)
                else:
                    session_patch[patch_key] = patch_value
            changed = True
        if not changed:
            return None
        session_patch["queue_protection"] = {
            "version": 2,
            "data_failures": _queue_group_failures_int(failures.get("data_failures")),
            "levels": new_levels,
        }
        updated = self.store.lp_update_session(
            str(session["session_id"]), patch=session_patch
        )
        self._notify_committed_protection_cancels(updated)
        return updated

    def tick(self) -> dict[str, object]:
        """Run one deterministic monitoring/reconciliation iteration."""

        return self._tick()

    def _schedule_session_attention(self, session_id: str, *, apply_lock=None) -> None:
        """Hand durable notices to one finite background delivery lane."""
        with self._attention_queue_lock:
            self._attention_pending[session_id] = apply_lock or self._attention_pending.get(session_id)
            start = self._attention_thread is None
            if start:
                self._attention_thread = threading.Thread(
                    target=self._attention_delivery_loop,
                    name="lp-session-attention",
                    daemon=True,
                )
                self._attention_thread.start()

    def _attention_delivery_loop(self) -> None:
        while True:
            with self._attention_queue_lock:
                if not self._attention_pending:
                    self._attention_thread = None
                    return
                session_id, apply_lock = self._attention_pending.popitem()
            try:
                verifier = self._facts_attention_verifier
                if callable(verifier):
                    verifier(session_id=session_id, apply_lock=apply_lock)
                row = self.store.lp_session(session_id)
                if (row and row.get('needs_attention_recovery_due')
                        and not self.store.lp_auto_owns_session(session_id)):
                    self.verify_session_recovery(session_id, apply_lock=apply_lock)
                callback = self._facts_attention_flusher
                if callback is not None:
                    callback(session_id)
                self.flush_session_attention(session_id)
                self.flush_session_recovery(session_id)
            except Exception:
                logger.exception("lp_session_attention_delivery_failed")

    def _flush_session_attention(self, session_id: str) -> None:
        callback = self._facts_attention_flusher
        if callback is not None:
            callback(session_id)
        self.flush_session_attention(session_id)
        self.flush_session_recovery(session_id)

    def verify_session_recovery(self, session_id, *, apply_lock=None, account_round=None):
        """Observe terminal facts for notifications without reopening settlement."""
        session = self.store.lp_session(session_id)
        if not session or session.get('account_baseline_archive') or session.get('state') not in {'complete', 'entry_rejected'}:
            return False
        last = session.get('attention_verification_attempted_at') or session.get('facts_checked_at')
        if last and (self._now() - _timestamp(last)).total_seconds() < 60:
            return False
        if not self._report_lock.acquire(blocking=False):
            return False
        try:
            self.store.lp_update_session(session_id, patch={
                'attention_verification_attempted_at': self._now(),
                'attention_verification_error': 'verification_pending',
            })
            self.reconcile_facts(session_id, report_only=True, verify_recovery=True,
                                 apply_lock=apply_lock, account_round=account_round)
            return True
        finally:
            self._report_lock.release()

    def _publish_facts_wait(self, session_id: str, reason: str) -> None:
        row = self.store.lp_session_with_revision(session_id, trading=True)
        if row is None:
            return
        try:
            self.store.lp_publish_facts(
                session_id, row[1],
                patch={"facts_error": reason, "reconcile_reason": reason,
                       "publication_pending": True, "reconcile_retry_at": None},
                publish=self._facts_publisher, error=reason,
            )
        except ValueError as exc:
            if str(exc) != "session_changed":
                raise

    def reconcile_facts(self, session_id, *, apply_lock=None, report_only=False,
                        verify_recovery=False, monitor=False, account_round=None):
        with _lp_read_task("session_facts"):
            return self._reconcile_facts(session_id, apply_lock=apply_lock,
                report_only=report_only, verify_recovery=verify_recovery,
                monitor=monitor, account_round=account_round)

    def _reconcile_facts(
        self,
        session_id,
        *,
        apply_lock=None,
        report_only=False,
        verify_recovery=False,
        monitor=False,
        account_round=None,
    ):
        """Join the one read/apply operation for this session.

        Only trading intents fence this operation. Its short apply publishes
        the session and automatic ledger together; observation writers cannot
        invalidate account facts, and no external read owns the apply mutex.
        """
        with self._facts_lock:
            flight = self._facts_inflight.get(session_id)
            owner = flight is None
            if owner:
                flight = self._facts_inflight[session_id] = dict(future=Future(), monitor=False, notification_only=verify_recovery)
            # Joining monitors cannot upgrade a notification-only owner.
            if monitor and not flight['notification_only']:
                flight.update(monitor=True, apply_lock=apply_lock)
            future = flight['future']
        if not owner:
            with _lp_read_stage("facts_join_wait"):
                return future.result()
        timings, failed = {}, False
        try:
            self._facts_owner.session_id = session_id
            waited_for_capacity = not self._facts_capacity.acquire(blocking=False)
            if waited_for_capacity and not report_only:
                self._publish_facts_wait(session_id, "facts_read_capacity")
            with _lp_read_stage("facts_capacity_wait", timings):
                if waited_for_capacity:
                    self._facts_capacity.acquire()
            try:
                if waited_for_capacity and not report_only:
                    self._publish_facts_wait(session_id, "facts_read_in_progress")
                result = self._reconcile_facts_once(
                    session_id,
                    apply_lock=apply_lock,
                    report_only=report_only,
                    verify_recovery=verify_recovery,
                    timings=timings,
                    account_round=account_round,
                )
                failed = result[3] is not None
            finally:
                self._facts_capacity.release()
            if failed:
                self._schedule_session_attention(session_id)
            with self._facts_lock:
                if not flight['monitor']:
                    if not failed:
                        self._schedule_session_attention(session_id)
                    # Finish atomically with request registration, so a joining
                    # tick is either included or starts the next operation.
                    self._facts_inflight.pop(session_id)
                    status = self._status_payload(self.store.lp_session(session_id) or result[0]) if flight['notification_only'] else None
                    future.set_result((*result, status))
                    return future.result()
            status = self._apply_tick_snapshot(
                *result,
                apply_lock=flight['apply_lock'],
                account_round=account_round,
            )
            if self._facts_wakeup and self.store.lp_session_revision(session_id, trading=True) != result[2]:
                self._facts_wakeup()
            result = (*result, status)
            self._schedule_session_attention(session_id)
            with self._facts_lock:
                self._facts_inflight.pop(session_id)
                future.set_result(result)
            return result
        except ValueError as exc:
            failed = True
            if str(exc) != 'session_changed':
                future.set_exception(exc)
                raise
            current = self.store.lp_session(session_id) or {'session_id': session_id, 'state': 'needs_attention'}
            result = (current, None, None, 'session_changed', self._status_payload(current))
            future.set_result(result)
            return result
        except BaseException as exc:
            failed = True
            future.set_exception(exc)
            raise
        finally:
            try:
                if failed or sum(timings.values()) >= 60:
                    logger.warning("lp_facts_timing outcome=%s stages=%s thread=%s",
                                   "failed" if failed else "slow", timings, threading.get_ident())
            except Exception:
                pass
            self._facts_owner.session_id = None
            with self._facts_lock:
                if self._facts_inflight.get(session_id) is flight:
                    self._facts_inflight.pop(session_id)

    def _publish_account_round_rejected(self, session_id: str) -> dict[str, object]:
        """Atomically reject account facts in the session and auto ledger."""

        with self._facts_lock:
            self._pending_facts.pop(session_id, None)
        for _ in range(3):
            row = self.store.lp_session_with_revision(session_id, trading=True)
            if row is None:
                raise ValueError('lp_session_not_found')
            current, current_revision = row
            try:
                session, _ = self.store.lp_publish_facts(
                    session_id,
                    current_revision,
                    patch={
                        'facts_error': 'account_round_invalid',
                        'reconcile_reason': 'account_round_invalid',
                        'publication_pending': True,
                        'fee_status': 'unknown',
                        'position_reconciled': False,
                    },
                    publish=self._facts_publisher,
                    error='account_round_invalid',
                )
                return session
            except ValueError as exc:
                if str(exc) != 'session_changed':
                    raise
        raise LpObservationWait('session_changed')

    def _account_bundle_is_current(self, snapshot: Mapping[str, object]) -> bool:
        """Check a bundle's observed DB generation at a use boundary."""

        generation = snapshot.get("_lp_trade_generation")
        reader = getattr(self.store, "lp_trade_generation", None)
        if not callable(reader):
            return True
        if not isinstance(generation, int):
            return True
        try:
            return int(generation) == int(reader())
        except (TypeError, ValueError, RuntimeError):
            return False

    def _take_pending_facts(
        self, session: Mapping[str, object], revision: int, trade_generation: int
    ):
        """Reuse one retained read only while its durable fences match."""
        session_id = str(session["session_id"])
        with self._facts_lock:
            pending = self._pending_facts.pop(session_id, None)
        if pending is None or pending[1] != revision or pending[3] != trade_generation:
            return None
        if any(
            pending[2].get(key) != session.get(key)
            for key in ("condition_id", "token_id", "entry_order_id", "owned_order_ids")
        ):
            return None
        return pending[0]

    def _retain_pending_facts(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        revision: int,
        trade_generation: int,
    ) -> None:
        with self._facts_lock:
            identity = {
                key: session.get(key)
                for key in ("condition_id", "token_id", "entry_order_id", "owned_order_ids")
            }
            self._pending_facts[str(session["session_id"])] = (
                snapshot, revision, identity, trade_generation,
            )

    def _reconcile_facts_once(
        self,
        session_id,
        *,
        apply_lock,
        report_only,
        verify_recovery=False,
        timings=None,
        account_round=None,
    ):
        row = self.store.lp_session_with_revision(session_id, trading=True)
        if row is None:
            raise ValueError('lp_session_not_found')
        session, revision = row
        generation_reader = getattr(self.store, "lp_trade_generation", None)
        observed_trade_generation = (
            int(generation_reader()) if callable(generation_reader) else None
        )
        if session.get('order_identity_conflict'):
            return session, None, revision, 'order_identity_conflict'
        late_receipts = [] if verify_recovery else [
            action
            for action in self.store.lp_actions(session_id)
            if action.get('state') == 'accepted'
            and action.get('order_id')
            and action.get('order_id') not in self._session_order_ids(session)
            and action.get('role') in {'entry', 'augment', 'passive_exit', 'protected_exit'}
        ]
        if late_receipts:
            entry_receipt = next(
                (action for action in late_receipts if action.get('role') == 'entry'),
                None,
            )
            ordered = [entry_receipt] if entry_receipt else []
            ordered.extend(action for action in late_receipts if action is not entry_receipt)
            registered_entry = False
            for action in ordered:
                role = str(action.get('role') or '')
                registered_session, _receipt_changed = self._register_direct_receipt(
                    session,
                    order_id=str(action['order_id']),
                    response=action,
                    side=str(action.get('side') or ('BUY' if role in {'entry', 'augment'} else 'SELL')).upper(),
                    price=action.get('price', action.get('min_price')),
                    quantity=action.get('quantity'),
                    expiration=action.get('expiration'),
                    order_type=action.get('order_type') or (
                        'FOK' if role == 'protected_exit' else None
                    ),
                )
                if str(registered_session.get("session_id") or "") != session_id:
                    continue
                session = registered_session
                if role == 'entry':
                    registered_entry = True
                role_patch = {
                    'entry': {'entry_order_id': action['order_id']},
                    'passive_exit': {'passive_exit_order_id': action['order_id']},
                    'protected_exit': {'protected_exit_order_id': action['order_id']},
                }.get(role, {})
                if role_patch:
                    session = self.store.lp_update_session(session_id, patch=role_patch)
            row = self.store.lp_session_with_revision(session_id, trading=True)
            if row is None:
                raise ValueError('lp_session_not_found')
            session, revision = row
            if entry_receipt and registered_entry:
                session, _ = self.store.lp_publish_facts(
                    session_id,
                    revision,
                    patch={'submit_status': 'unknown'},
                )
                row = self.store.lp_session_with_revision(session_id, trading=True)
                session, revision = row
        snapshot, error = None, None
        retry_at = None
        if not report_only:
            snapshot = self._take_pending_facts(
                session, revision, observed_trade_generation
            )
        if snapshot is not None and self._facts_validator and not report_only:
            try:
                with _lp_read_stage("facts_validate", timings):
                    self._facts_validator(session, snapshot)
            except (ValueError, RuntimeError, OSError):
                snapshot = None
        try:
            with _lp_read_stage("facts_read", timings):
                if snapshot is None:
                    snapshot = self._read_snapshot(
                        {
                            **self._normalize_request(session),
                            "lp_public_wait": False,
                        },
                        account_round=account_round,
                    )
            if self._facts_validator and not report_only:
                with _lp_read_stage("facts_validate", timings):
                    self._facts_validator(session, snapshot)
        except (ValueError, RuntimeError, OSError) as exc:
            error = str(exc)
            retry_at = exc.retry_at if isinstance(exc, LpAccountReadError) else None
        if not error and snapshot is not None:
            snapshot_generation = snapshot.get("_lp_trade_generation")
            if snapshot_generation is not None:
                if not isinstance(snapshot_generation, int):
                    error = "account_round_invalid"
                else:
                    observed_trade_generation = snapshot_generation
        if snapshot is not None:
            snapshot = {**snapshot, "_lp_observed_trade_generation": observed_trade_generation}
        if error == "account_round_invalid" and not report_only:
            session = self._publish_account_round_rejected(session_id)
            return session, None, revision, error
        if error and not report_only:
            # A failed read only removes permission to spend; an occupied
            # execution lock must not hide that failure behind an old lease.
            try:
                with _lp_read_stage("facts_failure_publish", timings):
                    session, _ = self.store.lp_publish_facts(
                        session_id,
                        revision,
                        patch={
                            'facts_error': error,
                            'reconcile_reason': error,
                            'reconcile_retry_at': retry_at,
                            'manual_attention': error in {
                                'account_identity_mismatch', 'credential_invalid'
                            },
                        },
                        trade_generation=observed_trade_generation,
                        publish=self._facts_publisher, error=error)
            except ValueError as exc:
                if str(exc) == 'account_round_invalid':
                    snapshot = None
                    error = str(exc)
                    session = self._publish_account_round_rejected(session_id)
                elif str(exc) != 'session_changed':
                    raise
                error = str(exc)
            return session, snapshot, revision, error
        with _lp_read_stage("facts_apply_wait", timings):
            self._facts_apply_lock.acquire()
        lock = None
        try:
            with _lp_read_stage("facts_execution_lock", timings):
                lock = apply_lock[0]() if apply_lock else None
        except BaseException:
            self._facts_apply_lock.release()
            raise
        if apply_lock and lock is None:
            if verify_recovery:
                self._facts_apply_lock.release()
                return session, snapshot, revision, 'execution_lock'
            try:
                if snapshot is not None and observed_trade_generation is not None:
                    self._retain_pending_facts(
                        session, snapshot, revision, observed_trade_generation
                    )
                session, _ = self.store.lp_publish_facts(
                    session_id,
                    revision,
                    patch={
                        "facts_error": "execution_lock",
                        "reconcile_reason": "execution_lock",
                        "publication_pending": True,
                        "manual_attention": False,
                    },
                    trade_generation=observed_trade_generation,
                    publish=self._facts_publisher,
                    error="execution_lock",
                )
            except ValueError as exc:
                if str(exc) == "account_round_invalid":
                    session = self._publish_account_round_rejected(session_id)
                    return session, None, revision, "account_round_invalid"
                if str(exc) != "session_changed":
                    raise
            finally:
                self._facts_apply_lock.release()
            return session, snapshot, revision, "execution_lock"
        changed = False
        try:
            with _lp_read_stage("facts_mutex_wait", timings):
                self._mutex.acquire()
            try:
                current, current_revision = self.store.lp_session_with_revision(session_id, trading=True)
                if current_revision != revision or (verify_recovery and current.get('account_baseline_archive')):
                    return session, snapshot, revision, "session_changed"
                patch, state = {}, None
                if not error and self._facts_validator is not None:
                    try:
                        self._facts_validator(current, snapshot)
                    except ValueError as exc:
                        error = str(exc) or "account_facts_stale"
                if report_only:
                    if verify_recovery:
                        try:
                            if error:
                                raise ValueError(error)
                            account = snapshot.get('account') or {}
                            stamp = snapshot.get('account_checked_at') or account.get('checked_at')
                            _freshness(stamp, self._now(), 'recovery_facts', max_age=60)
                            if (account.get('authenticated') is not True
                                    or account.get('open_orders_complete') is not True
                                    or account.get('positions_complete') is not True):
                                raise ValueError('account_facts_incomplete')
                            observed = {**current, **self._order_history_patch(current, snapshot)}
                            observed.update(self._fill_patch(observed, snapshot))
                            if self._completion_patch(observed) is None or observed.get('financial_block_reason'):
                                raise ValueError('terminal_recovery_unverified')
                            patch.update(attention_verified_at=stamp,
                                         attention_verified_trade_generation=observed_trade_generation)
                        except ValueError as exc:
                            error = str(exc)
                        patch['attention_verification_error'] = error
                    else:
                        if not error:
                            patch['trade_events'] = self._merge_report_trade_events(current, snapshot)
                        patch.update(report_checked_at=self._now(), report_error=error)
                    try:
                        with _lp_read_stage("facts_report_publish", timings):
                            current, _ = self.store.lp_publish_facts(
                                session_id, revision, patch=patch,
                                trade_generation=observed_trade_generation,
                                publish=None if verify_recovery else self._facts_publisher)
                    except ValueError as exc:
                        if str(exc) not in {'account_round_invalid', 'session_changed'}:
                            raise
                        error = str(exc)
                        snapshot = None
                    return current, snapshot, revision, error
                if not error:
                    try:
                        patch.update(self._order_history_patch(current, snapshot))
                        current = {**current, **patch}
                        patch.update(self._fill_patch(current, snapshot))
                        current = {**current, **patch}
                        receipt = self._order_history(current).get(str(current.get('entry_order_id')), {})
                        if (not reservation_is_released(current)
                                and receipt.get('status') not in (None, '', 'UNKNOWN')
                                and current.get('submit_status') in ('unknown','accepted_without_order_id',None)):
                            patch.update(submit_status='accepted',resume_state=None)
                            current.update(patch)
                            state = 'review' if current.get('stop_requested') else 'entry_open'
                        completion = self._completion_patch(current)
                        if completion is not None:
                            patch.update(completion)
                            if current.get('state') == 'needs_attention':
                                patch.update(self._needs_attention_recovery_patch(current))
                            state = 'complete'
                        patch['facts_checked_at'] = snapshot.get('account_checked_at') or (snapshot.get('account') or {}).get('checked_at') or self._now()
                    except ValueError as exc:
                        patch, state, error = {}, None, str(exc)
                patch.update({
                    "facts_error": error,
                    "reconcile_reason": error or patch.get("financial_block_reason"),
                    "manual_attention": error in {
                        "account_identity_mismatch", "credential_invalid"
                    },
                    "reconcile_retry_at": None,
                    "publication_pending": bool(error),
                })
                resolved_cancels = []
                if not error:
                    statuses = {self._order_id(row): str(_field(row, 'status', '')).upper()
                                for row in _items(snapshot.get('orders'))}
                    statuses.update({oid: str(row.get('status', '')).upper()
                                     for oid, row in self._order_history(current).items()})
                    for action in self.store.lp_actions(session_id):
                        if action.get('state') not in {'pending', 'unknown'} or submission_action_kind(action) != 'cancel':
                            continue
                        targets = action.get('targets') or [action.get('order_id')]
                        if targets and all(statuses.get(oid) in TERMINAL_ORDER_STATES for oid in targets):
                            resolved_cancels.append(action['action_id'])
                def publish_normal(current, *, connection, error):
                    return self._facts_publisher(current, connection=connection, error=error,
                        normal_facts=snapshot if not error else None)
                try:
                    with _lp_read_stage("facts_publish", timings):
                        current, changed = self.store.lp_publish_facts(
                            session_id, revision, patch=patch, state=state,
                            trade_generation=observed_trade_generation,
                            publish=publish_normal if self._facts_publisher else None,
                            error=error, resolved_cancels=resolved_cancels,
                        )
                except ValueError as exc:
                    if str(exc) == 'account_round_invalid':
                        snapshot = None
                        error = str(exc)
                        session = self._publish_account_round_rejected(session_id)
                        return session, snapshot, revision, error
                    elif str(exc) != 'session_changed':
                        raise
                    return session, snapshot, revision, 'session_changed'
            finally:
                self._mutex.release()
        finally:
            try:
                if apply_lock and lock is not None:
                    apply_lock[1](lock)
            finally:
                self._facts_apply_lock.release()
        if changed and self._facts_wakeup:
            self._facts_wakeup()
        return current, snapshot, revision, error

    def tick_with_apply_lock(
        self,
        acquire_lock: Callable[[], object | None],
        release_lock: Callable[[object], None],
    ) -> dict[str, object]:
        """Run a tick with the execution lock reserved for short apply work."""

        return self._tick(apply_lock=(acquire_lock, release_lock))

    def _tick(
        self,
        *,
        apply_lock: tuple[Callable[[], object | None], Callable[[object], None]] | None = None,
    ) -> dict[str, object]:
        """Run one deterministic monitoring/reconciliation iteration.

        Issue 165: group-level reconciliation is delegated to
        ``_reconcile_session`` for every active session row.  Issue 166:
        with zero groups the none payload is returned unchanged; with one
        group the top level keeps today's single-group payload shape plus a
        ``sessions`` key; with several groups the top level is an aggregate
        (worst state, oldest check stamps, no session_id) carrying every
        group's full payload in ``sessions``.
        """

        # First-seen fallback protections remain serialized in their own lane.
        # Their reads and protection sends never own the common publication or
        # execution locks; unrelated sessions can continue reconciling.
        # they must not own the common publication mutex or execution lock.
        cancel_notices = []
        self._deferred_protection_notices.cancels = cancel_notices
        try:
            with self._first_seen_apply_lock:
                self._apply_first_seen_protections()
        finally:
            self._deferred_protection_notices.cancels = None
            for notice in cancel_notices:
                self._start_protection_cancel_notice(*notice)

        verifier = self._facts_attention_verifier
        if callable(verifier):
            try:
                verifier(apply_lock=apply_lock)
            except Exception:
                logger.exception("lp_terminal_attention_schedule_failed")
        for session in self.store.lp_sessions():
            if (session.get('state') in {'complete', 'entry_rejected'} and session.get('needs_attention_recovery_due')
                    and not self.store.lp_auto_owns_session(str(session['session_id']))):
                self._schedule_session_attention(str(session['session_id']), apply_lock=apply_lock)

        active_reader = getattr(
            self.store, "lp_active_sessions_with_revisions", None
        )
        if callable(active_reader):
            session_pairs = active_reader()
        else:
            # Compatibility for lightweight stores used by older callers.
            session_pairs = []
            for session in self.store.lp_active_sessions():
                session_id = str(session.get("session_id") or "")
                try:
                    revision = self.store.lp_session_revision(session_id)
                except Exception:
                    revision = 0
                session_pairs.append((session, revision))
        if not session_pairs:
            return {"state": "none", "session_id": None}
        if getattr(self._facts_owner, 'session_id', None):
            return self._lp_tick_aggregate([self._status_payload(session) for session, _ in session_pairs])

        # ponytail: two account reads at a time; raise only with venue capacity evidence.
        round_begin = getattr(self.exchange, "lp_account_round_begin", None)
        round_end = getattr(self.exchange, "lp_account_round_end", None)
        trade_generation_reader = getattr(self.store, "lp_trade_generation", None)
        account_round = (
            round_begin(trade_generation_reader)
            if callable(round_begin)
            else None
        )
        try:
            if account_round is not None:
                with self._lp_account_rounds_lock:
                    self._lp_account_rounds.add(account_round)
            with ThreadPoolExecutor(max_workers=2) as workers:
                futures = [
                    workers.submit(
                        self._tick_session,
                        pair,
                        apply_lock=apply_lock,
                        account_round=account_round,
                    )
                    for pair in session_pairs
                ]
                payloads = [future.result() for future in futures]
        finally:
            if account_round is not None:
                with self._lp_account_rounds_lock:
                    self._lp_account_rounds.discard(account_round)
            if account_round is not None and callable(round_end):
                round_end(account_round)
        return self._lp_tick_aggregate(payloads)

    def _tick_session(self, session_pair, *, apply_lock, account_round=None):
        session, _ = session_pair
        session_id = str(session['session_id'])
        try:
            result = self.reconcile_facts(
                session_id,
                apply_lock=apply_lock,
                monitor=True,
                account_round=account_round,
            )
            return result[4] or self._status_payload(result[0])
        except Exception as exc:
            return {'state': 'error', 'session_id': session_id, 'error': type(exc).__name__}
        finally:
            # This risk rule belongs to normal LP monitoring, including when
            # the automatic BUY pool is paused or account/history reads fail.
            self._monitor_buy_yield(session_id)

    def _monitor_buy_yield(self, session_id):
        session = self.store.lp_session(session_id)
        wallet = str(getattr(getattr(self.exchange, 'config', None), 'wallet_address', '') or '').casefold()
        if (not session or not wallet or str(session.get('account_id') or '').casefold() != wallet
                or session.get('order_identity_conflict')):
            return
        history = self._order_history(session)
        buys = {oid: row for oid, row in history.items()
            if row.get('side') == 'BUY' and row.get('status') == 'LIVE'
            and row.get('token_id') == session.get('token_id')
            and self._queue_row_remaining(row) is not None and self._queue_row_remaining(row) > 0}
        if not buys:
            return
        direction = None
        try:
            direction = self._market_read(session, lambda: self._fetch_market_direction(session))
            now = self._now()
            _freshness(direction.get('reward_checked_at'), now, 'reward_data', max_age=60)
            _freshness(direction['book'].get('received_at'), now, 'book_freshness', max_age=60)
        except Exception:
            now = self._now()
            direction = None
        with self._mutex:
            current = self.store.lp_session(session_id)
            timers = deepcopy(current.get('buy_yield_unknown') or {})
            for oid, row in buys.items():
                remaining = self._queue_row_remaining(row)
                estimate = None
                if direction is not None:
                    try:
                        estimate = minimum_order_estimate(direction,
                            {'price': row['price'], 'quantity': remaining}, now, resting_quantity=remaining)
                    except (ValueError, KeyError, TypeError):
                        pass
                if estimate is not None and estimate.get('state') == 'known':
                    timers.pop(oid, None)
                else:
                    timers.setdefault(oid, {'account_id': wallet, 'unknown_since': _iso(now)})
            if timers != (current.get('buy_yield_unknown') or {}):
                self.store.lp_update_session(session_id, patch={'buy_yield_unknown': timers})
        for oid in buys:
            timer = timers.get(oid)
            if (not timer or timer.get('account_id') != wallet
                    or now - _timestamp(timer['unknown_since']) < timedelta(seconds=600)):
                continue
            with self._mutex:
                if not self._mutation_allowed():
                    continue
                current = self.store.lp_session(session_id)
                if (not current or current.get('order_identity_conflict')
                        or str(current.get('account_id') or '').casefold() != wallet):
                    continue
                actual_timer = (current.get('buy_yield_unknown') or {}).get(oid)
                if actual_timer != timer:
                    continue
                current_order = self._order_history(current).get(oid)
                remaining = self._queue_row_remaining(current_order)
                if (not current_order or current_order.get('side') != 'BUY'
                        or current_order.get('status') != 'LIVE'
                        or current_order.get('token_id') != current.get('token_id')
                        or remaining is None or remaining <= 0):
                    continue
                previous_key = actual_timer.get('cancel_request_key')
                if previous_key:
                    previous = next((a for a in self.store.lp_actions(session_id)
                        if a.get('action_key') == previous_key), None)
                    if (not previous or previous.get('session_id') != session_id
                            or previous.get('order_id') != oid
                            or previous.get('role') != 'reconciliation_cancel'
                            or previous.get('reason') != 'buy_yield_unknown_timeout'
                            or previous.get('state') != 'rejected'
                            or previous.get('post_started') is not False
                            or previous.get('submit_stage') != 'pre_send_rejected'):
                        continue
                attempts = self.begin_order_cancel((oid,))
                own = [(sid, key, {**payload, 'reason': 'buy_yield_unknown_timeout'})
                    for sid, key, payload in attempts if sid == session_id]
                if len(own) != 1:
                    continue
                sid, key, payload = own[0]
                self.store.lp_upsert_action(sid, key, state='pending', payload=payload)
                saved = deepcopy(current.get('buy_yield_unknown') or {})
                saved[oid] = {**timer, 'cancel_request_key': key}
                self.store.lp_update_session(session_id, patch={'buy_yield_unknown': saved})
            try:
                self._cancel_order(oid, attempts=own)
            except _MutationBlocked:
                # The lane committed the exact unsent rejection and its proof.
                pass
            except Exception:
                logger.exception('lp_buy_yield_unknown_cancel_failed')

    def _apply_tick_snapshot(
        self, session, snapshot, initial_revision, reason, *,
        apply_lock, account_round=None,
    ):
        session_id = str(session['session_id'])
        if reason == 'order_identity_conflict':
            return self._status_payload(session)
        snapshot_error = ValueError(reason) if reason and reason not in {'execution_lock', 'session_changed'} else None
        if snapshot_error is not None:
            return self._handle_snapshot_failure_fenced(
                session,
                snapshot_error,
                int(initial_revision),
                snapshot.get("_lp_trade_generation") if isinstance(snapshot, Mapping) else None,
            )
        if snapshot is not None:
            ownership_reason = self._unowned_target_order_reason(session, snapshot)
            if ownership_reason:
                state = str(session.get("state") or "")
                resume_state = (
                    str(session.get("resume_state") or "")
                    if state == "needs_attention"
                    else state
                ) or "entry_open"
                if resume_state not in {"entry_open", "passive_exit", "stop_loss_exit", "review"}:
                    resume_state = "review"
                updated = self.store.lp_update_session(
                    session_id,
                    state="needs_attention",
                    patch={
                        "reconciliation": ownership_reason,
                        "resume_state": resume_state,
                        **self._needs_attention_notify_patch(session, self._now()),
                    },
                )
                return self._status_payload(updated)
        if snapshot is not None and not self._account_bundle_is_current(snapshot):
            # The bundle was valid at publication, but a trade registered
            # before this post-publication boundary. Never score, protect, or
            # complete strategy work from that old bundle.
            return self._status_payload(self._publish_account_round_rejected(session_id))
        protected_levels: set[str] = set()
        protection_writes = 0
        if snapshot is not None:
            try:
                protected_levels, protection_writes = (
                    self._apply_triggered_protection_cancel_off_lock(
                        session, snapshot
                    )
                )
            except Exception:
                # A partial protection write is fenced by the durable
                # revision below.  If no write happened, the ordinary
                # serialized apply can retry the protection operation.
                protected_levels = set()
                protection_writes = 0

        if reason == "execution_lock":
            # Exact-owned protection has its own fence; financial publication
            # still waits for the execution lock and reuses the pending facts.
            current = self.store.lp_session(session_id) or session
            return self._status_payload(current)

        # Scoring is a read, not a trading action. Keep its network wait out
        # of both apply locks so other sessions can publish fresh funds.
        # A partial fill must collect remaining BUYs before any scoring read.
        scoring = {}
        if snapshot is not None and not reason and not (
            _decimal(session.get("buy_filled_quantity", 0), "buy_filled_quantity") > 0
            and not self._group_buys_terminal(session, snapshot)
        ):
            scoring = self._read_scoring(session)
        if snapshot is not None and not self._account_bundle_is_current(snapshot):
            return self._status_payload(self._publish_account_round_rejected(session_id))
        if snapshot is not None and not reason:
            generation = snapshot.get("_lp_trade_generation", snapshot.get("_lp_observed_trade_generation"))
            if isinstance(generation, int):
                self._prepare_reconcile_actions_off_lock(
                    session, snapshot, scoring, int(initial_revision), int(generation)
                )
                prepared = self.store.lp_session(session_id)
                if prepared and prepared.get("state") == "review" and session.get("state") != "review":
                    return self._status_payload(prepared)
        apply_handle: object | None = None
        deferred_notices: list[tuple[str, str, str, Callable[[], None]]] = []
        production_reconcile = True

        def apply_locked() -> dict[str, object]:
            nonlocal apply_handle, production_reconcile, session, snapshot, snapshot_error
            if apply_lock is not None:
                apply_handle = apply_lock[0]()
                if apply_handle is None:
                    current = self.store.lp_session(session_id) or session
                    return self._status_payload(current)
            if snapshot is not None and not self._account_bundle_is_current(snapshot):
                # Close the window opened while the scoring network read ran.
                return self._status_payload(self._publish_account_round_rejected(session_id))
            with self._mutex:
                current_with_revision = getattr(
                    self.store, "lp_session_with_revision", None
                )
                if callable(current_with_revision):
                    current_row = current_with_revision(session_id, trading=True)
                else:
                    current = self.store.lp_session(session_id)
                    current_row = (
                        (current, self.store.lp_session_revision(session_id))
                        if current is not None
                        else None
                    )
                if current_row is None:
                    return self._status_payload(session)
                current, current_revision = current_row
                if snapshot is not None and not self._account_bundle_is_current(snapshot):
                    return self._status_payload(self._publish_account_round_rejected(session_id))
                expected_revision = int(initial_revision)
                if current_revision != expected_revision:
                    if protected_levels and set(self._session_order_ids(current)) == set(self._session_order_ids(session)):
                        current = self._apply_queue_protection(
                            current,
                            snapshot,
                            skip_cancel_keys=protected_levels,
                            trade_revision=expected_revision,
                        )
                    return self._status_payload(current)
                if snapshot_error is not None:
                    return self._handle_snapshot_failure(current, snapshot_error)
                if snapshot is None:
                    raise RuntimeError("lp_tick_snapshot_missing")
                reconcile = self._reconcile_session
                if (
                    getattr(reconcile, "__func__", None)
                    is PolymarketLPService._reconcile_session
                ):
                    return reconcile(
                        current,
                        prefetched_snapshot=snapshot,
                        protection_skip_keys=protected_levels,
                        facts_applied=True,
                        scoring=scoring,
                        trade_revision=(
                            expected_revision
                            if isinstance(snapshot.get('_lp_trade_generation'), int)
                            else None
                        ),
                    )
                production_reconcile = False
                return reconcile(current)

        cancel_notices = []
        self._deferred_protection_notices.cancels = cancel_notices
        self._deferred_protection_notices.notices = deferred_notices
        self._facts_apply_lock.acquire()
        try:
            result = apply_locked()
        except Exception as exc:
            # One group's reconciliation failure must not swallow the others.
            result = {
                "state": "error",
                "session_id": session_id,
                "error": type(exc).__name__,
            }
        finally:
            try:
                if apply_handle is not None and apply_lock is not None:
                    apply_lock[1](apply_handle)
            finally:
                self._deferred_protection_notices.notices = None
                self._facts_apply_lock.release()
                self._deferred_protection_notices.cancels = None
        for notice in cancel_notices:
            self._start_protection_cancel_notice(*notice)
        for title, message, xiaoai, mark_delivered in deferred_notices:
            if self._notify_protection(title, message, xiaoai):
                mark_delivered()
        if production_reconcile and str(result.get("session_id")) == session_id:
            current = self.store.lp_session(session_id)
            if current is not None:
                result = self._status_payload(current)
        return result

    def _prepare_reconcile_actions_off_lock(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        scoring: Mapping[str, object],
        initial_revision: int,
        trade_generation: int,
    ) -> None:
        """Claim reconcile trades atomically, then send only the claimed intent."""
        current = self.store.lp_session(str(session["session_id"]))
        if current is None:
            return
        session_id = str(current["session_id"])
        reason = "monitor"
        try:
            review_at = _timestamp(current.get("review_at"), name="review_at")
        except (TypeError, ValueError):
            review_at = None
        if review_at is not None and self._now() >= review_at and str(current.get("state")) not in {"review", "complete", "entry_rejected"}:
            reason = "review_deadline"
        elif str(current.get("state")) == "review" and (
            current.get("stop_requested") is True
            or current.get("review_status") == "awaiting_reconciliation"
        ):
            reason = "review_reconcile"
        elif _decimal(
            current.get("buy_filled_quantity", 0), "buy_filled_quantity"
        ) > 0 and not self._group_buys_terminal(current, snapshot):
            reason = "group_fill_collect"
        elif (
            scoring.get("role") == "entry"
            and scoring.get("value") is not True
            and not current.get("entry_cancel_requested")
        ):
            try:
                lost_at = _timestamp(
                    current.get("scoring_lost_at"), name="scoring_lost_at"
                )
            except (TypeError, ValueError):
                lost_at = None
            if lost_at is not None and (
                self._now() - lost_at
            ).total_seconds() >= float(SCORING_FAILURE_WINDOW_SECONDS):
                reason = "scoring_failure"
        if reason != "monitor":
            self._claim_and_send_owned_cancels_off_lock(
                current,
                snapshot,
                initial_revision=initial_revision,
                trade_generation=trade_generation,
                reason=reason,
                allow_history=True,
            )
            if reason == "review_deadline":
                after_cancel = self.store.lp_session(session_id) or current
                if str(after_cancel.get("reconciliation") or "").startswith("deadline_cancel_"):
                    return
                self.store.lp_update_session(
                    session_id, state="review", patch={"review_status": "awaiting_reconciliation"}
                )
                return
            if self.store.lp_session_revision(session_id, trading=True) != initial_revision:
                return
        current = self.store.lp_session(session_id) or current
        if self.store.lp_session_revision(session_id, trading=True) != initial_revision:
            return
        convergence_patch: dict[str, object] = {}
        try:
            convergence_patch = self._order_history_patch(current, snapshot)
            current = {**current, **convergence_patch}
            fill_patch = self._fill_patch(current, snapshot)
            convergence_patch.update(fill_patch)
            current = {**current, **fill_patch}
        except ValueError:
            return
        current = self._reconcile_protected_exit(current, snapshot)
        rows_by_id = self._queue_level_rows(snapshot)
        for key, bucket in self._queue_protection_levels(current).items():
            converged = self._converge_queue_protection(
                current, bucket, rows_by_id, bucket_key=key
            )
            if converged is not None:
                current = self.store.lp_merge_queue_protection_bucket(
                    session_id, level_key=key, bucket=converged
                )
                self._notify_committed_protection_cancels(current)
        protection = current.get("queue_protection")
        canceling = any(
            str(bucket.get("state")) == "canceling"
            for bucket in self._queue_protection_levels(current).values()
            if isinstance(bucket, Mapping)
        ) or (
            isinstance(protection, Mapping)
            and str(protection.get("state")) == "canceling"
        )
        if canceling and not self._group_buys_terminal(current, snapshot):
            return
        residual = _decimal(current.get("residual_quantity", 0), "residual_quantity")
        loss = self._opening_loss_from_session(current)
        business_patch: dict[str, object] = {"opening_loss": loss}
        if loss is not None and loss >= STOP_LOSS:
            business_patch.update(self._stop_loss_latch_patch(current, loss))
            business_patch["state"] = "stop_loss_exit"
        stop_loss_exit = (
            bool(current.get("stop_loss_latched"))
            or str(current.get("state")) == "stop_loss_exit"
            or business_patch.get("state") == "stop_loss_exit"
        )
        if stop_loss_exit:
            if str(current.get("state")) != "stop_loss_exit":
                business_patch.update({"state": "stop_loss_exit", "stop_loss_latched": True})
            current = {**current, **business_patch}
            if not self._owned_sells_terminal(current, snapshot):
                patch = {**convergence_patch, **business_patch}
                patch.pop("state", None)
                self._request_passive_cancel(
                    current,
                    expected_generation=trade_generation,
                    expected_trade_revision=initial_revision,
                    claim_patch=patch,
                    claim_state="stop_loss_exit",
                )
                return
            if residual > 0 and not current.get("protected_exit_order_id"):
                claim_state = (
                    str(business_patch["state"])
                    if business_patch.get("state")
                    else None
                )
                patch = {**convergence_patch, **business_patch}
                patch.pop("state", None)
                self._submit_protected_exit(
                    current,
                    residual,
                    snapshot,
                    trade_generation=trade_generation,
                    expected_trade_revision=initial_revision,
                    claim_patch=patch,
                    claim_state=claim_state,
                )
            return
        if residual > 0 and str(current.get("state")) != "review":
            self._ensure_passive_exit(
                current,
                snapshot,
                residual,
                trade_generation=trade_generation,
                expected_trade_revision=initial_revision,
            )

    def _claim_trade_action(
        self,
        session: Mapping[str, object],
        action_key: str,
        payload: Mapping[str, object],
        patch: Mapping[str, object],
        *,
        trade_generation: int,
        expected_trade_revision: int | None = None,
        claim_state: str | None = None,
    ) -> Mapping[str, object] | None:
        """CAS-claim one submit intent; manual and monitor share this boundary."""
        claim_method = getattr(self.store, "lp_claim_trade_actions", None)
        if not callable(claim_method) or expected_trade_revision is None:
            return None
        generation_reader = getattr(self.store, "lp_trade_generation", None)
        generation = (
            int(trade_generation)
            if trade_generation is not None
            else int(generation_reader())
            if callable(generation_reader)
            else None
        )
        if generation is None:
            return None
        with self._mutex:
            claims = claim_method(
                str(session["session_id"]),
                trade_revision=int(expected_trade_revision),
                trade_generation=generation,
                actions=[(action_key, payload)],
                patch=patch,
                state=claim_state,
            )
        if not claims:
            if (
                self.store.lp_session_revision(str(session["session_id"]), trading=True) != expected_trade_revision
                or self.store.lp_trade_generation() != generation
            ):
                self._publish_account_round_rejected(str(session["session_id"]))
            return None
        return self.store.lp_session(str(session["session_id"])) or session

    def _current_cancel_order_ids(
        self, session: Mapping[str, object], snapshot: Mapping[str, object],
        trade_generation: int | None,
    ) -> set[str] | None:
        """Prove absence for cancel selection only; never infer terminality."""
        generation = snapshot.get("_lp_trade_generation")
        account = snapshot.get("account")
        if (
            type(generation) is not int or generation != trade_generation
            or not callable(self._facts_validator)
            or not isinstance(account, Mapping)
            or account.get("authenticated") is not True
            or account.get("open_orders_complete") is not True
        ):
            return None
        orders = account.get("open_orders")
        if not isinstance(orders, (list, tuple)):
            return None
        order_ids: set[str] = set()
        for order in orders:
            if not isinstance(order, Mapping):
                return None
            order_id = _field(order, "order_id", _field(order, "id", ""))
            token_id = _field(order, "token_id", _field(order, "asset_id", ""))
            if (
                not isinstance(order_id, str) or not order_id.strip()
                or not isinstance(token_id, str) or not token_id.strip()
            ):
                return None
            order_ids.add(order_id)
        try:
            self._facts_validator(session, snapshot)
        except (ValueError, RuntimeError, OSError):
            return None
        if not self._account_bundle_is_current(snapshot):
            return None
        return order_ids | {
            self._order_id(order) for order in _items(snapshot.get("orders"))
            if str(_field(order, "status", "")).upper() in {"LIVE", "OPEN", "ACCEPTED", "PENDING"}
        }

    def _claim_and_send_owned_cancels_off_lock(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        *,
        initial_revision: int,
        trade_generation: int,
        reason: str,
        allow_history: bool = False,
    ) -> None:
        session_id = str(session["session_id"])
        claims: list[tuple[str, str, Mapping[str, object]]] = []
        requested_by_order: dict[str, str] = {}
        error_prefix = "deadline" if reason == "review_deadline" else reason
        with self._mutex:
            row = self.store.lp_session_with_revision(session_id, trading=True)
            if row is None:
                return
            current, current_revision = row
            if current_revision != initial_revision:
                return
            current, _ = row
            history = self._order_history(current)
            venue_statuses = {
                self._order_id(order): str(_field(order, "status", "")).upper()
                for order in _items(snapshot.get("orders"))
            }

            def order_status(order_id: str) -> str:
                status = venue_statuses.get(order_id)
                if not status and allow_history:
                    status = str(
                        history.get(order_id, {}).get("status") or "UNKNOWN"
                    ).upper()
                return status

            blocked_orders = self._recent_pending_cancel_order_ids(session_id)
            targets: list[str] = []
            patch: dict[str, object] = {}
            protected_id = str(current.get("protected_exit_order_id") or "")
            cancel_fields = [
                ("entry_order_id", "entry_cancel_requested"),
            ]
            if reason != "group_fill_collect":
                cancel_fields.append(("passive_exit_order_id", "passive_cancel_requested"))
            for key, requested_key in cancel_fields:
                order_id = str(current.get(key) or "")
                if (
                    order_id
                    and not bool(current.get(requested_key))
                    and order_status(order_id)
                    and order_status(order_id) not in TERMINAL_ORDER_STATES
                    and order_id not in blocked_orders
                ):
                    targets.append(order_id)
                    requested_by_order[order_id] = requested_key
            owned_requested = {
                str(value) for value in _items(current.get("owned_cancel_requested"))
            }
            for order_id, record in history.items():
                if (
                    (
                        reason == "group_fill_collect"
                        and order_id == str(current.get("passive_exit_order_id") or "")
                    )
                    or not order_id
                    or order_id == protected_id
                    or order_id in targets
                    or str(record.get("side") or "").upper() != "SELL"
                    or order_id in owned_requested
                    or order_id in blocked_orders
                    or order_status(order_id) in TERMINAL_ORDER_STATES
                ):
                    continue
                targets.append(order_id)
            requested_augments = {
                str(value) for value in _items(current.get("augment_cancel_requested"))
            }
            for value in _items(current.get("augment_order_ids")):
                order_id = str(value or "")
                if (
                    order_id
                    and order_id not in requested_augments
                    and order_status(order_id)
                    and order_status(order_id) not in TERMINAL_ORDER_STATES
                    and order_id not in blocked_orders
                ):
                    targets.append(order_id)
            if allow_history:
                current_order_ids = self._current_cancel_order_ids(
                    current, snapshot, trade_generation
                )
                if current_order_ids is not None:
                    targets = [order_id for order_id in targets if order_id in current_order_ids]
            if targets:
                claim_method = getattr(self.store, "lp_claim_trade_actions", None)
                if callable(claim_method):
                    claims = claim_method(
                        session_id,
                        trade_revision=initial_revision,
                        trade_generation=trade_generation,
                        actions=[
                            (
                                f"{session_id}:reconcile-cancel:{reason}:{order_id}:{uuid.uuid4().hex}",
                                {
                                    "role": "reconciliation_cancel",
                                    "reason": reason,
                                    "order_id": order_id,
                                    "submit_requested_at": _iso(self._now()),
                                },
                            )
                            for order_id in targets
                        ],
                        patch=patch,
                    )
        for _session_id, _action_key, payload in claims:
            order_id = str(payload["order_id"])
            try:
                acknowledged = self._cancel_order(
                    order_id,
                    attempts=[(_session_id, _action_key, dict(payload))],
                )
            except Exception as exc:
                self.store.lp_update_session(
                    session_id,
                    state="needs_attention",
                    patch={
                        "reconciliation": f"{error_prefix}_cancel_{type(exc).__name__}",
                        "resume_state": "review",
                        "review_status": "awaiting_reconciliation",
                    },
                )
                continue
            if not acknowledged:
                self.store.lp_update_session(
                    session_id,
                    state="needs_attention",
                    patch={
                        "reconciliation": f"{error_prefix}_cancel_not_acknowledged",
                        "resume_state": "review",
                        "review_status": "awaiting_reconciliation",
                    },
                )
                continue
            current = self.store.lp_session(session_id) or session
            requested_key = requested_by_order.get(order_id)
            if requested_key:
                patch = {requested_key: True}
            elif order_id in {
                str(value) for value in _items(current.get("augment_order_ids"))
            }:
                patch = {
                    "augment_cancel_requested": sorted(
                        {
                            str(value)
                            for value in _items(current.get("augment_cancel_requested"))
                        }
                        | {order_id}
                    )
                }
            else:
                patch = {
                    "owned_cancel_requested": sorted(
                        {str(value) for value in _items(current.get("owned_cancel_requested"))}
                        | {order_id}
                    )
                }
            if reason in {"review_deadline", "review_reconcile", "scoring_failure"}:
                current = self.store.lp_update_session(
                    session_id,
                    state="review",
                    patch={**patch, "review_status": "awaiting_reconciliation"},
                )
            else:
                current = self.store.lp_update_session(session_id, patch=patch)
            self._mark_group_buckets_canceling(current, reason)

    def _recent_pending_cancel_order_ids(self, session_id: str) -> set[str]:
        """Exact IDs whose durable cancel intent is still awaiting a reply."""
        now = self._now()
        blocked: set[str] = set()
        for action in self.store.lp_actions(session_id):
            if submission_action_kind(action) != 'cancel':
                continue
            if str(action.get("state")) != "pending":
                continue
            order_id = str(action.get("order_id") or "")
            if not order_id:
                continue
            try:
                pending_recent = (
                    now - _timestamp(action.get("updated_at"), name="updated_at")
                ).total_seconds() < 60
            except (TypeError, ValueError):
                pending_recent = True
            if pending_recent:
                blocked.add(order_id)
        return blocked

    def _apply_triggered_protection_cancel_off_lock(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
    ) -> tuple[set[str], int]:
        """Plan and authorize every triggered bucket before any venue call."""

        protection = session.get("queue_protection")
        buckets = self._queue_protection_levels(session)
        if not isinstance(protection, Mapping) or not buckets:
            return set(), 0
        current_session = self.store.lp_session(str(session["session_id"]))
        concurrent_group_change = (
            isinstance(current_session, Mapping)
            and set(self._session_order_ids(current_session))
            != set(self._session_order_ids(session))
        )
        if (
            self._snapshot_has_group_buy_fill(session, snapshot)
            and not concurrent_group_change
        ):
            return set(), 0
        rows_by_id = self._queue_level_rows(snapshot)
        session_id = str(session["session_id"])
        merger = getattr(self.store, "lp_merge_queue_protection_bucket", None)
        if not callable(merger):
            merger = getattr(self.store, "lp_merge_queue_protection", None)
        if not callable(merger):
            return set(), 0

        plans: list[tuple[str, Mapping[str, object], dict[str, object]]] = []
        for key, bucket in buckets.items():
            state = str(bucket.get("state") or "")
            only_order_ids: list[str] | None = None
            if state == "canceling":
                only_order_ids = [
                    str(value)
                    for value in _items(bucket.get("cancel_failed"))
                    if str(value or "")
                ]
                retryable: list[str] = []
                for order_id in only_order_ids:
                    row = rows_by_id.get(order_id)
                    if row is not None:
                        status = str(_field(row, "status", "") or "").upper()
                        matched = _maybe_decimal(_field(row, "size_matched"))
                        if status in TERMINAL_ORDER_STATES or (
                            matched is not None and matched > 0
                        ):
                            continue
                    retryable.append(order_id)
                only_order_ids = retryable
                if not only_order_ids:
                    continue
            elif state != "triggered":
                evaluation = self._bucket_queue_protection_evaluation(
                    session, bucket, snapshot, rows_by_id
                )
                if evaluation is None or str(evaluation.get("state")) != "triggered":
                    continue
                bucket = evaluation
            plan, _blocked, _patch = self._plan_bucket_protection_cancel(
                session,
                snapshot,
                bucket,
                reason=str(bucket.get("cancel_reason") or "queue_ahead_ratio"),
                only_order_ids=only_order_ids,
                notify_blocked=False,
            )
            if plan is not None:
                plans.append((str(key), bucket, plan))

        if not plans:
            return set(), 0
        actions = [
            {
                "action_key": plan["action_key"],
                "payload": plan["intent_payload"],
            }
            for _key, _bucket, plan in plans
        ]
        try:
            self.store.lp_register_fenced_actions(
                session_id,
                actions,
                expected_generation=snapshot.get("_lp_trade_generation"),
            )
        except ValueError as exc:
            if str(exc) == "account_round_invalid":
                return set(), 0
            raise

        protected_levels: set[str] = set()
        writes = 0
        for key, bucket, plan in plans:
            next_bucket, patch = self._execute_bucket_protection_cancel(
                session, snapshot, bucket, plan, bucket_key=str(key)
            )
            if str(next_bucket.get("state") or "") not in {
                "canceling",
                "canceled",
                "partially_filled",
            }:
                continue
            if hasattr(self.store, "lp_merge_queue_protection_bucket"):
                committed = merger(
                    session_id,
                    level_key=key,
                    bucket=next_bucket,
                    patch=patch,
                )
            else:
                committed = merger(
                    session_id,
                    queue_protection={
                        "version": 2,
                        "levels": {key: next_bucket},
                    },
                    patch=patch,
                )
            self._notify_committed_protection_cancels(committed)
            protected_levels.add(key)
            writes += 1
        return protected_levels, writes

    def _snapshot_has_group_buy_fill(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
    ) -> bool:
        """Return whether the snapshot proves a fill for this group's BUY."""

        token_id = str(session.get("token_id") or "")
        for order_id in self._session_order_ids(session):
            if not order_id:
                continue
            try:
                quantity, _ = self._trade_totals(
                    snapshot,
                    order_id,
                    "BUY",
                    token_id=token_id or None,
                )
            except ValueError:
                # An uncertain trade read belongs to the serialized
                # reconciliation path; do not issue a speculative cancel.
                return True
            if quantity > 0:
                return True
        return False

    @staticmethod
    def _lp_tick_aggregate(
        payloads: list[dict[str, object]],
    ) -> dict[str, object]:
        """Build the tick report per the issue 166 aggregation contract."""

        if len(payloads) == 1:
            return {**payloads[0], "sessions": list(payloads)}
        oldest: dict[str, object] = {}
        for key in ("account_checked_at", "book_checked_at"):
            oldest[key] = PolymarketLPService._oldest_stamp(
                [payload.get(key) for payload in payloads]
            )
        states = {
            str(payload.get("state") or "") for payload in payloads
        }
        aggregate_state = "ok"
        for worst in ("needs_attention", "busy", "error", "failed"):
            if worst in states:
                aggregate_state = worst
                break
        return {
            "state": aggregate_state,
            "session_id": None,
            "sessions": list(payloads),
            "account_checked_at": oldest["account_checked_at"],
            "book_checked_at": oldest["book_checked_at"],
        }

    @staticmethod
    def _oldest_stamp(values: list[object]) -> object:
        """Return the oldest parseable stamp; None when none is parseable."""

        best: tuple[datetime, object] | None = None
        for value in values:
            if value is None:
                continue
            try:
                moment = _timestamp(value, name="stamp")
            except ValueError:
                continue
            if best is None or moment < best[0]:
                best = (moment, value)
        return best[1] if best is not None else None

    def _reconcile_session(
        self,
        session: Mapping[str, object],
        *,
        prefetched_snapshot: Mapping[str, object] | None = None,
        protection_skip_keys: Collection[str] = (),
        facts_applied: bool = False,
        scoring: Mapping[str, object] | None = None,
        trade_revision: int | None = None,
    ) -> dict[str, object]:
        """Run one group-level monitoring/reconciliation iteration.

        A tick may supply the main snapshot fetched outside ``_mutex``.
        Scoring reads also arrive prefetched; their order identity is checked
        before applying. Already-triggered bucket cancels are skipped here
        so they cannot be sent twice by the same tick.
        """

        if session.get("order_identity_conflict"):
            return self._status_payload(session)
        state = str(session.get("state"))
        if state in {"entry_rejected", "complete"}:
            if facts_applied and prefetched_snapshot is not None:
                session = self._apply_queue_protection(
                session,
                prefetched_snapshot,
                skip_cancel_keys=protection_skip_keys,
                trade_revision=trade_revision,
            )
            return self._status_payload(session)
        try:
            request = self._normalize_request(session)
            snapshot = (
                prefetched_snapshot
                if prefetched_snapshot is not None
                else self._read_snapshot(request)
            )
        except ValueError as exc:
            return self._handle_snapshot_failure(session, exc)
        try:
            patch = {} if facts_applied else self._fill_patch(session, snapshot)
        except ValueError as exc:
            outage_patch: dict[str, object] = {
                "reconciliation": str(exc),
                "resume_state": state
                if state != "needs_attention"
                else session.get("resume_state"),
            }
            failures = self._queue_protection_data_failure(session, str(exc))
            if failures is not None:
                outage_patch["queue_protection"] = failures
            outage_patch.update(
                self._needs_attention_notify_patch(
                    session, self._now(), protection=failures
                )
            )
            updated = self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch=outage_patch,
            )
            conservative = self._conservative_protection_cancel(updated, failures)
            if conservative is not None:
                return self._status_payload(conservative)
            return self._status_payload(updated)
        ownership_reason = self._unowned_target_order_reason(session, snapshot)
        if ownership_reason is not None:
            resume_state = (
                str(session.get("resume_state") or "")
                if state == "needs_attention"
                else state
            ) or "entry_open"
            patch.update(
                {
                    "reconciliation": ownership_reason,
                    "resume_state": resume_state,
                }
            )
            patch.update(
                self._needs_attention_notify_patch(
                    session,
                    self._now(),
                    protection=(
                        patch["queue_protection"]
                        if isinstance(patch.get("queue_protection"), Mapping)
                        else None
                    ),
                )
            )
            updated = self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch=patch,
            )
            return self._status_payload(updated)
        updated = session if facts_applied else self.store.lp_update_session(str(session["session_id"]), patch=patch)
        session = updated
        try:
            session = session if facts_applied else self._sync_order_history(session, snapshot)
        except ValueError as exc:
            updated = self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch={
                    "reconciliation": str(exc),
                    "resume_state": state
                    if state != "needs_attention"
                    else session.get("resume_state"),
                    **self._needs_attention_notify_patch(session, self._now()),
                },
            )
            return self._status_payload(updated)
        if state == "needs_attention":
            resume_state = str(session.get("resume_state") or "")
            if not resume_state:
                resume_state = "review" if session.get("stop_requested") else "entry_open"
            if resume_state not in {"entry_open", "passive_exit", "stop_loss_exit", "review"}:
                resume_state = "review"
            session = self.store.lp_update_session(
                str(session["session_id"]),
                state=resume_state,
                patch=self._needs_attention_recovery_patch(session),
            )
            state = resume_state
        # Issue 152: queue protection runs inside the existing one-second
        # monitor tick, before any exit reconciliation can mutate orders.
        session = self._apply_queue_protection(
            session,
            snapshot,
            skip_cancel_keys=protection_skip_keys,
            trade_revision=trade_revision,
        )
        session = self._reconcile_protected_exit(session, snapshot)
        if _decimal(session.get("buy_filled_quantity", 0), "buy_filled_quantity") > 0:
            # Issue 167 D3: a fill at any level collects the whole group's
            # own BUYs; economics stay group-merged.
            session = self._collect_group_buys(
                session, snapshot, trade_revision=trade_revision
            )
            if not self._group_buys_terminal(session, snapshot):
                return self._status_payload(session)
        if state == "review":
            self._update_scoring(session, scoring)
            session = self.store.lp_session(str(session["session_id"])) or session
            return self._review_iteration(
                session, snapshot, trade_revision=trade_revision
            )
        self._update_scoring(session, scoring)
        session = self.store.lp_session(str(session["session_id"])) or session
        if str(session.get("state")) == "review":
            return self._review_iteration(
                session, snapshot, trade_revision=trade_revision
            )
        now = self._now()
        review_at = (
            None
            if session.get("review_at") is None
            else _timestamp(session["review_at"], name="review_at")
        )
        residual = _decimal(session.get("residual_quantity", 0), "residual_quantity")
        loss = self._opening_loss_from_session(session)
        session = self.store.lp_update_session(
            str(session["session_id"]),
            patch={"opening_loss": loss},
        )
        # A missing bid, fee, or position reconciliation must not prevent
        # the absolute review deadline from cancelling known quotes.
        if review_at is not None and now >= review_at:
            try:
                self._cancel_owned_orders(
                    session,
                    snapshot=snapshot,
                    expected_generation=snapshot.get("_lp_trade_generation"),
                    expected_trade_revision=trade_revision,
                )
            except Exception as exc:
                updated = self.store.lp_update_session(
                    str(session["session_id"]),
                    state="needs_attention",
                    patch={
                        "reconciliation": f"deadline_cancel_{type(exc).__name__}",
                        "resume_state": "review",
                        "review_status": "awaiting_reconciliation",
                    },
                )
                return self._status_payload(updated)
            # Issue 167: the deadline sweep cancels every own BUY; the price
            # buckets follow into canceling so receipts settle them.
            session = self.store.lp_session(str(session["session_id"])) or session
            session = self._mark_group_buckets_canceling(session, "review_deadline")
            updated = self.store.lp_update_session(
                str(session["session_id"]),
                state="review",
                patch={"review_status": "awaiting_reconciliation"},
            )
            return self._status_payload(updated)
        if loss is not None and loss >= STOP_LOSS:
            session = self.store.lp_update_session(
                str(session["session_id"]),
                state="stop_loss_exit",
                patch=self._stop_loss_latch_patch(session, loss),
            )
        session = self.store.lp_session(str(session["session_id"])) or session
        if bool(session.get("stop_loss_latched")) or str(session.get("state")) == "stop_loss_exit":
            if str(session.get("state")) != "stop_loss_exit":
                session = self.store.lp_update_session(
                    str(session["session_id"]),
                    state="stop_loss_exit",
                    patch={"stop_loss_latched": True},
                )
            session = self._request_passive_cancel(
                session,
                expected_generation=snapshot.get("_lp_trade_generation"),
                expected_trade_revision=trade_revision,
            )
            session = self.store.lp_session(str(session["session_id"])) or session
            if not self._owned_sells_terminal(session, snapshot):
                return self._status_payload(session)
            residual = _decimal(session.get("residual_quantity", 0), "residual_quantity")
            if residual > 0 and not session.get("protected_exit_order_id"):
                self._submit_protected_exit(
                    session, residual, snapshot, trade_revision=trade_revision
                )
                session = self.store.lp_session(str(session["session_id"])) or session
            return self._complete_if_flat(session, snapshot)
        if loss is None:
            return self._complete_if_flat(session, snapshot)
        if residual > 0:
            self._ensure_passive_exit(
                session, snapshot, residual, trade_revision=trade_revision
            )
            session = self.store.lp_session(str(session["session_id"])) or session
        return self._complete_if_flat(session, snapshot)

    def _handle_snapshot_failure(
        self, session: Mapping[str, object], exc: ValueError
    ) -> dict[str, object]:
        """Persist one failed main snapshot read in serialized apply."""

        if str(exc) == "account_round_invalid":
            return self._status_payload(
                self._publish_account_round_rejected(str(session["session_id"]))
            )
        state = str(session.get("state"))
        patch: dict[str, object] = {
            "reconciliation": str(exc),
            "resume_state": state
            if state != "needs_attention"
            else session.get("resume_state"),
        }
        failures = self._queue_protection_data_failure(session, str(exc))
        if failures is not None:
            patch["queue_protection"] = failures
        patch.update(
            self._needs_attention_notify_patch(
                session, self._now(), protection=failures
            )
        )
        updated = self.store.lp_update_session(
            str(session["session_id"]),
            state="needs_attention",
            patch=patch,
        )
        conservative = self._conservative_protection_cancel(updated, failures)
        if conservative is not None:
            return self._status_payload(conservative)
        return self._status_payload(updated)

    def _handle_snapshot_failure_fenced(
        self,
        session: Mapping[str, object],
        exc: ValueError,
        initial_revision: int,
        trade_generation: int | None,
    ) -> dict[str, object]:
        """Publish a failed read from the current durable session image."""

        if str(exc) == "account_round_invalid":
            return self._status_payload(
                self._publish_account_round_rejected(str(session["session_id"]))
            )
        session_id = str(session["session_id"])
        failures = None
        generation_reader = getattr(self.store, "lp_trade_generation", None)
        generation = (
            int(trade_generation)
            if trade_generation is not None
            else int(generation_reader())
            if callable(generation_reader)
            else None
        )
        with self._mutex:
            row = self.store.lp_session_with_revision(session_id, trading=True)
            if row is None:
                return self._status_payload(session)
            current, current_revision = row
            if current_revision != initial_revision:
                return self._status_payload(current)
            state = str(current.get("state"))
            patch: dict[str, object] = {
                "reconciliation": str(exc),
                "resume_state": state
                if state != "needs_attention"
                else current.get("resume_state"),
            }
            failures = self._queue_protection_data_failure(current, str(exc))
            if failures is not None:
                patch["queue_protection"] = failures
            patch.update(
                self._needs_attention_notify_patch(
                    current, self._now(), protection=failures
                )
            )
            try:
                current, _ = self.store.lp_publish_facts(
                    session_id,
                    initial_revision,
                    state="needs_attention",
                    patch=patch,
                    publish=self._facts_publisher,
                    error=str(exc),
                    trade_generation=generation,
                )
            except ValueError:
                current = self.store.lp_session(session_id) or current
        conservative = self._conservative_protection_cancel(current, failures)
        if conservative is not None:
            return self._status_payload(conservative)
        return self._status_payload(current)

    def _collect_group_buys(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        *,
        trade_revision: int | None = None,
    ) -> Mapping[str, object]:
        """After any fill, collect owned orders except the managed passive exit.

        ``_cancel_owned_orders`` retains entry, historical SELL, and augment
        cleanup with the same ownership checks and authorizes the complete
        batch before its first venue cancel.
        """

        actionable = False
        for order_id in self._session_augment_own_order_ids(session):
            if self._order_terminal(snapshot, order_id, session):
                continue
            if self._order_cancel_requested(session, order_id):
                continue
            actionable = True
            break
        if not actionable:
            return session
        try:
            self._cancel_owned_orders(
                session,
                snapshot=snapshot,
                expected_generation=snapshot.get("_lp_trade_generation"),
                expected_trade_revision=trade_revision,
                preserve_passive_exit=True,
            )
        except ValueError as exc:
            if str(exc) == "account_round_invalid":
                return self._publish_account_round_rejected(str(session["session_id"]))
            raise
        except Exception as exc:
            return self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch={
                    "reconciliation": f"group_collect_{type(exc).__name__}",
                    "resume_state": str(session.get("state") or "entry_open"),
                },
            )
        session = self.store.lp_session(str(session["session_id"])) or session
        return self._mark_group_buckets_canceling(session, "group_fill_collect")

    def _mark_group_buckets_canceling(
        self,
        session: Mapping[str, object],
        reason: str,
    ) -> dict[str, object]:
        """Mark every cancel-requested bucket ``canceling`` with this reason.

        The D5 protection notifications deliberately stay silent for these
        sweeps (a group collection or the review deadline is not a
        protection trigger), so ``notification_sent`` is preset and the
        receipt convergence settles the buckets without announcing.
        """

        protection = session.get("queue_protection")
        buckets = self._queue_protection_levels(session)
        if not isinstance(protection, Mapping) or not buckets:
            return session
        changed = False
        new_levels: dict[str, dict[str, object]] = {}
        for key, bucket in buckets.items():
            if str(bucket.get("state")) in {"canceling", "canceled", "partially_filled"}:
                new_levels[key] = bucket
                continue
            order_id = str(bucket.get("order_id") or "")
            if order_id and self._order_cancel_requested(session, order_id):
                bucket = {
                    **bucket,
                    "state": "canceling",
                    "cancel_reason": reason,
                    "cancel_targets": [order_id],
                    "cancel_requested_at": _iso(self._now()),
                    "notification_sent": True,
                }
                changed = True
            new_levels[key] = bucket
        if not changed:
            return session
        return self.store.lp_update_session(
            str(session["session_id"]),
            patch={
                "queue_protection": {
                    "version": 2,
                    "data_failures": _queue_group_failures_int(
                        protection.get("data_failures")
                    ),
                    "levels": new_levels,
                }
            },
        )

    def _group_buys_terminal(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> bool:
        """True when every own BUY of the group shows a terminal receipt."""

        for order_id in self._session_augment_own_order_ids(session):
            if not self._order_terminal(snapshot, order_id, session):
                return False
        return True

    def _owned_sells_terminal(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> bool:
        """True only when every owned SELL has exact terminal evidence."""

        history = self._order_history(session)
        sells = [
            order_id
            for order_id, record in history.items()
            if str(record.get("side") or "").upper() == "SELL"
        ]
        # Legacy sessions may carry the exact passive SELL identity before its
        # first receipt is persisted. Missing history is UNKNOWN, not absence.
        for field in ("passive_exit_order_id", "protected_exit_order_id"):
            order_id = str(session.get(field) or "")
            if order_id and order_id not in sells:
                sells.append(order_id)
        return all(
            self._order_terminal(snapshot, order_id, session) for order_id in sells
        )

    # Public math is intentionally not used by the approved behavior cases;
    # the lifecycle calls this private helper after reading external facts.
    def _opening_loss_from_session(self, session: Mapping[str, object]) -> Decimal | None:
        if session.get("position_reconciled") is not True:
            return None
        cost = _maybe_decimal(session.get("buy_cost"))
        proceeds = _maybe_decimal(session.get("sold_revenue"))
        residual = _maybe_decimal(session.get("residual_exit_value"))
        fees = _maybe_decimal(session.get("fees"))
        if cost is None or proceeds is None or residual is None or fees is None:
            return None
        return cost - proceeds - residual + fees

    def _stop_loss_latch_patch(
        self, session: Mapping[str, object], loss: Decimal | None
    ) -> dict[str, object]:
        patch: dict[str, object] = {"stop_loss_latched": True}
        if (
            loss is not None
            and loss >= STOP_LOSS
            and session.get("stop_loss_triggered_at") is None
            and session.get("stop_loss_triggered_loss") is None
        ):
            patch["stop_loss_triggered_at"] = _iso(self._now())
            patch["stop_loss_triggered_loss"] = loss
        return patch

    def _normalize_request(self, request: Mapping[str, object]) -> dict[str, object]:
        if not isinstance(request, Mapping):
            raise ValueError("request_invalid")
        result = dict(request)
        for key in ("market_id", "condition_id", "token_id", "outcome"):
            value = _text(result.get(key))
            if value is None:
                raise ValueError(f"{key}_invalid")
            result[key] = value
        if result["outcome"] not in {"YES", "NO"}:
            raise ValueError("outcome_invalid")
        for key in ("price", "quantity"):
            result[key] = _decimal(result.get(key), key)
        if cast(Decimal, result["price"]) <= 0 or cast(Decimal, result["quantity"]) <= 0:
            raise ValueError("quantity_or_price_invalid")
        result["review_at"] = (
            None
            if result.get("review_at") is None
            else _timestamp(result.get("review_at"), name="review_at")
        )
        if result.get("candidate_policy") == "best_bid_minimum":
            level = result.get("candidate_bid_level", result.get("bid_level", 1))
            if type(level) is not int or level not in (1, 2):
                raise ValueError("bid_level_invalid")
            result["candidate_bid_level"] = level
        return result

    def _read_snapshot(
        self,
        request: Mapping[str, object],
        *,
        account_round: object | None = None,
    ) -> Mapping[str, object]:
        try:
            if getattr(self._facts_owner, 'session_id', None):
                return self._market_read(
                    request,
                    lambda: self._fetch_snapshot(request, account_round=account_round),
                    on_newer_facts=self._invalidate_lp_trade_generation,
                )
            return self._fetch_snapshot(request, account_round=account_round)
        except LpAccountRoundInvalid as exc:
            raise LpObservationWait("account_round_invalid") from exc
        except LpNewerAccountFacts as exc:
            if self._invalidate_lp_trade_generation(exc.observed_trade_generation):
                raise LpObservationWait("account_round_invalid") from exc
            raise ValueError("external_snapshot_unknown") from exc

    def _market_read(
        self, identity, read, *,
        wait_for_capacity=False, on_newer_facts=None,
    ):
        """Bound waiting without pretending a Python thread can be cancelled.

        Workers only return read data. An abandoned result is never applied;
        the existing trading revision still fences accepted session snapshots.
        """
        key = str(identity.get('condition_id') or identity.get('token_id') or '')
        deadline = monotonic() + self._market_read_timeout
        while True:
            blockers = None
            refusal = None
            diagnostic_jobs = ()
            with self._market_reads_lock:
                existing = self._market_reads.get(key)
                if existing is not None:
                    if not existing.done():
                        refusal = 'market_read_in_progress'
                    else:
                        self._market_reads.pop(key)
                if refusal is None and monotonic() < self._market_read_retry.get(key, 0):
                    refusal = 'market_read_cooling_down'
                unfinished = [job for job in self._market_reads.values() if not job.done()]
                if refusal is None:
                    if len(unfinished) >= 2:
                        if not wait_for_capacity:
                            refusal = 'market_read_capacity'
                        else:
                            blockers = tuple(unfinished)
                    else:
                        future = Future()
                        try:
                            future.lp_diagnostic = dict(task_id=uuid.uuid4().hex,
                                entry=sys._getframe(1).f_code.co_name, budget=self._market_read_timeout)
                        except Exception:
                            pass
                        self._market_reads[key] = future
                        break
                if refusal == 'market_read_capacity' and monotonic() >= getattr(self, '_market_read_diagnostic_at', float('-inf')):
                    self._market_read_diagnostic_at = monotonic() + 60
                    diagnostic_jobs = tuple(unfinished)
            if refusal:
                if diagnostic_jobs:
                    try:
                        _lp_market_read_diagnostic(refusal, diagnostic_jobs)
                    except Exception:
                        pass
                raise LpObservationWait(refusal)
            with _lp_read_stage('market_capacity_wait'):
                done, _ = wait(
                    blockers,
                    timeout=max(0, deadline - monotonic()),
                    return_when=FIRST_COMPLETED,
                )
            if not done:
                self._market_read_diagnostics('market_read_capacity')
                raise LpObservationWait('market_read_capacity')
        owner_session = getattr(self._facts_owner, 'session_id', None)
        def run():
            pending_logs = []
            self._facts_owner.session_id = owner_session
            try:
                with _lp_read_task('market_read', task=getattr(future, 'lp_diagnostic', None), deferred_logs=pending_logs):
                    result = read()
                future.set_result(result)
            except BaseException as exc:
                future.set_exception(exc)
            finally:
                self._facts_owner.session_id = None
                _lp_flush_read_logs(pending_logs)
        threading.Thread(target=run, daemon=True, name='lp-market-read').start()
        try:
            return future.result(timeout=self._market_read_timeout)
        except LpNewerAccountFacts as exc:
            # The caller received this result within the read deadline; the
            # authoritative transaction runs here, outside the SDK thread.
            if callable(on_newer_facts) and on_newer_facts(
                exc.observed_trade_generation
            ):
                raise LpObservationWait("account_round_invalid") from exc
            raise ValueError("external_snapshot_unknown") from exc
        except TimeoutError as exc:
            with self._market_reads_lock:
                self._market_read_retry[key] = monotonic() + 60
                task = getattr(future, 'lp_diagnostic', None)
                if task is not None:
                    task['caller_timed_out'] = True
            self._market_read_diagnostics('market_read_timeout', timed_out=future)
            raise ValueError('market_read_timeout') from exc
        finally:
            with self._market_reads_lock:
                if future.done() and self._market_reads.get(key) is future:
                    self._market_reads.pop(key)

    def _market_read_diagnostics(self, reason, *, timed_out=None):
        try:
            with self._market_reads_lock:
                if timed_out is None:
                    now = monotonic()
                    if now < getattr(self, '_market_read_diagnostic_at', float('-inf')):
                        return
                    self._market_read_diagnostic_at = now + 60
                jobs = tuple(job for job in self._market_reads.values() if not job.done())
                if timed_out is not None and timed_out not in jobs:
                    jobs += (timed_out,)
            _lp_market_read_diagnostic(reason, jobs, stack=timed_out is not None)
        except Exception:
            pass

    def market_read_retry_at(self, condition_id: str) -> datetime | None:
        """Expose the actual local read backoff as a wall-clock deadline."""
        with self._market_reads_lock:
            retry_monotonic = self._market_read_retry.get(str(condition_id))
        if retry_monotonic is None:
            return None
        return self._now() + timedelta(seconds=max(0, retry_monotonic - monotonic()))

    def _fetch_snapshot(
        self,
        request: Mapping[str, object],
        *,
        account_round: object | None = None,
    ):
        snapshot_request = dict(request)
        snapshot_request.pop("_lp_terminal_orders", None)
        session_id = str(request.get("session_id") or "")
        saved = self.store.lp_session(session_id) if session_id else None
        if saved and all(saved.get(key) == request.get(key)
                         for key in ("condition_id", "token_id")):
            # Reuse durable terminal receipts across ticks and restarts. Only
            # persisted facts can suppress reads, never request-supplied history.
            snapshot_request["_lp_terminal_orders"] = {
                oid: row for oid, row in self._order_history(saved).items()
                if str(row.get("status") or "").upper() in TERMINAL_ORDER_STATES
                and row.get("token_id") == request.get("token_id")
            }
        if account_round is not None:
            snapshot_request["_lp_account_round"] = account_round
        for name in ("lp_snapshot", "snapshot"):
            method = getattr(self.exchange, name, None)
            if not callable(method):
                continue
            try:
                value = method(snapshot_request)
            except TypeError:
                try:
                    value = method()
                except (LpAccountReadError, LpAccountRoundInvalid, LpNewerAccountFacts):
                    raise
                except Exception as exc:
                    raise ValueError("external_snapshot_unknown") from exc
            except (LpAccountReadError, LpAccountRoundInvalid, LpNewerAccountFacts):
                raise
            except Exception as exc:
                raise ValueError("external_snapshot_unknown") from exc
            if isinstance(value, Mapping):
                return value
        raise ValueError("external_snapshot_unknown")

    @classmethod
    def _validate_snapshot(
        cls,
        request: Mapping[str, object],
        snapshot: Mapping[str, object],
        *,
        now: datetime,
        allowed_open_order_ids: Collection[str] | None = None,
        reservations: object = None,
    ) -> dict[str, object]:
        account = snapshot.get("account")
        if not isinstance(account, Mapping):
            raise ValueError("account_unknown")
        authenticated = account.get("authenticated", account.get("auth"))
        if authenticated is None:
            raise ValueError("account_unknown")
        if authenticated is not True:
            raise ValueError("account_invalid")
        if snapshot.get("external_inventory") is True:
            raise ValueError("target_inventory")
        if snapshot.get("external_orders") is True:
            raise ValueError("target_orders")
        positions = _items(account.get("positions"))
        for position in positions:
            token = _field(position, "token_id", _field(position, "asset_id"))
            size = _maybe_decimal(_field(position, "size", _field(position, "quantity", 0)))
            if token == request["token_id"] and size is not None and size > 0:
                raise ValueError("target_inventory")
        # Issue 158: an augment re-check must tolerate the session's own
        # resting orders (entry + earlier augments); every other order on the
        # token still rejects exactly as before.
        allowed_ids = {
            str(value or "") for value in (allowed_open_order_ids or ())
        }
        for order in _items(account.get("open_orders")):
            if cls._order_id(order) and cls._order_id(order) in allowed_ids:
                continue
            token = _field(order, "token_id", _field(order, "asset_id"))
            market = _field(order, "market_id", _field(order, "market"))
            if token == request["token_id"] or market == request["market_id"]:
                raise ValueError("target_orders")
        balance = account.get("balance")
        allowance = account.get("allowance")
        if balance is None:
            raise ValueError("balance_unknown")
        if allowance is None:
            raise ValueError("allowance_unknown")
        balance_d = _decimal(balance, "balance")
        allowance_d = _decimal(allowance, "allowance")
        # Issue 166: submission competes against the balance/allowance left
        # after every active group's resting BUY reservation (dedup by order
        # id inside _account_after_reservations), not the raw wallet fact.
        # When the occupancy itself cannot be computed the honest answer is
        # "facts unknown", never an unadjusted pass.
        if reservations is not None:
            available_account = _account_after_reservations(account, reservations)
            if available_account is None:
                raise ValueError("account_facts_unknown")
            available_balance = _decimal(
                available_account.get("balance"), "balance"
            )
            available_allowance = _decimal(
                available_account.get("allowance"), "allowance"
            )
        else:
            available_balance = balance_d
            available_allowance = allowance_d
        rules = cls._validate_market_rules(request, snapshot)
        if (available_balance < 0 or available_allowance < 0
                or available_balance < request["price"] * request["quantity"]
                or available_allowance < request["price"] * request["quantity"]):
            raise ValueError("balance_insufficient")
        facts = cls._validate_market_book(request, snapshot, rules, now=now)
        return {**facts, "balance": balance_d, "allowance": allowance_d}

    @classmethod
    def _validate_market_snapshot(cls, request, snapshot, *, now):
        """Validate the frozen order against current market facts only."""
        rules = cls._validate_market_rules(request, snapshot)
        facts = cls._validate_market_book(request, snapshot, rules, now=now)
        stress = estimate_lp_stress_exit(snapshot.get('book'), market=snapshot['market'],
            price=request['price'], quantity=request['quantity'],
            bid_level=request.get('candidate_bid_level', request.get('bid_level', 1)))
        if stress['state'] != 'eligible':
            raise ValueError(stress['reason_codes'][0])
        return facts

    @classmethod
    def _validate_market_rules(cls, request, snapshot):
        market = snapshot.get("market")
        if not isinstance(market, Mapping):
            raise ValueError("market_unknown")
        for key in ("market_id", "condition_id", "token_id", "outcome"):
            if market.get(key) is None:
                raise ValueError("market_identity_unknown")
            if str(market.get(key)) != str(request[key]):
                raise ValueError("market_identity_mismatch")
        accepting = market.get("accepting_orders")
        if accepting is None:
            raise ValueError("market_acceptance_unknown")
        if accepting is not True:
            raise ValueError("market_not_accepting")
        exchange_type = market.get("exchange_type")
        if exchange_type is None:
            raise ValueError("exchange_unknown")
        if str(exchange_type).upper() not in {"CLOB", "POLYMARKET"}:
            raise ValueError("exchange_unknown")
        tick = market.get("tick_size")
        minimum = market.get("minimum_order_size")
        reward_min = market.get("reward_min_size")
        reward_spread = market.get("reward_max_spread")
        fee = market.get("fee")
        taker_fee_rate = market.get("taker_fee_rate", market.get("fee_rate"))
        fees_enabled = market.get("fees_enabled")
        if tick is None:
            raise ValueError("tick_size_unknown")
        if minimum is None:
            raise ValueError("minimum_order_size_unknown")
        if reward_min is None:
            raise ValueError("reward_min_size_unknown")
        if reward_spread is None:
            raise ValueError("reward_distance_unknown")
        if fee is None and fees_enabled is not False:
            raise ValueError("fee_unknown")
        if taker_fee_rate is None and fees_enabled is not False:
            raise ValueError("fee_rate_unknown")
        tick_d = _decimal(tick, "tick_size")
        minimum_d = _decimal(minimum, "minimum_order_size")
        reward_min_d = _decimal(reward_min, "reward_min_size")
        reward_spread_d = _decimal(reward_spread, "reward_max_spread")
        fee_d = Decimal("0") if fees_enabled is False else _decimal(fee, "fee")
        taker_fee_rate_d = (
            Decimal("0")
            if fees_enabled is False
            else _decimal(taker_fee_rate, "taker_fee_rate")
        )
        if (
            tick_d <= 0
            or minimum_d <= 0
            or reward_min_d <= 0
            or reward_spread_d <= 0
            or fee_d < 0
            or taker_fee_rate_d < 0
        ):
            raise ValueError("market_rule_invalid")
        price = cast(Decimal, request["price"])
        quantity = cast(Decimal, request["quantity"])
        if price % tick_d != 0:
            raise ValueError("price_off_tick")
        if quantity < minimum_d or quantity < reward_min_d:
            raise ValueError("order_size_invalid")
        return dict(tick_size=tick_d, minimum_order_size=minimum_d,
            reward_min_size=reward_min_d, reward_max_spread=reward_spread_d,
            fee=fee_d, taker_fee_rate=taker_fee_rate_d)

    @classmethod
    def _validate_market_book(cls, request, snapshot, rules, *, now):
        price, quantity = request['price'], request['quantity']
        reward_min_d, reward_spread_d = rules['reward_min_size'], rules['reward_max_spread']
        book = snapshot.get("book")
        if not isinstance(book, Mapping):
            raise ValueError("book_unknown")
        candidate_policy = request.get("candidate_policy")
        if candidate_policy not in (None, "best_bid_minimum"):
            raise ValueError("candidate_policy_invalid")
        stamp = book.get("received_at")
        if stamp is None:
            raise ValueError("book_freshness_unknown")
        _freshness(
            stamp,
            now,
            "book_freshness",
            max_age=60 if candidate_policy == "best_bid_minimum" else BOOK_FRESHNESS_SECONDS,
        )
        asks = cls._levels(book.get("asks"), "asks")
        bids = cls._levels(book.get("bids"), "bids")
        if not asks or not bids:
            raise ValueError("book_invalid")
        selected_bid, _selected_bid_size = _select_bid_level(
            bids,
            request.get("candidate_bid_level", request.get("bid_level", 1)),
        )
        if candidate_policy == "best_bid_minimum":
            if price != selected_bid:
                level = request.get("candidate_bid_level", request.get("bid_level", 1))
                raise ValueError(
                    "candidate_best_bid_changed" if level == 1
                    else "candidate_bid_level_changed"
                )
        bid, ask, midpoint = _qualify_reward_quote(
            bids,
            asks,
            price=price,
            reward_min_size=reward_min_d,
            reward_max_spread=reward_spread_d,
            require_positive_score=candidate_policy == "best_bid_minimum",
            cumulative_depth=candidate_policy == "best_bid_minimum",
        )
        if sum(size for _, size in bids) < quantity:
            raise ValueError("exit_liquidity_insufficient")
        review_at = _timestamp(request["review_at"], name="review_at")
        expiration = expiration_for_review(review_at, now=now)
        return {
            **rules,
            "midpoint": midpoint,
            "best_bid": bid[0],
            "selected_bid": selected_bid,
            "selected_bid_level": request.get(
                "candidate_bid_level", request.get("bid_level", 1)
            ),
            "best_ask": ask[0],
            "midpoint_source": "local_size_filtered_estimate",
            "checked_at": now,
            "entry_expiration": expiration,
        }

    @staticmethod
    def _levels(value: object, name: str) -> list[tuple[Decimal, Decimal]]:
        return _levels(value, name)

    @staticmethod
    def _order_id(value: object) -> str:
        return str(_field(value, "order_id", _field(value, "id", "")) or "")

    @staticmethod
    def _queue_level_rows(
        snapshot: Mapping[str, object] | None,
    ) -> dict[str, object]:
        """Merge order receipts over the account open-order projection."""

        rows_by_id: dict[str, object] = {}
        if not isinstance(snapshot, Mapping):
            return rows_by_id
        for order in _items(snapshot.get("orders")):
            order_id = PolymarketLPService._order_id(order)
            if order_id:
                rows_by_id.setdefault(order_id, order)
        account = snapshot.get("account")
        open_orders = (
            account.get("open_orders") if isinstance(account, Mapping) else ()
        )
        for order in _items(open_orders):
            order_id = PolymarketLPService._order_id(order)
            if order_id:
                rows_by_id.setdefault(order_id, order)
        return rows_by_id

    @staticmethod
    def _queue_row_remaining(row: object) -> Decimal | None:
        for name in ("remaining_size", "remaining_quantity", "size"):
            value = _maybe_decimal(_field(row, name))
            if value is not None:
                return value
        original = _maybe_decimal(
            _field(row, "original_size", _field(row, "quantity"))
        )
        matched = _maybe_decimal(_field(row, "size_matched"))
        if original is not None and matched is not None:
            return original - matched
        return None

    def _queue_account_open_orders(
        self, account_round: object | None = None
    ) -> list[object] | None:
        """Read open orders through one fresh account read (issue 152 D5)."""

        for name in ("lp_account_snapshot", "account_snapshot"):
            if account_round is not None and name == "lp_account_snapshot":
                reader = getattr(self.exchange, "lp_open_orders_for_round", None)
                if not callable(reader):
                    return None
                try:
                    return list(reader(account_round))
                except LpAccountRoundInvalid:
                    raise
                except Exception:
                    return None
            reader = getattr(self.exchange, name, None)
            if not callable(reader):
                continue
            try:
                value = reader()
            except Exception:
                return None
            rows: object = ()
            if isinstance(value, Mapping):
                rows = value.get("open_orders")
            else:
                rows = getattr(value, "open_orders", None)
            if rows is None:
                continue
            return list(_items(rows))
        return None

    def _own_queue_remaining(
        self,
        snapshot: Mapping[str, object],
        *,
        token_id: str,
        price: Decimal,
    ) -> Decimal | None:
        """Sum remaining size of own open BUY orders at one token and price.

        Receipt rows (``snapshot["orders"]``) take priority over the account
        ``open_orders`` projection for the same order id.  Any participating
        row without a parseable remaining size poisons the total: the caller
        receives None and the estimate stays UNKNOWN instead of guessing.
        """

        total = Decimal("0")
        for row in self._queue_level_rows(snapshot).values():
            row_token = _field(row, "token_id", _field(row, "asset_id"))
            if row_token not in (None, "", token_id):
                continue
            if str(_field(row, "side", "")).upper() != "BUY":
                continue
            if _maybe_decimal(_field(row, "price")) != price:
                continue
            if str(_field(row, "status", "")).upper() in TERMINAL_ORDER_STATES:
                continue
            remaining = self._queue_row_remaining(row)
            if remaining is None:
                return None
            total += remaining
        return total

    def _bucket_queue_protection_evaluation(
        self,
        session: Mapping[str, object],
        bucket: Mapping[str, object],
        snapshot: Mapping[str, object],
        rows_by_id: Mapping[str, object],
    ) -> dict[str, object] | None:
        """Return the per-bucket queue-protection patch for this tick, or None
        when the bucket stays unchanged."""

        if str(bucket.get("state")) in {"canceling", "canceled", "partially_filled"}:
            return None
        baseline_price = _maybe_decimal(bucket.get("baseline_price"))
        if baseline_price is None:
            return None
        if not self._bucket_protection_gate_open(session, bucket, rows_by_id):
            return None
        token_id = str(session.get("token_id") or "")
        own_remaining = self._own_queue_remaining_rows(
            rows_by_id, token_id=token_id, price=baseline_price
        )
        estimate = estimate_lp_queue_position(
            snapshot.get("book"),
            price=baseline_price,
            own_remaining=own_remaining,
            baseline_front=_maybe_decimal(bucket.get("baseline_front"))
            or Decimal("0"),
            threshold=_maybe_decimal(bucket.get("threshold"))
            or LP_QUEUE_PROTECTION_THRESHOLD,
            condition_id=str(session.get("condition_id") or "") or None,
            token_id=token_id or None,
        )
        updated = dict(bucket)
        updated.update(
            {
                "state": estimate["state"],
                "front_estimate": estimate["front_estimate"],
                "level_total": estimate["level_total"],
                "ratio": estimate["ratio"],
                "reason_codes": estimate["reason_codes"],
                "data_time": estimate["data_time"],
            }
        )
        return updated

    @staticmethod
    def _protection_cancel_event(session, bucket, *, first_seen=False) -> str:
        if first_seen:
            return f"{session['episode_id']}:first-seen-protection-cancel"
        anchor = str(bucket.get("order_id") or "") or format(
            _decimal(bucket["baseline_price"], "baseline_price"), "f"
        )
        return f"{session['session_id']}:entry-protection-cancel:{anchor}"

    def _restore_protection_cancel_events(self) -> None:
        """Restore business only: pre-existing cancel actions can never notify."""
        sessions = self.store.lp_sessions()
        for session in sessions:
            actions = self.store.lp_actions(str(session["session_id"]))
            for action in actions:
                if action.get("role") == "entry-protection-cancel":
                    self._protection_cancel_events.add(str(action["action_key"]))
                elif action.get("role") == "first-seen-protection-cancel":
                    self._protection_cancel_events.add(
                        f"{action['episode_id']}:first-seen-protection-cancel"
                    )
            # Legacy business images may lack the cancel action audit.
            for bucket in self._queue_protection_levels(session).values():
                if bucket.get("cancel_targets") or bucket.get("state") in {"canceling", "canceled", "partially_filled"}:
                    self._protection_cancel_events.add(self._protection_cancel_event(session, bucket))
        for episode in self.store.lp_active_first_seen_episodes():
            if episode.get("cancel_targets") or episode.get("state") == "canceling":
                self._protection_cancel_events.add(
                    self._protection_cancel_event(episode, episode, first_seen=True)
                )

    def _notify_committed_protection_cancels(self, session, *, first_seen=False) -> None:
        """Consume each real cancel episode once, after its business commit."""
        if not self._protection_cancel_enabled:
            return
        buckets = {"": session} if first_seen else self._queue_protection_levels(session)
        for bucket in buckets.values():
            # Non-protection sweeps preset this flag to suppress alerts.
            if bucket.get("notification_sent") is True:
                continue
            canceled = self._merge_order_id_lists(bucket.get("canceled_order_ids"))
            targets = self._merge_order_id_lists(bucket.get("cancel_targets"))
            if not canceled or not (
                bucket.get("state") in {"canceled", "partially_filled"}
                or (targets and set(targets) <= set(canceled))
            ):
                continue
            event = self._protection_cancel_event(session, bucket, first_seen=first_seen)
            with self._protection_cancel_lock:
                if event in self._protection_cancel_events:
                    continue
                self._protection_cancel_events.add(event)
            title = ("LP 位置保护撤单（首见基线）" if first_seen else
                     self._queue_protection_price_title(session, bucket, "位置保护已触发撤单"))
            notice = self._queue_protection_success_notification(
                bucket, session, canceled_count=len(canceled),
                manual_count=(len(canceled) if first_seen else
                              sum(order != session.get("entry_order_id") for order in canceled)),
                canceled_remaining=self._episode_canceled_remaining(
                    bucket.get("cancel_target_remaining"), canceled
                ),
                title=title, trigger_prefix="首见基线 · " if first_seen else "",
            )
            # Only volatile work exists after commit; a crash/drop is final.
            pending = getattr(self._deferred_protection_notices, "cancels", None)
            if pending is not None:
                pending.append((event, *notice))
            else:
                self._start_protection_cancel_notice(event, *notice)

    def _start_protection_cancel_notice(self, event, title, message, voice) -> threading.Thread | None:
        # A daemon task owns only this message. Runtime stop does not
        # wait for it; process exit may drop it, and startup never replays it.
        event_id = hashlib.sha256(event.encode()).hexdigest()[:16]

        def deliver():
            results = self._deliver_protection_details(title, message, voice, one_shot=True)
            for channel, success in results.items():
                logger.log(logging.INFO if success else logging.WARNING,
                           "lp_protection_cancel_notice event=%s channel=%s at=%s outcome=%s error_type=%s",
                           event_id, channel, _iso(self._now()), "success" if success else "unconfirmed",
                           "none" if success else "delivery_unconfirmed")

        try:
            worker = threading.Thread(target=deliver, name="lp-protection-cancel-notice", daemon=True)
            worker.start()
            return worker
        except Exception as exc:
            logger.warning("lp_protection_cancel_enqueue_failed event=%s error_type=%s", event_id, type(exc).__name__)

    def _deliver_protection_details(
        self,
        title: str,
        message: str,
        xiaoai_text: str,
        *,
        channels: set[str] | None = None,
        one_shot: bool = False,
    ) -> dict[str, bool]:
        """Return per-channel delivery facts without turning partial success true."""
        callback = self._protection_notifier
        if callback is None:
            if one_shot:
                return {}
            if channels is None:
                return {"feishu": False, "xiaoai": False}
            return {name: False for name in channels}
        kwargs = {}
        if channels is not None:
            try:
                inspect.signature(callback).bind(
                    title, message, xiaoai_text, channels=channels
                )
            except (TypeError, ValueError):
                pass
            else:
                kwargs["channels"] = channels
        if one_shot:
            try:
                inspect.signature(callback).bind(
                    title, message, xiaoai_text, **kwargs, one_shot=True
                )
            except (TypeError, ValueError):
                pass
            else:
                kwargs["one_shot"] = True
        try:
            result = callback(title, message, xiaoai_text, **kwargs)
        except Exception as exc:
            if one_shot:
                logger.warning("lp_protection_cancel_callback_failed error_type=%s", type(exc).__name__)
            if channels is None:
                return {"feishu": False, "xiaoai": False}
            return {name: False for name in channels}
        if isinstance(result, Mapping):
            return {
                str(key): bool(result.get(key))
                for key in (result if one_shot else channels if channels is not None else {"feishu", "xiaoai"})
            }
        delivered = result is True
        if channels is None:
            return {"feishu": delivered, "xiaoai": delivered}
        return {name: delivered for name in channels}

    def _notify_protection(
        self, title: str, message: str, xiaoai_text: str
    ) -> bool:
        """Deliver one protection notification through both channels."""
        results = self._deliver_protection_details(title, message, xiaoai_text)
        return bool(results) and all(results.values())

    def _notify_bucket_protection(
        self,
        session: Mapping[str, object],
        bucket: Mapping[str, object],
        bucket_key: str,
        field: str,
        title: str,
        message: str,
        xiaoai_text: str,
    ) -> bool:
        """Send one bucket notice outside locks after durable episode arming."""
        session_id = str(session["session_id"])
        episode = str(bucket.get("notification_episode") or uuid.uuid4().hex)
        bucket = {**bucket, "notification_episode": episode}
        arm = getattr(self.store, "lp_arm_queue_protection_notification", None)
        if callable(arm) and not arm(
            session_id,
            level_key=bucket_key,
            episode=episode,
            order_id=str(bucket.get("order_id") or ""),
        ):
            return False

        def mark_delivered() -> None:
            marker = getattr(
                self.store, "lp_mark_queue_protection_notified", None
            )
            if callable(marker):
                marker(
                    session_id,
                    level_key=bucket_key,
                    field=field,
                    episode=episode,
                    order_id=str(bucket.get("order_id") or ""),
                )

        queue = getattr(self._deferred_protection_notices, "notices", None)
        if queue is not None:
            queue.append((title, message, xiaoai_text, mark_delivered))
            return False
        if not self._notify_protection(title, message, xiaoai_text):
            return False
        mark_delivered()
        return True

    @staticmethod
    def _needs_attention_reason_copy(
        reconciliation: object,
    ) -> tuple[str, str]:
        """Return durable operator copy for the current reconciliation reason."""
        code = str(reconciliation or "")
        if code in {"market_read_capacity", "facts_read_capacity"}:
            return ("本地读取容量已占满，系统等待空闲后继续核对。", "等待读取容量")
        if code in {"market_read_in_progress", "facts_read_in_progress"}:
            return ("本次读取尚在进行，系统等待结果后继续核对。", "读取进行中")
        if code == "missing_reliable_order_id":
            return (
                "历史提交缺少可靠订单编号，占资和名额仍待核清。需要对照历史订单、成交与当前持仓核对。",
                "历史订单身份需要核对",
            )
        if code in {"submission_unknown", "order_receipt_unknown"}:
            return ("订单结果尚未核清，系统保留占资并继续只读核对。", "订单结果待核对")
        if code in {"financial_facts_unknown", "trade_fee_unknown", "position_mismatch"}:
            return ("成交、费用或持仓尚未核清，受影响资金继续隔离，系统继续只读核对。", "资金事实待核对")
        if code == "unowned_target_order":
            return (
                "账户里有一张挂在本市场、但不归本组管理的单（常见：手工挂的单）。"
                "系统已暂停本组自动管理，追加暂不可用；那张单撤掉或成交后自动恢复，无需操作。",
                "本市场有不归系统管理的挂单",
            )
        if code in {
            "external_snapshot_unknown", "book_unknown", "book_freshness_unknown",
            "market_read_timeout", "market_read_cooling_down",
        }:
            return ("市场/账户数据连续读取失败，系统自动重试中。", "数据读取连续失败")
        if code in {"account_facts_stale", "account_facts_incomplete"}:
            return ("账户事实已变化或未完整返回，系统重新读取中。", "账户事实不完整")
        if code == "execution_lock":
            return ("等待其他交易操作完成，随后自动继续核对。", "等待交易锁")
        if "submit_unknown" in code:
            return (
                "一笔提交结果未知，需要到 Polymarket 订单页核对该单状态。",
                "有提交结果未知",
            )
        if code.startswith(("stop_cancel_", "deadline_cancel_", "group_collect_")):
            return ("一次撤单操作失败，系统自动重试中，长时间未恢复需人工核对。", "撤单操作失败")
        fallback = code or "unknown"
        return (f"系统暂停了本组的自动管理（原因：{fallback}）。", f"原因 {fallback}")

    def _needs_attention_notify_patch(
        self,
        session: Mapping[str, object],
        now: datetime,
        *,
        protection: Mapping[str, object] | None = None,
    ) -> dict[str, object]:
        """Arm one durable five-minute attention episode; never send here."""
        owns_reader = getattr(self.store, "lp_auto_owns_session", None)
        if callable(owns_reader) and owns_reader(str(session.get("session_id"))):
            return {}
        state = str(session.get("state"))
        since_raw = session.get("needs_attention_since")
        if state != "needs_attention" or since_raw is None:
            return {
                "needs_attention_episode": uuid.uuid4().hex,
                "needs_attention_delivery_group": None,
                "needs_attention_recovery_delivery_group": None,
                "needs_attention_recovery_ready_since": None,
                "needs_attention_recovery_first_checked_at": None,
                "needs_attention_verified_recovery_episode": None,
                "needs_attention_since": now.isoformat(),
                "needs_attention_notified": False,
                "needs_attention_due": False,
                "needs_attention_recovery_due": False,
                "needs_attention_channel_status": {},
                "needs_attention_recovery_channel_status": {},
                "needs_attention_send_error": None,
                "needs_attention_sending": False,
                "needs_attention_send_retry_at": None,
                "needs_attention_recovery_retry_at": None,
            }
        if not str(session.get("needs_attention_episode") or ""):
            return {"needs_attention_episode": uuid.uuid4().hex}
        if bool(session.get("needs_attention_notified")):
            return {}
        try:
            since = _timestamp(since_raw, name="needs_attention_since")
        except ValueError:
            return {
                "needs_attention_since": now.isoformat(),
                "needs_attention_notified": False,
            }
        if (now - since).total_seconds() < LP_NEEDS_ATTENTION_NOTIFY_SECONDS:
            return {}
        retry = session.get("needs_attention_send_retry_at")
        if retry and now < _timestamp(retry, name="needs_attention_send_retry_at"):
            return {}
        return {"needs_attention_due": True}

    @staticmethod
    def _attention_internal_wait(reason: object) -> bool:
        return str(reason or "") in {
            "market_read_capacity", "market_read_in_progress", "execution_lock",
            "facts_read_capacity", "facts_read_in_progress", "account_round_invalid",
        }

    @staticmethod
    def _attention_session_reason(session: Mapping[str, object]) -> object:
        return session.get("facts_error") or session.get("reconcile_reason") or session.get("reconciliation")

    def _attention_notice(self, rows, *, recovery: bool, reason=None, funds=False):
        identities = [self._queue_protection_identity(row) for row in rows]
        names = [identity["title"] for identity in identities]
        label = names[0] if len(names) == 1 else f"{len(names)} 个市场"
        scope = "标的资金" if funds else "会话"
        title = f"LP {scope}核对恢复 · {label}" if recovery else f"LP 需要核对 · {label}"
        main, voice = self._needs_attention_reason_copy(reason)
        voice = "LP 需要核对，" + voice
        if recovery:
            main, voice = f"本次 {scope}核对恢复：{len(rows)} 个市场。", f"LP {scope}核对恢复"
        details = []
        for row, identity in zip(rows, identities):
            line = f"- {identity['title']} {identity['outcome']}\n  {identity['url']}"
            protection = row.get("queue_protection")
            failures = _queue_group_failures_int(protection.get("data_failures") if isinstance(protection, Mapping) else 0)
            if not recovery and failures > 0:
                line += f"\n  数据读取失败 {failures}/10，满 10 次将保护性撤单。"
            details.append(line)
        message = main + "\n\n市场：\n" + "\n".join(details)
        summary = self._facts_attention_summary
        if callable(summary):
            try:
                state = summary()
                slots = state["slots"]
                active, target = slots["active"], state["target_buy_count"]
                pending = slots.get("pending_review", 0)
                occupied = slots.get("occupied", active + pending)
                blocked = bool(state.get("admission_block_reasons")) or (active < target and occupied >= target)
                mode = "已暂停新增" if not state["desired_running"] else "新增受阻" if blocked else "继续检查"
                reserved = state["funds"].get("pending_reserved_usd", "未知")
                message += f"\n\n自动池：{mode}；有效 BUY {active}/{target}，待核对 {pending} 笔，未核清占资 {reserved} USDC。"
                if state["funds"].get("status") == "unknown":
                    message += " 资金事实仍未全部核清。"
            except Exception:
                message += "\n\n自动池：状态未核实。"
        else:
            message += "\n\n自动池：状态未核实。"
        if not recovery:
            message += "\n系统继续核对并保留受影响资金；详情见 Dashboard。"
        return title, message, voice

    def _needs_attention_recovery_patch(self, session):
        channels = {str(key) for key, value in (session.get("needs_attention_channel_status") or {}).items() if value}
        episode = str(session.get("needs_attention_episode") or "")
        return {
            "reconciliation": None, "resume_state": None,
            "needs_attention_since": None, "needs_attention_notified": False,
            "needs_attention_due": False, "needs_attention_channel_status": {},
            "needs_attention_send_error": None, "needs_attention_sending": False,
            "needs_attention_send_retry_at": None,
            "needs_attention_recovery_due": bool(session.get("needs_attention_notified") or channels),
            "needs_attention_recovery_episode": episode,
            "needs_attention_verified_recovery_episode": episode,
            "needs_attention_recovery_channels": sorted({"feishu", "xiaoai"} if session.get("needs_attention_notified") else channels),
            "needs_attention_recovery_channel_status": {},
            "needs_attention_recovery_retry_at": None,
        }

    def _attention_recovery_ready(self, session, *, prefix="needs_attention", financial_known=None):
        since_key, checked_key = prefix + "_recovery_ready_since", prefix + "_recovery_first_checked_at"
        terminal = session.get("settled") or session.get("state") in {"complete", "entry_rejected"}
        checked = (session.get("attention_verified_at") if terminal else None) or session.get("facts_checked_at") or session.get("checked_at")
        if terminal and session.get("attention_verification_error") == "verification_pending":
            return False, {}
        if terminal and (session.get("attention_verification_error") or (
                session.get("attention_verified_at") and session.get("attention_verified_trade_generation") != self.store.lp_trade_generation())):
            return False, {since_key: None, checked_key: None}
        if financial_known is None:
            financial_known = session.get("position_reconciled") is True and not self._has_unresolved_submission(session)
        if (not financial_known or session.get("state") == "needs_attention"
                or session.get("facts_error") or session.get("financial_block_reason")
                or session.get("position_reconciled") is False or not checked):
            return False, {since_key: None, checked_key: None}
        try:
            stamp = _timestamp(checked, name="recovery_facts")
            _freshness(stamp, self._now(), "recovery_facts", max_age=60)
            since = session.get(since_key)
            if not since:
                return False, {since_key: self._now().isoformat(), checked_key: stamp.isoformat()}
            ready = (stamp - _timestamp(session[checked_key], name="first_recovery_facts")).total_seconds() >= 60
            return ready, {}
        except (ValueError, KeyError):
            return False, {}

    def flush_session_attention(self, session_id: str) -> None:
        self._flush_attention_notices(session_id, recovery=False)

    def flush_session_recovery(self, session_id: str) -> None:
        self._flush_attention_notices(session_id, recovery=True)

    def _flush_attention_notices(self, session_id: str, *, recovery: bool) -> None:
        """Batch one reason; retry confirmed delivery bookkeeping without I/O."""
        with self._attention_delivery_lock:
            selected = self.store.lp_session(session_id)
            for key, results in list(self._attention_delivery_results.items()):
                sid, cached_recovery, episode = key
                if sid != session_id:
                    continue
                episode_key = "needs_attention_recovery_episode" if cached_recovery else "needs_attention_episode"
                if (not selected or selected.get("account_baseline_archive")
                        or selected.get("state") == "account_baseline_archived"
                        or str(selected.get(episode_key)) != episode):
                    self._attention_delivery_results.pop(key, None)
                    continue
                retry_key = "needs_attention_recovery_retry_at" if cached_recovery else "needs_attention_send_retry_at"
                retry = selected.get(retry_key)
                if not retry or self._now() >= _timestamp(retry, name="attention_ack_retry"):
                    self.store.lp_finish_attention_notification(sid, recovery=cached_recovery, episode=episode, results=results)
                    self._attention_delivery_results.pop(key, None)
                    selected = self.store.lp_session(session_id)
            due_key = "needs_attention_recovery_due" if recovery else "needs_attention_due"
            if (selected is None or selected.get("account_baseline_archive")
                    or selected.get("state") == "account_baseline_archived" or not selected.get(due_key)):
                return
            if self.store.lp_auto_owns_session(session_id):
                return
            reason = self._attention_session_reason(selected)
            if not recovery and self._attention_internal_wait(reason):
                return
            group_key = "needs_attention_recovery_delivery_group" if recovery else "needs_attention_delivery_group"
            episode_key = "needs_attention_recovery_episode" if recovery else "needs_attention_episode"
            status_key = "needs_attention_recovery_channel_status" if recovery else "needs_attention_channel_status"
            retry_key = "needs_attention_recovery_retry_at" if recovery else "needs_attention_send_retry_at"
            prefix = "needs_attention_recovery" if recovery else "needs_attention"
            batches_key = prefix + "_delivery_batches"
            group = selected.get(group_key)
            rows = []
            fences = {}
            for row in self.store.lp_sessions():
                if (row.get("account_baseline_archive") or row.get("state") == "account_baseline_archived"
                        or not row.get(due_key) or not row.get(episode_key)):
                    continue
                trade_generation = self.store.lp_trade_generation()
                snapshot = self.store.lp_session_with_revision(row["session_id"])
                if snapshot is None or snapshot[0].get(episode_key) != row.get(episode_key):
                    continue
                row, revision = snapshot
                if (row.get("account_baseline_archive") or row.get("state") == "account_baseline_archived"
                        or not row.get(due_key)):
                    continue
                if self.store.lp_auto_owns_session(row["session_id"]):
                    continue
                if group and row.get(group_key) != group:
                    continue
                if not group and row.get(group_key):
                    continue
                if not recovery and (row.get("state") != "needs_attention" or self._attention_session_reason(row) != reason):
                    continue
                retry = row.get(retry_key)
                if retry and self._now() < _timestamp(retry, name="attention_retry"):
                    continue
                if recovery:
                    ready, patch = self._attention_recovery_ready(row)
                    if patch:
                        self.store.lp_update_session(row["session_id"], patch=patch)
                    if not ready:
                        continue
                rows.append(row)
                fences[row["session_id"]] = (revision, trade_generation)
            if not rows:
                return
            group = group or uuid.uuid5(uuid.NAMESPACE_URL, str(recovery) + ":" + ":".join(
                sorted(str(row["session_id"]) + ":" + str(row[episode_key]) for row in rows)
            )).hex
            pending = set()
            statuses = {}
            claimed = []
            for row in rows:
                sid, episode = str(row["session_id"]), str(row[episode_key])
                key = (sid, recovery, episode)
                requested = set(row.get("needs_attention_recovery_channels") or ("feishu", "xiaoai")) if recovery else {"feishu", "xiaoai"}
                prior = row.get(status_key) or {}
                cached = self._attention_delivery_results.get(key, {})
                matching = matching_batch_channels(cached, row.get(batches_key) or {})
                cached = {channel: sent for channel, sent in cached.items()
                          if matching is None or channel in matching}
                status = {channel: bool(prior.get(channel) or cached.get(channel)) for channel in requested}
                claim = self.store.lp_claim_attention_notification(sid, recovery=recovery,
                    episode=episode, revision=fences[sid][0], trade_generation=fences[sid][1], patch={
                    "needs_attention_sending": True,
                    group_key: group,
                    retry_key: (self._now() + timedelta(seconds=60)).isoformat(),
                })
                if claim is None:
                    continue
                claimed.append(claim)
                statuses[key] = status
                pending.update(channel for channel, delivered in status.items() if not delivered)
            if not claimed:
                return
            current = {
                str(row["session_id"]): (row, fences[str(row["session_id"])][0] + 1)
                for row in claimed
            }

            def member_for(row):
                identity = self._queue_protection_identity(row)
                protection = row.get("queue_protection")
                return {
                    "id": str(row["session_id"]),
                    "session_id": str(row["session_id"]),
                    "episode": str(row[episode_key]),
                    "fault_episode": str(row.get("needs_attention_episode") or ""),
                    "account_id": str(row.get("account_id") or ""),
                    "condition_id": str(row.get("condition_id") or ""),
                    "token_id": str(row.get("token_id") or ""),
                    "reason": self._attention_session_reason(row),
                    "render": {
                        "condition_id": identity["condition_id"],
                        "token_id": identity["token_id"],
                        "market_title": identity["title"],
                        "market_url": identity["url"],
                        "outcome": identity["outcome"],
                        "queue_protection": {
                            "data_failures": protection.get("data_failures", 0)
                            if isinstance(protection, Mapping) else 0,
                        },
                    },
                }

            def member_state(member, batch, channel):
                sid = str(member["id"])
                if sid not in current:
                    current[sid] = self.store.lp_session_with_revision(sid)
                snapshot = current[sid]
                if snapshot is None:
                    return "retire"
                row = snapshot[0]
                if (row.get("account_baseline_archive")
                        or row.get("state") == "account_baseline_archived"
                        or self.store.lp_auto_owns_session(sid)
                        or (str(row.get(episode_key) or "") != member["episode"]
                            and (row.get(episode_key) or row.get(due_key) or not recovery))
                        or str(row.get("needs_attention_episode") or "") != member["fault_episode"]
                        or any(str(row.get(key) or "") != member[key]
                               for key in ("account_id", "condition_id", "token_id"))):
                    return "retire"
                if recovery:
                    if row.get("state") == "needs_attention":
                        return "retire"
                elif (row.get("state") != "needs_attention"
                        or self._attention_session_reason(row) != member["reason"]):
                    return "retire"
                # An acknowledged original member is historical context. Only
                # recipients still owing this channel need fresh recovery proof.
                prior = row.get(status_key) or {}
                cached = self._attention_delivery_results.get((sid, recovery, member["episode"]), {})
                matching = matching_batch_channels(cached, row.get(batches_key) or {})
                if prior.get(channel) or (cached.get(channel) and (matching is None or channel in matching)):
                    return "acknowledged"
                if not row.get(due_key):
                    return "acknowledged" if recovery else "retire"
                if recovery and not self._attention_recovery_ready(row)[0]:
                    return "defer"
                return "valid"

            deliveries, assignments = plan_notification_batches(
                rows={str(row["session_id"]): row for row in claimed},
                pending={key[0]: {channel for channel, sent in status.items() if not sent}
                         for key, status in statuses.items()},
                stored={str(row["session_id"]): row.get(batches_key) or {} for row in claimed},
                member_for=member_for,
                member_state=member_state,
                render=lambda members: self._attention_notice(
                    [member["render"] for member in members], recovery=recovery, reason=reason),
            )
            if not deliveries and pending:
                return
            patches = {}
            for sid, channel_batches in assignments.items():
                row = current[sid][0]
                merged = {**(row.get(batches_key) or {}), **channel_batches}
                if merged != row.get(batches_key):
                    patches[sid] = {batches_key: merged}
            claims = {
                str(row["session_id"]): (str(row[episode_key]), fences[str(row["session_id"])][0] + 1)
                for row in claimed
            }
            if not self.store.lp_finalize_attention_notification_batch(
                    recovery=recovery, claims=claims,
                    trade_generation=fences[str(claimed[0]["session_id"])][1],
                    patches=patches, guards={sid: current[sid][1] for sid in assignments}):
                return
            for key, status in list(statuses.items()):
                saved = patches.get(key[0], {}).get(batches_key, current[key[0]][0].get(batches_key) or {})
                batch_ids = {
                    channel: batch["id"] for channel, batch in saved.items()
                    if channel in status and isinstance(batch, Mapping) and batch.get("id")
                }
                statuses[key] = ChannelStatuses(status, batch_ids=batch_ids) if batch_ids else status
                self._attention_delivery_results[key] = statuses[key]
            for delivery in deliveries:
                batch, channels = delivery["batch"], delivery["channels"]
                with notification_delivery_episode("lp-session:" + batch["id"]):
                    results = self._deliver_protection_details(
                        batch["title"], batch["message"], batch["voice"], channels=channels)
                for channel, recipients in delivery["recipients"].items():
                    for sid in recipients:
                        key = (sid, recovery, str(current[sid][0][episode_key]))
                        statuses[key][channel] = bool(results.get(channel))
                        self._attention_delivery_results[key] = statuses[key]
            # Cache every recipient before the first ack: a later DB failure
            # must not re-send the batch members whose acknowledgement failed.
            for key, status in statuses.items():
                sid, _, episode = key
                self.store.lp_finish_attention_notification(sid, recovery=recovery, episode=episode, results=status)
                self._attention_delivery_results.pop(key, None)

    def _queue_protection_identity(
        self, session: Mapping[str, object]
    ) -> dict[str, str]:
        """Resolve notification identity from the durable payload or local cache."""

        condition_id = str(session.get("condition_id") or "").strip()
        token_id = str(session.get("token_id") or "").strip()
        title = _text(session.get("market_title")) or _text(session.get("question"))
        market_url = _text(session.get("market_url"))
        outcome = _text(session.get("outcome"))
        if not title or not market_url or not outcome:
            try:
                entries_reader = getattr(self.store, "lp_metadata_cache_entries", None)
                entries = (
                    entries_reader(now=self._now())
                    if callable(entries_reader)
                    else {}
                )
                entry = entries.get(condition_id) if isinstance(entries, Mapping) else None
                cached = (
                    entry[1]
                    if isinstance(entry, tuple) and len(entry) == 2
                    else None
                )
                if isinstance(cached, Mapping):
                    title = title or _text(cached.get("market_title")) or _text(
                        cached.get("question")
                    ) or _text(cached.get("title"))
                    market_url = market_url or _text(cached.get("market_url"))
                    outcome = outcome or _text(cached.get("outcome"))
                    outcomes = cached.get("outcomes")
                    if not outcome and isinstance(outcomes, Mapping):
                        for raw_outcome in outcomes.values():
                            if not isinstance(raw_outcome, Mapping):
                                continue
                            raw_token = str(raw_outcome.get("token_id") or "").strip()
                            if raw_token and raw_token == token_id:
                                outcome = _text(raw_outcome.get("label")) or _text(
                                    raw_outcome.get("outcome")
                                )
                                break
            except Exception:
                pass
        if not title:
            title = (
                f"未知市场（condition_id={condition_id or '未知'}; "
                f"token_id={token_id or '未知'}）"
            )
        if not outcome:
            outcome = f"选项未知（token_id={token_id or '未知'}）"
        return {
            "title": title,
            "url": market_url or "",
            "outcome": outcome,
            "condition_id": condition_id or "未知",
            "token_id": token_id or "未知",
        }

    def _queue_protection_market_title(
        self, session: Mapping[str, object]
    ) -> str:
        return self._queue_protection_identity(session)["title"]

    @staticmethod
    def _record_order_placement_times(
        protection: Mapping[str, object],
        rows_by_id: Mapping[str, object] | None,
        order_ids: Collection[str],
    ) -> dict[str, object]:
        """Carry valid venue placement stamps into the existing payload."""

        result: dict[str, object] = {}
        raw = protection.get("order_placement_times")
        if isinstance(raw, Mapping):
            result.update({str(key): value for key, value in raw.items() if str(key)})
        for order_id in order_ids:
            order_id = str(order_id or "")
            if not order_id:
                continue
            row = rows_by_id.get(order_id) if rows_by_id is not None else None
            raw_created_at = _field(row, "created_at") if row is not None else None
            if raw_created_at is None:
                result.setdefault(order_id, None)
                continue
            try:
                created_at = _timestamp(raw_created_at, name="venue_created_at")
            except ValueError:
                result.setdefault(order_id, None)
            else:
                result[order_id] = _iso(created_at)
        return result

    @staticmethod
    def _beijing_datetime_text(value: object) -> str | None:
        try:
            return _timestamp(value).astimezone(_BEIJING).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        except ValueError:
            return None

    @staticmethod
    def _lifetime_text(start: datetime, end: datetime) -> str | None:
        seconds = int((end - start).total_seconds())
        if seconds < 0:
            return None
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        parts: list[str] = []
        if hours:
            parts.append(f"{hours}小时")
        if minutes:
            parts.append(f"{minutes}分")
        if seconds or not parts:
            parts.append(f"{seconds}秒")
        return "".join(parts)

    def _queue_protection_lifecycle_lines(
        self,
        protection: Mapping[str, object],
        order_ids: Sequence[str],
        *,
        observed_at: object = None,
    ) -> list[str]:
        """Describe actual venue lifetime, or clearly label observation fallback."""

        placement_values = protection.get("order_placement_times")
        confirmation_values = protection.get("order_cancel_confirmed_at")
        placements: list[datetime] = []
        confirmations: list[datetime] = []
        if isinstance(placement_values, Mapping) and isinstance(
            confirmation_values, Mapping
        ):
            for order_id in order_ids:
                try:
                    placement = _timestamp(
                        placement_values.get(order_id), name="venue_created_at"
                    )
                    confirmation = _timestamp(
                        confirmation_values.get(order_id), name="cancel_confirmed_at"
                    )
                except (AttributeError, ValueError):
                    continue
                if placement > confirmation:
                    continue
                placements.append(placement)
                confirmations.append(confirmation)
        actual_known = bool(order_ids) and len(placements) == len(order_ids)
        lines: list[str] = []
        if actual_known and placements and confirmations:
            started = min(placements)
            completed = max(confirmations)
            lifetime = self._lifetime_text(started, completed)
            start_text = self._beijing_datetime_text(started)
            completed_text = self._beijing_datetime_text(completed)
            if lifetime is not None and start_text and completed_text:
                lines.extend(
                    [
                        f"首次挂单：北京时间 {start_text}",
                        f"撤单完成：北京时间 {completed_text}",
                        f"挂单存续：{lifetime}",
                    ]
                )
                return lines

        lines.append("首次挂单：未知（未取得有效的实际交易所下单时间）")
        completed: datetime | None = None
        if isinstance(confirmation_values, Mapping):
            valid_confirmations: list[datetime] = []
            for value in confirmation_values.values():
                try:
                    valid_confirmations.append(
                        _timestamp(value, name="cancel_confirmed_at")
                    )
                except (AttributeError, ValueError):
                    continue
            if valid_confirmations:
                completed = max(valid_confirmations)
                completed_text = self._beijing_datetime_text(completed)
                if completed_text:
                    lines.append(f"撤单完成：北京时间 {completed_text}")
        try:
            first_seen = _timestamp(protection.get("first_seen_at"), name="first_seen_at")
            observed_text = self._beijing_datetime_text(first_seen)
            observed_lifetime = (
                self._lifetime_text(first_seen, completed)
                if completed is not None
                else None
            )
            if observed_text:
                lines.append(f"首次观察：北京时间 {observed_text}")
            if observed_lifetime is not None:
                lines.append(f"观察到的存续时长：{observed_lifetime}")
        except (TypeError, ValueError):
            pass
        return lines

    @staticmethod
    def _queue_protection_order_ids(
        protection: Mapping[str, object],
    ) -> list[str]:
        values = protection.get("canceled_order_ids")
        return [str(value) for value in _items(values) if str(value or "")]

    def _queue_protection_success_notification(
        self,
        protection: Mapping[str, object],
        session: Mapping[str, object],
        *,
        canceled_count: int,
        manual_count: int,
        canceled_remaining: Decimal | None,
        title: str = "LP 位置保护撤单",
        trigger_prefix: str = "",
    ) -> tuple[str, str, str]:
        ratio = _maybe_decimal(protection.get("ratio"))
        cancel_reason = str(protection.get("cancel_reason") or "")
        price = _maybe_decimal(protection.get("baseline_price"))
        if cancel_reason == "book_unreliable":
            trigger = "行情数据中断超过 10 秒，进入保守撤单保护，因此已撤单"
        else:
            threshold = (
                _maybe_decimal(protection.get("threshold"))
                or LP_QUEUE_PROTECTION_THRESHOLD
            )
            front = _maybe_decimal(protection.get("front_estimate"))
            total = _maybe_decimal(protection.get("level_total"))
            trigger = (
                f"BUY 买单估计按份额排到 "
                f"{_queue_decimal_text(price)} 价位买单队列前约"
                f"{_queue_ratio_percent_text(ratio)}%的位置，进入“前"
                f"{_queue_ratio_percent_text(threshold)}%自动撤单”的保护范围"
                "（按份额估计，不是订单数，也不是精确名次），因此已撤单。\n"
                f"判断证据：A 比例 {_queue_ratio_percent_text(ratio)}% ≤ "
                f"{_queue_ratio_percent_text(threshold)}%"
                f"（前方≈{_queue_decimal_text(front)} / "
                f"同价位 {_queue_decimal_text(total)} 份）"
            )
        identity = self._queue_protection_identity(session)
        outcome = identity["outcome"]
        if outcome.upper() in {"YES", "NO"}:
            outcome = outcome.upper()
        identity_line = f"市场：{identity['title']}。"
        if identity["url"]:
            identity_line += f"\n链接：{identity['url']}。"
        identity_line += f"\n方向：BUY {outcome}；价格：{_queue_decimal_text(price)}。"
        order_ids = self._queue_protection_order_ids(protection)
        remaining_values = protection.get("cancel_target_remaining")
        order_parts: list[str] = []
        for order_id in order_ids:
            remaining = (
                _maybe_decimal(remaining_values.get(order_id))
                if isinstance(remaining_values, Mapping)
                else None
            )
            order_parts.append(f"{order_id}={_queue_decimal_text(remaining)}份")
        order_line = (
            "撤单订单（撤单时余量）：" + "；".join(order_parts) + "。"
            if order_parts
            else "撤单订单（撤单时余量）：未知。"
        )
        baseline_source = str(protection.get("baseline_source") or "")
        if baseline_source == "first_observation":
            source_line = "盘口基线：首次观察订单时建立的盘口基线。"
        elif baseline_source == "submit":
            source_line = "盘口基线：提交时基线。"
        else:
            source_line = "盘口基线：未知。"
        data_time = self._beijing_datetime_text(protection.get("data_time"))
        if data_time is None:
            data_time = beijing_clock(protection.get("data_time"), seconds=True)
        lifecycle = self._queue_protection_lifecycle_lines(protection, order_ids)
        message = (
            f"{identity_line}\n"
            f"触发：{trigger_prefix}{trigger}。\n"
            f"结果：已撤 {canceled_count} 张买单"
            f"合计余量 {_queue_decimal_text(canceled_remaining)} 份"
            f" @ {_queue_decimal_text(price)}"
            f"（含 {manual_count} 张手动）。\n"
            f"{order_line}\n"
            f"{source_line}\n"
            + "\n".join(lifecycle)
            + "\n"
            f"数据时间：北京时间 {data_time or '未知'}。"
        )
        return (
            title,
            message,
            f"{title}，{canceled_count} 张买单已撤",
        )

    def _queue_protection_blocked_notification(
        self,
        protection: Mapping[str, object],
        session: Mapping[str, object],
        failure_reason: str,
        remaining: Decimal | None,
        *,
        title: str = "LP 位置保护撤单受阻",
        trigger_prefix: str = "",
    ) -> tuple[str, str, str]:
        ratio = _maybe_decimal(protection.get("ratio"))
        price = _maybe_decimal(protection.get("baseline_price"))
        identity = self._queue_protection_identity(session)
        outcome = identity["outcome"]
        if outcome.upper() in {"YES", "NO"}:
            outcome = outcome.upper()
        identity_line = f"市场：{identity['title']}。"
        if identity["url"]:
            identity_line += f"\n链接：{identity['url']}。"
        identity_line += f"\n方向：BUY {outcome}；价格：{_queue_decimal_text(price)}。"
        cancel_reason = str(protection.get("cancel_reason") or "")
        if cancel_reason == "book_unreliable" or ratio is None:
            trigger = (
                "行情数据中断，无法可靠估计排队位置，进入保守撤单尝试"
            )
        else:
            threshold = (
                _maybe_decimal(protection.get("threshold"))
                or LP_QUEUE_PROTECTION_THRESHOLD
            )
            trigger = (
                f"{trigger_prefix}BUY 买单估计按份额排到 "
                f"{_queue_decimal_text(price)} 价位买单队列前约"
                f"{_queue_ratio_percent_text(ratio)}%的位置，进入“前"
                f"{_queue_ratio_percent_text(threshold)}%自动撤单”的保护范围"
                "（按份额估计，不是订单数，也不是精确名次）"
            )
        baseline_source = str(protection.get("baseline_source") or "")
        if baseline_source == "first_observation":
            source_line = "盘口基线：首次观察订单时建立的盘口基线。"
        elif baseline_source == "submit":
            source_line = "盘口基线：提交时基线。"
        else:
            source_line = "盘口基线：未知。"
        data_time = self._beijing_datetime_text(protection.get("data_time"))
        if data_time is None:
            data_time = beijing_clock(protection.get("data_time"), seconds=True)
        message = (
            f"{identity_line}\n"
            f"尝试保护：{trigger}。\n"
            f"撤单未成功：{failure_reason}，"
            f"残余 {_queue_decimal_text(remaining)} 份待处理。\n"
            f"{source_line}\n"
            f"数据时间：北京时间 {data_time or '未知'}。"
        )
        return (title, message, title)

    @staticmethod
    def _merge_order_id_lists(*groups: object) -> list[str]:
        """Union order ids across a protection episode (ordered, deduplicated)."""

        result: list[str] = []
        seen: set[str] = set()
        for group in groups:
            for value in _items(group):
                order_id = str(value or "")
                if order_id and order_id not in seen:
                    seen.add(order_id)
                    result.append(order_id)
        return result

    @staticmethod
    def _episode_canceled_remaining(
        target_remaining: object, canceled_order_ids: list[str]
    ) -> Decimal | None:
        """Sum persisted cancel-time remaining over the episode's canceled set.

        Any canceled order without a persisted numeric remaining (unknown at
        request time, or persisted by an older build) makes the whole total
        UNKNOWN instead of under-reporting a partial sum (issue 152 review
        fix).
        """

        if not isinstance(target_remaining, Mapping):
            return None if canceled_order_ids else Decimal("0")
        total = Decimal("0")
        for order_id in canceled_order_ids:
            remaining = _maybe_decimal(target_remaining.get(str(order_id)))
            if remaining is None:
                return None
            total += remaining
        return total

    def _queue_protection_price_title(
        self, session: Mapping[str, object], bucket: Mapping[str, object], base: str
    ) -> str:
        """Issue 167 D5: per-bucket notification title carrying the price."""

        outcome = str(self._queue_protection_identity(session)["outcome"] or "").upper()
        price = _maybe_decimal(bucket.get("baseline_price"))
        return f"{outcome} {_queue_decimal_text(price)} {base}"

    def _plan_bucket_protection_cancel(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object] | None,
        bucket: Mapping[str, object],
        *,
        reason: str = "queue_ahead_ratio",
        only_order_ids: list[str] | None = None,
        notify_blocked: bool = True,
        bucket_key: str | None = None,
    ) -> tuple[dict[str, object] | None, dict[str, object], dict[str, object]]:
        """Plan one protection cancel without committing or cancelling.

        A ``snapshot=None`` fallback may perform its existing read-only
        account lookup to enumerate targets; it never places or cancels.
        """

        session_id = str(session["session_id"])
        entry_order_id = str(session.get("entry_order_id") or "")
        token_id = str(session.get("token_id") or "")
        baseline_price = _maybe_decimal(bucket.get("baseline_price"))
        updated = dict(bucket)
        current = self.store.lp_session(session_id) or session
        if current.get("order_identity_conflict"):
            return None, self._blocked_bucket_protection_cancel(
                session, updated, "order_identity_conflict", "订单身份冲突，等待核对",
                None, notify=notify_blocked, bucket_key=bucket_key
            ), {}
        if baseline_price is None:
            return None, updated, {}
        own_order_ids = self._session_augment_own_order_ids(session)

        if snapshot is None:
            # Data-unreliable path: enumerate targets from one fresh
            # account read; a failed read blocks this tick and retries.
            rows = self._queue_account_open_orders()
            if rows is None:
                return None, self._blocked_bucket_protection_cancel(
                    session,
                    updated,
                    "account_read_failed",
                    "账户读取失败",
                    None,
                    notify=notify_blocked,
                    bucket_key=bucket_key,
                ), {}
            rows_by_id: dict[str, object] = {}
            for row in rows:
                order_id = self._order_id(row)
                if order_id:
                    rows_by_id.setdefault(order_id, row)
        else:
            rows_by_id = self._queue_level_rows(snapshot)

        # Identity re-check: every registered own receipt must still name a
        # BUY on the protected token before any cancel is sent.
        for order_id, row in rows_by_id.items():
            if order_id not in own_order_ids:
                continue
            row_token = str(_field(row, "token_id", _field(row, "asset_id", "")) or "")
            side = str(_field(row, "side", "")).upper()
            if (side and side != "BUY") or (row_token and row_token != token_id):
                return None, self._blocked_bucket_protection_cancel(
                    session,
                    updated,
                    "identity_conflict",
                    "回执身份不符",
                    None,
                    notify=notify_blocked,
                    bucket_key=bucket_key,
                ), {}

        if not self._mutation_allowed():
            remaining = self._own_queue_remaining_rows(
                rows_by_id, token_id=token_id, price=baseline_price
            )
            return None, self._blocked_bucket_protection_cancel(
                session,
                updated,
                "mutation_blocked",
                "撤单被熔断阻止",
                remaining,
                notify=notify_blocked,
                bucket_key=bucket_key,
            ), {}

        history = self._order_history(session)
        anchor = str(bucket.get("order_id") or "") or format(baseline_price, "f")
        targets: list[str] = []
        skipped: list[dict[str, object]] = []
        seen_targets: set[str] = set()

        def add_target(order_id: str) -> None:
            if order_id and order_id not in seen_targets:
                seen_targets.add(order_id)
                targets.append(order_id)

        # The bucket's own registered order first, then every other own
        # order resting at this price (durable history or receipt evidence).
        add_target(str(bucket.get("order_id") or ""))
        for order_id in own_order_ids:
            record = history.get(order_id)
            row = rows_by_id.get(order_id)
            source = (
                record
                if isinstance(record, Mapping) and record.get("status")
                else row
            )
            if source is None:
                continue
            status = str(_field(source, "status", "") or "").upper()
            if status and status in TERMINAL_ORDER_STATES:
                continue
            order_price = _maybe_decimal(_field(source, "price"))
            if order_price is not None and order_price != baseline_price:
                continue
            side = str(_field(source, "side", "BUY") or "BUY").upper()
            if side != "BUY":
                continue
            add_target(order_id)
        # Then every same-token same-price BUY row visible on the read
        # (manual same-price orders share the bucket's cancel scope).
        for order_id, row in rows_by_id.items():
            if order_id in seen_targets:
                continue
            row_token = str(_field(row, "token_id", _field(row, "asset_id", "")) or "")
            if row_token and row_token != token_id:
                continue
            row_price = _maybe_decimal(_field(row, "price"))
            if row_price is None:
                skipped.append({"order_id": order_id, "reason": "identity_unknown"})
                continue
            if row_price != baseline_price:
                continue
            side = str(_field(row, "side", "")).upper()
            if side != "BUY":
                skipped.append({"order_id": order_id, "reason": "identity_mismatch"})
                continue
            if str(_field(row, "status", "")).upper() in TERMINAL_ORDER_STATES:
                continue
            add_target(order_id)

        if only_order_ids is not None:
            retry = set(only_order_ids)
            targets = [order_id for order_id in targets if order_id in retry]
        # Issue 152 review: within one protection episode the target set and
        # the canceled set accumulate across retries (ordered union), so a
        # retried batch can never overwrite the earlier episode state.
        episode_targets = self._merge_order_id_lists(
            bucket.get("cancel_targets"), targets
        )

        # Issue 152 review fix: persist every target's cancel-time remaining
        # at request (intent) time, whether or not this batch's cancel is
        # later acknowledged, so an order the venue cancels without our
        # acknowledgment still reports its share in the episode total. A
        # target without a readable remaining persists as None (UNKNOWN),
        # never 0. First write wins: retries never overwrite an earlier
        # batch's persisted value.
        persisted_remaining: dict[str, object] = {}
        raw_remaining = bucket.get("cancel_target_remaining")
        if isinstance(raw_remaining, Mapping):
            for key, value in raw_remaining.items():
                order_id = str(key or "")
                if order_id:
                    persisted_remaining[order_id] = value
        for order_id in targets:
            if order_id in persisted_remaining:
                continue
            row = rows_by_id.get(order_id)
            remaining = self._queue_row_remaining(row) if row is not None else None
            persisted_remaining[order_id] = (
                None if remaining is None else str(remaining)
            )
        placement_times = self._record_order_placement_times(
            updated, rows_by_id, targets
        )
        confirmed_times: dict[str, object] = {}
        raw_confirmed = updated.get("order_cancel_confirmed_at")
        if isinstance(raw_confirmed, Mapping):
            confirmed_times.update(
                {str(key): value for key, value in raw_confirmed.items() if str(key)}
            )
        action_key = f"{session_id}:entry-protection-cancel:{anchor}"
        intent_payload: dict[str, object] = {
            "role": "entry-protection-cancel",
            "targets": targets,
            "skipped": skipped,
            "reason": reason,
            "ratio": updated.get("ratio"),
            "data_time": updated.get("data_time"),
            "cancel_target_remaining": persisted_remaining,
        }
        plan = {
            "session_id": session_id,
            "entry_order_id": entry_order_id,
            "action_key": action_key,
            "intent_payload": intent_payload,
            "targets": targets,
            "episode_targets": episode_targets,
            "persisted_remaining": persisted_remaining,
            "placement_times": placement_times,
            "confirmed_times": confirmed_times,
            "updated": updated,
        }
        return plan, updated, {}

    def _execute_bucket_protection_cancel(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        bucket: Mapping[str, object],
        plan: dict[str, object],
        *,
        bucket_key: str | None = None,
    ) -> tuple[dict[str, object], dict[str, object]]:
        """Send one already-committed cancel plan and persist its receipt."""

        session_id = str(plan["session_id"])
        entry_order_id = str(plan["entry_order_id"])
        action_key = str(plan["action_key"])
        intent_payload = dict(plan["intent_payload"])
        targets = list(plan["targets"])
        episode_targets = list(plan["episode_targets"])
        persisted_remaining = dict(plan["persisted_remaining"])
        placement_times = dict(plan["placement_times"])
        confirmed_times = dict(plan["confirmed_times"])
        updated = dict(plan["updated"])
        canceled: list[str] = []
        failed: list[str] = []
        unsent: list[str] = []
        failure_error: str | None = None
        for order_id in targets:
            try:
                if self._cancel_order(order_id):
                    canceled.append(order_id)
                    confirmed_times.setdefault(order_id, _iso(self._now()))
                else:
                    failed.append(order_id)
            except _MutationBlocked as exc:
                unsent.append(order_id)
                failed.append(order_id)
                failure_error = type(exc).__name__
            except Exception as exc:
                failed.append(order_id)
                failure_error = type(exc).__name__

        receipt_payload: dict[str, object] = {
            **intent_payload,
            "canceled": canceled,
            "failed": failed,
        }
        # An authorized action's real receipt always survives, even if a newer
        # account fence lands while its venue call is in flight.
        if targets and len(unsent) == len(targets):
            self.store.lp_reject_pending_cancel(session_id, action_key)
        elif failed:
            receipt_payload["error"] = failure_error or "cancel_not_acknowledged"
            self.store.lp_finish_cancel(
                session_id, action_key, state="pending", payload=receipt_payload
            )
        else:
            self.store.lp_finish_cancel(
                session_id, action_key, state="accepted", payload=receipt_payload
            )

        # Cancel-time remaining is summed from the per-target values
        # persisted at request time over every order in the episode's
        # canceled set (acknowledged or receipt-proved), never re-derived
        # from post-cancel reads.
        episode_canceled = self._merge_order_id_lists(
            bucket.get("canceled_order_ids"), canceled
        )
        episode_remaining = self._episode_canceled_remaining(
            persisted_remaining, episode_canceled
        )

        updated["state"] = "canceling"
        updated["cancel_reason"] = str(intent_payload["reason"])
        updated["cancel_targets"] = episode_targets
        updated["cancel_failed"] = failed
        updated["cancel_target_remaining"] = persisted_remaining
        updated["order_placement_times"] = placement_times
        updated["order_cancel_confirmed_at"] = confirmed_times
        updated["canceled_order_ids"] = episode_canceled
        updated["canceled_remaining"] = episode_remaining
        updated["cancel_requested_at"] = _iso(self._now())
        if failed:
            updated["cancel_failure"] = failure_error or "cancel_not_acknowledged"

        session_patch: dict[str, object] = {}
        if entry_order_id in targets and not bool(session.get("entry_cancel_requested")):
            session_patch["entry_cancel_requested"] = True
        session_augment_ids = {
            str(value)
            for value in _items(session.get("augment_order_ids"))
            if str(value or "")
        }
        augment_requested = {
            str(value) for value in _items(session.get("augment_cancel_requested"))
        }
        new_augment = sorted(
            augment_requested
            | {
                order_id
                for order_id in targets
                if order_id in session_augment_ids
            }
        )
        if new_augment != sorted(augment_requested):
            session_patch["augment_cancel_requested"] = new_augment
        return updated, session_patch

    def _request_bucket_protection_cancel(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object] | None,
        bucket: Mapping[str, object],
        *,
        reason: str = "queue_ahead_ratio",
        only_order_ids: list[str] | None = None,
        notify_blocked: bool = True,
        expected_trade_revision: int | None = None,
        bucket_key: str | None = None,
    ) -> tuple[dict[str, object], dict[str, object]]:
        """Plan, fence one bucket, then send its registered cancel intent."""

        plan, blocked, patch = self._plan_bucket_protection_cancel(
            session, snapshot, bucket, reason=reason,
            only_order_ids=only_order_ids, notify_blocked=notify_blocked,
            bucket_key=bucket_key,
        )
        if plan is None:
            return blocked, patch
        expected_generation = (
            snapshot.get("_lp_trade_generation")
            if isinstance(snapshot, Mapping)
            else None
        )
        if expected_generation is not None and not isinstance(
            expected_trade_revision, int
        ):
            self._publish_account_round_rejected(str(session["session_id"]))
            return dict(bucket), {}
        actions = [{
            "action_key": plan["action_key"],
            "payload": plan["intent_payload"],
        }]
        try:
            self.store.lp_register_fenced_actions(
                str(session["session_id"]), actions,
                expected_generation=expected_generation,
                expected_trade_revision=expected_trade_revision,
            )
        except ValueError as exc:
            if str(exc) == "account_round_invalid":
                self._publish_account_round_rejected(str(session["session_id"]))
                return dict(bucket), {}
            raise
        return self._execute_bucket_protection_cancel(
            session, snapshot, bucket, plan, bucket_key=bucket_key
        )

    def _blocked_bucket_protection_cancel(
        self,
        session: Mapping[str, object],
        bucket: dict[str, object],
        reason_code: str,
        failure_reason: str,
        remaining: Decimal | None,
        *,
        notify: bool = True,
        bucket_key: str | None = None,
    ) -> dict[str, object]:
        codes = list(bucket.get("reason_codes") or [])
        if reason_code not in codes:
            codes.append(reason_code)
        bucket["state"] = "blocked"
        bucket["reason_codes"] = codes
        if notify and bucket.get("blocked_notified") is not True:
            title, message, xiaoai = self._queue_protection_blocked_notification(
                bucket,
                session,
                failure_reason,
                remaining,
                title=self._queue_protection_price_title(
                    session, bucket, "位置保护撤单受阻"
                ),
            )
            if self._notify_bucket_protection(
                session,
                bucket,
                bucket_key or str(bucket.get("order_id") or ""),
                "blocked_notified",
                title,
                message,
                xiaoai,
            ):
                bucket["blocked_notified"] = True
        return bucket

    def _converge_queue_protection(
        self,
        session: Mapping[str, object],
        bucket: Mapping[str, object],
        rows_by_id: Mapping[str, object],
        *,
        bucket_key: str | None = None,
    ) -> dict[str, object] | None:
        """Settle one canceling bucket from order receipts (issue 152 D4.7)."""

        if str(bucket.get("state")) != "canceling":
            return None
        targets = [
            str(value)
            for value in _items(bucket.get("cancel_targets"))
            if str(value or "")
        ]
        if not targets:
            return None
        history = self._order_history(session)
        filled = Decimal("0")
        receipt_canceled: list[str] = []
        for order_id in targets:
            record = history.get(order_id)
            row = rows_by_id.get(order_id)
            source = (
                record
                if isinstance(record, Mapping)
                and record.get("status")
                else row
            )
            if source is None:
                # No receipt and no resting row anywhere: the order is no
                # longer open on any read path, i.e. canceled.
                receipt_canceled.append(order_id)
                continue
            status = str(_field(source, "status", "") or "").upper()
            if not status:
                return None
            if status not in TERMINAL_ORDER_STATES:
                return None
            if status in {"CANCELED", "CANCELLED"}:
                receipt_canceled.append(order_id)
            matched = _maybe_decimal(_field(source, "size_matched"))
            if matched is not None and matched > 0:
                filled += matched
        updated = dict(bucket)
        updated["order_placement_times"] = self._record_order_placement_times(
            updated, rows_by_id, targets
        )
        confirmed_times: dict[str, object] = {}
        raw_confirmed = updated.get("order_cancel_confirmed_at")
        if isinstance(raw_confirmed, Mapping):
            confirmed_times.update(
                {str(key): value for key, value in raw_confirmed.items() if str(key)}
            )
        if receipt_canceled:
            observed_at = _iso(self._now())
            for order_id in receipt_canceled:
                confirmed_times.setdefault(order_id, observed_at)
        updated["order_cancel_confirmed_at"] = confirmed_times
        if filled > 0:
            updated["state"] = "partially_filled"
            updated["partially_filled_quantity"] = filled
        else:
            updated["state"] = "canceled"
        # Receipt-proved cancellations join the durable episode set so the
        # one-shot success notification reports only actually canceled
        # orders. A fully filled/rejected target has no cancellation success
        # to announce.
        canceled = self._merge_order_id_lists(
            updated.get("canceled_order_ids"), receipt_canceled
        )
        updated["canceled_order_ids"] = canceled
        if canceled:
            updated["canceled_remaining"] = self._episode_canceled_remaining(
                updated.get("cancel_target_remaining"), canceled
            )
        return updated

    def _apply_queue_protection(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        *,
        skip_cancel_keys: Collection[str] = (),
        trade_revision: int | None = None,
    ) -> dict[str, object]:
        """Evaluate every price bucket inside the monitor tick and persist
        the v2 {version, data_failures, levels} payload (issue 167)."""

        protection = session.get("queue_protection")
        buckets = self._queue_protection_levels(session)
        if not isinstance(protection, Mapping) or not buckets:
            return dict(session)
        session_id = str(session["session_id"])
        rows_by_id = self._queue_level_rows(snapshot)
        failures = _queue_group_failures_int(protection.get("data_failures"))
        changed = False
        session_patch: dict[str, object] = {}
        new_levels: dict[str, dict[str, object]] = {}
        skip_keys = {str(value) for value in skip_cancel_keys}
        for key, bucket in buckets.items():
            if str(bucket.get("state")) == "canceling":
                converged = self._converge_queue_protection(
                    session, bucket, rows_by_id, bucket_key=key
                )
                if converged is not None:
                    new_levels[key] = converged
                    changed = True
                    continue
                failed = [
                    str(value)
                    for value in _items(bucket.get("cancel_failed"))
                    if str(value or "")
                ]
                if failed and key not in skip_keys:
                    bucket, patch = self._request_bucket_protection_cancel(
                        session,
                        snapshot,
                        bucket,
                        reason=str(bucket.get("cancel_reason") or "queue_ahead_ratio"),
                        only_order_ids=failed,
                        expected_trade_revision=trade_revision,
                        bucket_key=key,
                    )
                    # Issue 167 review fix: each bucket computes its session
                    # flags from the same pre-loop session, so a plain
                    # update() would let the second triggered bucket drop
                    # the first one's augment ids. Merge set-like keys by
                    # union (same pattern as _conservative_protection_cancel).
                    for patch_key, patch_value in patch.items():
                        if patch_key == "augment_cancel_requested":
                            merged = {
                                str(value)
                                for value in _items(session_patch.get(patch_key))
                            } | {str(value) for value in _items(patch_value)}
                            session_patch[patch_key] = sorted(merged)
                        else:
                            session_patch[patch_key] = patch_value
                    new_levels[key] = bucket
                    changed = True
                    continue
                new_levels[key] = bucket
                continue
            evaluation = self._bucket_queue_protection_evaluation(
                session, bucket, snapshot, rows_by_id
            )
            if evaluation is not None:
                bucket = evaluation
                changed = True
                if str(bucket.get("state")) not in {"unknown", "registered"}:
                    failures = 0
            if str(bucket.get("state")) == "triggered":
                if key in skip_keys:
                    new_levels[key] = bucket
                    continue
                bucket, patch = self._request_bucket_protection_cancel(
                    session,
                    snapshot,
                    bucket,
                    reason="queue_ahead_ratio",
                    expected_trade_revision=trade_revision,
                    bucket_key=key,
                )
                # Same union merge as above: two buckets triggering in one
                # tick must accumulate their session flags, not overwrite.
                for patch_key, patch_value in patch.items():
                    if patch_key == "augment_cancel_requested":
                        merged = {
                            str(value)
                            for value in _items(session_patch.get(patch_key))
                        } | {str(value) for value in _items(patch_value)}
                        session_patch[patch_key] = sorted(merged)
                    else:
                        session_patch[patch_key] = patch_value
                new_levels[key] = bucket
                changed = True
                continue
            new_levels[key] = bucket
        if not changed:
            return dict(session)
        session_patch["queue_protection"] = {
            "version": 2,
            "data_failures": failures,
            "levels": new_levels,
        }
        queue_payload = cast(Mapping[str, object], session_patch.pop("queue_protection"))
        merger = getattr(self.store, "lp_merge_queue_protection", None)
        if callable(merger):
            updated = merger(
                session_id,
                queue_protection=queue_payload,
                patch=session_patch,
            )
        else:
            updated = self.store.lp_update_session(
                session_id,
                patch={**session_patch, "queue_protection": queue_payload},
            )
        self._notify_committed_protection_cancels(updated)
        return updated

    # ---- Issue 159: first-seen baseline fallback protections ----

    def _apply_first_seen_protections(self) -> None:
        """Evaluate every active first-seen episode, serially per token.

        Runs inside the existing one-second monitor tick under the service
        mutex, even when no LP session is active: web-manual BUYs registered
        by the dashboard's first-seen diff get the same protection loop as
        the issue 152 submit-boundary episodes, with no added concurrency.
        """

        reader = getattr(self.store, "lp_active_first_seen_episodes", None)
        if not callable(reader):
            return
        try:
            episodes = reader()
        except Exception:
            return
        valid_episodes = [
            episode
            for episode in episodes
            if isinstance(episode, Mapping) and str(episode.get("episode_id") or "")
        ]
        if not valid_episodes:
            return
        begin = getattr(self.exchange, "lp_account_round_begin", None)
        end = getattr(self.exchange, "lp_account_round_end", None)
        reader_generation = getattr(self.store, "lp_trade_generation", None)
        account_round = (
            begin(reader_generation)
            if callable(begin)
            else None
        )
        if account_round is not None:
            self.track_lp_account_round(account_round)
        try:
            for episode in valid_episodes:
                self._apply_first_seen_protection(episode, account_round)
        finally:
            if account_round is not None:
                self.untrack_lp_account_round(account_round)
                if callable(end):
                    end(account_round)

    def _first_seen_rows_by_id(
        self, account_round: object | None = None
    ) -> dict[str, object] | None:
        """Open-order rows keyed by id from one fresh account read, or None."""

        rows = self._queue_account_open_orders(account_round)
        if rows is None:
            return None
        rows_by_id: dict[str, object] = {}
        for row in rows:
            order_id = self._order_id(row)
            if order_id and order_id not in rows_by_id:
                rows_by_id[order_id] = row
        return rows_by_id

    @staticmethod
    def _first_seen_anchor_ids(episode: Mapping[str, object]) -> list[str]:
        raw = episode.get("anchor_order_ids")
        if isinstance(raw, Mapping) or not isinstance(raw, (list, tuple)):
            return []
        return [str(value) for value in raw if str(value or "")]

    def _first_seen_anchors_all_terminal(
        self,
        rows_by_id: dict[str, object] | None,
        episode: Mapping[str, object],
    ) -> bool:
        """True when every registered anchor is gone from every read path.

        A missing row means the order no longer rests anywhere open; a row
        without a readable status cannot prove terminality and keeps the
        episode alive.
        """

        anchor_ids = self._first_seen_anchor_ids(episode)
        if not anchor_ids:
            return False
        for order_id in anchor_ids:
            row = rows_by_id.get(order_id) if rows_by_id is not None else None
            if row is None:
                continue
            status = str(_field(row, "status", "") or "").upper()
            if not status:
                return False
            if status not in TERMINAL_ORDER_STATES:
                return False
        return True

    def _first_seen_gate_open(
        self,
        episode: Mapping[str, object],
        rows_by_id: dict[str, object] | None,
    ) -> bool:
        """Issue 159 gate, mirroring ``_queue_protection_gate_open``: at
        least one registered anchor alive, cancel not yet requested, and no
        anchor has taken a fill."""

        if episode.get("cancel_requested_at"):
            return False
        anchor_ids = self._first_seen_anchor_ids(episode)
        if not anchor_ids:
            return False
        for order_id in anchor_ids:
            row = rows_by_id.get(order_id) if rows_by_id is not None else None
            if row is None:
                continue
            status = str(_field(row, "status", "") or "").upper()
            if status and status in TERMINAL_ORDER_STATES:
                continue
            matched = _maybe_decimal(_field(row, "size_matched"))
            if matched is not None and matched > 0:
                continue
            return True
        return False

    def _own_queue_remaining_rows(
        self,
        rows_by_id: Mapping[str, object],
        *,
        token_id: str,
        price: Decimal,
    ) -> Decimal | None:
        """Sum remaining size of own open BUYs at one token and price.

        Same poisoning rule as ``_own_queue_remaining``: any participating
        row without a parseable remaining poisons the total to None.
        """

        total = Decimal("0")
        for row in rows_by_id.values():
            row_token = _field(row, "token_id", _field(row, "asset_id"))
            if row_token not in (None, "", token_id):
                continue
            if str(_field(row, "side", "")).upper() != "BUY":
                continue
            if _maybe_decimal(_field(row, "price")) != price:
                continue
            if str(_field(row, "status", "")).upper() in TERMINAL_ORDER_STATES:
                continue
            remaining = self._queue_row_remaining(row)
            if remaining is None:
                return None
            total += remaining
        return total

    def _first_seen_book(
        self, token_id: str
    ) -> tuple[Mapping[str, object] | None, str | None]:
        """Fresh single-token book read with snapshot freshness semantics.

        Freshness is measured against a clock read taken after the book
        arrives, so a book we just received is never "negative age" stale.
        """

        book = self._read_first_seen_book(token_id)
        if book is None or book.get("received_at") is None:
            return None, "book_unknown"
        try:
            _freshness(
                book.get("received_at"),
                self._now(),
                "book_freshness",
                max_age=BOOK_FRESHNESS_SECONDS,
            )
        except ValueError:
            return None, "book_freshness_unknown"
        return book, None

    def _first_seen_data_failure(
        self,
        episode: Mapping[str, object],
        reason: str,
        *,
        gate_open: bool,
    ) -> dict[str, object] | None:
        """Increment the durable outage counter, mirroring issue 152."""

        if reason not in _QUEUE_DATA_FAILURE_REASONS:
            return None
        if str(episode.get("state")) in {"canceling", "canceled", "partially_filled"}:
            return None
        updated = dict(episode)
        if not gate_open:
            # The episode no longer protects a live anchor: an outage streak
            # is irrelevant and resets instead of accumulating.
            updated["data_failures"] = 0
            return updated
        failures = _maybe_decimal(updated.get("data_failures")) or Decimal("0")
        updated["data_failures"] = failures + 1
        return updated

    def _conservative_first_seen_cancel(
        self,
        episode: Mapping[str, object],
        failures: dict[str, object] | None,
        *,
        gate_open: bool,
        account_round: object | None = None,
        expected_generation: int | None = None,
        expected_round_generation: int | None = None,
    ) -> dict[str, object] | None:
        """Cancel the protected anchors after ten data outages (issue 159)."""

        if failures is None:
            return None
        count = _maybe_decimal(failures.get("data_failures")) or Decimal("0")
        if count < LP_PROTECTION_DATA_FAILURE_LIMIT:
            return None
        if not gate_open:
            return None
        return self._request_first_seen_protection_cancel(
            episode,
            None,
            reason="book_unreliable",
            account_round=account_round,
            expected_generation=expected_generation,
            expected_round_generation=expected_round_generation,
        )

    def _first_seen_round_is_current(
        self,
        account_round: object | None,
        round_generation: int | None,
        trade_generation: int | None,
    ) -> bool:
        """Check both the in-memory read generation and durable fence."""

        if account_round is None:
            return True
        matches = getattr(self.exchange, "_lp_account_round_matches", None)
        if not callable(matches):
            return False
        try:
            matches(account_round, round_generation)
        except LpAccountRoundInvalid:
            return False
        reader = getattr(self.store, "lp_trade_generation", None)
        if trade_generation is None or not callable(reader):
            return True
        return int(reader()) == int(trade_generation)

    def _update_first_seen_episode(
        self,
        episode_id: str,
        *,
        state: str | None = None,
        patch: Mapping[str, object] | None = None,
        expected_generation: int | None = None,
    ) -> dict[str, object] | None:
        """Persist one account-derived observation or reject it as stale."""

        try:
            updated = self.store.lp_update_first_seen_episode(
                episode_id,
                state=state,
                patch=patch,
                expected_generation=expected_generation,
            )
            self._notify_committed_protection_cancels(updated, first_seen=True)
            return updated
        except ValueError as exc:
            if str(exc) == "account_round_invalid":
                return None
            raise

    def _apply_first_seen_protection(
        self,
        episode: Mapping[str, object],
        account_round: object | None = None,
    ) -> None:
        """Run one episode's evaluate/converge/cancel step and persist it."""

        episode_id = str(episode["episode_id"])
        state = str(episode.get("state") or "")
        read_round_generation: int | None = None
        read_trade_generation: int | None = None
        failure_trade_generation: int | None = None
        if account_round is not None:
            # Sample before the call: invalidation after the adapter returns
            # must never relabel old rows with the next generation.
            read_round_generation = getattr(account_round, "generation", None)
            reader = getattr(self.store, "lp_trade_generation", None)
            failure_trade_generation = (
                int(reader()) if callable(reader) else None
            )
        try:
            rows_by_id = self._first_seen_rows_by_id(account_round)
        except LpAccountRoundInvalid:
            # An ended or superseded read is only a wait: do not turn it
            # into an outage or authorize protection from stale facts.
            return
        if account_round is not None:
            # This is the fact version established by the completed read.
            read_trade_generation = getattr(
                account_round, "trade_generation", None
            )
        if not self._first_seen_round_is_current(
            account_round, read_round_generation, read_trade_generation
        ):
            return

        if state == "canceling":
            converged = self._converge_first_seen_protection(episode, rows_by_id)
            if converged is not None:
                if not self._first_seen_round_is_current(
                    account_round, read_round_generation, read_trade_generation
                ):
                    return
                self._update_first_seen_episode(
                    episode_id,
                    state=str(converged.get("state")),
                    patch=converged,
                    expected_generation=read_trade_generation,
                )
                return
            failed = [
                str(value)
                for value in _items(episode.get("cancel_failed"))
                if str(value or "")
            ]
            if failed and rows_by_id is not None:
                result = self._request_first_seen_protection_cancel(
                    episode,
                    rows_by_id,
                    reason=str(episode.get("cancel_reason") or "queue_ahead_ratio"),
                    only_order_ids=failed,
                    account_round=account_round,
                    expected_generation=read_trade_generation,
                    expected_round_generation=read_round_generation,
                )
                if result is not None:
                    self._update_first_seen_episode(
                        episode_id,
                        state=str(result.get("state")),
                        patch=result,
                        expected_generation=(
                            read_trade_generation
                            if result.get("state") == "blocked"
                            else None
                        ),
                    )
            return

        if rows_by_id is None:
            # The account read failed: the observation is a data outage and
            # the anchors cannot be proven dead, so the gate stays open.
            failures = self._first_seen_data_failure(
                episode, "external_snapshot_unknown", gate_open=True
            )
            if not self._first_seen_round_is_current(
                account_round,
                read_round_generation,
                failure_trade_generation,
            ):
                return
            conservative = self._conservative_first_seen_cancel(
                episode,
                failures,
                gate_open=True,
                account_round=account_round,
                expected_generation=failure_trade_generation,
                expected_round_generation=read_round_generation,
            )
            if conservative is not None:
                self._update_first_seen_episode(
                    episode_id,
                    state=str(conservative.get("state")),
                    patch=conservative,
                    expected_generation=(
                        failure_trade_generation
                        if conservative.get("state") == "blocked"
                        else None
                    ),
                )
            elif failures is not None:
                if not self._first_seen_round_is_current(
                    account_round,
                    read_round_generation,
                    failure_trade_generation,
                ):
                    return
                self._update_first_seen_episode(
                    episode_id,
                    patch=failures,
                    expected_generation=failure_trade_generation,
                )
            return

        if self._first_seen_anchors_all_terminal(rows_by_id, episode):
            # Every anchor reached a terminal state on its own: the episode
            # ends and the token's remaining orders return to position
            # unknown (no chaining, no re-anchoring).
            if not self._first_seen_round_is_current(
                account_round, read_round_generation, read_trade_generation
            ):
                return
            self._update_first_seen_episode(
                episode_id,
                state="terminal",
                expected_generation=read_trade_generation,
            )
            return

        gate_open = self._first_seen_gate_open(episode, rows_by_id)
        token_id = str(episode.get("token_id") or "")
        anchor_price = _maybe_decimal(episode.get("anchor_price"))
        if anchor_price is None:
            return
        book, reason = self._first_seen_book(token_id)
        if not self._first_seen_round_is_current(
            account_round, read_round_generation, read_trade_generation
        ):
            return
        if reason is not None:
            failures = self._first_seen_data_failure(
                episode, reason, gate_open=gate_open
            )
            conservative = self._conservative_first_seen_cancel(
                episode,
                failures,
                gate_open=gate_open,
                account_round=account_round,
                expected_generation=read_trade_generation,
                expected_round_generation=read_round_generation,
            )
            if conservative is not None:
                self._update_first_seen_episode(
                    episode_id,
                    state=str(conservative.get("state")),
                    patch=conservative,
                    expected_generation=(
                        read_trade_generation
                        if conservative.get("state") == "blocked"
                        else None
                    ),
                )
            elif failures is not None:
                if not self._first_seen_round_is_current(
                    account_round, read_round_generation, read_trade_generation
                ):
                    return
                self._update_first_seen_episode(
                    episode_id,
                    patch=failures,
                    expected_generation=read_trade_generation,
                )
            return
        if not gate_open:
            # Nothing protectable and the data is healthy: no write, exactly
            # like the issue 152 evaluation returning None.
            return

        own_remaining = self._own_queue_remaining_rows(
            rows_by_id, token_id=token_id, price=anchor_price
        )
        estimate = estimate_lp_queue_position(
            book,
            price=anchor_price,
            own_remaining=own_remaining,
            baseline_front=_maybe_decimal(episode.get("baseline_front"))
            or Decimal("0"),
            threshold=_maybe_decimal(episode.get("threshold"))
            or LP_QUEUE_PROTECTION_THRESHOLD,
            condition_id=str(episode.get("condition_id") or "") or None,
            token_id=token_id or None,
        )
        updated = dict(episode)
        updated.update(
            {
                "state": estimate["state"],
                "front_estimate": estimate["front_estimate"],
                "level_total": estimate["level_total"],
                "ratio": estimate["ratio"],
                "reason_codes": estimate["reason_codes"],
                "data_time": estimate["data_time"],
            }
        )
        if estimate["state"] != "unknown":
            updated["data_failures"] = 0
            if (
                str(episode.get("state")) == "blocked"
                and updated.get("blocked_notified") is True
                and (
                    "mutation_blocked"
                    not in {
                        str(value)
                        for value in _items(episode.get("reason_codes"))
                    }
                    or self._mutation_allowed()
                )
            ):
                # blocked → recovered: re-arm the one-shot block notice so a
                # later block notifies again.
                updated["blocked_notified"] = False
        # The column state stays in the episode lifecycle domain; an
        # UNKNOWN estimate keeps the episode monitoring with reason codes.
        next_state = (
            "monitoring"
            if estimate["state"] in {"monitoring", "unknown", "triggered"}
            else str(estimate["state"])
        )
        if estimate["state"] != "triggered":
            if not self._first_seen_round_is_current(
                account_round, read_round_generation, read_trade_generation
            ):
                return
            self._update_first_seen_episode(
                episode_id,
                state=next_state,
                patch=updated,
                expected_generation=read_trade_generation,
            )
            return
        if not self._first_seen_round_is_current(
            account_round, read_round_generation, read_trade_generation
        ):
            return
        updated["state"] = next_state
        result = self._request_first_seen_protection_cancel(
            updated,
            rows_by_id,
            reason="queue_ahead_ratio",
            account_round=account_round,
            expected_generation=read_trade_generation,
            expected_round_generation=read_round_generation,
        )
        if result is not None:
            self._update_first_seen_episode(
                episode_id,
                state=str(result.get("state")),
                patch=result,
                expected_generation=(
                    read_trade_generation
                    if result.get("state") == "blocked"
                    else None
                ),
            )

    def _blocked_first_seen_cancel(
        self,
        episode: Mapping[str, object],
        protection: dict[str, object],
        reason_code: str,
        failure_reason: str,
        remaining: Decimal | None,
    ) -> dict[str, object]:
        codes = list(protection.get("reason_codes") or [])
        if reason_code not in codes:
            codes.append(reason_code)
        protection["state"] = "blocked"
        protection["reason_codes"] = codes
        if protection.get("blocked_notified") is not True:
            title, message, xiaoai = self._queue_protection_blocked_notification(
                protection,
                episode,
                failure_reason,
                remaining,
                title="LP 位置保护撤单受阻（首见基线）",
                trigger_prefix="首见基线 · ",
            )
            self._notify_protection(title, message, xiaoai)
            protection["blocked_notified"] = True
        return protection

    def _converge_first_seen_protection(
        self,
        episode: Mapping[str, object],
        rows_by_id: dict[str, object] | None,
    ) -> dict[str, object] | None:
        """Settle a canceling episode from fresh open-order reads (issue 159)."""

        if str(episode.get("state")) != "canceling":
            return None
        targets = [
            str(value)
            for value in _items(episode.get("cancel_targets"))
            if str(value or "")
        ]
        if not targets or rows_by_id is None:
            return None
        filled = Decimal("0")
        receipt_canceled: list[str] = []
        for order_id in targets:
            row = rows_by_id.get(order_id)
            if row is None:
                # No resting row anywhere: the order is no longer open on
                # any read path, i.e. canceled.
                receipt_canceled.append(order_id)
                continue
            status = str(_field(row, "status", "") or "").upper()
            if not status:
                return None
            if status not in TERMINAL_ORDER_STATES:
                return None
            if status in {"CANCELED", "CANCELLED"}:
                receipt_canceled.append(order_id)
            matched = _maybe_decimal(_field(row, "size_matched"))
            if matched is not None and matched > 0:
                filled += matched
        updated = dict(episode)
        updated["order_placement_times"] = self._record_order_placement_times(
            updated, rows_by_id, targets
        )
        confirmed_times: dict[str, object] = {}
        raw_confirmed = updated.get("order_cancel_confirmed_at")
        if isinstance(raw_confirmed, Mapping):
            confirmed_times.update(
                {str(key): value for key, value in raw_confirmed.items() if str(key)}
            )
        if receipt_canceled:
            observed_at = _iso(self._now())
            for order_id in receipt_canceled:
                confirmed_times.setdefault(order_id, observed_at)
        updated["order_cancel_confirmed_at"] = confirmed_times
        if filled > 0:
            updated["state"] = "partially_filled"
            updated["partially_filled_quantity"] = filled
        else:
            updated["state"] = "canceled"
        # Keep the success notice tied to the durable canceled union. A
        # target that only reached FILLED/another terminal state must not be
        # presented as a cancellation.
        canceled = self._merge_order_id_lists(
            updated.get("canceled_order_ids"), receipt_canceled
        )
        updated["canceled_order_ids"] = canceled
        if canceled:
            updated["canceled_remaining"] = self._episode_canceled_remaining(
                updated.get("cancel_target_remaining"), canceled
            )
        return updated

    def _request_first_seen_protection_cancel(
        self,
        episode: Mapping[str, object],
        rows_by_id: dict[str, object] | None,
        *,
        reason: str = "queue_ahead_ratio",
        only_order_ids: list[str] | None = None,
        account_round: object | None = None,
        expected_generation: int | None = None,
        expected_round_generation: int | None = None,
    ) -> dict[str, object] | None:
        """Cancel every own BUY resting at the first-seen anchor price.

        Deliberately not routed through the manual cancel audit pipeline;
        the episode records its own durable per-target actions instead.
        """

        episode_id = str(episode.get("episode_id") or "")
        token_id = str(episode.get("token_id") or "")
        anchor_price = _maybe_decimal(episode.get("anchor_price"))
        if not episode_id or anchor_price is None:
            return None
        updated = dict(episode)

        if account_round is not None and expected_round_generation is not None:
            if not self._first_seen_round_is_current(
                account_round,
                expected_round_generation,
                expected_generation,
            ):
                return None

        if rows_by_id is None:
            # Data-unreliable path: retry only inside the caller's original
            # scoped round; never sample a newer generation for these rows.
            try:
                rows_by_id = self._first_seen_rows_by_id(account_round)
            except LpAccountRoundInvalid:
                return None
            if not self._first_seen_round_is_current(
                account_round,
                expected_round_generation,
                expected_generation,
            ):
                return None
            if rows_by_id is None:
                return self._blocked_first_seen_cancel(
                    episode,
                    updated,
                    "account_read_failed",
                    "账户读取失败",
                    None,
                )

        # Identity re-check: every registered anchor receipt must still name
        # a BUY on the episode's token before any cancel is sent.
        anchor_set = set(self._first_seen_anchor_ids(episode))
        for order_id, row in rows_by_id.items():
            if order_id not in anchor_set:
                continue
            row_token = str(_field(row, "token_id", _field(row, "asset_id", "")) or "")
            side = str(_field(row, "side", "")).upper()
            if (side and side != "BUY") or (row_token and row_token != token_id):
                return self._blocked_first_seen_cancel(
                    episode, updated, "identity_conflict", "回执身份不符", None
                )

        if not self._mutation_allowed():
            remaining = None
            anchor_ids = self._first_seen_anchor_ids(episode)
            if anchor_ids and all(order_id in rows_by_id for order_id in anchor_ids):
                anchor_rows_valid = all(
                    str(_field(rows_by_id[order_id], "side", "") or "").upper()
                    == "BUY"
                    and str(
                        _field(
                            rows_by_id[order_id],
                            "token_id",
                            _field(rows_by_id[order_id], "asset_id", ""),
                        )
                        or ""
                    )
                    == token_id
                    and _maybe_decimal(_field(rows_by_id[order_id], "price"))
                    == anchor_price
                    for order_id in anchor_ids
                )
                if anchor_rows_valid:
                    remaining = self._own_queue_remaining_rows(
                        rows_by_id, token_id=token_id, price=anchor_price
                    )
            return self._blocked_first_seen_cancel(
                episode, updated, "mutation_blocked", "撤单被熔断阻止", remaining
            )

        targets: list[str] = []
        skipped: list[dict[str, object]] = []
        for order_id in self._first_seen_anchor_ids(episode):
            targets.append(order_id)
        for order_id, row in rows_by_id.items():
            if not order_id or order_id in anchor_set:
                continue
            row_token = str(_field(row, "token_id", _field(row, "asset_id", "")) or "")
            if row_token and row_token != token_id:
                continue
            row_price = _maybe_decimal(_field(row, "price"))
            if row_price is None:
                skipped.append({"order_id": order_id, "reason": "identity_unknown"})
                continue
            if row_price != anchor_price:
                continue
            side = str(_field(row, "side", "")).upper()
            if side != "BUY":
                skipped.append({"order_id": order_id, "reason": "identity_mismatch"})
                continue
            if str(_field(row, "status", "")).upper() in TERMINAL_ORDER_STATES:
                continue
            targets.append(order_id)

        if only_order_ids is not None:
            retry = set(only_order_ids)
            targets = [order_id for order_id in targets if order_id in retry]
        # Within one protection episode the target set and the canceled set
        # accumulate across retries (ordered union), so a retried batch can
        # never overwrite the earlier episode state.
        episode_targets = self._merge_order_id_lists(
            episode.get("cancel_targets"), targets
        )

        # Persist every target's cancel-time remaining at request (intent)
        # time; first write wins, unknown stays None, never 0.
        persisted_remaining: dict[str, object] = {}
        raw_remaining = episode.get("cancel_target_remaining")
        if isinstance(raw_remaining, Mapping):
            for key, value in raw_remaining.items():
                order_id = str(key or "")
                if order_id:
                    persisted_remaining[order_id] = value
        for order_id in targets:
            if order_id in persisted_remaining:
                continue
            row = rows_by_id.get(order_id)
            remaining = self._queue_row_remaining(row) if row is not None else None
            persisted_remaining[order_id] = (
                None if remaining is None else str(remaining)
            )

        # One durable action per target: intent first, then the cancel.
        placement_times = self._record_order_placement_times(
            updated, rows_by_id, targets
        )
        confirmed_times: dict[str, object] = {}
        raw_confirmed = updated.get("order_cancel_confirmed_at")
        if isinstance(raw_confirmed, Mapping):
            confirmed_times.update(
                {str(key): value for key, value in raw_confirmed.items() if str(key)}
            )

        def action_payload(order_id: str) -> dict[str, object]:
            return {
                "role": "first-seen-protection-cancel",
                "episode_id": episode_id,
                "targets": [order_id],
                "skipped": skipped,
                "reason": reason,
                "ratio": updated.get("ratio"),
                "data_time": updated.get("data_time"),
                "cancel_target_remaining": {
                    order_id: persisted_remaining.get(order_id)
                },
            }

        action_keys = {
            order_id: f"{episode_id}:first-seen-protection-cancel:{order_id}"
            for order_id in targets
        }
        # lp_actions rows reference lp_sessions; the reserved manual anchor
        # session (state complete, never active) is created once so the FK
        # holds for first-seen episode actions, mirroring the dashboard
        # manual-cancel audit anchor.  Creation is best-effort: while an
        # n-leg batch owns the insert gate (or the store is unavailable) the
        # refusal must not escape into the tick — the episode blocks through
        # the same one-shot path as every other cancel blocker instead of
        # starving the monitor and the issue 152 session pipeline.
        try:
            self.store.lp_create_session(
                LP_RESERVED_MANUAL_SESSION_ID,
                LP_RESERVED_MANUAL_SESSION_ID,
                state="complete",
                payload={"context": "first_seen_protection_audit"},
            )
        except Exception as exc:
            detail = str(exc).strip() or type(exc).__name__
            return self._blocked_first_seen_cancel(
                episode,
                updated,
                "anchor_session_failed",
                f"锚点审计会话创建失败（{detail}）",
                None,
            )
        actions = [
            {
                "action_key": action_keys[order_id],
                "payload": action_payload(order_id),
            }
            for order_id in targets
        ]
        try:
            self.store.lp_register_fenced_actions(
                LP_RESERVED_MANUAL_SESSION_ID,
                actions,
                expected_generation=expected_generation,
            )
        except ValueError as exc:
            if str(exc) == "account_round_invalid":
                return None
            raise

        canceled: list[str] = []
        failed: list[str] = []
        unsent: set[str] = set()
        failure_error: str | None = None
        for order_id in targets:
            try:
                if self._cancel_order(order_id):
                    canceled.append(order_id)
                    confirmed_times.setdefault(order_id, _iso(self._now()))
                else:
                    failed.append(order_id)
            except _MutationBlocked as exc:
                unsent.add(order_id)
                failed.append(order_id)
                failure_error = type(exc).__name__
                self.store.lp_reject_pending_cancel(
                    LP_RESERVED_MANUAL_SESSION_ID, action_keys[order_id]
                )
            except Exception as exc:
                failed.append(order_id)
                failure_error = type(exc).__name__

        for order_id in targets:
            if order_id in unsent:
                continue
            receipt = action_payload(order_id)
            if order_id in failed:
                receipt["canceled"] = []
                receipt["failed"] = [order_id]
                receipt["error"] = failure_error or "cancel_not_acknowledged"
                self.store.lp_finish_cancel(
                    LP_RESERVED_MANUAL_SESSION_ID,
                    action_keys[order_id],
                    state="pending",
                    payload=receipt,
                )
            else:
                receipt["canceled"] = [order_id]
                receipt["failed"] = []
                self.store.lp_finish_cancel(
                    LP_RESERVED_MANUAL_SESSION_ID,
                    action_keys[order_id],
                    state="accepted",
                    payload=receipt,
                )

        # Cancel-time remaining is summed from the per-target values
        # persisted at request time over every order in the episode's
        # canceled set, never re-derived from post-cancel reads.
        episode_canceled = self._merge_order_id_lists(
            episode.get("canceled_order_ids"), canceled
        )
        episode_remaining = self._episode_canceled_remaining(
            persisted_remaining, episode_canceled
        )

        updated["state"] = "canceling"
        updated["cancel_reason"] = reason
        updated["cancel_targets"] = episode_targets
        updated["cancel_failed"] = failed
        updated["cancel_target_remaining"] = persisted_remaining
        updated["order_placement_times"] = placement_times
        updated["order_cancel_confirmed_at"] = confirmed_times
        updated["canceled_order_ids"] = episode_canceled
        updated["canceled_remaining"] = episode_remaining
        updated["cancel_requested_at"] = _iso(self._now())
        if failed:
            updated["cancel_failure"] = failure_error or "cancel_not_acknowledged"
        return updated

    @staticmethod
    def _session_order_ids(session: Mapping[str, object]) -> list[str]:
        """Return every order owned by this opening in stable insertion order."""

        result: list[str] = []
        seen: set[str] = set()

        def add(value: object) -> None:
            order_id = str(value or "")
            if order_id and order_id not in seen:
                seen.add(order_id)
                result.append(order_id)

        for key in (
            "entry_order_id",
            "passive_exit_order_id",
            "protected_exit_order_id",
        ):
            add(session.get(key))
        for value in _items(session.get("augment_order_ids")):
            add(value)
        for value in _items(session.get("owned_order_ids")):
            add(value)
        history = session.get("order_history")
        if isinstance(history, Mapping):
            for value in history:
                add(value)
        elif isinstance(history, Sequence) and not isinstance(history, (str, bytes)):
            for value in history:
                add(_field(value, "order_id", _field(value, "id", "")))
        return result

    @staticmethod
    def _order_history(session: Mapping[str, object]) -> dict[str, dict[str, object]]:
        raw = session.get("order_history")
        history: dict[str, dict[str, object]] = {}
        if isinstance(raw, Mapping):
            for order_id, value in raw.items():
                if isinstance(value, Mapping):
                    history[str(order_id)] = dict(value)
        elif isinstance(raw, Sequence) and not isinstance(raw, (str, bytes)):
            for value in raw:
                if not isinstance(value, Mapping):
                    continue
                order_id = str(_field(value, "order_id", _field(value, "id", "")) or "")
                if order_id:
                    history[order_id] = dict(value)
        return history

    def _sync_order_history(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> dict[str, object]:
        return self.store.lp_update_session(
            str(session['session_id']), patch=self._order_history_patch(session, snapshot)
        )

    def _order_history_patch(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> dict[str, object]:
        """Merge exact owned order receipts without trusting aggregate hints.

        The authenticated adapter may expose only open orders on one read and
        a terminal order on a later read.  A terminal receipt is therefore
        retained, while a previously live/missing receipt becomes UNKNOWN and
        can never prove that all orders ended.
        """

        order_ids = self._session_order_ids(session)
        history = self._order_history(session)
        rows_by_id: dict[str, object] = {}
        for order in _items(snapshot.get("orders")):
            order_id = self._order_id(order)
            if not order_id or order_id not in order_ids:
                continue
            if order_id in rows_by_id:
                # Duplicate rows from paginated account reads are harmless
                # only when they carry the same order identity.
                continue
            rows_by_id[order_id] = order

        expected_token = str(session.get("token_id") or "")
        expected_sides = {
            str(session.get("entry_order_id") or ""): "BUY",
        }
        for key in ("passive_exit_order_id", "protected_exit_order_id"):
            expected_sides[str(session.get(key) or "")] = "SELL"
        # Issue 158: augment orders are session-owned BUYs; their receipts
        # must reconcile like the entry order's.
        for value in _items(session.get("augment_order_ids")):
            augment_id = str(value or "")
            if augment_id:
                expected_sides[augment_id] = "BUY"
        for order_id in order_ids:
            previous = dict(history.get(order_id, {}))
            order = rows_by_id.get(order_id)
            if order is None:
                previous_status = str(previous.get("status") or "").upper()
                if previous_status not in TERMINAL_ORDER_STATES:
                    previous["status"] = "UNKNOWN"
                    previous['read_error'] = (snapshot.get('order_read_errors') or {}).get(order_id, 'order_receipt_unknown')
                previous.setdefault("order_id", order_id)
                history[order_id] = previous
                continue
            token = _field(order, "token_id", _field(order, "asset_id", None))
            if token not in (None, "", expected_token):
                raise ValueError("owned_order_token_mismatch")
            side = str(_field(order, "side", "")).upper()
            expected_side = expected_sides.get(order_id)
            if expected_side and side and side != expected_side:
                raise ValueError("owned_order_side_mismatch")
            status = str(_field(order, "status", "")).upper()
            if not status:
                raise ValueError("owned_order_status_unknown")
            current = dict(previous)
            current.pop('read_error', None)
            current.update(
                {
                    "order_id": order_id,
                    "status": status,
                    "token_id": token or expected_token,
                    "side": side or expected_side,
                }
            )
            for name in (
                "price",
                "original_size",
                "size_matched",
                "remaining_size",
                "size",
                "quantity",
                "order_type",
                "expiration",
                "matched_at",
                "updated_at",
                "average_price",
                "fee",
            ):
                value = _field(order, name, None)
                if value is not None:
                    current[name] = value
            history[order_id] = current
        for order_id in order_ids:
            receipt = history.get(order_id, {})
            if (str(receipt.get("status") or "").upper() != "UNKNOWN"
                    or not self._verified_fill_completed(session, order_id, receipt)):
                continue
            receipt["status"] = "MATCHED"
            receipt.pop("read_error", None)
            history[order_id] = receipt
        terminal = bool(order_ids) and all(
            str(history.get(order_id, {}).get("status") or "").upper()
            in TERMINAL_ORDER_STATES
            for order_id in order_ids
        )
        return dict(owned_order_ids=order_ids, order_history=history, orders_terminal=terminal)

    @staticmethod
    def _verified_fill_completed(session, order_id, receipt):
        fact = (session.get("verified_order_fills") or {}).get(order_id)
        if not isinstance(fact, Mapping) or fact.get("order_id") != order_id:
            return False
        side = str(receipt.get("side") or "").upper()
        expected_side = ("BUY" if order_id == session.get("entry_order_id")
                         else "SELL" if order_id in {
                             session.get("passive_exit_order_id"),
                             session.get("protected_exit_order_id"),
                         } else "BUY" if any(
                             order_id == str(value)
                             for value in _items(session.get("augment_order_ids"))
                         ) else None)
        fact_side = str(fact.get("side") or "").upper()
        original = next((_maybe_decimal(receipt.get(key)) for key in ("original_size", "size", "quantity")
                         if receipt.get(key) is not None), None)
        quantity = _maybe_decimal(fact.get("quantity"))
        return (
            str(fact.get("source") or "") in {"trades", "receipt"}
            and fact.get("quantity_known") is True
            and expected_side is not None
            and side == expected_side
            and fact_side == expected_side
            and str(receipt.get("token_id") or "") == str(session.get("token_id") or "")
            and original is not None and original > 0
            and quantity is not None and quantity == original
            and _maybe_decimal(fact.get("fee")) is not None
        )

    def _create_limit(self, *, plan_authorization=None, **kwargs: object) -> object:
        self._require_mutation()
        if plan_authorization is not None:
            from .polymarket_lp_auto import _PlanEntryAuthorization
            if not isinstance(plan_authorization, _PlanEntryAuthorization) or plan_authorization.pool.lp is not self:
                raise _MutationBlocked('plan_authorization_invalid')
            plan_authorization.validate(kwargs)
        if (
            str(kwargs.get("side") or "").upper() == "BUY"
            and self._account_order_sync_error is not None
            and plan_authorization is None
        ):
            raise _MutationBlocked(self._account_order_sync_error)
        direct = getattr(self.exchange, "lp_create_limit_order", None)
        if callable(direct):
            return direct(**kwargs)
        method = getattr(self.exchange, "create_limit_order", None)
        if not callable(method):
            raise RuntimeError("limit_order_adapter_unavailable")
        return method(**kwargs)

    def _post_limit(
        self,
        signed: object,
        *,
        side: str | None = None,
        on_post_started: Callable[[], None] | None = None,
        plan_authorization=None,
    ) -> object:
        self._require_mutation()
        if plan_authorization is not None:
            from .polymarket_lp_auto import _PlanEntryAuthorization
            if not isinstance(plan_authorization, _PlanEntryAuthorization) or plan_authorization.pool.lp is not self:
                raise _MutationBlocked('plan_authorization_invalid')
            plan_authorization.validate()
        if (
            str(side or "").upper() == "BUY"
            and self._account_order_sync_error is not None
            and plan_authorization is None
        ):
            raise _MutationBlocked(self._account_order_sync_error)
        direct = getattr(self.exchange, "lp_post_order", None)
        method = getattr(self.exchange, "post_order", None)
        adapter = direct if callable(direct) else method if callable(method) else None
        if adapter is None:
            raise RuntimeError("order_post_adapter_unavailable")
        if on_post_started is not None:
            on_post_started()
        return adapter(signed)

    @staticmethod
    def _order_response(response: object) -> tuple[bool, str]:
        order_id = _field(response, "order_id", _field(response, "id", ""))
        order = str(order_id or "")
        accepted = _field(response, "accepted", None)
        ok = _field(response, "ok", None)
        status = str(_field(response, "status", "")).upper()
        if (
            accepted is False
            or ok is False
            or status in {"REJECTED", "FAILED", "CANCELLED", "CANCELED", "EXPIRED"}
        ):
            return False, order
        if accepted is True or order or status in {"LIVE", "OPEN", "ACCEPTED", "MATCHED", "FILLED"}:
            return True, order
        return False, order

    def _queue_level_order_exempt(
        self, session: Mapping[str, object], order: object
    ) -> bool:
        """Whether a same-token BUY belongs to the active protection episodes.

        Issue 152: manual BUY quotes on the protected token (any price) are
        expected while an episode is open — they are monitored and, on
        trigger, canceled at the bucket price.  Issue 167: the episodes are
        the per-price buckets; the exemption stays on while at least one
        bucket is still live (none settled).  SELL rows and other tokens
        remain governed by the unowned-order guard, and the submit boundary
        keeps rejecting outside orders exactly as before.
        """

        protection = session.get("queue_protection")
        buckets = self._queue_protection_levels(session)
        if not isinstance(protection, Mapping) or not buckets:
            return False
        if all(
            str(bucket.get("state")) in {"canceled", "partially_filled"}
            for bucket in buckets.values()
        ):
            return False
        if all(
            bucket.get("cancel_scope") != "own_buys_at_level"
            for bucket in buckets.values()
        ):
            return False
        if str(_field(order, "side", "")).upper() != "BUY":
            return False
        row_token = str(_field(order, "token_id", _field(order, "asset_id", "")) or "")
        expected = str(session.get("token_id") or "")
        return bool(row_token) and row_token == expected

    def _unowned_target_order_reason(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> str | None:
        account = snapshot.get("account")
        if not isinstance(account, Mapping):
            return None
        expected_token = str(session.get("token_id") or "")
        expected_market = str(session.get("market_id") or "")
        owned_ids = set(self._session_order_ids(session))
        for order in _items(account.get("open_orders")):
            order_id = self._order_id(order)
            token_value = _field(order, "token_id", _field(order, "asset_id", None))
            # 生产 raw 挂单行恒含 market_id 键但值为 None；_field 是 dict.get，
            # 键存在值 None 不走 default，嵌套写法的 market/condition_id 兜底
            # 全成死代码 → 跨市场单被判成本市场单。这里必须是「第一个非空值」。
            market_value = (
                _field(order, "market_id")
                or _field(order, "market")
                or _field(order, "condition_id")
            )
            token = str(token_value or "")
            market = str(market_value or "")
            target = token == expected_token or market in {expected_market, str(session.get("condition_id") or "")}
            if not target and (not token or not market):
                # Without both identities the account read cannot establish
                # that this open order is outside the selected exposure.
                target = True
            if target and (not order_id or order_id not in owned_ids):
                if self._queue_level_order_exempt(session, order):
                    continue
                return "unowned_target_order"
            if order_id in owned_ids and token and token != expected_token:
                return "unowned_target_order"
        return None

    def _snapshot_trade_events(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
    ) -> list[dict[str, object]]:
        """Retain official matched trade facts needed for report cutoffs."""

        own_order_ids = set(self._session_order_ids(session))
        market = snapshot.get("market")
        market_facts = market if isinstance(market, Mapping) else {}
        events: list[dict[str, object]] = []
        for trade in _items(snapshot.get("trades")):
            status = str(_field(trade, "status", "")).upper()
            if status == "FAILED":
                continue
            if status != "CONFIRMED":
                continue
            trade_id = str(_field(trade, "trade_id", _field(trade, "id", "")) or "")
            if not trade_id:
                continue
            maker_orders = _items(_field(trade, "maker_orders", ()))
            taker_order_id = str(_field(trade, "taker_order_id", "") or "")
            candidates: list[tuple[object, str, str]] = []
            for order in maker_orders:
                order_id = self._order_id(order)
                if order_id in own_order_ids:
                    candidates.append((order, "maker", order_id))
            if taker_order_id in own_order_ids:
                candidates.append((trade, "taker", taker_order_id))
            for order, role, order_id in candidates:
                side = str(
                    _field(order, "side", _field(trade, "side", ""))
                ).upper()
                amount = _maybe_decimal(
                    _field(
                        order,
                        "matched_amount",
                        _field(order, "size", _field(order, "quantity", _field(trade, "size"))),
                    )
                )
                price = _maybe_decimal(_field(order, "price", _field(trade, "price")))
                if side not in {"BUY", "SELL"} or amount is None or price is None:
                    continue
                fee = _maybe_decimal(
                    _field(
                        order,
                        "fee",
                        _field(order, "fees", _field(trade, "fee", _field(trade, "fees"))),
                    )
                )
                if fee is None and role == "taker":
                    rate = _maybe_decimal(
                        market_facts.get("taker_fee_rate", market_facts.get("fee_rate"))
                    )
                    exponent = _maybe_decimal(market_facts.get("fee_exponent", 1))
                    if rate is not None and exponent is not None and rate >= 0 and exponent >= 0:
                        fee = (
                            amount
                            * rate
                            * (price * (Decimal("1") - price)) ** exponent
                        ).quantize(Decimal("0.00001"))
                elif fee is None and role == "maker":
                    maker_fee = _maybe_decimal(market_facts.get("fee"))
                    if market_facts.get("fees_enabled") is False:
                        fee = Decimal("0")
                    elif maker_fee == 0:
                        fee = Decimal("0")
                matched_at_value = _field(
                    trade,
                    "matched_at",
                    _field(
                        trade,
                        "match_time",
                        _field(trade, "updated_at", _field(trade, "timestamp")),
                    ),
                )
                try:
                    matched_at = _iso(_timestamp(matched_at_value))
                except ValueError:
                    matched_at = None
                events.append(
                    {
                        "trade_id": trade_id,
                        "order_id": order_id,
                        "matched_at": matched_at,
                        "status": "CONFIRMED",
                        "side": side,
                        "quantity": amount,
                        "price": price,
                        "fee": fee,
                    }
                )
        return events

    def _merge_report_trade_events(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
    ) -> list[dict[str, object]]:
        merged: dict[tuple[str, str], dict[str, object]] = {}
        existing = session.get("trade_events")
        for raw_event in _items(existing):
            if not isinstance(raw_event, Mapping):
                continue
            trade_id = str(raw_event.get("trade_id") or "")
            order_id = str(raw_event.get("order_id") or "")
            if trade_id:
                merged[(trade_id, order_id)] = dict(raw_event)
        for event in self._snapshot_trade_events(session, snapshot):
            key = (str(event["trade_id"]), str(event["order_id"]))
            current = merged.setdefault(key, {})
            current.update({name: value for name, value in event.items() if value is not None})
            if event.get("matched_at") is None:
                current.setdefault("matched_at", None)
            if event.get("fee") is None:
                current.setdefault("fee", None)
        return list(merged.values())

    @staticmethod
    def _report_fee_total(
        trade_events: Sequence[Mapping[str, object]], side: str
    ) -> Decimal | None:
        fees = [
            _maybe_decimal(event.get("fee"))
            for event in trade_events
            if str(event.get("side") or "").upper() == side
        ]
        if any(fee is None for fee in fees):
            return None
        return sum((fee for fee in fees if fee is not None), Decimal("0"))

    def _verified_order_fills(self, session, snapshot, trade_events):
        """One cumulative fact per owned order, merging streams and receipts.

        A later stream replaces receipt coverage, never adds it. Only an exact
        authenticated order ID with verified execution price can fill a gap.
        """
        previous = session.get("verified_order_fills") or {}
        automatic = self.store.lp_auto_owns_session(str(session["session_id"]))
        facts = {}
        history = self._order_history(session)
        market = snapshot.get("market") or {}
        for order_id in self._session_order_ids(session):
            side = str(history.get(order_id, {}).get("side") or (
                "BUY" if order_id == session.get("entry_order_id") else "SELL"))
            self._trade_totals(snapshot, order_id, side, token_id=str(session["token_id"]))
            events = [e for e in trade_events if e["order_id"] == order_id]
            quantity = sum((_decimal(e["quantity"], "fill_quantity") for e in events), Decimal(0))
            value = sum((_decimal(e["quantity"], "fill_quantity") * _decimal(e["price"], "fill_price") for e in events), Decimal(0))
            fee = self._report_fee_total(events, side)
            matched_at = events[0].get("matched_at") if len(events) == 1 else None
            old = previous.get(order_id, {})
            old_quantity = _maybe_decimal(old.get("quantity")) or Decimal(0)
            source = "trades"
            if old_quantity > quantity:
                source = old.get("source", "receipt")
                quantity, value = old_quantity, _decimal(old["value"], "fill_value")
                fee, matched_at = _maybe_decimal(old.get("fee")), old.get("matched_at")
            for order in _items(snapshot.get("orders")):
                if self._order_id(order) != order_id:
                    continue
                matched = _maybe_decimal(_field(order, "size_matched", None))
                status = str(_field(order, "status", "")).upper()
                if automatic and _field(order, "fill_quantity_known", True) is False:
                    raise ValueError("owned_fill_quantity_unknown")
                if matched is None:
                    if status in {"MATCHED", "FILLED"} and quantity == 0:
                        raise ValueError("owned_fill_quantity_unknown")
                    continue
                if matched < 0:
                    raise ValueError("owned_fill_quantity_invalid")
                if matched <= quantity:
                    if matched == quantity and fee is None:
                        fee = _maybe_decimal(_field(order, "fee", _field(order, "fees", None)))
                        if fee is None and market.get("fees_enabled") is False:
                            fee = Decimal(0)
                    continue
                token = str(_field(order, "token_id", _field(order, "asset_id", "")))
                order_side = str(_field(order, "side", "")).upper()
                if token != str(session["token_id"]) or order_side != side:
                    raise ValueError("owned_fill_identity_unknown")
                # Entry and passive exit are explicitly post-only. Protected
                # taker exits need an actual execution-average price.
                maker = order_id == session.get("entry_order_id") or order_id == session.get("passive_exit_order_id") or order_id in (session.get("augment_order_ids") or [])
                price = _maybe_decimal(_field(order, "average_price", _field(order, "average_fill_price", None)))
                if price is None and maker:
                    price = _maybe_decimal(_field(order, "price", None))
                if price is None or not 0 < price < 1:
                    raise ValueError("owned_fill_price_unknown")
                quantity, value = matched, matched * price
                source = "receipt"
                fee = _maybe_decimal(_field(order, "fee", _field(order, "fees", None)))
                if fee is None and (market.get("fees_enabled") is False or (maker and _maybe_decimal(market.get("fee")) == 0)):
                    fee = Decimal(0)
                matched_at = _field(order, "matched_at", None)
            quantity_known = not (quantity == 0 and str(history.get(order_id, {}).get("status", "")).upper() in {"FILLED", "MATCHED"})
            facts[order_id] = dict(order_id=order_id, side=side, quantity=quantity, quantity_known=quantity_known,
                value=value, price=value/quantity if quantity else None, fee=fee, matched_at=matched_at, source=source)
        return facts

    def _fill_patch(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> dict[str, object]:
        account = snapshot.get("account")
        if not isinstance(account, Mapping):
            raise ValueError("account_unknown")
        if account.get("positions_complete") is False or account.get("open_orders_complete") is False:
            raise ValueError("account_facts_incomplete")
        if "positions" not in account or account.get("positions") is None:
            raise ValueError("position_unknown")
        token_id = session["token_id"]
        trade_events = self._merge_report_trade_events(session, snapshot)
        verified = self._verified_order_fills(session, snapshot, trade_events)
        fills_known = all(f['quantity_known'] for f in verified.values())
        buys = [f for f in verified.values() if f["side"] == "BUY"]
        sells = [f for f in verified.values() if f["side"] == "SELL"]
        quantity = sum((f["quantity"] for f in buys), Decimal(0))
        cost = sum((f["value"] for f in buys), Decimal(0))
        sold_quantity = sum((f["quantity"] for f in sells), Decimal(0))
        sold_revenue = sum((f["value"] for f in sells), Decimal(0))
        # Reconcile against the latest exact-ID receipts, not a stale planned
        # quantity. An unknown original size contributes its observed fill as
        # a lower bound; UNKNOWN remains UNKNOWN for lifecycle completion.
        history = self._order_history(session)
        owned_buys = [
            record
            for record in history.values()
            if str(record.get("side") or "").upper() == "BUY"
        ]
        requested_quantity = sum(
            (
                _maybe_decimal(record.get("quantity"))
                if _maybe_decimal(record.get("quantity")) is not None
                else _maybe_decimal(record.get("size_matched")) or Decimal("0")
            )
            for record in owned_buys
        ) or (
            _maybe_decimal(session.get("group_buy_quantity"))
            or _maybe_decimal(session.get("quantity"))
        )
        def fees_for(rows):
            return None if any(f["fee"] is None for f in rows) else sum((f["fee"] for f in rows), Decimal(0))
        buy_fees, sell_fees = fees_for(buys), fees_for(sells)
        fees = None if buy_fees is None or sell_fees is None else buy_fees + sell_fees
        residual = self._position_quantity(account, str(token_id))
        book = snapshot.get("book")
        book_received_at = book.get("received_at") if isinstance(book, Mapping) else None
        book_ready = False
        if book_received_at is not None:
            try:
                _freshness(book_received_at, self._now(), "book_freshness")
                book_ready = True
            except ValueError:
                book_ready = False
        # A positive inventory cannot inherit zero from the helper when the
        # executable book is absent; valuation is market-purpose only.
        residual_value = (
            Decimal("0") if residual == 0
            else self._executable_bid_value(snapshot, residual) if book_ready
            else None
        )
        market = snapshot.get("market")
        if residual == 0:
            projected_fee = Decimal("0")
        elif isinstance(market, Mapping) and market.get("fees_enabled") is False:
            projected_fee = Decimal("0")
        elif book_ready:
            projected_fee = self._projected_taker_fee(snapshot, residual)
        else:
            projected_fee = None
        historical_fees_known = fees is not None
        # Financial settlement uses executed order facts. A live book is only
        # admission/exit valuation input, except a non-empty residual needs a
        # reliable projected exit fee to describe the full fee boundary.
        fees_known = fills_known and historical_fees_known and projected_fee is not None
        if fees is not None and projected_fee is not None:
            fees += projected_fee
        else:
            fees = None
        if requested_quantity is None:
            raise ValueError("opening_quantity_unknown")
        if sold_quantity > quantity:
            raise ValueError("sold_quantity_exceeded")
        # A complete current account read owns inventory quantity. Historical
        # fills remain reporting evidence, not a veto over that position.
        position_reconciled = True
        inventory_valuation_known = residual == 0 or residual_value is not None
        financial_block_reason = None
        if not fills_known:
            financial_block_reason = "owned_fill_quantity_unknown"
        elif not historical_fees_known:
            financial_block_reason = "trade_fee_unknown"
        elif not inventory_valuation_known:
            financial_block_reason = "inventory_valuation_unknown"
        patch: dict[str, object] = {
            "buy_filled_quantity": quantity,
            "buy_cost": cost,
            "sold_quantity": sold_quantity,
            "sold_revenue": sold_revenue,
            "buy_fees": buy_fees,
            "sell_fees": sell_fees,
            "residual_quantity": residual,
            "residual_exit_value": residual_value,
            "projected_exit_fee": projected_fee,
            "trade_events": trade_events,
            "verified_order_fills": verified,
            "fees": fees,
            "fee_status": "known" if fees_known else "unknown",
            "position_reconciled": position_reconciled,
            "account_checked_at": snapshot.get("account_checked_at", self._now()),
            "book_checked_at": book_received_at if book_ready else None,
            "book_admission_ready": book_ready,
            "inventory_valuation_status": "known" if inventory_valuation_known else "unknown",
            "financial_block_reason": financial_block_reason,
            "orders_terminal": bool(session.get("orders_terminal")),
        }
        if session.get("reconciliation") == "position_mismatch":
            patch["reconciliation"] = None
        reward = snapshot.get("reward_status")
        if reward in {"known", "unknown"}:
            patch["reward_status"] = reward
        return patch

    @staticmethod
    def _position_quantity(account: Mapping[str, object], token_id: str) -> Decimal:
        total = Decimal("0")
        for position in _items(account.get("positions")):
            token = _field(position, "token_id", _field(position, "asset_id"))
            if token != token_id:
                continue
            amount = _maybe_decimal(_field(position, "size", _field(position, "quantity", 0)))
            if amount is None:
                raise ValueError("position_size_unknown")
            if amount < 0:
                raise ValueError("position_invalid")
            total += amount
        return total

    def _trade_totals(
        self,
        snapshot: Mapping[str, object],
        order_id: str,
        side: str,
        *,
        token_id: str | None = None,
    ) -> tuple[Decimal, Decimal]:
        if not order_id:
            return Decimal("0"), Decimal("0")
        quantity = Decimal("0")
        proceeds = Decimal("0")
        seen_trades: set[tuple[str, str]] = set()
        for trade in _items(snapshot.get("trades")):
            status = str(_field(trade, "status", "")).upper()
            maker_orders = _items(_field(trade, "maker_orders", ()))
            taker_order = str(_field(trade, "taker_order_id", "") or "")
            candidates: list[tuple[object, str]] = []
            for order in maker_orders:
                if self._order_id(order) == order_id:
                    candidates.append((order, "maker"))
            if taker_order == order_id:
                candidates.append((trade, "taker"))
            if not candidates:
                continue
            if not status:
                raise ValueError("trade_status_unknown")
            if status == "FAILED":
                continue
            if status != "CONFIRMED":
                raise ValueError("trade_not_confirmed")
            trade_id = str(_field(trade, "trade_id", _field(trade, "id", "")) or "")
            if not trade_id:
                raise ValueError("trade_identity_unknown")
            for order, role in candidates:
                identity = (
                    trade_id,
                    order_id if role == "taker" else self._order_id(order),
                )
                if identity in seen_trades:
                    continue
                seen_trades.add(identity)
                current_token = _field(
                    order,
                    "token_id",
                    _field(order, "asset_id", _field(trade, "token_id", _field(trade, "asset_id"))),
                )
                if token_id is not None:
                    if current_token in (None, ""):
                        raise ValueError("trade_token_unknown")
                    if str(current_token) != token_id:
                        raise ValueError("trade_token_mismatch")
                current_side = str(_field(order, "side", _field(trade, "side", ""))).upper()
                if not current_side:
                    raise ValueError("trade_side_unknown")
                if current_side != side:
                    raise ValueError("trade_side_mismatch")
                amount = _maybe_decimal(
                    _field(
                        order,
                        "matched_amount",
                        _field(order, "size", _field(order, "quantity", None)),
                    )
                )
                price = _maybe_decimal(_field(order, "price", _field(trade, "price", None)))
                if amount is None or amount <= 0:
                    raise ValueError("trade_amount_unknown")
                if price is None or price <= 0:
                    raise ValueError("trade_price_unknown")
                quantity += amount
                proceeds += amount * price
        return quantity, proceeds

    def _known_trade_fees(
        self,
        snapshot: Mapping[str, object],
        session: Mapping[str, object],
        *,
        token_id: str,
    ) -> Decimal | None:
        own_ids = set(self._session_order_ids(session))
        seen: set[tuple[str, str]] = set()
        total = Decimal("0")
        for trade in _items(snapshot.get("trades")):
            trade_id = str(_field(trade, "trade_id", _field(trade, "id", "")) or "")
            status = str(_field(trade, "status", "")).upper()
            maker_orders = list(_items(_field(trade, "maker_orders", ())))
            taker_order = str(_field(trade, "taker_order_id", "") or "")
            candidates: list[tuple[object, str]] = [
                (order, "maker")
                for order in maker_orders
                if self._order_id(order) in own_ids
            ]
            if taker_order in own_ids:
                candidates.append((trade, "taker"))
            if not candidates:
                continue
            if not trade_id or not status:
                return None
            if status == "FAILED":
                continue
            if status != "CONFIRMED":
                return None
            for order, role in candidates:
                order_id = taker_order if role == "taker" else self._order_id(order)
                identity = (trade_id, order_id)
                if identity in seen:
                    continue
                seen.add(identity)
                current_token = _field(
                    order,
                    "token_id",
                    _field(order, "asset_id", _field(trade, "token_id", _field(trade, "asset_id"))),
                )
                if current_token in (None, "") or str(current_token) != token_id:
                    return None
                amount = _maybe_decimal(
                    _field(
                        order,
                        "matched_amount",
                        _field(order, "size", _field(trade, "size", None)),
                    )
                )
                price = _maybe_decimal(_field(order, "price", _field(trade, "price", None)))
                if amount is None or price is None or amount <= 0 or price <= 0:
                    return None
                fee = _maybe_decimal(
                    _field(
                        order,
                        "fee",
                        _field(order, "fees", _field(trade, "fee", _field(trade, "fees"))),
                    )
                )
                if fee is None:
                    market = snapshot.get("market")
                    if not isinstance(market, Mapping):
                        return None
                    if role == "taker":
                        rate = _maybe_decimal(
                            market.get("taker_fee_rate", market.get("fee_rate"))
                        )
                        exponent = _maybe_decimal(market.get("fee_exponent", 1))
                        if rate is None or exponent is None or rate < 0 or exponent < 0:
                            return None
                        fee = (
                            amount
                            * rate
                            * (price * (Decimal("1") - price)) ** exponent
                        ).quantize(Decimal("0.00001"))
                    else:
                        maker_fee = _maybe_decimal(market.get("fee"))
                        if market.get("fees_enabled") is False:
                            maker_fee = Decimal("0")
                        if maker_fee is None or maker_fee < 0 or maker_fee != 0:
                            return None
                        fee = Decimal("0")
                total += fee
        return total

    @staticmethod
    def _projected_taker_fee(
        snapshot: Mapping[str, object], residual: Decimal
    ) -> Decimal | None:
        return _projected_taker_fee(snapshot, residual)

    @staticmethod
    def _executable_bid_value(
        snapshot: Mapping[str, object], quantity: Decimal
    ) -> Decimal | None:
        return _executable_bid_value(snapshot, quantity)

    def _orders_terminal(
        self, snapshot: Mapping[str, object], session: Mapping[str, object]
    ) -> bool:
        del snapshot
        order_ids = self._session_order_ids(session)
        if not order_ids:
            return False
        history = self._order_history(session)
        return all(
            str(history.get(order_id, {}).get("status") or "").upper()
            in TERMINAL_ORDER_STATES
            for order_id in order_ids
        )

    def _order_terminal(
        self,
        snapshot: Mapping[str, object],
        order_id: str,
        session: Mapping[str, object] | None = None,
    ) -> bool:
        if not order_id:
            return False
        for order in _items(snapshot.get("orders")):
            current_id = self._order_id(order)
            if current_id != order_id:
                continue
            status = str(_field(order, "status", "")).upper()
            if status in TERMINAL_ORDER_STATES and session is not None:
                prior = self._order_history(session).get(order_id, {})
                if (str(prior.get("status") or "").upper() == "UNKNOWN"
                        and not self._verified_fill_completed(session, order_id, prior)):
                    # A terminal-looking aggregate row cannot resolve an old
                    # BUY whose receipt lacks the original size/terminal proof.
                    return False
            return status in TERMINAL_ORDER_STATES
        if session is not None:
            status = str(self._order_history(session).get(order_id, {}).get("status") or "").upper()
            return status in TERMINAL_ORDER_STATES
        return False

    @staticmethod
    def _scoring_reset_patch(
        order_id: str | None = None, role: str | None = None
    ) -> dict[str, object]:
        return {
            "scoring_status": "unknown",
            "scoring_checked_at": None,
            "scoring_order_id": order_id or None,
            "scoring_order_role": role if order_id else None,
            "scoring_lost_at": None,
        }

    @staticmethod
    def _scoring_target(session: Mapping[str, object]) -> tuple[str, str]:
        state = str(session.get("state") or "")
        entry_id = str(session.get("entry_order_id") or "")
        passive_id = str(session.get("passive_exit_order_id") or "")
        protected_id = str(session.get("protected_exit_order_id") or "")
        if state.startswith("entry"):
            order_id, role = entry_id, "entry"
        elif state == "passive_exit":
            order_id, role = passive_id, "passive_exit"
        elif state == "stop_loss_exit":
            order_id, role = protected_id, "protected_exit"
        else:
            order_id, role = "", ""
        return order_id, role

    def _read_scoring(self, session: Mapping[str, object]) -> dict[str, object]:
        order_id, role = self._scoring_target(session)
        now = self._now()
        previous_id = str(session.get("scoring_order_id") or "")
        previous_role = str(session.get("scoring_order_role") or "")
        previous_checked = session.get("scoring_checked_at")
        target_changed = previous_id != order_id or previous_role != role
        previous_status = str(session.get("scoring_status") or "unknown")
        value: bool | None = None
        checked_at = previous_checked
        queried = False
        if order_id:
            due = target_changed or previous_checked is None
            if not due and previous_checked is not None:
                try:
                    age = (now - _timestamp(previous_checked, name="scoring_checked_at")).total_seconds()
                    due = age >= float(SCORING_POLL_SECONDS)
                except ValueError:
                    due = True
            if due:
                queried = True
                method = getattr(self.exchange, "get_order_scoring", None)
                if callable(method):
                    try:
                        response = method(order_id)
                        value = response if response is True or response is False else None
                    except Exception:
                        value = None
                checked_at = _iso(now)
            elif not target_changed and previous_status in {"true", "false"}:
                try:
                    age = (now - _timestamp(previous_checked, name="scoring_checked_at")).total_seconds()
                    if 0 <= age <= float(SCORING_STALE_SECONDS):
                        value = previous_status == "true"
                except ValueError:
                    value = None
        return dict(order_id=order_id, role=role, value=value, checked_at=checked_at,
                    queried=queried, observed_at=now)

    def _update_scoring(self, session: Mapping[str, object], scoring: Mapping[str, object] | None) -> None:
        if scoring is None:
            return
        order_id, role = self._scoring_target(session)
        if (scoring.get('order_id'), scoring.get('role')) != (order_id, role):
            # Reconciliation may have changed the exit stage or order since
            # the read; never attach evidence for a different order.
            return
        value, checked_at = scoring['value'], scoring['checked_at']
        now = scoring['observed_at']
        queried = scoring['queried']
        status = "true" if value is True else "false" if value is False else "unknown"
        lost_at = session.get("scoring_lost_at")
        if role != "entry":
            lost_at = None
        elif value is True:
            # Only fresh evidence for this exact current order can clear the
            # continuous-loss window.
            if queried or (checked_at is not None and status == "true"):
                lost_at = None
        elif lost_at is None:
            lost_at = _iso(now)
        patch: dict[str, object] = {
            "scoring_status": status,
            "scoring_checked_at": checked_at,
            "scoring_order_id": order_id or None,
            "scoring_order_role": role if order_id else None,
            "scoring_lost_at": lost_at,
        }
        updated = self.store.lp_update_session(str(session["session_id"]), patch=patch)
        if role != "entry" or value is True:
            return
        lost_at_value = updated.get("scoring_lost_at")
        if lost_at_value is None:
            return
        try:
            age = (now - _timestamp(lost_at_value, name="scoring_lost_at")).total_seconds()
        except ValueError:
            age = 0
        if age < float(SCORING_FAILURE_WINDOW_SECONDS):
            return
        # The window ends the opening stage.  Loss/account reconciliation
        # remains independent and is handled by the normal tick path.
        current = self.store.lp_session(str(session["session_id"])) or updated
        if not current.get("entry_cancel_requested"):
            return
        self.store.lp_update_session(
            str(session["session_id"]),
            state="review",
            patch={"review_status": "scoring_continuously_lost"},
        )

    def _cancel_entry_order(self, session: Mapping[str, object]) -> None:
        order_id = str(session.get("entry_order_id") or "")
        if not order_id:
            return
        if not self._cancel_order(order_id):
            raise RuntimeError("cancel_not_acknowledged")

    def _request_entry_cancel(self, session: Mapping[str, object]) -> None:
        order_id = str(session.get("entry_order_id") or "")
        if not order_id:
            return
        try:
            if not self._cancel_order(order_id):
                raise RuntimeError("cancel_not_acknowledged")
        except Exception as exc:
            self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch={"reconciliation": f"entry_cancel_{type(exc).__name__}"},
            )
            return
        self.store.lp_update_session(
            str(session["session_id"]), patch={"entry_cancel_requested": True}
        )

    def _cancel_passive_order(self, session: Mapping[str, object]) -> None:
        order_id = str(session.get("passive_exit_order_id") or "")
        if order_id:
            self._cancel_order(order_id)

    def _request_passive_cancel(
        self,
        session: Mapping[str, object],
        *,
        expected_generation: int | None = None,
        expected_trade_revision: int | None = None,
        claim_patch: Mapping[str, object] | None = None,
        claim_state: str | None = None,
    ) -> dict[str, object]:
        session_id = str(session["session_id"])
        history = self._order_history(session)
        protected_id = str(session.get("protected_exit_order_id") or "")
        expected_token = str(session.get("token_id") or "")
        passive_id = str(session.get("passive_exit_order_id") or "")
        passive_record = history.get(passive_id)
        if isinstance(passive_record, Mapping):
            record_side = str(passive_record.get("side") or "").upper()
            record_token = str(passive_record.get("token_id") or "")
            if record_side and record_side != "SELL":
                raise ValueError("owned_order_side_mismatch")
            if record_token and expected_token and record_token != expected_token:
                raise ValueError("owned_order_token_mismatch")
        owned_requested = {
            str(value) for value in _items(session.get("owned_cancel_requested"))
        }
        pending = self._recent_pending_cancel_order_ids(session_id)
        specs: list[tuple[str, str]] = []
        if (
            passive_id
            and passive_id != protected_id
            and not isinstance(passive_record, Mapping)
            and not bool(session.get("passive_cancel_requested"))
            and passive_id not in pending
        ):
            specs.append((passive_id, "passive_exit_cancel"))
        for order_id, record in history.items():
            if (
                not order_id
                or order_id == protected_id
                or str(record.get("side") or "").upper() != "SELL"
                or str(record.get("status") or "").upper() in TERMINAL_ORDER_STATES
                or order_id in pending
            ):
                continue
            if order_id == passive_id:
                if bool(session.get("passive_cancel_requested")):
                    continue
                specs.append((order_id, "passive_exit_cancel"))
            elif order_id not in owned_requested:
                specs.append((order_id, "owned_sell_cancel"))
        if not specs:
            return dict(session)
        try:
            self._require_mutation()
        except Exception as exc:
            return self.store.lp_update_session(
                session_id,
                state="needs_attention",
                patch={"reconciliation": f"passive_cancel_{type(exc).__name__}"},
            )
        if expected_generation is not None and not isinstance(
            expected_trade_revision, int
        ):
            return self._publish_account_round_rejected(session_id)
        try:
            self.store.lp_register_fenced_actions(
                session_id,
                [
                    {
                        "action_key": self._action_key(
                            session_id, "passive-cancel", order_id
                        ),
                        "payload": {
                            "role": role,
                            "order_id": order_id,
                            "targets": [order_id],
                        },
                    }
                    for order_id, role in specs
                ],
                expected_generation=expected_generation,
                expected_trade_revision=expected_trade_revision,
                patch=claim_patch,
                state=claim_state,
            )
        except ValueError as exc:
            if str(exc) == "account_round_invalid":
                return self._publish_account_round_rejected(session_id)
            raise
        current = dict(session)
        owned_requested = set(owned_requested)
        for order_id, role in specs:
            action_key = self._action_key(session_id, "passive-cancel", order_id)
            try:
                if not self._cancel_order(
                    order_id,
                    attempts=[(session_id, action_key, {"role": role, "order_id": order_id})],
                ):
                    raise RuntimeError("cancel_not_acknowledged")
            except Exception as exc:
                return self.store.lp_update_session(
                    session_id,
                    state="needs_attention",
                    patch={"reconciliation": f"passive_cancel_{type(exc).__name__}"},
                )
            self.store.lp_upsert_action(
                session_id,
                action_key,
                state="accepted",
                payload={"role": role, "order_id": order_id},
            )
            patch: dict[str, object] = {}
            if order_id == passive_id:
                patch["passive_cancel_requested"] = True
            else:
                owned_requested.add(order_id)
                patch["owned_cancel_requested"] = sorted(owned_requested)
            current = dict(self.store.lp_update_session(session_id, patch=patch))
        return current

    def _cancel_owned_orders(
        self,
        session: Mapping[str, object],
        *,
        snapshot: Mapping[str, object] | None = None,
        expected_generation: int | None = None,
        expected_trade_revision: int | None = None,
        preserve_passive_exit: bool = False,
    ) -> None:
        current = dict(self.store.lp_session(str(session["session_id"])) or session)
        if current.get("order_identity_conflict"):
            raise ValueError("order_identity_conflict")
        session_id = str(current["session_id"])
        history = self._order_history(current)
        pending_cancels = self._recent_pending_cancel_order_ids(session_id)
        specs: list[tuple[str, str, str]] = []
        cancel_fields = [("entry_order_id", "entry_cancel_requested", "entry")]
        if not preserve_passive_exit:
            cancel_fields.append(("passive_exit_order_id", "passive_cancel_requested", "passive_exit"))
        for key, requested_key, role in cancel_fields:
            order_id = str(current.get(key) or "")
            if not order_id or bool(current.get(requested_key)) or order_id in pending_cancels:
                continue
            if str(history.get(order_id, {}).get("status") or "").upper() in TERMINAL_ORDER_STATES:
                continue
            specs.append((order_id, requested_key, role))
        # Augment orders join the same review/stop/collect sweep so an entry
        # plus its augments always end together.  The full target set is fixed
        # before authorization; a target appearing later waits for a new pass.
        augment_requested = [
            str(value) for value in _items(current.get("augment_cancel_requested"))
        ]
        owned_requested = [
            str(value) for value in _items(current.get("owned_cancel_requested"))
        ]
        managed = {
            str(current.get("entry_order_id") or ""),
            str(current.get("passive_exit_order_id") or ""),
            *augment_requested,
        }
        for order_id, record in history.items():
            if (
                str(record.get("side") or "").upper() != "SELL"
                or not order_id
                or order_id in managed
                or order_id in owned_requested
                or order_id in pending_cancels
                or str(record.get("status") or "").upper() in TERMINAL_ORDER_STATES
            ):
                continue
            specs.append((order_id, "owned_cancel_requested", "owned-sell-cancel"))
        for value in _items(current.get("augment_order_ids")):
            order_id = str(value or "")
            if not order_id or order_id in augment_requested or order_id in pending_cancels:
                continue
            if str(history.get(order_id, {}).get("status") or "").upper() in TERMINAL_ORDER_STATES:
                continue
            specs.append((order_id, "augment_cancel_requested", "augment-cancel"))
        if snapshot is not None:
            current_order_ids = self._current_cancel_order_ids(
                current, snapshot, expected_generation
            )
            if current_order_ids is not None:
                specs = [spec for spec in specs if spec[0] in current_order_ids]
        if not specs:
            return
        self._require_mutation()
        if expected_generation is not None and not isinstance(expected_trade_revision, int):
            self._publish_account_round_rejected(session_id)
            raise LpObservationWait("account_round_invalid")
        actions = [
            {
                "action_key": self._action_key(
                    session_id, "owned-cancel", uuid.uuid4().hex
                ),
                "payload": {
                    "role": role,
                    "order_id": order_id,
                    "targets": [order_id],
                    "source": "owned_cancel_sweep",
                },
            }
            for order_id, _requested_key, role in specs
        ]
        try:
            registered = self.store.lp_register_fenced_actions(
                session_id,
                actions,
                expected_generation=expected_generation,
                expected_trade_revision=expected_trade_revision,
            )
        except ValueError as exc:
            if str(exc) == "account_round_invalid":
                self._publish_account_round_rejected(session_id)
            raise
        attempts = {
            order_id: (session_id, str(row["action_key"]), dict(row))
            for (order_id, _requested_key, _role), row in zip(specs, registered)
        }
        errors: list[BaseException] = []
        for order_id, requested_key, role in specs:
            try:
                if not self._cancel_order(order_id, attempts=[attempts[order_id]]):
                    raise RuntimeError("cancel_not_acknowledged")
            except Exception as exc:
                errors.append(exc)
                continue
            patch: dict[str, object] = {}
            self.store.lp_upsert_action(
                session_id,
                self._action_key(
                    session_id,
                    role if role == "augment-cancel" else f"{role}-cancel",
                    order_id,
                ),
                state="accepted",
                payload={"role": role, "order_id": order_id},
            )
            if role == "augment-cancel":
                augment_requested = [*augment_requested, order_id]
                patch["augment_cancel_requested"] = list(augment_requested)
            elif role == "owned-sell-cancel":
                patch[requested_key] = sorted(
                    {
                        str(value)
                        for value in _items(current.get(requested_key))
                    }
                    | {order_id}
                )
            else:
                patch[requested_key] = True
            current = dict(
                self.store.lp_update_session(session_id, patch=patch)
            )
            history = self._order_history(current)
        if errors:
            raise RuntimeError(type(errors[0]).__name__) from errors[0]

    @staticmethod
    def _cancel_acknowledged(response: object, order_id: str) -> bool:
        """Accept only a response that names the requested canceled order."""

        target = str(order_id)
        if not target or response is None or isinstance(response, bool):
            return False
        if isinstance(response, str):
            return response == target
        if isinstance(response, Mapping):
            for key in (
                "canceled",
                "cancelled",
                "canceled_order_ids",
                "cancelled_order_ids",
                "order_ids",
            ):
                values = _field(response, key, None)
                if isinstance(values, str):
                    if values == target:
                        return True
                elif values is not None:
                    try:
                        if target in {str(value) for value in values}:
                            return True
                    except TypeError:
                        pass
            not_canceled = _field(response, "not_canceled", _field(response, "not_cancelled", None))
            if isinstance(not_canceled, Mapping) and target in {str(key) for key in not_canceled}:
                return False
            response_id = _field(response, "order_id", _field(response, "id", ""))
            status = str(_field(response, "status", "")).upper()
            return str(response_id or "") == target and status in TERMINAL_ORDER_STATES
        try:
            values = tuple(response)  # type: ignore[arg-type]
        except TypeError:
            response_id = _field(response, "order_id", _field(response, "id", ""))
            status = str(_field(response, "status", "")).upper()
            return str(response_id or "") == target and status in TERMINAL_ORDER_STATES
        return target in {str(value) for value in values}

    def begin_order_cancel(self, order_ids: Collection[str], *, serialized=True, plan_round_id=None):
        """Persist exact owned cancel attempts before allowing network I/O."""
        import sqlite3
        attempts = []
        with self._mutex if serialized else nullcontext():
            targets = set(order_ids)
            for session in self.store.lp_sessions():
                for order_id in targets.intersection(self._session_order_ids(session)):
                    session_id = str(session['session_id'])
                    key = self._action_key(session_id, 'reconciliation-cancel', uuid.uuid4().hex)
                    payload = dict(role='reconciliation_cancel', order_id=order_id,
                                   submit_requested_at=_iso(self._now()))
                    if plan_round_id is not None:
                        payload['rotation_round_id'] = plan_round_id
                    try:
                        self.store.lp_upsert_action(session_id, key, state='pending', payload=payload)
                    except sqlite3.Error as exc:
                        for sid, previous_key, previous in attempts:
                            self.store.lp_finish_cancel(sid, previous_key, state='rejected',
                                payload={**previous, 'post_started': False, 'submit_stage': 'pre_send_rejected',
                                    'reason': str(exc)})
                        raise
                    attempts.append((session_id, key, payload))
        return attempts

    def finish_order_cancel(self, attempts, canceled, *, serialized=True):
        with self._mutex if serialized else nullcontext():
            for session_id, key, payload in attempts:
                self.store.lp_finish_cancel(session_id, key,
                    state='accepted' if payload['order_id'] in canceled else 'unknown', payload=payload)
        if attempts and self._facts_wakeup:
            self._facts_wakeup()

    def _cancel_order(self, order_id: str, *, attempts=None, on_response=None) -> bool:
        sender = uuid.uuid4().hex
        with self._entry_sends_lock:
            self._cancel_sends.add(sender)
        try:
            return self._cancel_order_in_lane(order_id, attempts=attempts, on_response=on_response)
        finally:
            with self._entry_sends_lock:
                self._cancel_sends.discard(sender)

    def _cancel_order_in_lane(self, order_id: str, *, attempts=None, on_response=None) -> bool:
        try:
            self._require_mutation()
        except _MutationBlocked:
            # The guard ran before any venue call: a preclaimed intent was
            # definitely not sent and must not suppress the next cancel.
            for session_id, key, payload in attempts or ():
                if (payload.get('role') == 'reconciliation_cancel'
                        and payload.get('reason') == 'buy_yield_unknown_timeout'):
                    self.store.lp_reject_pending_cancel(session_id, key, record_unsent=True)
                else:
                    self.store.lp_reject_pending_cancel(session_id, key)
            raise
        # Cancel intent/receipt persistence is serialized with strategy and
        # generation fences; the venue request between those short sections is
        # deliberately off the mutex.
        if attempts is None:
            attempts = self.begin_order_cancel((order_id,), serialized=False)
        acknowledged = False
        try:
            direct = getattr(self.exchange, "cancel_order", None)
            if callable(direct):
                response = direct(order_id)
            else:
                method = getattr(self.exchange, "cancel_orders_detailed", None) if on_response is not None else None
                if not callable(method):
                    method = getattr(self.exchange, "cancel_orders", None)
                if not callable(method):
                    raise RuntimeError("cancel_adapter_unavailable")
                response = method((order_id,))
            if on_response is not None:
                on_response(response)
            acknowledged = self._cancel_acknowledged(response, order_id)
            return acknowledged
        finally:
            self.finish_order_cancel(
                attempts, (order_id,) if acknowledged else (), serialized=False
            )

    @staticmethod
    def _has_unresolved_submission(session: Mapping[str, object]) -> bool:
        """Return whether any durable submit intent still lacks a terminal receipt."""

        # Account coverage or an operator waiver removes only the original
        # entry hold. Its UNKNOWN audit is not an independent in-flight SELL
        # and must not prevent management of actual orders/inventory.
        covered = reservation_is_released(session)
        if (covered and not reservation_is_manually_released(session)
                and str(session.get("submit_stage") or "") in {"preparing", "sending"}
                and (session.get('reservation_coverage') or {}).get('basis') != 'runtime_owner_exit'):
            return True
        if not covered:
            if str(session.get("state") or "") == "entry_submit_pending":
                return True
            if str(session.get("submit_status") or "") in {
                "pending",
                "unknown",
                "accepted_without_order_id",
            }:
                return True
        return any(
            str(session.get(key) or "")
            in {"pending", "unknown", "accepted_without_order_id"}
            for key in (
                "passive_exit_attempt_state",
                "protected_exit_attempt_state",
            )
        )

    def _ensure_passive_exit(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        quantity: Decimal,
        *,
        trade_revision: int | None = None,
        trade_generation: int | None = None,
        expected_trade_revision: int | None = None,
    ) -> None:
        # A submit that may have reached the venue is durable before the POST.
        # Pending, unknown, and accepted-without-ID states are never safe to
        # replay merely because a monitoring process restarted.
        if self._has_unresolved_submission(session):
            return
        history = self._order_history(session)
        if any(
            str(record.get("side") or "").upper() == "BUY"
            and str(record.get("status") or "").upper() == "UNKNOWN"
            and not self._verified_fill_completed(session, order_id, record)
            for order_id, record in history.items()
        ):
            # A filled quantity and current inventory do not resolve an old
            # BUY receipt whose original size or terminal proof is missing.
            # Keep the existing exit identity until that prerequisite is known.
            return
        managed_passive = str(session.get("passive_exit_order_id") or "")
        blocking_sells = [
            order_id
            for order_id, record in history.items()
            if order_id != managed_passive
            and str(record.get("side") or "").upper() == "SELL"
            and str(record.get("status") or "").upper() not in TERMINAL_ORDER_STATES
        ]
        if blocking_sells:
            return
        attempt_state = str(session.get("passive_exit_attempt_state") or "")
        if attempt_state in {"pending", "unknown", "accepted_without_order_id"}:
            return
        book = snapshot.get("book")
        if not isinstance(book, Mapping):
            return
        stamp = book.get("received_at")
        if stamp is None:
            return
        try:
            _freshness(stamp, self._now(), "book_freshness")
            asks = self._external_asks(session, snapshot)
        except ValueError as exc:
            self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch={"reconciliation": str(exc), "resume_state": "passive_exit"},
            )
            return
        if not asks:
            return
        price = asks[0][0]
        old_price = _maybe_decimal(session.get("passive_exit_price"))
        old_order = str(session.get("passive_exit_order_id") or "")
        old_passive_record: dict[str, object] = {}
        if old_order:
            old_terminal = self._order_terminal(snapshot, old_order, session)
            if not old_terminal:
                if old_price == price and not session.get("passive_cancel_requested"):
                    return
                if not bool(session.get("passive_cancel_requested")):
                    self._request_passive_cancel(
                        session,
                        expected_generation=trade_generation if trade_generation is not None else snapshot.get("_lp_trade_generation"),
                        expected_trade_revision=expected_trade_revision if expected_trade_revision is not None else trade_revision,
                    )
                return
            # Preserve the legacy exact-ID record before clearing the role.
            # Its GTD facts remain the only source for replacement expiration.
            old_passive_record = dict(history.get(old_order) or {})
        expiration: int | None
        expiration_error: str | None = None
        if old_passive_record and (old_passive_record.get("order_type") or old_passive_record.get("expiration") is not None):
            # An imported replacement inherits only the exact old order's
            # lifecycle type. It can never turn GTD into GTC or extend expiry.
            order_type = str(old_passive_record.get("order_type") or "GTD").upper()
            if order_type == "GTC":
                expiration = None
            elif order_type == "GTD":
                raw_expiration = old_passive_record.get("expiration")
                parsed = _maybe_decimal(raw_expiration)
                try:
                    if parsed is None:
                        # The SDK exposes expires_at as a datetime; durable
                        # history stores the same instant as an ISO string.
                        expires_at = _timestamp(raw_expiration, name="expiration")
                    else:
                        if parsed != parsed.to_integral_value():
                            raise ValueError("expiration_invalid")
                        expires_at = datetime.fromtimestamp(int(parsed), tz=UTC)
                    expiration = int(expires_at.timestamp())
                    if expiration <= 0 or expires_at.microsecond:
                        raise ValueError("expiration_invalid")
                except (OverflowError, OSError, ValueError):
                    expiration = None
                    expiration_error = "passive_expiration_invalid"
                else:
                    if expires_at <= self._now() + timedelta(seconds=SDK_MIN_EXPIRATION_SECONDS):
                        expiration = None
                        expiration_error = "passive_expiration_too_soon"
            else:
                expiration = None
                expiration_error = "passive_expiration_invalid"
        elif session.get("review_at") is not None:
            try:
                expiration = expiration_for_review(
                    _timestamp(session["review_at"], name="review_at"),
                    now=self._now(),
                )
            except ValueError:
                expiration = None
                expiration_error = "passive_expiration_too_soon"
        elif old_passive_record:
            expiration = None
            expiration_error = "passive_expiration_invalid"
        else:
            # First managed exit for a BUY-only imported group keeps the
            # existing GTC policy.
            expiration = None
        if expiration_error is not None:
            self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch={
                    "reconciliation": expiration_error,
                    "resume_state": "passive_exit",
                },
            )
            return
        # Keep the old identity and expiry until a new accepted receipt replaces
        # them. A rejected/stale claim must not turn the next retry into GTC.
        session_id = str(session["session_id"])
        attempt_key = self._action_key(
            session_id, "passive-submit", uuid.uuid4().hex
        )
        intent_payload: dict[str, object] = {
            "role": "passive_exit",
            "side": "SELL",
            "token_id": session["token_id"],
            "price": price,
            "quantity": quantity,
            "expiration": expiration,
            "order_type": "GTD" if expiration is not None else "GTC",
        }
        expected_generation = (
            int(trade_generation)
            if trade_generation is not None
            else snapshot.get("_lp_trade_generation")
        )
        expected_revision = (
            int(expected_trade_revision)
            if expected_trade_revision is not None
            else trade_revision
        )
        if expected_generation is not None and not isinstance(expected_revision, int):
            self._publish_account_round_rejected(session_id)
            return
        claimed = self._claim_trade_action(
            session,
            attempt_key,
            intent_payload,
            {
                "passive_exit_attempt_key": attempt_key,
                "passive_exit_attempt_state": "pending",
                "passive_exit_retryable": False,
                "opening_loss": self._opening_loss_from_session(session),
                **self._scoring_reset_patch(),
            },
            trade_generation=int(expected_generation or 0),
            expected_trade_revision=expected_revision,
            claim_state="passive_exit",
        )
        if claimed is None:
            return
        session = claimed
        try:
            signed = self._create_limit(
                token_id=str(session["token_id"]),
                price=price,
                quantity=quantity,
                side="SELL",
                post_only=True,
                expiration=expiration,
            )
            response = self._post_limit(signed)
        except Exception as exc:
            self.store.lp_upsert_action(
                session_id,
                attempt_key,
                state="unknown",
                payload={"role": "passive_exit", "side": "SELL", "error": type(exc).__name__},
            )
            self.store.lp_update_session(
                session_id,
                state="needs_attention",
                patch={
                    "reconciliation": f"passive_submit_{type(exc).__name__}",
                    "resume_state": "passive_exit",
                    "passive_exit_attempt_state": "unknown",
                    "passive_exit_retryable": False,
                    **self._scoring_reset_patch(),
                },
            )
            return
        accepted, order_id = self._order_response(response)
        if not accepted:
            self.store.lp_upsert_action(
                session_id,
                attempt_key,
                state="rejected",
                payload={
                    "role": "passive_exit",
                    "side": "SELL",
                    "order_id": order_id,
                    "reason": "explicit_zero_fill_rejection",
                },
            )
            self.store.lp_update_session(
                session_id,
                state="passive_exit",
                patch={
                    "reconciliation": "passive_rejected",
                    "passive_exit_attempt_state": "rejected",
                    "passive_exit_retryable": True,
                    **self._scoring_reset_patch(),
                },
            )
            return
        if not order_id:
            self.store.lp_upsert_action(
                session_id,
                attempt_key,
                state="accepted",
                payload={"role": "passive_exit", "side": "SELL", "order_id": ""},
            )
            self.store.lp_update_session(
                session_id,
                state="needs_attention",
                patch={
                    "reconciliation": "passive_order_id_unknown",
                    "resume_state": "passive_exit",
                    "passive_exit_attempt_state": "accepted_without_order_id",
                    "passive_exit_retryable": False,
                    **self._scoring_reset_patch(),
                },
            )
            return
        self.store.lp_upsert_action(
            session_id,
            attempt_key,
            state="accepted",
            payload={
                "role": "passive_exit",
                "side": "SELL",
                "order_id": order_id,
                "price": price,
                "quantity": quantity,
                "expiration": expiration,
                "order_type": "GTD" if expiration is not None else "GTC",
            },
        )
        registered_session, _receipt_changed = self._register_direct_receipt(
            session,
            order_id=order_id,
            response=response,
            side="SELL",
            price=price,
            quantity=quantity,
            expiration=expiration,
            order_type="GTD" if expiration is not None else "GTC",
        )
        if str(registered_session.get("session_id") or "") != session_id:
            return
        session = registered_session
        self.store.lp_update_session(
            session_id,
            state="passive_exit",
            patch={
                "passive_exit_order_id": order_id,
                "passive_exit_price": price,
                "passive_cancel_requested": False,
                "passive_exit_attempt_key": attempt_key,
                "passive_exit_attempt_state": "accepted",
                "passive_exit_retryable": False,
                **self._scoring_reset_patch(order_id, "passive_exit"),
            },
        )

    def _external_asks(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> list[tuple[Decimal, Decimal]]:
        book = snapshot.get("book")
        if not isinstance(book, Mapping):
            raise ValueError("book_unknown")
        levels = self._levels(book.get("asks"), "asks")
        aggregate: dict[Decimal, Decimal] = {}
        for price, size in levels:
            aggregate[price] = aggregate.get(price, Decimal("0")) + size
        history = self._order_history(session)
        own_sizes: dict[Decimal, Decimal] = {}
        current_passive_id = str(session.get("passive_exit_order_id") or "")
        for order_id in self._session_order_ids(session):
            record = history.get(order_id, {})
            side = str(record.get("side") or "").upper()
            if side != "SELL" or str(record.get("status") or "").upper() in TERMINAL_ORDER_STATES:
                continue
            order = next(
                (candidate for candidate in _items(snapshot.get("orders")) if self._order_id(candidate) == order_id),
                None,
            )
            price = _maybe_decimal(_field(order, "price", record.get("price")))
            if price is None and order_id == current_passive_id:
                price = _maybe_decimal(session.get("passive_exit_price"))
            if price is None:
                continue
            remaining = _maybe_decimal(
                _field(
                    order,
                    "remaining_size",
                    _field(order, "size", _field(order, "quantity", None)),
                )
            )
            if remaining is None:
                original = _maybe_decimal(_field(order, "original_size", record.get("quantity")))
                matched = _maybe_decimal(_field(order, "size_matched", Decimal("0")))
                if original is not None and matched is not None:
                    remaining = max(Decimal("0"), original - matched)
            if remaining is None and order_id == current_passive_id:
                remaining = _maybe_decimal(session.get("residual_quantity"))
            if remaining is not None and remaining > 0:
                own_sizes[price] = own_sizes.get(price, Decimal("0")) + remaining
        result: list[tuple[Decimal, Decimal]] = []
        for price, size in sorted(aggregate.items()):
            external_size = size - own_sizes.get(price, Decimal("0"))
            if external_size > 0:
                result.append((price, external_size))
        return result

    def _reconcile_protected_exit(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> dict[str, object]:
        order_id = str(session.get("protected_exit_order_id") or "")
        if not order_id:
            return session
        for order in _items(snapshot.get("orders")):
            current_id = str(_field(order, "order_id", _field(order, "id", "")))
            if current_id != order_id:
                continue
            status = str(_field(order, "status", "")).upper()
            if status not in TERMINAL_ORDER_STATES:
                return session
            session_id = str(session["session_id"])
            if status in {"REJECTED", "FAILED", "CANCELED", "CANCELLED", "EXPIRED"}:
                return self.store.lp_update_session(
                    session_id,
                    patch={
                        "protected_exit_order_id": None,
                        "protected_exit_attempt_state": "rejected",
                        "protected_exit_retryable": True,
                    },
                )
            prior_sold = _maybe_decimal(
                session.get("protected_exit_submit_sold_quantity")
            )
            prior_residual = _maybe_decimal(
                session.get("protected_exit_submit_residual_quantity")
            )
            residual = _maybe_decimal(session.get("residual_quantity"))
            submit_quantity = _maybe_decimal(
                session.get("protected_exit_submit_quantity")
            )
            current_fill = Decimal("0")
            try:
                current_fill, _ = self._trade_totals(
                    snapshot,
                    order_id,
                    "SELL",
                    token_id=str(session.get("token_id") or ""),
                )
            except ValueError:
                current_fill = Decimal("0")
            reconciled = (
                session.get("position_reconciled") is True
                and prior_residual is not None
                and residual is not None
                and submit_quantity is not None
                and current_fill >= submit_quantity
                and residual <= prior_residual - current_fill
            )
            if not reconciled:
                # A terminal venue status alone is not a fill receipt. Keep the
                # active ID until this order's own fills and the actual position
                # facts reconcile.
                return self.store.lp_update_session(
                    session_id,
                    patch={"protected_exit_attempt_state": "terminal"},
                )
            return self.store.lp_update_session(
                session_id,
                patch={
                    "protected_exit_order_id": None,
                    "protected_exit_attempt_state": "terminal",
                    "protected_exit_retryable": False,
                    "protected_exit_submit_quantity": None,
                    "protected_exit_submit_sold_quantity": None,
                    "protected_exit_submit_residual_quantity": None,
                },
            )
        return session

    def _submit_protected_exit(
        self,
        session: Mapping[str, object],
        quantity: Decimal,
        snapshot: Mapping[str, object] | None = None,
        *,
        trade_revision: int | None = None,
        trade_generation: int | None = None,
        expected_trade_revision: int | None = None,
        claim_patch: Mapping[str, object] | None = None,
        claim_state: str | None = None,
    ) -> None:
        method = getattr(self.exchange, "submit_protected_sell", None)
        if quantity <= 0 or session.get("protected_exit_order_id"):
            return
        if self._has_unresolved_submission(session):
            return
        available = _maybe_decimal(session.get("residual_quantity"))
        if session.get("position_reconciled") is not True or available is None or quantity > available:
            self.store.lp_update_session(
                str(session["session_id"]),
                patch={
                    "exit_error": "quantity_reconciliation_unknown",
                    "protected_exit_retryable": False,
                },
            )
            return
        history = self._order_history(session)
        protected_id = str(session.get("protected_exit_order_id") or "")
        if any(
            order_id != protected_id
            and str(record.get("side") or "").upper() == "SELL"
            and not self._order_terminal(snapshot, order_id, session)
            for order_id, record in history.items()
        ):
            return
        attempt_state = str(session.get("protected_exit_attempt_state") or "")
        if attempt_state in {"pending", "unknown", "accepted_without_order_id"}:
            return
        if attempt_state == "rejected" and session.get("protected_exit_retryable") is not True:
            return
        if not callable(method):
            method = getattr(self.exchange, "submit_fok_sell", None)
        if not callable(method):
            self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch={"exit_error": "protected_exit_adapter_unavailable"},
            )
            return
        if not self._mutation_allowed("submit"):
            self.store.lp_update_session(
                str(session["session_id"]),
                state="needs_attention",
                patch={
                    "exit_error": "mutation_blocked",
                    "resume_state": "stop_loss_exit",
                    "protected_exit_attempt_state": "unknown",
                },
            )
            return
        min_price = Decimal("0")
        submit_quantity = quantity
        if snapshot is not None:
            book = snapshot.get("book")
            if not isinstance(book, Mapping):
                self.store.lp_update_session(
                    str(session["session_id"]),
                    patch={"exit_error": "book_unknown", "protected_exit_retryable": False},
                )
                return
            book_received_at = book.get("received_at")
            if book_received_at is None:
                self.store.lp_update_session(
                    str(session["session_id"]),
                    patch={"exit_error": "book_freshness_unknown", "protected_exit_retryable": False},
                )
                return
            try:
                _freshness(book_received_at, self._now(), "book_freshness")
            except ValueError as exc:
                self.store.lp_update_session(
                    str(session["session_id"]),
                    patch={"exit_error": str(exc), "protected_exit_retryable": False},
                )
                return
            bids = self._levels(book.get("bids"), "bids")
            if not bids:
                self.store.lp_update_session(
                    str(session["session_id"]),
                    patch={"exit_error": "bid_unknown", "protected_exit_retryable": False},
                )
                return
            # A protected FOK must be bounded by the fresh executable depth.
            # Use the lowest price included in the quantity as the floor so a
            # multi-level fill remains protected, and never submit an
            # unbounded or zero-price order when the book is incomplete.
            remaining = quantity
            used_levels: list[tuple[Decimal, Decimal]] = []
            for price, size in sorted(bids, reverse=True):
                used = min(size, remaining)
                if used <= 0:
                    continue
                used_levels.append((price, used))
                remaining -= used
                if remaining <= 0:
                    break
            if not used_levels:
                self.store.lp_update_session(
                    str(session["session_id"]),
                    patch={"exit_error": "bid_unknown", "protected_exit_retryable": False},
                )
                return
            submit_quantity = sum(size for _, size in used_levels)
            minimum = _maybe_decimal(
                _field(session.get("preflight"), "minimum_order_size")
            )
            if minimum is not None and submit_quantity < minimum:
                self.store.lp_update_session(
                    str(session["session_id"]),
                    patch={
                        "exit_error": "exit_depth_below_minimum",
                        "protected_exit_retryable": False,
                    },
                )
                return
            min_price = used_levels[-1][0]
        if min_price <= 0 or submit_quantity <= 0:
            self.store.lp_update_session(
                str(session["session_id"]),
                patch={"exit_error": "bid_unknown", "protected_exit_retryable": False},
            )
            return
        session_id = str(session["session_id"])
        attempt_key = self._action_key(
            session_id, "protected-submit", uuid.uuid4().hex
        )
        prior_sold = _maybe_decimal(session.get("sold_quantity"))
        prior_residual = _maybe_decimal(session.get("residual_quantity"))
        intent_payload: dict[str, object] = {
            "role": "protected_exit",
            "side": "SELL",
            "token_id": session["token_id"],
            "quantity": submit_quantity,
            "min_price": min_price,
        }
        expected_generation = (
            int(trade_generation)
            if trade_generation is not None
            else snapshot.get("_lp_trade_generation")
            if isinstance(snapshot, Mapping)
            else None
        )
        expected_revision = (
            int(expected_trade_revision)
            if expected_trade_revision is not None
            else trade_revision
        )
        if expected_generation is not None and not isinstance(expected_revision, int):
            self._publish_account_round_rejected(session_id)
            return
        patch = {
            "protected_exit_attempt_key": attempt_key,
            "protected_exit_attempt_state": "pending",
            "protected_exit_retryable": False,
            "protected_exit_submit_quantity": submit_quantity,
            "protected_exit_submit_sold_quantity": prior_sold,
            "protected_exit_submit_residual_quantity": prior_residual,
            **self._scoring_reset_patch(),
            **(dict(claim_patch) if claim_patch is not None else {}),
        }
        claimed = self._claim_trade_action(
            session,
            attempt_key,
            intent_payload,
            patch,
            trade_generation=int(expected_generation or 0),
            expected_trade_revision=expected_revision,
            claim_state=claim_state,
        )
        if claimed is None:
            return
        session = claimed
        try:
            response = method(
                token_id=str(session["token_id"]),
                quantity=submit_quantity,
                min_price=min_price,
            )
        except Exception as exc:
            self.store.lp_upsert_action(
                session_id,
                attempt_key,
                state="unknown",
                payload={"role": "protected_exit", "side": "SELL", "error": type(exc).__name__},
            )
            self.store.lp_update_session(
                session_id,
                patch={
                    "protected_exit_attempt_state": "unknown",
                    "protected_exit_retryable": False,
                    "exit_error": type(exc).__name__,
                    **self._scoring_reset_patch(),
                },
            )
            return
        accepted, order_id = self._order_response(response)
        if not accepted:
            self.store.lp_upsert_action(
                session_id,
                attempt_key,
                state="rejected",
                payload={
                    "role": "protected_exit",
                    "side": "SELL",
                    "order_id": order_id,
                    "reason": "explicit_zero_fill_rejection",
                },
            )
            self.store.lp_update_session(
                session_id,
                patch={
                    "exit_error": "protected_exit_rejected",
                    "protected_exit_attempt_state": "rejected",
                    "protected_exit_retryable": True,
                    **self._scoring_reset_patch(),
                },
            )
            return
        if not order_id:
            self.store.lp_upsert_action(
                session_id,
                attempt_key,
                state="accepted",
                payload={"role": "protected_exit", "side": "SELL", "order_id": ""},
            )
            self.store.lp_update_session(
                session_id,
                patch={
                    "protected_exit_attempt_state": "accepted_without_order_id",
                    "protected_exit_retryable": False,
                    "exit_error": "order_id_unknown",
                    **self._scoring_reset_patch(),
                },
            )
            return
        self.store.lp_upsert_action(
            session_id,
            attempt_key,
            state="accepted",
            payload={
                "role": "protected_exit",
                "side": "SELL",
                "order_id": order_id,
                "quantity": submit_quantity,
                "min_price": min_price,
            },
        )
        registered_session, _receipt_changed = self._register_direct_receipt(
            session,
            order_id=order_id,
            response=response,
            side="SELL",
            price=min_price,
            quantity=submit_quantity,
            order_type="FOK",
        )
        if str(registered_session.get("session_id") or "") != session_id:
            return
        session = registered_session
        self.store.lp_update_session(
            session_id,
            patch={
                "protected_exit_order_id": order_id,
                "protected_exit_attempt_key": attempt_key,
                "protected_exit_attempt_state": "accepted",
                "protected_exit_retryable": False,
                "protected_exit_submit_quantity": submit_quantity,
                "protected_exit_submit_sold_quantity": prior_sold,
                "protected_exit_submit_residual_quantity": prior_residual,
                **self._scoring_reset_patch(order_id, "protected_exit"),
            },
        )

    def _review_iteration(
        self,
        session: Mapping[str, object],
        snapshot: Mapping[str, object],
        *,
        trade_revision: int | None = None,
    ) -> dict[str, object]:
        if (
            session.get("stop_requested") is True
            or session.get("review_status") == "awaiting_reconciliation"
        ):
            try:
                self._cancel_owned_orders(
                    session,
                    snapshot=snapshot,
                    expected_generation=snapshot.get("_lp_trade_generation"),
                    expected_trade_revision=trade_revision,
                )
            except Exception as exc:
                updated = self.store.lp_update_session(
                    str(session["session_id"]),
                    state="needs_attention",
                    patch={
                        "reconciliation": f"review_cancel_{type(exc).__name__}",
                        "resume_state": "review",
                    },
                )
                return self._status_payload(updated)
            session = self.store.lp_session(str(session["session_id"])) or session
        updated = self.store.lp_update_session(
            str(session["session_id"]),
            patch={"review_status": "awaiting_reconciliation"},
        )
        loss = self._opening_loss_from_session(updated)
        updated = self.store.lp_update_session(
            str(session["session_id"]), patch={"opening_loss": loss}
        )
        latched = bool(updated.get("stop_loss_latched"))
        if loss is None and not latched:
            return self._complete_if_flat(updated, snapshot)
        if (loss is not None and loss >= STOP_LOSS) or latched:
            updated = self.store.lp_update_session(
                str(session["session_id"]),
                state="stop_loss_exit",
                patch=self._stop_loss_latch_patch(updated, loss),
            )
            updated = self._request_passive_cancel(
                updated,
                expected_generation=snapshot.get("_lp_trade_generation"),
                expected_trade_revision=trade_revision,
            )
            if self._owned_sells_terminal(updated, snapshot):
                self._submit_protected_exit(
                    updated,
                    _decimal(updated.get("residual_quantity", 0), "residual_quantity"),
                    snapshot,
                    trade_revision=trade_revision,
                )
            updated = self.store.lp_session(str(session["session_id"])) or updated
        return self._complete_if_flat(updated, snapshot)

    def _completion_patch(self, session):
        if self._has_unresolved_submission(session):
            return None
        residual = _decimal(session.get("residual_quantity", 0), "residual_quantity")
        bought = _decimal(session.get("buy_filled_quantity", 0), "buy_filled_quantity")
        sold = _decimal(session.get("sold_quantity", 0), "sold_quantity")
        if (
            residual == 0
            and bought == sold
            and bool(session.get("position_reconciled"))
            and bool(session.get("orders_terminal"))
            and session.get("fee_status") == "known"
        ):
            sold_revenue = _maybe_decimal(session.get("sold_revenue"))
            buy_cost = _maybe_decimal(session.get("buy_cost"))
            fees = _maybe_decimal(session.get("fees"))
            pnl = (
                sold_revenue - buy_cost - fees
                if sold_revenue is not None and buy_cost is not None and fees is not None
                else None
            )
            return {"trade_pnl": pnl, "total_pnl": None}
        return None

    def _complete_if_flat(
        self, session: Mapping[str, object], snapshot: Mapping[str, object]
    ) -> dict[str, object]:
        patch = self._completion_patch(session)
        if patch is not None:
            session = self.store.lp_update_session(str(session['session_id']), state='complete', patch=patch)
        return self._status_payload(session)

    def _status_payload(self, session: Mapping[str, object]) -> dict[str, object]:
        result = dict(session)
        result.setdefault("session_id", session.get("session_id"))
        # Issue 158: informational-only default quantity for the augment
        # "加 5%" option (the entry candidate row's estimated target).  It is
        # never validated and never used for order sizing — every augment
        # quantity goes through augment_preview/augment validation.
        result["estimated_target_quantity"] = _maybe_decimal(
            result.get("estimated_target_quantity")
        )
        result["reward_observation"] = self._reward_status_payload(session)
        # Issue 167: expose the normalized per-bucket view (v2 + the
        # single-bucket projection for one-level groups) so every read
        # path — status, tick aggregation, dashboard — speaks one shape.
        protection = result.get("queue_protection")
        if isinstance(protection, Mapping) and protection:
            result["queue_protection"] = queue_protection_status_view(protection)
        for key in (
            "price",
            "quantity",
            "buy_filled_quantity",
            "buy_cost",
            "sold_quantity",
            "sold_revenue",
            "residual_quantity",
            "residual_exit_value",
            "fees",
            "opening_loss",
            "stop_loss_triggered_loss",
            "paid_rewards",
            "trade_pnl",
            "total_pnl",
        ):
            value = result.get(key)
            if isinstance(value, str):
                parsed = _maybe_decimal(value)
                if parsed is not None:
                    result[key] = parsed
        return result

    def _reward_status_payload(self, session: Mapping[str, object]) -> dict[str, object]:
        raw = session.get("reward_observation")
        if isinstance(raw, Mapping):
            observation = dict(raw)
        else:
            observation = {
                "status": "unknown",
                "threshold_status": "unknown",
                "reward_date": self._session_reward_date(session),
                "condition_id": _text(session.get("condition_id")),
                "source": "platform_earnings",
                "currency": "USD",
                "paid": False,
            }
        for key in ("market_amount", "account_amount", "gap"):
            value = observation.get(key)
            if isinstance(value, str):
                parsed = _maybe_decimal(value)
                if parsed is not None:
                    observation[key] = parsed
        status = str(observation.get("status") or "unknown").lower()
        checked_at = observation.get("last_success_at", observation.get("checked_at"))
        if status in {"below", "met"} and checked_at is not None:
            try:
                age = (self._now() - _timestamp(checked_at, name="reward_checked_at")).total_seconds()
            except ValueError:
                age = float("inf")
            if age < 0 or age > float(REWARD_STALE_SECONDS):
                observation["status"] = "unknown"
                observation["threshold_status"] = "unknown"
                observation["stale"] = True
        return observation


__all__ = [
    "GTD_REVIEW_BUFFER_SECONDS",
    "PolymarketLPService",
    "SCORING_FAILURE_WINDOW_SECONDS",
    "SCORING_STALE_SECONDS",
    "SDK_MIN_EXPIRATION_SECONDS",
    "STOP_LOSS",
    "expiration_for_review",
]
